module.exports.config = {
  name: "restartCheck",
  eventType: ["log:subscribe"], // سيتم فحصه عند بدء التشغيل
  version: "1.0.0",
  credits: "عبدو"
};

module.exports.run = async ({ api }) => {
  const fs = require("fs-extra");
  const path = __dirname + "/../commands/cache/restart.json";

  if (fs.existsSync(path)) {
    const data = JSON.parse(fs.readFileSync(path));
    const timeTaken = ((Date.now() - data.startTime) / 1000).toFixed(2);

    const msg = `
┏━━━━━━━━━━━━━━━━━━┓
   ✨ تـم الـتـشـغـيـل بـنـجـاح ✨
┗━━━━━━━━━━━━━━━━━━┛

✅ | الـحـالـة: الـنـظـام يـعـمـل الآن.
⏳ | الـوقـت الـمـسـتـغـرق: [ ${timeTaken} ] ثـانـيـة.
👑 | الـمـطـور: عـبـدو.

━━━━━━━━━━━━━━━
ريـو بـوت جـاهـز لـتـلـقـي الأوامـر! 🛡️
`;
    
    api.sendMessage(msg, data.threadID);
    fs.unlinkSync(path); // حذف الملف لكي لا تتكرر الرسالة
  }
};
