module.exports.config = {
    name: "antijoin",
    eventType: ["log:subscribe"],
    version: "1.0.3",
    credits: "tdunguwu",
    description: "منع دخول الأعضاء الجدد عند تفعيل خاصية الحماية"
};

module.exports.run = async function({ api, event, Users }) {
    const { threadID } = event;
    const fs = require("fs-extra");
    const path = require("path");
    
    // مسار ملف البيانات
    const pathData = path.resolve(__dirname, '../commands', 'cache', 'antijoin.json');
    
    // تأكد من وجود المجلد والملف باش ما يوقعش خطأ
    if (!fs.existsSync(pathData)) return;

    const dataJson = JSON.parse(fs.readFileSync(pathData, "utf-8"));
    
    if (dataJson.antijoin && dataJson.antijoin.hasOwnProperty(threadID) && dataJson.antijoin[threadID] == true) {
        const memJoin = event.logMessageData.addedParticipants.map(info => info.userFbId);
        
        for (let idUser of memJoin) {
            // تصحيح: جعل الدالة async لكي تعمل await بشكل صحيح
            setTimeout(async () => {
                try {
                    await api.removeUserFromGroup(idUser, threadID);
                } catch (e) {
                    console.log("Error removing user:", e);
                }
            }, 1000);
        }
        return api.sendMessage(`⚠️ [ نظام الحماية ]\nتم تفعيل طرد الأعضاء الجدد تلقائياً!`, threadID);
    }
};
