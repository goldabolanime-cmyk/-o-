module.exports.config = {
    name: "ممنوع_الخروج",
    eventType: ["log:unsubscribe"],
    version: "1.0.0",
    credits: "عبدو / RIO BOOT",
    description: "إعادة إضافة الأعضاء الذين يغادرون المجموعة تلقائياً"
};

module.exports.run = async({ event, api, Threads, Users }) => {
    let data = (await Threads.getData(event.threadID)).data || {};
    
    // التحقق مما إذا كانت ميزة منع الخروج مفعلة في هذه المجموعة
    if (!data.antiout) return;

    // إذا كان البوت هو من غادر، لا يفعل شيئاً
    if (event.logMessageData.leftParticipantFbId == api.getCurrentUserID()) return;

    // جلب اسم الشخص الذي غادر
    const name = global.data.userName.get(event.logMessageData.leftParticipantFbId) || await Users.getNameUser(event.logMessageData.leftParticipantFbId);
    
    // تحديد ما إذا كان الشخص خرج بنفسه أم تم طرده
    const type = (event.author == event.logMessageData.leftParticipantFbId) ? "خروج_اختياري" : "طرد_إداري";

    // إذا خرج الشخص بنفسه، يقوم البوت بإعادته
    if (type == "خروج_اختياري") {
        api.addUserToGroup(event.logMessageData.leftParticipantFbId, event.threadID, (error, info) => {
            if (error) {
                api.sendMessage(`⚠️ ┃ عـذراً يـا عـبـدو، لـم أسـتـطـع إعادة [ ${name} ] بـسبب إعدادات الخصوصية لديه.`, event.threadID);
            } else {
                api.sendMessage(`🛡️ ┃ مـمـنوع الـخـروج مـن هـنـا! \n━━━━━━━━━━━━━━━\n✨ ┃ تـمـت إعـادة الـعـضـو: [ ${name} ] بـنـجـاح.`, event.threadID);
            }
        });
    }
}
