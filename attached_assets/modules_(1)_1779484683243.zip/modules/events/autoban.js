module.exports.config = {
  name: "autoban",
  eventType: ["message"],
  version: "1.0.0",
  credits: "RIO BOOT",
  description: "تجاهل المحظورين تلقائياً"
};

module.exports.run = async ({ event }) => {
  if (global.data && global.data.userBanned && global.data.threadBanned) {
    if (global.data.userBanned.has(event.senderID) || global.data.threadBanned.has(event.threadID)) {
      if (event.stopImmediatePropagation) {
        event.stopImmediatePropagation();
      }
      return;
    }
  }
};
