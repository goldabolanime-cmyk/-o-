module.exports.config = {
  name: "badwordsMonitor",
  eventType: ["message"],
  version: "1.0.0",
  credits: "RIO BOOT",
  description: "مراقبة الدردشة وطرد المشاتمين"
};

module.exports.run = async ({ api, event }) => {
  const { threadID, senderID, body } = event;
  const fs = require("fs-extra");
  const path = __dirname + `/../commands/cache/badwords_${threadID}.json`;

  if (!body || senderID === api.getCurrentUserID()) return;

  if (fs.existsSync(path)) {
    const words = fs.readJsonSync(path);
    const messageContent = body.toLowerCase();

    if (words.some(word => messageContent.includes(word))) {
      // إرسال إنذار أخير قبل الطرد
      api.sendMessage(`
┏━━━━━━━━━━━━━━━━━━┓
   🚫 تـنـفـيـذ الـعـقـوبـة 🚫
┗━━━━━━━━━━━━━━━━━━┛

⚠️ | الـعـضـو: @${senderID}
🚫 | الـسـبـب: اسـتـخدام كـلمات نـابـية.
⚖️ | الإجـراء: الـطـرد الـفـوري.

تـم تـطهـير الـمجموعة مـن الـمـخالـفين! 🛡️
`, threadID, () => {
        api.removeUserFromGroup(senderID, threadID, (err) => {
          if (err) api.sendMessage("❌ | فشل الطرد! تأكد أن البوت مسؤول في المجموعة.", threadID);
        });
      });
    }
  }
};
