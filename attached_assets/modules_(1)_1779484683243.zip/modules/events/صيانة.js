module.exports.config = {
  name: "checkMaintenance",
  eventType: ["message"], // يفضل حصره في الرسائل لتجنب الثقل
  version: "2.1.0",
  credits: "عبدو / RIO BOT",
  description: "منع المستخدمين مع نظام عد تنازلي ملكي"
};

module.exports.run = async ({ api, event }) => {
  const fs = require("fs-extra");
  const path = __dirname + "/../commands/cache/maintenance.json";
  const myID = "100090081489341"; // الأيدي الخاص بك

  if (fs.existsSync(path)) {
    let data = JSON.parse(fs.readFileSync(path));

    // 1. فحص إذا كان الوقت التلقائي قد انتهى لإلغاء الصيانة فوراً
    if (data.status && data.endTime !== 0 && Date.now() > data.endTime) {
      data.status = false;
      data.endTime = 0;
      fs.writeFileSync(path, JSON.stringify(data));
      return api.sendMessage("✨ ┃ انـتـهـت فـتـرة الـصـيـانـة الـتـلقـائـيـة..\n🔓 ┃ الـبـوت مـتـاح لـلـجـمـيـع الآن! اسـتـمـتـعـوا.", event.threadID);
    }

    // 2. إذا كان البوت في صيانة والمستخدم ليس أنت
    if (data.status && event.senderID !== myID && event.senderID !== api.getCurrentUserID()) {
      
      // لا يرد إلا إذا كانت الرسالة تبدأ بنقطة (أمر)
      if (event.body && event.body.startsWith(".")) {
        
        let timeLeftMsg = "حـتـى إشـعـارٍ آخـر";
        
        // حساب الوقت المتبقي إذا كان هناك مؤقت
        if (data.endTime !== 0) {
          const diff = data.endTime - Date.now();
          const minutes = Math.floor(diff / 60000);
          const seconds = Math.floor((diff % 60000) / 1000);
          timeLeftMsg = `مُـتـبـقِّـي: ${minutes} دقـيـقـة و ${seconds} ثـانـيـة`;
        }

        const msg = `━━━━━━━━━━━━━━━\n🛠️ ┃ وُضِــعَ الـصِّـيَـانَـةِ الـمَـلَـكِي\n━━━━━━━━━━━━━━━\n\n🚫 ┃ عـذراً، الـبـوت خـارج الـخـدمـة حـالـيـاً.\n⚙️ ┃ يـقـوم الـمُـطَـوِّرُ عـبـدو بـتـحـسـيـن الـنِّـظـام.\n\n⏳ ┃ ${timeLeftMsg}\n👑 ┃ شُـكـراً لـتـفـهـمـكـم وصـبـركـم.\n\n━━━━━━━━━━━━━━━`;
        
        return api.sendMessage(msg, event.threadID, event.messageID);
      }
    }
  }
};
