module.exports.config = {
    name: "اللقب_التلقائي",
    eventType: ["log:subscribe"],
    version: "1.0.4",
    credits: "عبدو / RIO BOOT",
    description: "تعيين لقب تلقائي للأعضاء الجدد عند دخولهم"
};

module.exports.run = async function({ Threads, api, event, Users }) {
    const fs = require("fs-extra");
    const { join } = require("path");
    const moment = require("moment-timezone");
    const { threadID } = event;

    // إعداد الوقت والتاريخ بتوقيت أفريقيا/الدار البيضاء (يمكنك تغييره حسب بلدك)
    var gio = moment.tz("Africa/Casablanca").format("HH:mm:ss || DD/MM/YYYY");
    var thu = moment.tz('Africa/Casablanca').format('dddd');
    
    // تعريب أيام الأسبوع
    const days = {
        'Sunday': 'الأحد',
        'Monday': 'الإثنين',
        'Tuesday': 'الثلاثاء',
        'Wednesday': 'الأربعاء',
        'Thursday': 'الخميس',
        'Friday': 'الجمعة',
        'Saturday': 'السبت'
    };
    thu = days[thu] || thu;

    // مسار ملف البيانات
    const pathData = join(__dirname, "..", "commands", "cache", "data", "autosetname.json");
    
    // التأكد من وجود المجلدات والملفات لعدم حدوث خطأ
    if (!fs.existsSync(pathData)) return;

    var dataJson = JSON.parse(fs.readFileSync(pathData, "utf-8"));
    var thisThread = dataJson.find(item => item.threadID == threadID) || { threadID, nameUser: [] };

    // إذا لم يكن هناك لقب مخصص لهذه المجموعة، يتوقف الكود
    if (!thisThread || thisThread.nameUser.length == 0) return;

    var memJoin = event.logMessageData.addedParticipants.map(info => info.userFbId);
    
    for (let idUser of memJoin) {
        var setName = thisThread.nameUser[0]; 
        
        // انتظار ثانية لتجنب حظر الفيسبوك
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        try {
            var userInfo = await api.getUserInfo(idUser);
            var namee = userInfo[idUser].name;
            
            // تغيير اللقب بالصيغة: [اللقب المخصص] [اسم العضو]
            await api.changeNickname(`${setName} ${namee}`, threadID, idUser);
        } catch (e) {
            console.log("خطأ في تغيير اللقب: " + e);
        }
    }

    // رسالة النجاح بالعربية
    return api.sendMessage({
        body: `=== 『 نـجـاح الـضـبـط 』 ===\n▱▱▱▱▱▱▱▱▱▱▱▱▱\n← تـم تـعـيـيـن الـلـقـب الـتـلـقـائـي لـلأعـضـاء الـجـدد بـنـجـاح ✅\n▱▱▱▱▱▱▱▱▱▱▱▱▱\n=== 「${thu} || ${gio}」 ===`
    }, threadID, event.messageID);
}
