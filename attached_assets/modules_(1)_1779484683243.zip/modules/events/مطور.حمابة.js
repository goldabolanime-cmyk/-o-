module.exports.config = {
  name: "developerRadar",
  eventType: ["log:subscribe", "log:unsubscribe", "message"],
  version: "1.0.0",
  credits: "RIO BOOT",
  description: "إشعار المطور عند ذكره في المجموعات"
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID, senderID, body, type } = event;
  const devID = "100090081489341"; // آيدي المطور عبدو

  // التحقق من وجود نص الرسالة وأنها ليست من المطور نفسه
  if (!body || senderID == devID) return;

  // الكلمة المفتاحية للرادار
  const keyword = "عبدو";

  if (body.includes(keyword)) {
    try {
      // جلب معلومات الشخص والمجموعة
      const threadInfo = await api.getThreadInfo(threadID);
      const userInfo = await api.getUserInfo(senderID);
      
      const groupName = threadInfo.threadName || "مجموعة غير مسمى";
      const userName = userInfo[senderID].name;

      // زخرفة التقرير الملكي المرسل للمطور
      const reportMsg = `┏━━━━━━━ 👑 ━━━━━━━┓\n   تَـمَّ ذِكْـرُ الـمُـطَـوِّرِ عـبـدو   \n┗━━━━━━━ 👑 ━━━━━━━┛\n\n` +
        `👤 ┇ الـشـخـص: ${userName}\n` +
        `🆔 ┇ آيـدي الـمـنـشـن: ${senderID}\n` +
        `━━━━━━━━━━━━━━━\n` +
        `🏢 ┇ الـمـجـمـوعـة: ${groupName}\n` +
        `🔹 ┇ آيـدي الـجـروب: ${threadID}\n` +
        `━━━━━━━━━━━━━━━\n` +
        `💬 ┇ الـمـحـتـوى: "${body}"\n` +
        `━━━━━━━━━━━━━━━\n` +
        `⏰ ┇ الـتـوقـيـت: ${new Date().toLocaleString('ar-EG')}\n` +
        `━━━━━━━━━━━━━━━\n` +
        `[•] رِيُـو بُـوت - نِـظَـامُ الـحِـمَـايَـة`;

      // إرسال التقرير إلى الخاص للمطور
      await api.sendMessage(reportMsg, devID);
      
      console.log(`[RADAR] تم إخطار المطور عبدو بذكر اسمه في: ${groupName}`);

    } catch (e) {
      console.log("[ERROR] حدث خطأ في نظام الرادار: " + e.message);
    }
  }
};
