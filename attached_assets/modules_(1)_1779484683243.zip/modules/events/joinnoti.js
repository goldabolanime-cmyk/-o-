const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "jonNoti",
  eventType: ["log:subscribe"],
  version: "2.1.0",
  credits: "عبدو / RIO BOOT",
  description: "ترحيـب رسمي مزخرف بدون إيموجيات",
  dependencies: {
    "fs-extra": "",
    "path": "",
    "moment-timezone": "",
    "axios": ""
  }
};

module.exports.run = async function({ api, event, Users }) {
  const { threadID } = event;
  const moment = require("moment-timezone");
  const time = moment.tz("Africa/Casablanca").format("HH:mm:ss DD/MM/YYYY");
  const hours = moment.tz("Africa/Casablanca").format("HH");

  if (event.logMessageData.addedParticipants.some(i => i.userFbId == api.getCurrentUserID())) {
    api.changeNickname(`[ ${global.config.PREFIX} ] • ${(!global.config.BOTNAME) ? "ريـو بـوت" : global.config.BOTNAME}`, threadID, api.getCurrentUserID());
    return api.sendMessage(`╔══════════════════════╗\n  تـم تـنـصـيـب الـنـظـام بـنـجـاح  \n╚══════════════════════╝\n▣ مـرحـبـاً بـكـم فـي ريـو بـوت\n▣ لـرؤيـة الأوامـر: [ ${global.config.PREFIX}اوامر ]\n▣ الـمـطـور الـمـسـؤول: عـبـدو\n══════════════════════`, threadID);
  } 
  
  else {
    try {
      const { threadName, participantIDs } = await api.getThreadInfo(threadID);
      const addedParticipants = event.logMessageData.addedParticipants;
      const authorID = event.author;
      
      let msg = "";
      let mentions = [];

      for (let newMem of addedParticipants) {
        const id = newMem.userFbId;
        const name = newMem.fullName;
        
        const userDate = await api.getUserInfo(id);
        const gender = userDate[id].gender == 2 ? "ذكـر" : userDate[id].gender == 1 ? "أنـثـى" : "غـيـر مـحدد";
        
        const authorData = await Users.getData(authorID);
        const authorName = authorData.name || "رابـط دعـوة";

        const memberCount = participantIDs.length;

        let session = "";
        if (hours >= 5 && hours < 12) session = "صـبـاح الـخـيـر";
        else if (hours >= 12 && hours < 18) session = "مـسـاء الـخـيـر";
        else session = "مـسـاء الـنـور";

        msg = `╔══════════════════════╗\n      ${session}      \n╚══════════════════════╝\n` +
              `▣ الـمـنـضـم: ${name}\n` +
              `▣ الـمـجـمـوعـة: ${threadName}\n` +
              `╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼\n` +
              `▣ الـمـعـرف: ${id}\n` +
              `▣ الـجـنـس: ${gender}\n` +
              `▣ الـتـرتـيـب: الـعـضـو رقـم [ ${memberCount} ]\n` +
              `▣ بـواسطة: ${authorName}\n` +
              `▣ الـرابـط: fb.com/${id}\n` +
              `╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼\n` +
              `▣ الـتـوقـيت: ${time}\n` +
              `╚═══════ RIO BOOT ═══════╝`;

        mentions.push({ tag: name, id: id });
      }

      const lastID = addedParticipants[addedParticipants.length - 1].userFbId;
      const avatarUrl = `https://graph.facebook.com/${lastID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
      
      const axios = require("axios");
      const pathImg = path.join(__dirname, "cache", `welcome_${lastID}.png`);
      const getImg = (await axios.get(avatarUrl, { responseType: "arraybuffer" })).data;
      fs.writeFileSync(pathImg, Buffer.from(getImg, "utf-8"));

      return api.sendMessage({
        body: msg,
        attachment: fs.createReadStream(pathImg),
        mentions
      }, threadID, () => {
        if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
      });

    } catch (e) {
      console.log(e);
    }
  }
};
