module.exports.config = {
  name: "autoAzkar",
  eventType: ["log:subscribe"],
  version: "1.0.5",
  credits: "عبدو / RIO BOOT",
  description: "نظام الأذكار التلقائي حسب أوقات اليوم"
};

module.exports.run = async ({ api }) => {
  const fs = require("fs-extra");
  const path = __dirname + "/cache/azkarStatus.json";
  
  // دالة لجلب الوقت الحالي بتوقيتك (مثلاً بتوقيت مصر/المغرب)
  // يمكنك تعديل الرقم 3 حسب فرق التوقيت في سيرفرك
  const getCurrentTime = () => {
    const now = new Date();
    const localTime = new Date(now.getTime() + (3 * 60 * 60 * 1000)); 
    return {
      hour: localTime.getHours(),
      minute: localTime.getMinutes(),
      date: localTime.toDateString()
    };
  };

  const azkarData = {
    "الشروق": { time: 6, msg: "☀️ | أذكـار الـشـروق:\n(أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ)" },
    "الصباح": { time: 8, msg: "✨ | أذكـار الـصـبـاح:\n(اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ)" },
    "الظهر": { time: 13, msg: "🕌 | أذكـار الـظـهـر:\n(سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ)" },
    "العصر": { time: 16, msg: "📿 | أذكـار الـعـصـر:\n(يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ أَصْلِحْ لِي شَأْنِي كُلَّهُ وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ)" },
    "المساء": { time: 18, msg: "🌙 | أذكـار الـمـسـاء:\n(أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ)" },
    "النوم": { time: 23, msg: "💤 | أذكـار الـنـوم:\n(بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا)" }
  };

  setInterval(async () => {
    const { hour, date } = getCurrentTime();
    if (!fs.existsSync(path)) fs.writeJsonSync(path, {});
    let status = fs.readJsonSync(path);

    for (const key in azkarData) {
      if (hour === azkarData[key].time && status[key] !== date) {
        const threads = await api.getThreadList(100, null, ["INBOX"]);
        threads.forEach(thread => {
          if (thread.isGroup) {
            api.sendMessage(`
┏━━━━━━━━━━━━━━━━━━┓
   --- 📿 ذِكْـرُ الـلّٰـه ---
┗━━━━━━━━━━━━━━━━━━┛

${azkarData[key].msg}

━━━━━━━━━━━━━━━
سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.. سُبْحَانَ اللَّهِ الْعَظِيمِ
━━━━━━━━━━━━━━━
`, thread.threadID);
          }
        });
        status[key] = date;
        fs.writeJsonSync(path, status);
      }
    }
  }, 60000); // يفحص كل دقيقة
};
