module.exports.config = {
  name: "angryKick",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "طرد العضو عند تفاعل المطور بإيموجي أغضبني 😡",
  commandCategory: "نظام",
  usages: "",
  cooldowns: 0
};

module.exports.handleReaction = async function ({ api, event, Users }) {
  const { userID, messageID, threadID, reaction } = event;

  // الآيدي الخاص بك (عبدو)
  const developerID = "100090081489341"; 

  // التحقق: هل المتفاعل هو المطور؟ وهل الإيموجي هو "أغضبني"؟
  if (userID === developerID && reaction === "😡") {
    try {
      // جلب تفاصيل الرسالة التي تم التفاعل عليها لمعرفة صاحبها
      api.getMessageInfo(messageID, threadID, async (err, info) => {
        if (err || !info) return;

        const victimID = info.senderID;

        // الحماية: لا يطرد نفسه، المطور، أو حساب البوت
        if (victimID === api.getCurrentUserID() || victimID === developerID) {
           return;
        }

        // جلب اسم الضحية
        const name = (await Users.getData(victimID)).name || "العضو";

        // تنفيذ عملية الطرد
        api.removeUserFromGroup(victimID, threadID, (err) => {
          if (err) {
            return api.sendMessage("⚠️ ┃ فشل الطرد! قد لا أمتلك صلاحيات مسؤول (Admin).", threadID);
          }

          const msg = `
━━━━━━━━━━━━━━━
  👑 ┃ رِيُـو بُـوتْ - نِـظَـامُ الـغَـضَـبِ
━━━━━━━━━━━━━━━
🚫 ❯ لَـقَدْ أَغْـضَـبْتَ الْـمُـطَـوِّرَ يَـا [ ${name} ].
⚖️ ❯ الْـقَـرَارُ: الـطَّـرْدُ الْـفَوْرِيُّ مِـنَ الْـمَـجْـمُـوعَـةِ.
━━━━━━━━━━━━━━━
⚠️ ❯ نَـصِيـحَة: لَا تُـحَـاوِلْ إِغْـضَـابَ الْأَسَـادِ مَـرَّةً أُخْـرَى.`.trim();

          api.sendMessage(msg, threadID);
        });
      });
    } catch (e) {
      console.log("Error in angryKick:", e);
    }
  }
};
