module.exports.config = {
    name: "حماية_الأدمن",
    eventType: ["log:thread-admins"],
    version: "1.0.0",
    credits: "عبدو / RIO BOOT",
    description: "مـنع التلاعب برتب الإدارة وحماية المجموعة من الانقلاب",
};

module.exports.run = async function ({ event, api, Threads, Users }) {
    const { logMessageType, logMessageData, senderID } = event;
 	let data = (await Threads.getData(event.threadID)).data
 	if (data.guard == false) return;
    if (data.guard == true ) {
        switch (logMessageType) {
          case "log:thread-admins": {
            if (logMessageData.ADMIN_EVENT == "add_admin") {
              if(event.author == api.getCurrentUserID()) return
              if(logMessageData.TARGET_ID == api.getCurrentUserID()) return
              else {
                api.changeAdminStatus(event.threadID, event.author, false, editAdminsCallback)
                api.changeAdminStatus(event.threadID, logMessageData.TARGET_ID, false)
                function editAdminsCallback(err) {
                  if (err) return api.sendMessage("⚠️ ┃ لـم أسـتـطـع تـنـفـيـذ الـحـمـايـة، تـأكـد أنـنـي مـسـؤول!", event.threadID, event.messageID);
                    return api.sendMessage(`🛡️ ┃ نـظـام الـحـمـايـة: تـم رصـد مـحـاولة تـعـيـيـن مـسـؤول جـديـد! \n❌ ┃ تـم سـحـب الإدارة مـن الـطـرفـيـن لـحـمـايـة الـمـجـمـوعـة.`, event.threadID, event.messageID);
                }
              }
            }
            else if (logMessageData.ADMIN_EVENT == "remove_admin") {
              if(event.author == api.getCurrentUserID()) return
              if(logMessageData.TARGET_ID == api.getCurrentUserID()) return
              else {
                api.changeAdminStatus(event.threadID, event.author, false, editAdminsCallback)
                api.changeAdminStatus(event.threadID, logMessageData.TARGET_ID, true)
                function editAdminsCallback(err) {
                if (err) return api.sendMessage("⚠️ ┃ لـم أسـتـطـع تـنـفـيـذ الـحـمـايـة، تـأكـد أنـنـي مـسـؤول!", event.threadID, event.messageID);
                return api.sendMessage(`🛡️ ┃ نـظـام الـحـمـايـة: تـم رصـد مـحـاولـة إزالـة مـسـؤول! \n✅ ┃ تـم إحباط الـمـحـاولـة وإعـادة الإدارة لـلـمـسـؤول الـمـسـتـهدف.`, event.threadID, event.messageID);
              }
            }
          }
        }
      }
    }
}
