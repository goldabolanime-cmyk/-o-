module.exports.config = {
  name: "حماية_تلقائية",
  eventType: ["log:subscribe"],
  version: "1.0.0",
  credits: "عبدو / RIO BOT",
  description: "تشغيل وإيقاف حماية البروفايل عبر الرسائل مباشرة"
};

module.exports.handleEvent = async function({ api, event }) {
  const { threadID, messageID, body, senderID } = event;
  const adminID = "100090081489341"; // الأيدي الخاص بك يا عبدو

  // التحقق من أن المرسل هو المطور عبدو فقط
  if (senderID !== adminID || !body) return;

  const input = body.toLowerCase();

  // --- 1. حالة التشغيل ---
  if (input === "تشغيل حماية بروفايل") {
    return api.setProfileGuard(true, (err) => {
      if (err) {
        return api.sendMessage(`⚠️ ┃ فَـشَلَ تَـفْعِيلُ اَلْـحِمَايَةِ: ${err.errorDescription || "خـطأ فـي الـنظام"}`, threadID, messageID);
      }
      return api.sendMessage("🛡️ ┃ تَـمَّ تَـفْعِيلُ دِرْعِ حِـمَايَةِ صُـورَةِ اَلـبْرُوفَـايلِ بِنَـجَاحٍ.", threadID, messageID);
    });
  }

  // --- 2. حالة الإيقاف ---
  if (input === "ايقاف حماية بروفايل") {
    return api.setProfileGuard(false, (err) => {
      if (err) {
        return api.sendMessage(`⚠️ ┃ فَـشَلَ إِيـقَافُ اَلْـحِمَايَةِ: ${err.errorDescription || "خـطأ فـي الـنظام"}`, threadID, messageID);
      }
      return api.sendMessage("🔓 ┃ تَـمَّ إِيـقَافُ دِرْعِ حِـمَايَةِ صُـورَةِ اَلـبْرُوفَـايلِ.", threadID, messageID);
    });
  }
};
