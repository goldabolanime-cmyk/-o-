module.exports.config = {
  name: "antiunsend",
  eventType: ["message_unsend"],
  version: "2.5.0",
  credits: "عبدو / RIO BOT",
  description: "نِـظَـامُ فَـضْـحِ اَلْـمَـرَاسِـيـلِ اَلْـمَـحْـذُوفَـةِ اَلْـمَـلَـكِيّ"
};

module.exports.handleEvent = async function ({ api, event, Users }) {
  const { threadID, messageID, senderID, type } = event;

  // إعداد المخزن المؤقت في Global (باش ما يتمسحش مع كل ريفريش)
  if (!global.rio_msg_storage) {
    global.rio_msg_storage = new Map();
  }

  // 1. فاش كيوصل أي ميساج، كنخبيوه في الميموري
  if (event.type === "message" || event.type === "message_reply") {
    global.rio_msg_storage.set(messageID, {
      body: event.body,
      senderID: senderID,
      attachments: event.attachments
    });

    // تنظيف المخزن كل ساعة باش ما يعمرش ليك الرام في Replit
    if (global.rio_msg_storage.size > 500) {
      const firstKey = global.rio_msg_storage.keys().next().value;
      global.rio_msg_storage.delete(firstKey);
    }
  }

  // 2. فاش شي حد كيمسح الميساج (Unsend)
  if (event.type === "message_unsend") {
    const data = global.rio_msg_storage.get(messageID);
    
    if (!data) return; // الميساج قديم بزاف أو البوت يلاه ديمارا

    const name = await Users.getNameUser(data.senderID);
    
    let msg = `┏━━━━━━━━━━━━━━━━━┓\n   🚫 𝑹𝑰𝑶 𝑨𝑵𝑻𝑰-𝑼𝑵𝑺𝑬𝑵𝑫 🚫\n┗━━━━━━━━━━━━━━━━━┛\n\n👤 ┃ اَلْـفَـاعِـلُ: ${name}\n`;

    if (data.body) {
      msg += `💬 ┃ اَلْـمُـحْـتَـوَى: ${data.body}\n`;
    }

    if (data.attachments && data.attachments.length > 0) {
      msg += `📁 ┃ اَلْـمُـرْفَقَـاتُ: [ ${data.attachments.length} مِلَفّ ]\n`;
    }

    msg += `\n━━━━━━━━━━━━━━━\n🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;

    return api.sendMessage(msg, threadID);
  }
};
