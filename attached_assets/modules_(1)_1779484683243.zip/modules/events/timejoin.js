module.exports.config = {
    name: "تنظيف_بيانات",
    eventType: ["log:unsubscribe"],
    version: "1.0.0",
    credits: "Nam",
    description: "حذف بيانات وقت انضمام المستخدم تلقائياً عند خروجه"
};

const fs = require("fs");
// المسار الخاص بتخزين سجلات أوقات الانضمام
var path = __dirname + "/../commands/cache/timeJoin.json";

module.exports.run = async function ({ event: e }) {
    const {
        threadID: t,
        logMessageData: l
    } = e, {
        writeFileSync: w,
        readFileSync: r
    } = fs, {
        stringify: s,
        parse: p
    } = JSON;

    // جلب آيدي الشخص الذي غادر
    var v = l.leftParticipantFbId;

    try {
        // قراءة ملف البيانات وتحويله لكائن برمجي
        let a = p(r(path));

        // مسح السجل الخاص بهذا المستخدم في هذه المجموعة
        delete a[v + t]; 

        // حفظ التغييرات في الملف مرة أخرى
        w(path, s(a, null, 2));
    } catch (err) {
        // في حال عدم وجود الملف أو حدوث خطأ لا يتوقف البوت
        console.log("⚠️ سجل وقت الانضمام غير موجود أو حدث خطأ أثناء التنظيف.");
    }
}
