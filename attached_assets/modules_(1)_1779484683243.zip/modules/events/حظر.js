module.exports.config = {
  name: "checkBanned",
  eventType: ["log:subscribe", "log:unsubscribe", "message"],
  version: "1.0.0",
  credits: "RIO BOOT",
  description: "فحص الحظر وتجاهل الرسائل تلقائياً"
};

module.exports.run = async ({ api, event, Threads, Users }) => {
  const { threadID, senderID, type } = event;

  // 1. فحص حظر المجموعة
  if (global.data.threadBanned.has(threadID)) {
    // إذا كانت المجموعة محظورة، نتجاهل كل شيء
    return; 
  }

  // 2. فحص حظر المستخدم
  if (global.data.userBanned.has(senderID)) {
    // إذا كان المستخدم محظوراً، نتجاهل رسالته
    return;
  }

  // إذا لم يكن هناك حظر، البوت سيكمل عمله الطبيعي
};
