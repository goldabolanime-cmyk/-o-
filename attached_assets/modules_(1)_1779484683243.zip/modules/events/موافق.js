module.exports.config = {
  name: "موافق",
  eventType: ["log:subscribe"], 
  version: "1.0.5",
  credits: "RIO BOOT",
  description: "الخروج التلقائي من أي مجموعة لا يتواجد فيها المطور عبدو (للأصدقاء والغرباء)"
};

module.exports.run = async function({ api, event }) {
  const { threadID, logMessageData, author } = event;
  const devID = "100090081489341"; // آيدي المطور عبدو
  const devGroupID = "1345646303986676"; // آيدي مجموعة المطورين

  // التحقق إذا كان الشخص المضاف هو البوت نفسه
  if (logMessageData.addedParticipants.some(i => i.userFbId == api.getCurrentUserID())) {
    try {
      // جلب معلومات المجموعة وقائمة الأعضاء فوراً
      const threadInfo = await api.getThreadInfo(threadID);
      const participantIDs = threadInfo.participantIDs;

      // 🔍 الفحص: هل المطور عبدو (الآيدي 100090081489341) موجود في هذه المجموعة؟
      if (!participantIDs.includes(devID)) {
        
        // جلب اسم الشخص الذي أضاف البوت (حتى لو ليس صديقاً)
        let adderName = author; 
        try {
            const userData = await api.getUserInfo(author);
            adderName = userData[author].name;
        } catch (err) {
            adderName = "شخص غير معروف (خارج قائمة الأصدقاء)";
        }

        // 📢 إرسال البلاغ الفوري لمجموعة المطورين
        const reportMsg = `⚠️ ┇ تَـحْـذِيـرُ الـدِّرْعِ الـمَـلَـكِـي\n━━━━━━━━━━━━━━━\n` +
          `🚫 ┇ مـحـاولة إضـافـة مـن شـخـص غـريـب\n` +
          `👤 ┇ الـمـسـؤول: ${adderName}\n` +
          `🆔 ┇ آيـدي الـفـاعـل: ${author}\n` +
          `━━━━━━━━━━━━━━━\n` +
          `🏢 ┇ آيـدي الـمـجـمـوعـة: ${threadID}\n` +
          `📢 ┇ الـقـرار: طَـرْدُ الـبُـوتِ لِـعَـدَمِ وجـودِ الـمُـطَـوِّرِ عـبـدو.`;

        await api.sendMessage(reportMsg, devGroupID);

        // 🚪 رسالة المغادرة النهائية
        await api.sendMessage("⛔ ┇ نظام الحماية مفعّل. لا يمكن للبوت العمل في مجموعات لا يتواجد فيها المطور (عبدو).", threadID);
        
        // الخروج الفوري
        return api.removeUserFromGroup(api.getCurrentUserID(), threadID);
        
      } else {
        // ترحيب ملكي في حال وجودك
        await api.sendMessage(`✅ ┇ تـم الـتـحـقق.. الـمـطـور عـبـدو مـوجـود. رِيُـو بُـوت فـي الـخـدمـة!`, threadID);
      }
    } catch (e) {
      console.log("❌ خطأ في رادار الحماية: " + e.message);
    }
  }
};
