module.exports.config = {
  name: "اقفال",
  eventType: ["log:unsubscribe"],
  version: "1.0.1",
  credits: "RIO BOOT",
};

module.exports.handleEvent = async function({ api, event, Threads, Users }) {
  const { threadID, author, logMessageData } = event;
  let data = (await Threads.getData(threadID)).data || {};

  // التحقق مما إذا كانت الحماية مفعلة وأن الشخص خرج بنفسه
  if (data.antiOut !== true || author !== logMessageData.leftParticipantFbId) return;

  const uid = logMessageData.leftParticipantFbId;
  const res = await Users.getInfo(uid);
  const name = res.name;

  const funnyMessages = [
    `⚖️ ❯ هَـلْ نَـسِـيـتَ يَـا [ ${name} ] الِاسْـتِـئْـذَانَ؟ عُـدْ لِـمَـكَانِـكَ!`,
    `💰 ❯ الـدُّخُـولُ مَـجَّـانِي.. الـخُـرُوجُ بِـالْـفُـلُـوسِ! عُدْ هُنَا.`,
    `🏃‍♂️ ❯ حَـاوَلَ [ ${name} ] الـهُـرُوبَ وَلَـكِـنَّـهُ فَـشِـلَ!`
  ];
  
  const msg = funnyMessages[Math.floor(Math.random() * funnyMessages.length)];

  // محاولة الإعادة الفورية
  api.addUserToGroup(uid, threadID, (err) => {
    if (err) return; // إذا فشل لا يرسل رسالة لكي لا يتكرر الخطأ
    
    api.sendMessage(`━━━━━━━━━━━━━━━\n  👑 ┃ رِيُـو بُـوتْ - الـسِّـجْـنِ\n━━━━━━━━━━━━━━━\n${msg}\n━━━━━━━━━━━━━━━`, threadID);
  });
};
