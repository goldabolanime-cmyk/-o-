module.exports.config = {
  name: "إشعار_المغادرة",
  eventType: ["log:unsubscribe"],
  version: "1.0.0",
  credits: "عبدو / RIO BOOT",
  description: "إرسال رسالة وداع مزخرفة مع وسائط عند خروج عضو",
  dependencies: {
    "fs-extra": "",
    "path": ""
  }
};

const checkttPath = __dirname + '/../commands/tuongtac/checktt/';

module.exports.onLoad = function () {
    const { existsSync, mkdirSync } = global.nodemodule["fs-extra"];
    const { join } = global.nodemodule["path"];

    const path = join(__dirname, "cache", "leaveGif", "randomgif");
    if (!existsSync(path)) mkdirSync(path, { recursive: true });

    return;
}

module.exports.run = async function ({ api, event, Users, Threads }) {
    if (event.logMessageData.leftParticipantFbId == api.getCurrentUserID()) return;
    const { createReadStream, existsSync, readdirSync } = global.nodemodule["fs-extra"];
    const { join } = global.nodemodule["path"];
    const { threadID } = event;
    const moment = require("moment-timezone");
    
    // تعديل التوقيت للمغرب/الجزائر (Africa/Casablanca)
    const time = moment.tz("Africa/Casablanca").format("DD/MM/YYYY || HH:mm:ss");
    
    const name = global.data.userName.get(event.logMessageData.leftParticipantFbId) || await Users.getNameUser(event.logMessageData.leftParticipantFbId);
    const type = (event.author == event.logMessageData.leftParticipantFbId) ? "خـرج بـنـفـسـه 🏃" : "طُـرد مـن الإدارة 🚷";
    
    const pathGif = join(__dirname, "cache", "leaveGif", "randomgif");
    var msg = `✨ ┃ وداعـــاً يـا [ ${name} ]\n━━━━━━━━━━━━━━━\n📝 ┃ حـالـة الـخـروج: ${type}\n⏰ ┃ الـوقـت: ${time}\n━━━━━━━━━━━━━━━\n🍀 ┃ نـتـمـنـى لـك وقـتـاً طـيـبـاً خـارج الـمـجـمـوعة!`;

    if (existsSync(pathGif)) {
        const remoteGif = readdirSync(pathGif);
        if (remoteGif.length > 0) {
            var randomPath = join(pathGif, remoteGif[Math.floor(Math.random() * remoteGif.length)]);
            return api.sendMessage({ body: msg, attachment: createReadStream(randomPath) }, threadID);
        }
    }
    
    return api.sendMessage(msg, threadID);
}
