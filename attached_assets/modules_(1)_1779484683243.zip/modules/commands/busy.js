const fs = require("fs-extra");
const busyPath = __dirname + '/cache/busy.json';

module.exports.config = {
  name: "مشغول",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "تفعيل وضع الانشغال الملكي - لا يتوقف إلا عند الرسالة الثانية",
  commandCategory: "خدمات",
  usages: "[السبب]",
  cooldowns: 5
};

module.exports.onLoad = () => {
  if (!fs.existsSync(busyPath)) fs.writeFileSync(busyPath, JSON.stringify({}));
};

module.exports.handleEvent = async function({ api, event, Users }) {
    if (!fs.existsSync(busyPath)) return;
    let busyData = JSON.parse(fs.readFileSync(busyPath));
    var { senderID, threadID, messageID, mentions, body } = event;

    // [1] نظام العودة الذكي (الإيقاف عند الرسالة الثانية)
    if (senderID in busyData) {
        // إذا كانت هذه أول رسالة يرسلها المستخدم بعد تفعيل الوضع
        if (!busyData[senderID].firstMessageSent) {
            busyData[senderID].firstMessageSent = true;
            fs.writeFileSync(busyPath, JSON.stringify(busyData, null, 4));
            return; // نخرج من الدالة دون إيقاف الوضع
        }

        // إذا وصل هنا، فهذه هي الرسالة الثانية
        var info = busyData[senderID];
        delete busyData[senderID];
        fs.writeFileSync(busyPath, JSON.stringify(busyData, null, 4));
        
        const nameUser = (await Users.getData(senderID)).name;
        let msgReturn = `✨ ┃ أَهْـلاً بِـعَوْدَتِـكَ مَـلِـكَـنَا: ${nameUser} ┃ ✨\n━━━━━━━━━━━━━━━\n👑 ┃ لَقَدْ تَمَّ رَصْدُ رِسَالَتِكَ الثَّانِيَةِ، تَمَّ إِيـقَافُ وَضْـعِ الانْـشِغَالِ بِنَجَاح.`;

        return api.sendMessage(msgReturn, threadID, () => {
            if (info.tag.length == 0) {
                api.sendMessage("✨ ┃ لَـمْ يَـجْرُؤْ أَحَـدٌ عَـلَى إِزْعَاجِـكَ فِي غِـيَابِكَ.", threadID);
            } else {
                var listTag = "";
                for (var i of info.tag) { listTag += `• ${i}\n`; }
                api.sendMessage("👑 ┃ إِلَيْـكَ قَـائِمَةُ الَّـذِينَ سَـأَلُوا عَنْـكَ مُؤَخَّراً:\n━━━━━━━━━━━━━━━\n" + listTag, threadID);
            }
        }, messageID);
    }

    // [2] الرد على المنشن أثناء الانشغال
    if (!mentions || Object.keys(mentions).length == 0) return;

    for (const [ID, name] of Object.entries(mentions)) {
        if (ID in busyData) {
            var infoBusy = busyData[ID];
            var mentioner = (await Users.getData(senderID)).name;
            var cleanBody = body ? body.replace(name, "").trim() : "أرسل تاك فقط";
            
            infoBusy.tag.push(`${mentioner}: ${cleanBody == "" ? "أرسل تاك فقط" : cleanBody}`);
            busyData[ID] = infoBusy;
            fs.writeFileSync(busyPath, JSON.stringify(busyData, null, 4));
            
            return api.sendMessage(`⚠️ ┃ عَـذْراً يَا ${mentioner}..\n👑 ┃ الـمَطُـورُ ${name.replace("@", "")} مَشْـغُولٌ حَالِـياً.\n━━━━━━━━━━━━━━━\n📝 ┃ الـسَّـبَبُ: ${infoBusy.lido || "غـير مـحدد"}`, threadID, messageID);
        }
    }
};

module.exports.run = async function({ api, event, args }) {
    let busyData = JSON.parse(fs.readFileSync(busyPath));
    const { threadID, senderID, messageID } = event;
    var content = args.join(" ") || "لا يوجد سبب محدد";

    if (!(senderID in busyData)) {
        busyData[senderID] = {
            lido: content,
            tag: [],
            firstMessageSent: false // خاصية جديدة لتتبع الرسالة الأولى
        };
        fs.writeFileSync(busyPath, JSON.stringify(busyData, null, 4));
        
        return api.sendMessage(`👑 ┃ تَـمَّ تَـفْعِـيلُ الـوَضْعِ الْـمَلَكِي لِـلانْشِغَالِ.\n━━━━━━━━━━━━━━━\n📝 ┃ الـسَّـبَبُ: ${content}\n\n✨ ┃ نِـظَامُ الـرَّادَارِ يَـعْمَلُ، لَـنْ يَتَـوَقَّفَ الْـوَضْعُ إِلا بَعْدَ رِسَـالَتِكَ الثَّانِيَةِ.`, threadID, messageID);
    }
};