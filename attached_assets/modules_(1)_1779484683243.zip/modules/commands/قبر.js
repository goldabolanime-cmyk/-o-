const { createCanvas, loadImage } = require("canvas");
const fs = require("fs-extra");
const axios = require("axios");
const jimp = require("jimp");
const path = require("path");

module.exports.config = {
  name: "قبر",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "تسوية الشخص في قبر",
  commandCategory: "ترفية",
  usages: "[@منشن أو رد]",
  cooldowns: 5
};

async function circle(imageUrl) {
  try {
    const img = await jimp.read(imageUrl);
    img.circle();
    return await img.getBufferAsync(jimp.MIME_PNG);
  } catch (e) {
    console.error("circle error:", e.message);
    throw e;
  }
}

module.exports.run = async ({ event, api, Users }) => {
  try {
    const { threadID, messageID, senderID, mentions, messageReply } = event;
    const cacheDir = path.join(__dirname, "cache");
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

    let targetID = senderID;
    if (Object.keys(mentions).length > 0) {
      targetID = Object.keys(mentions)[0];
    } else if (messageReply) {
      targetID = messageReply.senderID;
    }

    api.setMessageReaction("⚰️", messageID, () => {}, true);

    const gravePath = path.join(cacheDir, `grave_${senderID}_${targetID}_${Date.now()}.jpg`);
    const canvas = createCanvas(500, 670);
    const ctx = canvas.getContext("2d");

    try {
      const background = await loadImage("https://i.imgur.com/A4quyh3.jpg");
      const circledAvatar = await circle(`https://graph.facebook.com/${targetID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`);
      const avatarImg = await loadImage(circledAvatar);

      ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
      ctx.drawImage(avatarImg, 160, 70, 160, 160);

      const buffer = canvas.toBuffer();
      fs.writeFileSync(gravePath, buffer);

      const name = await Users.getNameUser(targetID);
      return api.sendMessage(
        { body: `رحم الله ${name} 😔\n\nاقرأ الفاتحة 🤲`, attachment: fs.createReadStream(gravePath) },
        threadID,
        () => {
          if (fs.existsSync(gravePath)) fs.unlinkSync(gravePath);
        },
        messageID
      );
    } catch (imgErr) {
      console.error("image processing error:", imgErr.message);
      return api.sendMessage("❌ حدث خطأ في معالجة الصورة.", threadID, messageID);
    }
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ حدث خطأ.", event.threadID, event.messageID);
  }
};