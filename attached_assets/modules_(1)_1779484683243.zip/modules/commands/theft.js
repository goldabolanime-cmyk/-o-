module.exports.config = {
  name: "سرقة",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو & Gemini",
  description: "محاولة سرقة مستخدم عشوائي مع نظام عقوبات",
  commandCategory: "الاقتصاد",
  usages: "",
  cooldowns: 200
};

module.exports.run = async function({ api, event, Users, Currencies }) {
    const { threadID, messageID, senderID } = event;
    const alluser = global.data.allUserID;
    const victim = alluser[Math.floor(Math.random() * alluser.length)];
    const nameVictim = (await Users.getData(victim)).name;
    const myName = (await Users.getData(senderID)).name;
    
    // إيدي المطور عبدو (تأكد من وضع الأيدي الخاص بك هنا)
    const adminID = global.config.ADMINBOT[0] || "100086395995513"; 

    // --- حماية المطور عبدو ---
    if (victim == adminID) {
        return api.sendMessage(`🔱 ┃ ريـو يـتـدخـل:\n━━━━━━━━━━━━━━━\nيَا لَجُرْأَتِكَ! تُحَاوِلُ سَرِقَةَ سَيِّدِكَ وَمُطَوِّرِ النِّظَامِ [ عـبـدو ]؟\nتَمَّ صَفْعُكَ وَطَرْدُ فِكْرَةِ السَّرِقَةِ مِنْ رَأْسِكَ الْفَارِغِ.`, threadID, messageID);
    }

    if (victim == api.getCurrentUserID() || victim == senderID) {
        return api.sendMessage('❌ ┃ لا يمكنك السرقة من نفسك أو من البوت، حاول مجدداً مع ضحية أخرى.', threadID, messageID);
    }

    const route = Math.floor(Math.random() * 2); // 0 للنجاح، 1 للفشل

    // --- حالة النجاح (السرقة) ---
    if (route == 0) {
        const moneydb = (await Currencies.getData(victim)).money;
        const stolenMoney = Math.floor(Math.random() * 200) + 50; // سرقة مبلغ عشوائي

        if (moneydb <= 0 || moneydb == undefined) {
            return api.sendMessage(`🕵️ ┃ عَمَلِيَّةُ نَشْلٍ:\n━━━━━━━━━━━━━━━\nلَقَدْ سَرَقْتَ [ ${nameVictim} ] وَلَكِنَّكَ وَجَدْتَ جُيُوبَهُ فَارِغَةً تَمَاماً.. يَا لَلسُّوءِ!`, threadID, messageID);
        } else {
            const finalStolen = (moneydb >= stolenMoney) ? stolenMoney : moneydb;
            await Currencies.increaseMoney(victim, parseInt("-" + finalStolen));
            await Currencies.increaseMoney(senderID, parseInt(finalStolen));
            
            return api.sendMessage(`💰 ┃ نَجَاحُ الْعَمَلِيَّةِ:\n━━━━━━━━━━━━━━━\nتَمَّتِ السَّرِقَةُ بِنَجَاحٍ!\n👤 ┃ الضَّحِيَّةُ: ${nameVictim}\n💸 ┃ الْمَبْلَغُ: [ ${finalStolen} $ ]`, threadID, messageID);
        }
    }
    
    // --- حالة الفشل (الغرامة) ---
    else if (route == 1) {
        const userMoney = (await Currencies.getData(senderID)).money;
        const fine = 60; // الغرامة المحددة

        if (userMoney < fine) {
            return api.sendMessage(`🚨 ┃ فَشَلُ الْعَمَلِيَّةِ:\n━━━━━━━━━━━━━━━\nتَمَّ الْقَبْضُ عَلَيْكَ مَلَبَّساً! وَلأَنَّكَ لا تَمْلِكُ [ ${fine}$ ] لِدَفْعِ الْغَرَامَةِ، تَمَّ تَوْبِيخُكَ وَتَرْكُكَ لِعَارِكَ.`, threadID, messageID);
        } else {
            await Currencies.increaseMoney(senderID, parseInt("-" + fine));
            await Currencies.increaseMoney(victim, parseInt(fine / 2)); // الضحية تأخذ تعويض بسيط

            return api.sendMessage(`👮 ┃ تَمَّ الْقَبْضُ عَلَيْكَ:\n━━━━━━━━━━━━━━━\nفَشِلَتِ السَّرِقَةُ وَأَمْسَكَ بِكَ [ ${nameVictim} ]!\n⚠️ ┃ الْغَرَامَةُ: [ ${fine}$ ] خُصِمَتْ مِنْ حِسَابِكَ.`, threadID, messageID);
        }
    }
};