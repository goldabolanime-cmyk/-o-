const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "فوطوز",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "جَـلْـبُ 10 صُـوَرٍ بـسُـرْعَـةٍ خَـارِقَـةٍ (نِـظَـامُ اَلـتَّـوَازِي)",
  commandCategory: "الوسائط",
  usages: "[كلمة البحث بالإنجليزية]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const query = args.join(" ");

  if (!query) return api.sendMessage("⚠️ ┃ سَـيِّـدِي عـبـدو، أَدْخِـلْ كَـلِـمَـةَ اَلْـبَحْـثِ!\n💡 مِـثَـال: .صور neon", threadID, messageID);

  api.sendMessage("🚀 ┃ جَـارِي جَـلْـبُ 10 صُـوَرٍ بـسُـرْعَـةٍ اَلـبَـرْقِ . . .", threadID, messageID);

  try {
    const cachePath = path.join(__dirname, "cache");
    if (!fs.existsSync(cachePath)) fs.mkdirSync(cachePath, { recursive: true });

    // مصفوفة لروابط الصور (استعمال محرك بحث سريع جداً)
    const imagesToDownload = [];
    for (let i = 0; i < 10; i++) {
      imagesToDownload.push({
        url: `https://loremflickr.com/800/800/${encodeURIComponent(query)}?lock=${i + Math.random()}`,
        path: path.join(cachePath, `rio_img_${i}_${senderID}.jpg`)
      });
    }

    // تحميل الصور بـالتوازي (Parallel Download) - هادي هي السرعة!
    await Promise.all(imagesToDownload.map(async (img) => {
      const res = await axios.get(img.url, { responseType: "arraybuffer", timeout: 10000 });
      return fs.writeFileSync(img.path, Buffer.from(res.data));
    }));

    const attachments = imagesToDownload.map(img => fs.createReadStream(img.path));

    const msg = {
      body: `┏━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑭𝑨𝑺𝑻 𝑰𝑴𝑨𝑮𝑬𝑺 ♛\n┗━━━━━━━━━━━━━━━━━┛\n\n✅ ┃ تَـمَّ جَـلْـبُ 10 صُـوَرٍ لِـ [ ${query} ]\n━━━━━━━━━━━━━━━\n🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`,
      attachment: attachments
    };

    return api.sendMessage(msg, threadID, () => {
      // مسح الكاش فوراً بعد الإرسال
      imagesToDownload.forEach(img => {
        if (fs.existsSync(img.path)) fs.unlinkSync(img.path);
      });
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ سَـيِّـدِي عـبـدو، اَلـسِّـيرفَـرْ مَـضْـغُوطْ حَـالِـيـاً، جَـرِّبْ مَـرَّةً أُخْـرَى.", threadID, messageID);
  }
};