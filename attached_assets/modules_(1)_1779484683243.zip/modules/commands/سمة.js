module.exports.config = {
  name: "سمة",
  version: "2.0.0",
  hasPermssion: 1,
  credits: "عبدو / RIO BOT",
  description: "تغيير ثيم المحادثة (يدعم ذكاء فيسبوك الاصطناعي)",
  commandCategory: "إدارة",
  usages: "[رقم السمة] أو [ذكاء + وصف]",
  cooldowns: 5
};

const themes = [
  { name: "الحب (Love)", id: 1316226442137356 },
  { name: "الفضاء (Space)", id: 418465622492167 },
  { name: "الموسيقى (Music)", id: 326792612015243 },
  { name: "السايبربانك (Cyberpunk)", id: 284759302526 },
  { name: "كرة القدم (Soccer)", id: 1121115124962649 },
  { name: "ألوان النيون (Neon)", id: 754350585237889 }
];

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const choice = parseInt(body);
  if (isNaN(choice) || choice < 1 || choice > themes.length) return;

  const selectedTheme = themes[choice - 1];

  // استخدام setThreadTheme وهي الأكثر استقراراً
  api.setThreadTheme(selectedTheme.id, threadID, (err) => {
    if (err) return api.sendMessage("❌ ┃ فشل تغيير السمة، قد لا يدعم حساب البوت هذه الميزة.", threadID, messageID);
    return api.sendMessage(`✅ ┃ تم تغيير السمة إلى: ${selectedTheme.name}`, threadID);
  });
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;

  // خيار تيم الذكاء الاصطناعي الخاص بفيسبوك
  if (args[0] === "ذكاء") {
    const prompt = args.slice(1).join(" ");
    if (!prompt) return api.sendMessage("⚠️ ┃ اكتب وصفاً! مثال: .سمة ذكاء كوكب المريخ", threadID, messageID);

    // في مكتبات fca الحديثة، تمرير نص بدلاً من رقم في setThreadTheme يفعل الذكاء الاصطناعي
    return api.setThreadTheme(prompt, threadID, (err) => {
      if (err) return api.sendMessage("❌ ┃ فشل إنشاء سمة الذكاء الاصطناعي.", threadID, messageID);
      api.sendMessage(`✨ ┃ تم تطبيق سمة الذكاء الاصطناعي: ${prompt}`, threadID);
    });
  }

  let msg = "🎨 ━━━『 سـمات رِيُـو 』━━━ 🎨\n\n";
  themes.forEach((t, i) => {
    msg += `【 ${i + 1} 】 ┃ ${t.name}\n`;
  });
  
  msg += "\n━━━━━━━━━━━━━━━\n";
  msg += "📥 ┃ رد برقم السمة.\n";
  msg += "💡 ┃ أو اكتب: .سمة ذكاء [وصف]";

  return api.sendMessage(msg, threadID, (err, info) => {
    if (err) return;
    global.client.handleReply.push({
      name: this.config.name,
      messageID: info.messageID,
      author: senderID
    });
  }, messageID);
};