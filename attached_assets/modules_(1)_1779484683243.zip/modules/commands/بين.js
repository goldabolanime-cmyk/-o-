const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "بين",
  version: "1.5.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "اَلْـبَحْـثُ عَـنْ صُـوَرٍ مِـنْ 𝑷𝑰𝑵𝑻𝑬𝑹𝑬𝑺𝑻",
  commandCategory: "صور",
  usages: "[الكلمة الدلالية]",
  cooldowns: 10
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const query = args.join(" ");

  if (!query) return api.sendMessage("⚠️ ┃ يُـرْجَى كِـتَابَةُ مَا تُرِيدُ اَلْـبَحْـثَ عَـنْـهُ يَا عـبـدو !", threadID, messageID);

  api.sendMessage(`🔍 ┃ جَـارِي جَـلْبُ أَجْـمَلِ اَلـصُّـوَرِ لِـ: 『 ${query} 』...`, threadID, messageID);

  try {
    // جلب البيانات من الـ API اللي عطاك صاحبك
    const res = await axios.get(`https://egret-driving-cattle.ngrok-free.app/api/pin?query=${encodeURIComponent(query)}&num=90`);
    const data = res.data.data; // تأكد من بنية الـ JSON من صاحب السكريبت

    if (!data || data.length === 0) return api.sendMessage("❌ ┃ لَـمْ أَجِـدْ أَيَّ صُـوَرٍ لِـهَذَا اَلْـبَحْـثِ.", threadID, messageID);

    // اختيار 9 صور عشوائية من أصل 90 اللي كيجيبهم الـ API
    const images = [];
    for (let i = 0; i < 9; i++) {
      const randomImg = data[Math.floor(Math.random() * data.length)];
      const path = __dirname + `/cache/pin_${i}.png`;
      const getImg = (await axios.get(randomImg, { responseType: 'arraybuffer' })).data;
      fs.writeFileSync(path, Buffer.from(getImg, "utf-8"));
      images.push(fs.createReadStream(path));
    }

    const msg = 
      `┏━━━━━━━━━━━━━━━━━━━━┓\n` +
      `   ♛ 𝑹𝑰𝑶 𝑷𝑰𝑵𝑻𝑬𝑹𝑬𝑺𝑻 ♛\n` +
      `┗━━━━━━━━━━━━━━━━━━━━┛\n\n` +
      `✨ ┃ نَـتَـائِـجُ اَلْـبَحْـثِ عَنْ: 『 ${query} 』\n` +
      `📸 ┃ عَـدَدُ اَلـصُّـوَرِ: 9 صُـوَرٍ مَـلَـكِـيَّـةٍ\n\n` +
      `🔱 ┃ بِـوَاسِـطَـةِ: عـبـدو`;

    return api.sendMessage({
      body: msg,
      attachment: images
    }, threadID, () => {
      // مسح الصور من الكاش بعد الإرسال
      for (let i = 0; i < 9; i++) {
        const path = __dirname + `/cache/pin_${i}.png`;
        if (fs.existsSync(path)) fs.unlinkSync(path);
      }
    }, messageID);

  } catch (err) {
    console.error(err);
    return api.sendMessage("❌ ┃ عـذراً يَا عـبـدو، اَلـسِّـيرْفَـرْ اَلْخَـاصُّ بِـالـصُّـوَرِ لاَ يَـسْتَـجِيـبُ حَـالِيّـاً.", threadID, messageID);
  }
};