const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const jimp = require("jimp");

module.exports.config = {
  name: "طلاق",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "ريو بوت",
  description: "إصدار وثيقة طلاق رسمية بالأسماء (رابط جديد) 💔",
  commandCategory: "ترفيه",
  usages: "[@منشن / رد على رسالة]",
  cooldowns: 8
};

async function makeDivorce(name1, name2, id1, id2) {
  const cacheDir = path.join(__dirname, "cache", "canvas");
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  const outputPath = path.join(cacheDir, `divorce_new_${id1}_${id2}.png`);
  
  // الرابط الجديد الذي أرسلته (أضفنا .jpg للرابط ليكون مباشراً)
  const paperUrl = "https://i.imgur.com/4TSQmlJ.jpg"; 

  try {
    const [image, font] = await Promise.all([
      jimp.read(paperUrl),
      jimp.loadFont(jimp.FONT_SANS_32_BLACK) // خط أسود واضح
    ]);

    // تغيير الحجم ليتناسب مع الكتابة
    image.resize(800, 1100); 

    // طباعة الأسماء على الوثيقة (تم تعديل الإحداثيات لتناسب مكان الفراغات)
    // الاسم الأول (المطلق)
    image.print(font, 200, 450, name1); 
    
    // الاسم الثاني (المطلقة)
    image.print(font, 200, 580, name2);

    // إضافة التاريخ أسفل الوثيقة
    const date = new Date().toLocaleDateString('ar-EG');
    image.print(font, 500, 920, date);

    const buffer = await image.getBufferAsync(jimp.MIME_PNG);
    fs.writeFileSync(outputPath, buffer);

    return outputPath;
  } catch (e) {
    console.error("خطأ في التحرير:", e.message);
    throw e;
  }
}

module.exports.run = async function ({ event, api }) {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  
  let targetID;
  if (type === "message_reply") {
    targetID = messageReply.senderID;
  } else if (Object.keys(mentions).length > 0) {
    targetID = Object.keys(mentions)[0];
  } else {
    return api.sendMessage("💔 | يـرجى مـنشنة الـطرف الآخـر أو الـرد عـلى رسـالته لـإصدار وثـيقة الـطلاق!", threadID, messageID);
  }

  try {
    api.sendMessage("📝 | جـارٍ سـحب الـوثيقة مـن الأرشـيف الـملكي وتـوثيق الـأسماء...", threadID, messageID);

    // جلب أسماء الحسابات
    const user1 = await api.getUserInfo(senderID);
    const user2 = await api.getUserInfo(targetID);
    
    const name1 = user1[senderID].name;
    const name2 = user2[targetID].name;

    const outputPath = await makeDivorce(name1, name2, senderID, targetID);
    
    let msg = `📜 تـم تـوثيق حـالة الـانفصال بـين:\n`;
    msg += `🤵 الـسيد: ${name1}\n`;
    msg += `👰 الـسيدة: ${name2}\n\n`;
    msg += `💔 وقـع الـطلاق بـالـثلاث في مـحكمة رِيـو الـكبرى!`;

    return api.sendMessage(
      { body: msg, attachment: fs.createReadStream(outputPath) },
      threadID,
      () => { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); },
      messageID
    );
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ | حـدث خـطأ أثـناء الـوصول لـلرابط الـجديد أو تـعديل الـصور.", threadID, messageID);
  }
};