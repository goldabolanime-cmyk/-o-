const config = {
    name: "رادار",
    description: "رادار ريو الملكي لتحليل الطقس وتقديم النصائح الجوية",
    usage: "[اسم المدينة]",
    cooldown: 5,
    permissions: [0, 1, 2],
    credits: "RIO BOOT"
}

const langData = {
    "ar_SY": {
        "missingInput": "⚠️ ┇ مولي، أين المدينة التي تريد مسحها بالرادار؟",
        "notFound": "❌ ┇ لم يستطع الرادار العثور على هذه المنطقة في خرائطنا.",
        "error": "🚫 ┇ حدث تشويش في الأقمار الصناعية، حاول لاحقاً.",
        "results": "┏━━━━━━━ 📡 ━━━━━━━┓\n   تَـقْـرِيـرُ الـرَّادَارِ الـمَـلَـكِيّ   \n┗━━━━━━━ 📡 ━━━━━━━┛\n\n[📍] الـمـكـان: {name}\n[🌡️] الـحـرارة: {temperature}°C\n[☁️] الـسـمـاء: {sky}\n[💧] الـرطـوبـة: {humidity}%\n[💨] الـريـاح: {wind}\n\n━━━━━━━━━━━━━━━━━━━\n[💡] تـوصِـيـةُ رِيُـو الـجـويَّة:\n» {advice} «\n━━━━━━━━━━━━━━━━━━━\n[•] رِيُـو بُـوت - سُـلـطَـةُ الـمَـعْـلُـومَـات"
    }
}

function getAdvice(temp, sky) {
    const status = sky ? sky.toLowerCase() : "";
    if (temp <= 15) return "الجو بارد مولي، ارتدِ ملابس ثقيلة واحذر من نزلات البرد.";
    if (temp >= 35) return "الحرارة مرتفعة جداً، لا تنسَ شرب الكثير من الماء وتجنب الشمس.";
    if (status.includes("rain") || status.includes("مطر")) return "السماء تمطر! لا تخرج بدون مظلتك الملكية.";
    if (status.includes("cloud") || status.includes("غائم")) return "الجو غائم ومثالي للنزهات الخفيفة، استمتع بوقتك.";
    return "الطقس مستقر ومثالي للقيام بمهامك العظيمة اليوم.";
}

async function onCall({ message, args, getLang }) {
    try {
        const input = args.join(" ");
        if (!input) return message.reply(getLang("missingInput"));

        const res = await global.GET(`${global.xva_api.popcat}/weather?q=${encodeURIComponent(input)}`);
        
        if (!res.data || res.data.length === 0) return message.reply(getLang("notFound"));

        const current = res.data[0].current;
        const location = res.data[0].location;

        const advice = getAdvice(parseInt(current.temperature), current.skytext);

        return message.reply(getLang("results", {
            name: location.name,
            temperature: current.temperature,
            sky: current.skytext,
            humidity: current.humidity,
            wind: current.windspeed,
            advice: advice
        }));

    } catch (e) {
        console.error(e);
        message.reply(getLang("error"));
    }
}

// تم الإصلاح هنا ليتوافق مع نظامك
module.exports = { config, langData, onCall };