const fs = require("fs-extra");

module.exports.config = {
  name: "تحديث",
  version: "2.0.0",
  hasPermssion: 2,
  credits: "عبدو / RIO BOT",
  description: "تحديث ملفات النظام (appstate.json)",
  commandCategory: "نظام المطور",
  usages: "تحديث",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, senderID } = event;
  const adminID = "100090081489341"; // الأيدي الخاص بك يا عبدو

  // --- 1. التحقق من صلاحية المطور ---
  if (senderID !== adminID) {
    return api.sendMessage("⚠️ ┃ هَـذَا اَلْأَمْـرُ مَـخْـصُوصٌ لِـلْـمُطَـوِّرِ عَـبْـدُو فَـقَـطْ!", threadID, messageID);
  }

  try {
    const path = `${__dirname}/../../appstate.json`;
    const appstate = api.getAppState();
    const data = JSON.stringify(appstate, null, 2);

    let successCount = 0;
    let failCount = 0;
    let report = "";

    // --- 2. محاولة تحديث الملف ---
    if (fs.existsSync(path)) {
      try {
        fs.writeFileSync(path, data, 'utf8');
        successCount = 1;
        report += "📂 ┃ [ appstate.json ] ← ✅ نَـجَـاح\n";
      } catch (err) {
        failCount = 1;
        report += `📂 ┃ [ appstate.json ] ← ❌ فَـشَل (${err.message})\n`;
      }
    } else {
      failCount = 1;
      report += "📂 ┃ [ appstate.json ] ← ❌ اَلْـمَـلَفُّ غَـيْرُ مَوْجُودٍ\n";
    }

    // --- 3. إرسال النتيجة بالزخرفة الملكية ---
    const msg = `⚙️ ┃ نِـظَـامُ اَلـتَّـحْـدِيثِ اَلْـمَـلَـكِيِّ\n━━━━━━━━━━━━━━━\n` +
                `${report}` +
                `━━━━━━━━━━━━━━━\n` +
                `✅ ┃ تَـمَّ تَـحْدِيثُ [ ${successCount} ] مَـلَفٍ.\n` +
                `❌ ┃ فَـشَلَ تَـحْدِيثُ [ ${failCount} ] مَـلَفٍ.\n` +
                `━━━━━━━━━━━━━━━\n` +
                `🔱 ┃ رِيُـو بُـوتْ - اَلْـجَـاهِـزِيَّـةُ اَلـتَّـامَّـةُ`;

    return api.sendMessage(msg, threadID, messageID);

  } catch (error) {
    return api.sendMessage(`❌ ┃ حَـدَثَ خَـطَأٌ تَـقْـنِيٌّ: ${error.message}`, threadID, messageID);
  }
};