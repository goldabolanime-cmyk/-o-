const { createCanvas, loadImage } = require("canvas");
const fs = require("fs-extra");
const axios = require("axios");
const path = require("path");

module.exports.config = {
  name: "سجن",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "حط الشخص خلف القضبان",
  commandCategory: "صور",
  usages: "[@منشن أو رد]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  try {
    const { senderID, threadID, messageID, mentions, messageReply } = event;
    const cacheDir = path.join(__dirname, "cache");
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

    let targetID = senderID;
    if (Object.keys(mentions).length > 0) {
      targetID = Object.keys(mentions)[0];
    } else if (messageReply) {
      targetID = messageReply.senderID;
    }

    api.setMessageReaction("🔒", messageID, () => {}, true);

    const outputPath = path.join(cacheDir, `prison_${senderID}_${targetID}_${Date.now()}.png`);

    try {
      const prisonImg = await loadImage("https://i.postimg.cc/1zmxGQTS/8uv38cfmc74ur1p5rtntitrddi.png");
      const userImg = await loadImage(`https://graph.facebook.com/${targetID}/picture?width=1500&height=1500&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`);

      const canvas = createCanvas(userImg.width, userImg.height);
      const ctx = canvas.getContext("2d");

      ctx.drawImage(userImg, 0, 0, canvas.width, canvas.height);
      ctx.drawImage(prisonImg, 0, 0, canvas.width, canvas.height);

      const buffer = canvas.toBuffer();
      fs.writeFileSync(outputPath, buffer);

      return api.sendMessage(
        { body: "🔒 تم السجن!", attachment: fs.createReadStream(outputPath) },
        threadID,
        () => {
          if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
        },
        messageID
      );
    } catch (imgErr) {
      console.error("image processing error:", imgErr.message);
      return api.sendMessage("❌ حدث خطأ في معالجة الصورة.", threadID, messageID);
    }
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ حدث خطأ.", event.threadID, event.messageID);
  }
};