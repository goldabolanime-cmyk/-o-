const axios = require("axios");

module.exports.config = {
    name: "كابوي",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "عمر / تعديل ريو",
    description: "لعبة راعي البقر (سحب البقرة)",
    commandCategory: "العاب",
    usages: "[المبلغ]",
    cooldowns: 5
};

module.exports.run = async ({ api, event, args, Currencies }) => {
    const { threadID, messageID, senderID } = event;
    const bet = parseInt(args[0]);

    if (!bet || isNaN(bet) || bet <= 0) return api.sendMessage('⚠️ | يـرجى مـراهـنة بـمبلغ صـحيح لـلبدء!', threadID, messageID);
    
    const userData = await Currencies.getData(senderID);
    if (userData.money < bet) return api.sendMessage(`💸 | رصـيدك لا يـكفي! تـحتاج ${bet}$ ولـديـك ${userData.money}$.`, threadID, messageID);

    await Currencies.decreaseMoney(senderID, bet);

    try {
        const gifUrl = "https://i.ibb.co/2dgF3vf/keobogif.gif";
        const msg = { 
            body: `🤠 | لـعبة الـكابـوي\n━━━━━━━━━━━━━━━\nاخـتر بـقرة لـسحبها:\n1. بـقرة [1] - ربـح x1\n2. بـقرة [2] - ربـح x2\n3. بـقرة [3] - ربـح x5\n4. بـقرة [4] - ربـح x10\n5. بـقرة [5] - ربـح x50\n━━━━━━━━━━━━━━━\n📩 | رد بـرقم الـبقرة لـبدء الـسحب!`,
            attachment: (await axios.get(gifUrl, { responseType: "stream" })).data
        };

        return api.sendMessage(msg, threadID, (err, info) => {
            global.client.handleReply.push({
                name: this.config.name,
                messageID: info.messageID,
                author: senderID,
                bet: bet
            });
        }, messageID);
    } catch (e) {
        return api.sendMessage("❌ | حـدث خـطأ فـي تـحميل اللـعبة.", threadID, messageID);
    }
};

module.exports.handleReply = async ({ api, Currencies, event, handleReply }) => {
    const { threadID, senderID, messageID, body } = event;
    if (handleReply.author !== senderID) return;

    const choice = parseInt(body);
    if (isNaN(choice) || choice < 1 || choice > 5) return api.sendMessage("❌ | اخـتر رقـم مـن 1 إلى 5 فـقط!", threadID, messageID);

    api.unsendMessage(handleReply.messageID);
    api.sendMessage(`⏳ | جـاري سـحب الـبـقرة [${choice}]...`, threadID);

    setTimeout(async () => {
        const win = Math.random() > (0.2 * choice); // صعوبة متزايدة
        const multipliers = [0, 1, 2, 5, 10, 50];
        const prize = handleReply.bet * multipliers[choice];

        if (win) {
            await Currencies.increaseMoney(senderID, prize);
            api.sendMessage(`🎉 | مـبـروك! نـجحت فـي سـحب الـبقرة وربـحت ${prize}$.`, threadID, messageID);
        } else {
            api.sendMessage(`💀 | لـلأسـف! هـربت الـبقرة وخـسرت مـبلغ الـرهان.`, threadID, messageID);
        }
    }, 3000);
};