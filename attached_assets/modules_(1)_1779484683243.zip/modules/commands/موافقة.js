const fs = require("fs-extra");
const path = __dirname + "/cache/approvedThreads.json";

module.exports.config = {
  name: "موافقة",
  version: "2.1.0",
  hasPermssion: 2,
  credits: "عبدو / RIO BOOT",
  description: "نظام التفعيل الملكي - تجاهل تام للمجموعات غير المصرحة",
  commandCategory: "نظام المطور",
  usages: "[تشغيل/ايقاف]",
  cooldowns: 5
};

if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify([]));

module.exports.handleEvent = async function({ api, event }) {
  const { threadID, logMessageType, logMessageData, author, body } = event;
  const devID = "100090081489341";
  const myID = api.getCurrentUserID();
  let data = JSON.parse(fs.readFileSync(path));

  // 1. مراقبة دخول البوت لمجموعة جديدة (الاستثناء الوحيد لإرسال رسالة)
  if (logMessageType === "log:subscribe" && logMessageData.addedParticipants.some(i => i.userFbId == myID)) {
    if (author == devID) {
      if (!data.includes(threadID)) {
        data.push(threadID);
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
      }
      return api.sendMessage("👑 ┃ أهـلاً يـا سـيـدي عـبـدو.. تـم تـفـعـيـل الـبـوت تـلـقـائـيـاً لأنـك مـن أضـفـتـه!", threadID);
    } else {
      return api.sendMessage(`⚠️ ┃ الـمـجـمـوعة غـيـر مـصـرحـة.\n📩 ┃ تـواصـل مـع الـمـطـور عـبـدو لـلـتـفـعـيـل.\n⌛ ┃ سـأغـادر خـلال 10 ثـوانٍ...`, threadID, () => {
        setTimeout(() => { api.removeUserFromGroup(myID, threadID); }, 10000);
      });
    }
  }

  // 2. نظام التجاهل التام (Silent Mode)
  // إذا كانت المجموعة غير مفعلة والمستخدم ليس المطور، يتم إيقاف تنفيذ أي شيء (تجاهل)
  if (!data.includes(threadID) && author !== devID) {
    return; // إنهاء الوظيفة هنا دون إرسال أي رد
  }
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const devID = "100090081489341";

  if (senderID !== devID) return; // تجاهل حتى رسالة الرفض لغير المطور

  let data = JSON.parse(fs.readFileSync(path));

  if (args[0] === "تشغيل") {
    if (data.includes(threadID)) return api.sendMessage("✅ ┃ الـمـجـموعة مـفـعـلة بـالـفـعل!", threadID, messageID);
    data.push(threadID);
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
    return api.sendMessage("👑 ┃ تـم تـصـريـح الـمـجـمـوعـة! الـبـوت الآن سـيـبـدأ بـالـاسـتـجـابـة.", threadID, messageID);
  }

  if (args[0] === "ايقاف") {
    if (!data.includes(threadID)) return api.sendMessage("❌ ┃ الـمـجـموعة غـير مـفـعـلة أصـلاً!", threadID, messageID);
    data = data.filter(id => id !== threadID);
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
    return api.sendMessage("🚫 ┃ تـم إلـغـاء تـصـريـح الـمـجـمـوعـة.. سـيـعـود الـبـوت لـوضـع الـتـجـاهـل.", threadID, messageID);
  }

  return api.sendMessage(`🛡️ ┃ نـظـام الـتـصاريـح الـمـلـكـي\n━━━━━━━━━━━━━━━\n💡 ┃ لـلـتـفـعـيـل: .موافقة تشغيل\n💡 ┃ لـلإلـغـاء: .موافقة ايقاف\n━━━━━━━━━━━━━━━\n👤 ┃ حـالـة الـمـجـمـوعـة: ${data.includes(threadID) ? "✅ مـوثـقة" : "❌ غـيـر مـوثـقة"}`, threadID, messageID);
};