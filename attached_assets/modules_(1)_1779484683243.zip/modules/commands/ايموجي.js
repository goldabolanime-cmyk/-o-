const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "ايموجي",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "تحدي تحليل صورة الإيموجي السريع",
  usages: "ايموجي",
  commandCategory: "العاب",
  cooldowns: 5
};

const questions = [
  { emoji: "👮‍♂️", name: "رجل شرطة" },
  { emoji: "👮‍♀️", name: "امرأة شرطة" },
  { emoji: "😢", name: "حزين" },
  { emoji: "🙂", name: "مبتسم" },
  { emoji: "😛", name: "لسان" },
  { emoji: "😶", name: "صامت" },
  { emoji: "🥱", name: "يتثائب" },
  { emoji: "😴", name: "نائم" },
  { emoji: "😜", name: "غمزة ولسان" },
  { emoji: "😮", name: "مندهش" },
  { emoji: "🤐", name: "فم مغلق" },
  { emoji: "🙃", name: "مقلوب" },
  { emoji: "🤯", name: "منفجر" },
  { emoji: "🥵", name: "محتر" },
  { emoji: "🥶", name: "متجمد" },
  { emoji: "😎", name: "نظارات" },
  { emoji: "😭", name: "يبكي" },
  { emoji: "😱", name: "مرعوب" },
  { emoji: "🤣", name: "يضحك" },
  { emoji: "🤖", name: "رجل آلي" },
  { emoji: "👽", name: "فضائي" },
  { emoji: "👻", name: "شبح" },
  { emoji: "🤠", name: "كاوبوي" },
  { emoji: "🎈", name: "بالون" },
  { emoji: "👀", name: "عيون" },
  { emoji: "🛒", name: "تسوق" },
  { emoji: "🚲", name: "دراجة" },
  { emoji: "🚓", name: "شرطة" },
  { emoji: "🚀", name: "صاروخ" },
  { emoji: "📱", name: "هاتف" },
  { emoji: "👑", name: "تاج" },
  { emoji: "💍", name: "خاتم" },
  { emoji: "💣", name: "قنبلة" },
  { emoji: "🔪", name: "سكين" },
  { emoji: "🔥", name: "نار" },
  { emoji: "🏠", name: "بيت" },
  { emoji: "🦁", name: "أسد" },
  { emoji: "🐯", name: "نمر" },
  { emoji: "🐱", name: "قطة" },
  { emoji: "🐼", name: "باندا" },
  { emoji: "🐘", name: "فيل" },
  { emoji: "🐲", name: "تنين" },
  { emoji: "🌹", name: "وردة" },
  { emoji: "🌙", name: "قمر" },
  { emoji: "☀️", name: "شمس" },
  { emoji: "⚽", name: "كرة قدم" },
  { emoji: "🍕", name: "بيتزا" },
  { emoji: "🍔", name: "برجر" },
  { emoji: "🍦", name: "آيس كريم" },
  { emoji: "🍎", name: "تفاحة" }
];

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { senderID, body, threadID, messageID } = event;
  const userAnswer = body.trim();
  const correctAnswer = handleReply.correctAnswer;

  if (userAnswer === correctAnswer) {
      await Currencies.increaseMoney(senderID, 50);
      api.unsendMessage(handleReply.messageID); 
      return api.sendMessage(`✅ ┃ تـهـانـيـنـا يـا بـطـل!\n━━━━━━━━━━━━━━━\n✨ ┃ لـقـد حـلـلـت الـإيـمـوجـي صـح: [ ${correctAnswer} ]\n💰 ┃ الـجـائـزة: 50$ تـم إضـافـتـهـا لـك.`, threadID, messageID);
  } else {
      return api.sendMessage(`❌ ┃ خـطأ! الإيـمـوجـي غـيـر مـطـابـق، حـاول مـجـدداً.`, threadID, messageID);
  }
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  const random = questions[Math.floor(Math.random() * questions.length)];
  
  // استخدام API خارجي لجلب صورة الإيموجي (Apple Style)
  const codepoint = [...random.emoji].map(e => e.codePointAt(0).toString(16)).join("-");
  const imgUrl = `https://abs.twimg.com/emoji/v2/72x72/${codepoint}.png`;
  
  const path = __dirname + `/cache/emoji_${threadID}.png`;

  try {
    const response = await axios.get(imgUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(path, Buffer.from(response.data, "binary"));

    const msg = {
      body: `⚡ ┃ تـحـدي تَـحْـلِـيلِ اَلْإِيـمُـوجِـي اَلـسَّـرِيعِ\n━━━━━━━━━━━━━━━\n‹ مـا هـو الإيـمـوجـي الـمـوجـود فـي الـصـورة؟ ›\n━━━━━━━━━━━━━━━\n💰 ┃ اَلْـجَـائِـزَةُ: [ 50$ ]\n📝 ┃ قُـمْ بِـالـرَّدِّ عـلـى اَلـصُّـورَةِ بِـالْإِيـمُـوجِـي اَلْـمُـنَـاسِـبِ.`,
      attachment: fs.createReadStream(path)
    };

    return api.sendMessage(msg, threadID, (err, info) => {
      if (fs.existsSync(path)) fs.unlinkSync(path);
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        correctAnswer: random.emoji
      });
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حـدث خـطأ أثـنـاء جـلـب صـورة الإيـمـوجـي.", threadID, messageID);
  }
};