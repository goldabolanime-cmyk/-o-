module.exports.config = {
  name: "سنة",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "العد التنازلي الملحمي للسنة الجديدة",
  commandCategory: "خدمات",
  cooldowns: 5
};

module.exports.run = function ({ event, api }) {
    // تحديد موعد رأس السنة القادمة 2027
    const nextYear = new Date().getFullYear() + 1;
    const t = Date.parse(`January 1, ${nextYear} 00:00:00`) - Date.parse(new Date());

    // الحسابات التفصيلية
    const seconds = Math.floor((t / 1000) % 60);
    const minutes = Math.floor((t / 1000 / 60) % 60);
    const hours = Math.floor((t / (1000 * 60 * 60)) % 24);
    const days = Math.floor(t / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(days / 7);
    const months = Math.floor(days / 30.44); // متوسط أيام الشهر

    const msg = `
┏━━━━━━━━━━━━━━━━━━┓
   ⏳ الـعـد الـتـنـازلـي لـ 2027 ⏳
┗━━━━━━━━━━━━━━━━━━┛

📊 الـزمـن الـمـتـبـقـي لـلـقـمـة:

🗓️ الـأشـهـر : 【 ${months} 】 شـهـر
📅 الـأَسـابـيـع : 【 ${weeks} 】 أسـبـوع
🏹 الـأَيـام : 【 ${days} 】 يـوم
⏰ الـسـاعـات : 【 ${hours} 】 سـاعـة
⏱️ الـدقـائـق : 【 ${minutes} 】 دقـيـقـة
⚡ الـثـوانـي : 【 ${seconds} 】 ثـانـيـة

━━━━━━━━━━━━━━━
👑 انـتـظـروا عـام ريـو الـمـجـيـد 👑
━━━━━━━━━━━━━━━
`;

    return api.sendMessage(msg, event.threadID, event.messageID);
}
