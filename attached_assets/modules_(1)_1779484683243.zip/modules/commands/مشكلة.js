const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "مشكلة",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "مَـخْـزَنُ اَلْأَعْـطَـابِ: تَـسْـجِيـلُ وَإِدَارَةُ مَـشَـاكِلِ اَلـنِّـظَـامِ",
  commandCategory: "نظام",
  usages: "[الرد بـ 'مشكلة' / قائمة / حذف + اسم]",
  cooldowns: 2
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, type, messageReply, senderID } = event;
  const filePath = path.join(__dirname, "cache", "problems.json");

  // إنشاء الملف إذا لم يكن موجوداً
  if (!fs.existsSync(filePath)) fs.writeJsonSync(filePath, []);

  let problems = fs.readJsonSync(filePath);

  // 1. عرض قائمة المشاكل
  if (args[0] === "قائمة") {
    if (problems.length === 0) return api.sendMessage("📭 ┃ سَـيِّـدِي عـبـدو، لَا تُـوجَـدُ مَـشَـاكِلُ مُـسَـجَّـلَةٌ حَـالِيـاً.", threadID, messageID);
    
    let msg = "⚠️ ┃ قَـائِمَةُ أَعْـطَـابِ رِيُـو بُـوت ┃ ⚠️\n━━━━━━━━━━━━━━━━━━\n";
    problems.forEach((p, i) => {
      msg += `[ ${i + 1} ] ❮ اَلأَمْـر: ${p.command} ❯\n🔹 ┃ اَلْـمُشْكِلَة: ${p.issue}\n⏰ ┃ اَلْـوَقْـت: ${p.time}\n👤 ┃ اَلْـمُبَلِّـغ: ${p.reporter}\n┈┈┈┈┈┈┈┈┈┈┈┈┈\n`;
    });
    msg += `👑 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;
    return api.sendMessage(msg, threadID, messageID);
  }

  // 2. حذف مشكلة معينة
  if (args[0] === "حذف") {
    const cmdName = args.slice(1).join(" ");
    if (!cmdName) return api.sendMessage("⚠️ ┃ يُـرْجَى كِـتَابَةُ اِسْـمِ اَلأَمْـرِ لِـحَـذْفِ مَـشَاكِلِهِ.", threadID, messageID);
    
    const initialLength = problems.length;
    problems = problems.filter(p => p.command.toLowerCase() !== cmdName.toLowerCase());
    
    if (problems.length === initialLength) return api.sendMessage(`❌ ┃ لَمْ يَـتِمَّ اَلْـعُثُـورُ عَـلَى مَـشَاكِلَ لِلأَمْـرِ [ ${cmdName} ].`, threadID, messageID);
    
    fs.writeJsonSync(filePath, problems);
    return api.sendMessage(`✅ ┃ تَمَّ حَـذْفُ مَـشَاكِلِ اَلأَمْـرِ [ ${cmdName} ] بِنَـجَـاحٍ.`, threadID, messageID);
  }

  // 3. إضافة مشكلة عن طريق الرد (Reply)
  if (type === "message_reply") {
    // التحقق إذا كان الرد على رسالة البوت
    if (messageReply.senderID !== api.getCurrentUserID()) {
      return api.sendMessage("⚠️ ┃ سَـيِّـدِي عـبـدو، يَـجِبُ اَلـرَّدُّ عَـلَى رِسَـالَةِ اَلْـبُـوتِ اَلَّـتِي حَـدَثَ فِـيهَا اَلْـخَـطَأُ.", threadID, messageID);
    }

    // استخراج اسم الأمر (غالباً يكون أول كلمة أو مكتوب في الهيدر)
    // هنا سنحاول استنتاج الأمر من محتوى الرسالة
    let detectedCmd = "غير محدد";
    if (messageReply.body.includes("الأمر") || messageReply.body.includes("command")) {
       detectedCmd = messageReply.body.split("\n")[0].replace(/[^a-zA-Z0-9]/g, "") || "غير معروف";
    } else {
       detectedCmd = "عطل عام / " + messageReply.body.substring(0, 10) + "...";
    }

    const newProblem = {
      command: detectedCmd,
      issue: messageReply.body,
      time: new Date().toLocaleString('ar-EG', { hour12: true }),
      reporter: senderID
    };

    problems.push(newProblem);
    fs.writeJsonSync(filePath, problems);

    api.setMessageReaction("📝", messageID, () => {}, true);
    return api.sendMessage(`✅ ┃ تَمَّ تَـسْـجِيـلُ اَلْـمُشْكِلَةِ فِـي اَلْـمَـخْـزَنِ.\n📂 ┃ اَلأَمْـر: ${detectedCmd}`, threadID, messageID);
  }

  // إذا كتب الأمر بدون رد أو وسائط
  return api.sendMessage("❓ ┃ كَيْفِيَّـةُ اَلِاسْـتِخْـدَامِ:\n1️⃣ رُدَّ عَـلَى رِسَـالَةِ خَـطَأِ اَلْـبُـوتِ بِـكَـلِمَةِ 'مشكلة'.\n2️⃣ اكتب 'مشكلة قائمة' لِـعَرْضِ اَلْأَعْـطَـابِ.\n3️⃣ اكتب 'مشكلة حذف [اسم الأمر]' لِـتَنْظِيفِ اَلْـمَـخْـزَنِ.", threadID, messageID);
};