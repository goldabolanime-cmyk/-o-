const axios = require("axios");
const moment = require("moment-timezone");

module.exports.config = {
  name: "طقس",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "يعرض حالة الطقس لأي مدينة في العالم بزخرفة ملكية",
  commandCategory: "خدمات",
  usages: "[اسم المدينة]",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID } = event;
  const apiKey = "c4ef85b93982d6627681b056e24bd438"; 
  const city = args.join(" ");

  if (!city) return api.sendMessage("📍 يـرجـى كـتـابـة اسـم الـمـديـنـة بـعـد الأمـر.\nمـثـال: طقس لندن", threadID, messageID);

  try {
    // جلب البيانات من OpenWeather لجميع مدن العالم
    const res = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURI(city)}&appid=${apiKey}&units=metric&lang=ar`);
    const data = res.data;

    const temp = data.main.temp;
    const feelsLike = data.main.feels_like;
    const desc = data.weather[0].description;
    const humidity = data.main.humidity;
    const windSpeed = data.wind.speed;
    
    // حساب التوقيت المحلي للمدينة المختارة باستخدام الـ Offset
    const sunrise = moment.utc(data.sys.sunrise, 'X').add(data.timezone, 'seconds').format('HH:mm:ss');
    const sunset = moment.utc(data.sys.sunset, 'X').add(data.timezone, 'seconds').format('HH:mm:ss');
    
    const cityName = data.name;
    const country = data.sys.country;

    let msg = `✨ ═══ ﴿ أحْـوَالُ الـطَّـقْـس ﴾ ═══ ✨\n\n`;
    msg += `📍 الـمـوقـع: ${cityName}, ${country}\n`;
    msg += `━━━━━━━━━━━━━━━\n`;
    msg += `🌡 درخـة الـحـرارة : 【 ${temp}°C 】\n`;
    msg += `🌡 الإحـسـاس الـفـعـلـي : 【 ${feelsLike}°C 】\n`;
    msg += `☁️ وصـف الـجـو : 【 ${desc} 】\n`;
    msg += `💦 نـسـبـة الـرطـوبـة : 【 ${humidity}% 】\n`;
    msg += `💨 سـرعـة الـريـاح : 【 ${windSpeed} km/h 】\n`;
    msg += `🌅 شـروق الـشـمـس : 【 ${sunrise} 】\n`;
    msg += `🌄 غـروب الـشـمـس : 【 ${sunset} 】\n`;
    msg += `━━━━━━━━━━━━━━━\n`;
    msg += `🌍 الـتـوقـيـت: حـسـب الـمـوقـع الـمـحـلـي لـلـمـديـنـة\n`;
    msg += `👑 مـطـور الـنـظـام: عـبـدو`;

    return api.sendMessage(msg, threadID, messageID);
  } catch (err) {
    if (err.response && err.response.status === 404) {
      return api.sendMessage(`❌ عـذراً يـا سـيـدي، لـم أتـمـكـن مـن الـعـثـور عـلى مـديـنـة بـاسـم: ${city}`, threadID, messageID);
    }
    return api.sendMessage("⚠️ حـدث خـطأ فـي الـعثـور عـلى بـيـانات هـذه الـمـديـنـة.", threadID, messageID);
  }
};