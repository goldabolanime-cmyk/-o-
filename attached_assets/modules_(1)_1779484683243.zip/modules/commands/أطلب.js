module.exports.config = {
  name: "أطلب",
  version: "1.0.0",
  hasPermssion: 2, // للمطور (عبدو) فقط أو الأدمن لضمان عدم حظر حساب البوت
  credits: "عبدو",
  description: "إِرْسَـالُ طَـلَبِ صَـدَاقَةٍ إِلَى مُسْتَخْدِمٍ",
  commandCategory: "نظام",
  usages: "[الآيدي ID / الرد على رسالة]",
  cooldowns: 10
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID, type, messageReply } = event;
  
  // تحديد الآيدي المستهدف (سواء من الرد أو من الكتابة)
  let targetID;
  if (type == "message_reply") {
    targetID = messageReply.senderID;
  } else {
    targetID = args[0] || senderID; // إذا لم يكتب شيئاً يرسل لنفسه (للتجربة)
  }

  api.sendMessage(`⏳ ┃ جَـارِي إِرْسَـالُ طَـلَبِ اَلـصَّـدَاقَةِ اَلْـمَلَـكِي...`, threadID, messageID);

  try {
    // إرسال طلب الصداقة
    await api.sendFriendRequest(targetID, (err) => {
      if (err) {
        return api.sendMessage(`❌ ┃ عـذراً يَا عـبـدو، فَـشَلَ إِرْسَـالُ اَلـطَّـلَبِ. رُبَّـمَا اَلْـحِسَابُ لَدَيْـهِ قُـيُـودٌ.`, threadID, messageID);
      }
      
      return api.sendMessage({
        body: `┏━━━━━━━━━━━━━━━━━━━━┓\n` +
              `   ♛ 𝑹𝑰𝑶 𝑭𝑹𝑰𝑬𝑵𝑫𝑺𝑯𝑰𝑷 ♛\n` +
              `┗━━━━━━━━━━━━━━━━━━━━┛\n\n` +
              `✅ ┃ تَـمَّ إِرْسَـالُ اَلـطَّـلَبِ بِـنَـجَاحٍ\n` +
              `👤 ┃ اَلْـمُسْتَهْـدَفُ: 『 ${targetID} 』\n\n` +
              `🔱 ┃ بِـوَاسِـطَـةِ: عـبـدو`,
      }, threadID, messageID);
    });

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ غَـيْرُ مَـتَوَقَّـعٍ.", threadID, messageID);
  }
};