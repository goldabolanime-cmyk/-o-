module.exports.config = {
  name: "اطردني",
  version: "1.5.0",
  hasPermssion: 0,
  credits: "عمر / تعديل Gemini",
  description: "يقوم بطرد المستخدم من المجموعة بطلب منه",
  commandCategory: "خدمات",
  usages: "اكتب الأمر ليتم طردك فوراً",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID, senderID } = event;
  const developerID = "100090081489341"; // الآيدي الخاص بك

  try {
    // 1. التحقق من صلاحيات البوت في المجموعة
    const info = await api.getThreadInfo(threadID);
    if (!info.adminIDs.some(item => item.id == api.getCurrentUserID())) {
      return api.sendMessage("⚠️ ┇ عـذراً، يـجـب أن أكـون مـسؤولاً (Admin) لـتـنـفـيـذ هـذا الأمـر!", threadID, messageID);
    }

    // 2. استثناء المطور من الطرد
    if (senderID === developerID) {
      return api.sendMessage("👑 ┇ حـاشـاك يـا مـطـوري! لا يـمـكـنـني طـرد سـيـد الـبـوت مـن هـنـا.", threadID, messageID);
    }

    // 3. تنفيذ الطرد للمستخدمين العاديين مع رسالة مزخرفة
    return api.sendMessage("🚮 ┇ جـاري تـنـفـيـذ طـلـبـك.. وداعـاً!", threadID, async () => {
      await api.removeUserFromGroup(senderID, threadID);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┇ حـدث خـطأ، قـد لا أمـلـك الـصلاحـيـة لـطـردك.", threadID, messageID);
  }
};
