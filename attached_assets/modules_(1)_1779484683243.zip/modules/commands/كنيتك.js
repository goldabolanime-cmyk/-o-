module.exports.config = {
  name: "كنيتك",
  version: "1.1.0",
  hasPermssion: 2, 
  credits: "عبدو",
  description: "تغيير كنية البوت في جميع المجموعات بنقرة واحدة",
  commandCategory: "نظام",
  usages: "[الكنية الجديدة]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const newNickname = args.join(" ");

  if (!newNickname) return api.sendMessage("⚠️ ┃ رَجَاءً أَدْخِلِ اَلْكُنْيَةَ اَلْمُرَادَ تَعْمِيمُهَا.", threadID, messageID);

  const decoratedNickname = `『 ${newNickname} 』`;
  
  // جلب قائمة المجموعات النشطة (حتى 500 مجموعة)
  api.getThreadList(500, null, ["INBOX"], async (err, list) => {
    if (err) return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِي جَـلْبِ اَلْـمَـجْمُـوعَاتِ.", threadID, messageID);

    let count = 0;
    const botID = api.getCurrentUserID();

    for (const thread of list) {
      // التأكد أنها مجموعة وليست دردشة خاصة
      if (thread.isGroup && thread.threadID != threadID) {
        await api.changeNickname(decoratedNickname, thread.threadID, botID);
        count++;
      }
    }

    // تغيير الكنية في المجموعة الحالية أيضاً
    await api.changeNickname(decoratedNickname, threadID, botID);

    const responseMsg = `┏━━━━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑵𝑰𝑪𝑲𝑵𝑨𝑴𝑬 𝑼𝑷𝑫𝑨𝑻𝑬 ♛\n┗━━━━━━━━━━━━━━━━━━━━┛\n\n✅ ┃ تَـمَّ اَلـتَّعْـمِيمُ بِنَـجَاحٍ\n✨ ┃ اَلْكُنْيَةُ: ${decoratedNickname}\n📊 ┃ اَلْأَعْضَاءُ اَلْمُتَأَثِّرُونَ: [ ${count + 1} ] مَجْمُوعَة\n\n━━━━━━━━━━━━━━━\n🔱 ┃ اَلْـمُطَـوِّرُ: عـبـدو`;

    return api.sendMessage(responseMsg, threadID, messageID);
  });
};