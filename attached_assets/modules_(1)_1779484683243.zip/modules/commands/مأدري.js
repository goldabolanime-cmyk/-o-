module.exports.config = {
  name: "زخرفة",
  version: "5.5.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "زخرفة ملكية احترافية مع نظام إرسال منفصل للنسخ",
  commandCategory: "خدمات",
  usages: "[ar/en] [النص]",
  cooldowns: 2
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID } = event;
  const type = args[0] ? args[0].toLowerCase() : null;
  const text = args.slice(1).join(" ");

  if (!type || !text || (type !== "ar" && type !== "en")) {
    return api.sendMessage("⚠️ ┇ يـرجـى الاسـتـخـدام الـصـحـيـح:\n💡 ┇ [ .زخرفة ar محمد ]\n💡 ┇ [ .زخرفة en rio ]", threadID, messageID);
  }

  // الرسالة التمهيدية الفخمة
  api.sendMessage("⏳ ┇ جَـارِي إحْـضَـارُ زَخْـرَفَـةٍ مَـلَـكِـيَّـةٍ لَـكَ . . .", threadID);

  let finalResult = "";

  if (type === "ar") {
    // أنماط زخرفة عربية نادرة وفخمة (مشكولة ومزينة)
    const arStyles = [
        (t) => t.split('').join('ـ'), // نمط المـد
        (t) => t.split('').join(' '), // نمط التباعد
        (t) => t.split('').map(c => c + "ُ").join(''), // نمط الضم الملكي
        (t) => t.split('').map(c => c + "ّ").join(''), // نمط التشديد
        (t) => t.split('').map(c => c + "ۡ").join(''), // نمط السكون
        (t) => t.split('').map(c => c + "ٍ").join(''), // نمط الكسر
        (t) => `『 ${t} 』`, // نمط الأقواس الملكية
        (t) => `« ${t} »`, // نمط الاقتباس النبيل
        (t) => `✥ ${t} ✥`, // نمط الختم
        (t) => `♛ ${t} ♛`, // نمط التاج
        (t) => `✧ ${t} ✧`, // نمط البريق
        (t) => `( ${t} )`, // نمط هادئ
        (t) => `• ${t} •`, // نمط النقطة
        (t) => `| ${t} |`, // نمط الأعمدة
        (t) => `⭐ ${t} ⭐` // نمط النجوم
    ];
    const randomAr = arStyles[Math.floor(Math.random() * arStyles.length)];
    finalResult = randomAr(text);

  } else {
    // أنماط زخرفة إنجليزية (Unicode نادرة)
    const enStyles = {
      1: { a: "𝗮", b: "𝗯", c: "𝗰", d: "𝗱", e: "𝗲", f: "𝗳", g: "𝗴", h: "𝗵", i: "𝗶", j: "𝗷", k: "𝗸", l: "𝗹", m: "𝗺", n: "𝗻", o: "𝗼", p: "𝗽", q: "𝗾", r: "𝗿", s: "𝘀", t: "𝘁", u: "𝘂", v: "𝘃", w: "𝘄", x: "𝘅", y: "𝘆", z: "𝘇" },
      2: { a: "𝓪", b: "𝓫", c: "𝓬", d: "𝓭", e: "𝓮", f: "𝓯", g: "𝓰", h: "𝓱", i: "𝓲", j: "𝓳", k: "𝓴", l: "𝓵", m: "𝓶", n: "𝓷", o: "𝓸", p: "𝓹", q: "𝓿", r: "𝓻", s: "𝓼", t: "𝓽", u: "𝓾", v: "𝓿", w: "𝔀", x: "𝔁", y: "𝔂", z: "𝔃" },
      3: { a: "𝕒", b: "𝕓", c: "𝕔", d: "𝕕", e: "𝕖", f: "𝕗", g: "𝕘", h: "𝕙", i: "𝕚", j: "𝕛", k: "𝕜", l: "𝕝", m: "𝕞", n: "𝕟", o: "𝕠", p: "𝕡", q: "𝕢", r: "𝕣", s: "𝕤", t: "𝕥", u: "𝕦", v: "𝕧", w: "𝕨", x: "𝕩", y: "𝕪", z: "𝕫" },
      4: { a: "🄰", b: "🄱", c: "🄲", d: "🄳", e: "🄴", f: "🄵", g: "🄶", h: "🄷", i: "🄸", j: "🄹", k: "🄺", l: "🄻", m: "🄼", n: "🄽", o: "🄾", p: "🄿", q: "🅀", r: "🅁", s: "🅂", t: "🅃", u: "🅄", v: "🅅", w: "🅆", x: "🅇", y: "🅈", z: "🅉" },
      5: { a: "𝖆", b: "𝖇", c: "𝖈", d: "𝖉", e: "𝖊", f: "𝖋", g: "𝖌", h: "𝕙", i: "𝖎", j: "𝖏", k: "𝖐", l: "𝖑", m: "𝖒", n: "𝖓", o: "𝖔", p: "𝖕", q: "𝖖", r: "𝖗", s: "𝖘", t: "𝖙", u: "𝖚", v: "𝖛", w: "𝖜", x: "𝖝", y: "𝖞", z: "𝖟" },
      6: { a: "ⓐ", b: "ⓑ", c: "ⓒ", d: "ⓓ", e: "ⓔ", f: "ⓕ", g: "ⓖ", h: "ⓗ", i: "ⓘ", j: "ⓙ", k: "ⓚ", l: "ⓛ", m: "ⓜ", n: "ⓝ", o: "ⓞ", p: "ⓟ", q: "ⓠ", r: "ⓡ", s: "ⓢ", t: "ⓣ", u: "ⓤ", v: "ⓥ", w: "ⓦ", x: "ⓧ", y: "ⓨ", z: "ⓩ" },
      7: { a: "🅰", b: "🅱", c: "🅲", d: "🅳", e: "🅴", f: "🅵", g: "🅶", h: "🅷", i: "🅸", j: "🅹", k: "🅺", l: "🅻", m: "🅼", n: "🅽", o: "🅾", p: "🅿", q: "🆀", r: "🆁", s: "🆂", t: "🆃", u: "🆄", v: "🆅", w: "🆆", x: "🆇", y: "🆈", z: "🆉" },
      8: { a: "Λ", b: "B", c: "C", d: "D", e: "Ξ", f: "F", g: "G", h: "H", i: "I", j: "J", k: "K", l: "L", m: "M", n: "N", o: "O", p: "P", q: "Q", r: "R", s: "S", t: "T", u: "U", v: "V", w: "W", x: "X", y: "Y", z: "Z" },
      9: { a: "α", b: "в", c: "¢", d: "∂", e: "є", f: "ƒ", g: "g", h: "н", i: "ι", j: "ʝ", k: "к", l: "ℓ", m: "м", n: "η", o: "σ", p: "ρ", q: "ף", r: "я", s: "ѕ", t: "т", u: "υ", v: "ν", w: "ω", x: "χ", y: "у", z: "չ" },
      10: { a: "å", b: "ß", c: "ç", d: "Ð", e: "ê", f: "£", g: "g", h: "h", i: "ï", j: "j", k: "k", l: "l", m: "m", n: "ñ", o: "ð", p: "þ", q: "q", r: "r", s: "§", t: "†", u: "µ", v: "v", w: "w", x: "x", y: "¥", z: "z" },
      11: { a: "ค", b: "๒", c: "ς", d: "๔", e: "є", f: "Ŧ", g: "ﻮ", h: "ђ", i: "เ", j: "ן", k: "к", l: "ɭ", m: "๓", n: "ภ", o: "๏", p: "ק", q: "ợ", r: "г", s: "ร", t: "t", u: "ย", v: "v", w: "ω", x: "ץ", y: "ץ", z: "z" },
      12: { a: "𝙰", b: "𝙱", c: "𝙲", d: "𝙳", e: "𝙴", f: "𝙵", g: "𝙶", h: "𝙷", i: "𝙸", j: "𝙹", k: "𝙺", l: "𝙻", m: "𝙼", n: "𝙽", o: "𝙾", p: "𝙿", q: "𝚀", r: "𝚁", s: "𝚂", t: "𝚃", u: "𝚄", v: "𝚅", w: "𝚆", x: "𝚇", y: "𝚈", z: "𝚉" },
      13: { a: "A̶", b: "B̶", c: "C̶", d: "D̶", e: "E̶", f: "F̶", g: "G̶", h: "H̶", i: "I̶", j: "J̶", k: "K̶", l: "L̶", m: "M̶", n: "N̶", o: "O̶", p: "P̶", q: "Q̶", r: "R̶", s: "S̶", t: "T̶", u: "U̶", v: "V̶", w: "W̶", x: "X̶", y: "Y̶", z: "Z̶" },
      14: { a: "A", b: "B", c: "C", d: "D", e: "E", f: "F", g: "G", h: "H", i: "I", j: "J", k: "K", l: "L", m: "M", n: "N", o: "O", p: "P", q: "Q", r: "R", s: "S", t: "T", u: "U", v: "V", w: "W", x: "X", y: "Y", z: "Z" },
      15: { a: "̾a", b: "̾b", c: "̾c", d: "̾d", e: "̾e", f: "̾f", g: "̾g", h: "̾h", i: "̾i", j: "̾j", k: "̾k", l: "̾l", m: "̾m", n: "̾n", o: "̾o", p: "̾p", q: "̾q", r: "̾r", s: "̾s", t: "̾t", u: "̾u", v: "̾v", w: "̾w", x: "̾x", y: "̾y", z: "̾z" }
    };

    const randomID = Math.floor(Math.random() * 15) + 1;
    const selectedStyle = enStyles[randomID];
    finalResult = text.split('').map(c => selectedStyle[c.toLowerCase()] || c).join('');
  }

  // إرسال النتيجة كـ "رد" (Reply) بدون أي إطار لتسهيل النسخ
  return api.sendMessage(finalResult, threadID, messageID);
};