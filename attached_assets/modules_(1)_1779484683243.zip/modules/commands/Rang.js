const fs = require("fs-extra");
const axios = require("axios");
const path = require("path");

module.exports.config = {
  name: "رانك",
  version: "4.1.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "نِـظَـامُ اَلـتَّـفَـاعُـلِ اَلْـمَـلَـكِي (اَلـنِّـظَـامُ اَلـصَّـعْـبُ)",
  commandCategory: "الخدمات",
  cooldowns: 5
};

// وظيفة لتحديد اللقب بناءً على المستوى
function getRankTitle(level) {
  if (level >= 50) return "مُـعَـمِّـرُ اَلـعُـصُـورِ ⏳";
  if (level >= 40) return "اَلْأسْـطُـورَةُ اَلْـخَـالِـدَةُ ✨";
  if (level >= 30) return "اَلـدَّجَّـالُ 👁️";
  if (level >= 20) return "اَلْإِمْـبَـرَاطُـورُ 👑";
  if (level >= 10) return "اَلـزَّعِيـمُ 🔥";
  if (level >= 5) return "اَلْـفَـارِسُ ⚔️";
  return "اَلْـمُـبْـتَـدِئُ 🌱";
}

// --- الجزء الأول: زيادة الخبرة (المعادلة الصعبة: كل مستوى = 300 رسالة إضافية) ---
module.exports.handleEvent = async function({ api, event, Currencies }) {
  const { threadID, senderID, messageID } = event;
  if (!senderID || senderID == api.getCurrentUserID()) return;

  if (!global.rioRankNotify) global.rioRankNotify = {};
  if (global.rioRankNotify[threadID] === false) return; 

  try {
    let data = await Currencies.getData(senderID);
    let exp = data.exp || 0;
    
    let oldLevel = Math.floor(exp / 300); 
    exp += 1;
    let newLevel = Math.floor(exp / 300); 

    await Currencies.setData(senderID, { exp });

    if (newLevel > oldLevel && newLevel !== 0) {
      let reward = 500 * newLevel; // مكافأة أكبر لأن النظام صعب
      await Currencies.increaseMoney(senderID, reward);
      
      let name = global.data.userName.get(senderID) || "اَلْـعُـضْـوُ اَلْـمَـلَـكِي";
      let rankTitle = getRankTitle(newLevel);
      
      let msg = `✨ 🎊 ﴿ تَـهْـنِـئَـةٌ مَـلَـكِيَّـةٌ ﴾ 🎊 ✨\n` +
                `━━━━━━━━━━━━━━━━━━\n` +
                `👤 اَلْـمُـشَارِكُ: 『 ${name} 』\n` +
                `🆙 لَـقَـدِ اِرْتَـقَى مُسْتَوَاكَ إِلَى: 【 ${newLevel} 】\n` +
                `🎖️ لَـقَـبُـكَ اَلْـجَـدِيـدُ: ${rankTitle}\n` +
                `🎁 اَلْـهَـدِيَّـةُ: +${reward} عُـمْـلَـة\n` +
                `🔥 اَلـنِّـظَـامُ صَـعْـبٌ لَـكِـنَّـكَ كُـفُـؤٌ لَـهُ!\n` +
                `━━━━━━━━━━━━━━━━━━\n` +
                `🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;

      const gifUrl = "https://i.postimg.cc/G2zxwJsg/65z-M0I.gif";
      const gifPath = path.resolve(__dirname, 'cache', `rank_up_${senderID}.gif`);
      
      const res = await axios.get(gifUrl, { responseType: "arraybuffer" });
      fs.writeFileSync(gifPath, Buffer.from(res.data, "utf-8"));

      api.sendMessage({
        body: msg,
        attachment: fs.createReadStream(gifPath)
      }, threadID, () => { if (fs.existsSync(gifPath)) fs.unlinkSync(gifPath); }, messageID);
    }
  } catch (e) { console.log(e); }
};

// --- الجزء الثاني: عرض البطاقة ---
module.exports.run = async function({ api, event, Currencies, Users, args }) {
  const { threadID, messageID, senderID } = event;

  if (!global.rioRankNotify) global.rioRankNotify = {};
  
  if (args[0] === "تشغيل") {
    global.rioRankNotify[threadID] = true;
    return api.sendMessage("✅ ┃ تَـمَّ تَـشْـغِيـلُ إِشْـعَـارَاتِ اَلـتَّـرْقِيَـةِ.", threadID, messageID);
  }
  if (args[0] === "إيقاف") {
    global.rioRankNotify[threadID] = false;
    return api.sendMessage("🔕 ┃ تَـمَّ إِيـقَـافُ إِشْـعَـارَاتِ اَلـتَّـرْقِيَـةِ.", threadID, messageID);
  }

  try {
    let userCurrencies = await Currencies.getData(senderID);
    let exp = userCurrencies.exp || 0;
    
    let level = Math.floor(exp / 300);
    let name = await Users.getNameUser(senderID);
    let rankTitle = getRankTitle(level);

    // حساب التقدم للمستوى القادم
    let nextLevelExp = (level + 1) * 300;
    let progress = Math.floor(((exp % 300) / 300) * 10);
    const bar = "█".repeat(progress) + "▒".repeat(10 - progress);

    let message = `✨ ═══ ﴿ بِـطَـاقَـةُ مَـسْـتَـوَاكَ ﴾ ═══ ✨\n\n` +
                  `👤 اَلْـمُـسْتَـخْـدِمُ: 『 ${name} 』\n` +
                  `🎖️ اَلـلَّـقَـبُ: 『 ${rankTitle} 』\n` +
                  `🆙 اَلْـمُـسْتَـوَى: 【 ${level} 】\n` +
                  `📈 اَلـتَّـقَـدُّمُ: [${bar}]\n` +
                  `💎 إِجْـمَـالِي اَلـرَّسَـائِـلِ: ${exp}\n` +
                  `🎯 اَلـبَـاقِي لِلـتَّـرْقِـيَةِ: ${300 - (exp % 300)} رِسَـالَـة\n` +
                  `━━━━━━━━━━━━━━━━━━\n` +
                  `🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;

    const imagePath = __dirname + `/cache/rank_${senderID}.png`;
    const imgUrl = `https://graph.facebook.com/${senderID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
    
    const imgRes = await axios.get(imgUrl, { responseType: 'arraybuffer' });
    fs.writeFileSync(imagePath, Buffer.from(imgRes.data, "utf-8"));

    return api.sendMessage({
      body: message,
      attachment: fs.createReadStream(imagePath)
    }, threadID, () => { if (fs.existsSync(imagePath)) fs.unlinkSync(imagePath); }, messageID);

  } catch (e) {
    console.log(e);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي عَـرْضِ اَلْـبِـطَـاقَةِ.", threadID, messageID);
  }
};