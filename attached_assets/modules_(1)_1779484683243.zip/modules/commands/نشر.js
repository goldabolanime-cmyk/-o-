const axios = require("axios");

module.exports.config = {
  name: "نشر",
  version: "1.0.0",
  hasPermssion: 2, // للمطور فقط لضمان عدم عبث المستخدمين بحساب البوت
  credits: "عبدو / RIO BOT",
  description: "تمويه: نشر اقتباسات إنجليزية مشهورة على حساب البوت",
  commandCategory: "نظام",
  usages: ".نشر",
  cooldowns: 20
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID } = event;

  const quotes = [
    "The future belongs to those\nwho believe in the beauty\nof their own dreams and\nnever give up on them.",
    "Do not go where the path\nmay lead, go instead where\nthere is no path and\nleave a trail behind.",
    "The only way to do great\nwork is to love what you\ndo. If you haven't found\nit yet, keep looking.",
    "Success is not final,\nfailure is not fatal: it\nis the courage to continue\nthat counts the most.",
    "Believe in yourself and\nall that you are. Know\nthat there is something\ninside you greater than.",
    "Your time is limited,\nso don't waste it living\nsomeone else's life or\nbeing someone you're not.",
    "In the end, it's not the\nyears in your life that\ncount. It's the life in\nyour years that matters.",
    "Many of life's failures\nare people who did not\nrealize how close they\nwere to success today.",
    "If you want to live a\nhappy life, tie it to\na goal, not to people\nor things around you.",
    "Never let the fear of\nstriking out keep you\nfrom playing the game\nin front of everyone.",
    "Life is what happens\nwhen you're busy making\nother plans for your\nfuture and your goals.",
    "The secret of success\nis to do the common\nthing uncommonly well\nwith all your heart.",
    "I find that the harder\nI work, the more luck\nI seem to have in\neverything I try to do.",
    "You miss one hundred\npercent of the shots\nyou don't take in\nyour life every day.",
    "The only impossible\njourney is the one\nyou never begin with\na single small step.",
    "Life is short, and it\nis up to you to\nmake it sweet and\nfull of great memories.",
    "Spread love everywhere\nyou go. Let no one\never come to you without\nleaving much happier.",
    "The purpose of our\nlives is to be happy\nand to share that\njoy with everyone else.",
    "Get busy living or\nget busy dying. There\nis no middle ground\nin this beautiful life.",
    "You only live once,\nbut if you do it\nright, once is more\nthan enough for you.",
    "The best way to predict\nthe future is to create\nit yourself with your\nown hands and mind.",
    "The greatest glory in\nliving lies not in\nnever falling, but in\nrising every time fall.",
    "Dream big and dare\nto fail. Only those\nwho dare to fail can\never achieve greatness.",
    "Don't count the days,\nmake the days count\nand turn every moment\ninto a masterpiece.",
    "Be the change that\nyou wish to see in\nthe world around you\nstarting from today.",
    "Whatever you are, be\na good one. It is\nbetter to be a lion\nthan a thousand sheep.",
    "Keep your face always\ntoward the sunshine and\nshadows will fall fast\nbehind you forever.",
    "Happiness depends upon\nourselves and how we\nchoose to see the\nworld we live in.",
    "Turn your wounds into\nwisdom and your fears\ninto the fuel for\nyour ultimate success.",
    "The mind is everything.\nWhat you think you\nbecome. So think of\ngreatness and light.",
    "Strive not to be a\nsuccess, but rather to\nbe of value to the\npeople in your life.",
    "I am not a product of\nmy circumstances. I am\na product of my\nown strong decisions.",
    "Every strike brings me\ncloser to the next\nhome run. Never give\nup on your dreams.",
    "Life shrinks or expands\nin proportion to one's\ncourage to face the\nunknown challenges.",
    "The only limit to our\nrealization of tomorrow\nwill be our doubts\nof today's potential.",
    "Creativity is intelligence\nhaving fun. Let your\nimagination run wild and\nbuild new worlds.",
    "What you get by achieving\nyour goals is not as\nimportant as what you\nbecome by achieving.",
    "If you can dream it,\nyou can do it. Your\nlimits are only in\nyour own imagination.",
    "It does not matter how\nslowly you go as long\nas you do not stop\nmoving toward success.",
    "Everything you've ever\nwanted is on the other\nside of fear today.",
    "Hardships often prepare\nordinary people for an\nextraordinary destiny in\nthis beautiful world.",
    "Great things never come\nfrom comfort zones. You\nmust challenge yourself\nto grow every day.",
    "Success is walking from\nfailure to failure with\nno loss of enthusiasm\nfor your goals.",
    "The way to get started\nis to quit talking\nand begin doing the\nwork that matters.",
    "Your passion is waiting\nfor your courage to\ncatch up. Don't let\nit wait any longer.",
    "A journey of a thousand\nmiles begins with a\nsingle step. Take that\nstep with confidence.",
    "Courage is grace under\npressure. Stay calm and\nkeep moving forward no\nmatter what happens.",
    "Act as if what you\ndo makes a difference.\nIt does, more than\nyou can ever imagine.",
    "Don't wait. The time\nwill never be just\nright. Start where you\nstand with your tools.",
    "Either you run the day\nor the day runs you.\nTake control of your\nlife and your time.",
    "Energy and persistence\nconquer all things in\nthis life. Never lose\nyour inner fire.",
    "Failure is the condiment\nthat gives success its\nflavor. Enjoy the journey\nand learn from it.",
    "Small deeds done are\nbetter than great deeds\nplanned but never done\nby anyone at all.",
    "The power of imagination\nmakes us infinite. We\ncan reach the stars\nwith our own minds.",
    "To be the best, you\nmust be able to handle\nthe worst. Stay strong\nand never back down.",
    "Quality is not an act,\nit is a habit. Make\nexcellence a part of\nyورك daily routine.",
    "Innovation distinguishes\nbetween a leader and\na follower. Lead the\nway with your ideas.",
    "The only thing we have\nto fear is fear itself.\nStand tall and face\nyour shadows today.",
    "Everything has beauty,\nbut not everyone sees\nit. Look deeper into\nthe world around you.",
    "Character is destiny.\nWho you are defines\nwhere you will go\nin this great life."
  ];

  api.sendMessage("⏳ ┃ جـارٍ تـجـهـيـز الـمـنـشـور الـتـمـويـهـي...", threadID, messageID);

  // اختيار اقتباس عشوائي
  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

  // محاكاة وقت انتظار (التمويه)
  setTimeout(() => {
    api.createPost(randomQuote, (err, res) => {
      if (err) {
        return api.sendMessage(`❌ ┃ فـشـل الـنـشر: ${err.errorMessage}`, threadID, messageID);
      }
      return api.sendMessage("✅ ┃ تـمَّ الـنـشـر بـنـجـاح عـلـى حـسـاب الـبـوت!\n━━━━━━━━━━━━━━━\n📝 ┃ الـنـص الـمـنـشـور:\n\n" + randomQuote, threadID, messageID);
    });
  }, 5000); // ينتظر 5 ثوانٍ قبل النشر
};