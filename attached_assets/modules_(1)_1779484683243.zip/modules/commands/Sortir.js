module.exports.config = {
  name: "برا",
  version: "1.3.0",
  hasPermssion: 2,
  credits: "عبدو",
  description: "مُـغَـادَرَةُ اَلْـمَجْـمُوعَـةِ بِـرِسَـالَةٍ بَـسِيـطَةٍ",
  commandCategory: "المطور",
  usages: "[ايدي المجموعة / فارغ]",
  cooldowns: 10,
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  
  // قائمة المطورين المسموح لهم
  const permission = ["100090081489341", "100081948980908"];
  
  if (!permission.includes(senderID)) {
    return api.sendMessage("🚫 ┃ اَلْأَمْـرُ مَـحْـصُورٌ لِـلْـمُـطَـوِّرِ عـبـدو فَ_قَـطْ.", threadID, messageID);
  }

  const targetID = args[0] && !isNaN(args[0]) ? args[0] : threadID;

  // الرسالة كما طلبتها بدون زخرفة أو أسطر
  const goodbyeMsg = `ريــــو يــــلقــي تحــيته.. بــس لا تســتحقــون...وداعــــا ايــها الاغــبياء لــن اشــتاق اليــــكم...🐦‍⬛🖤`;

  try {
    // إرسال الرسالة العادية
    await api.sendMessage(goodbyeMsg, targetID);

    // مغادرة المجموعة
    setTimeout(() => {
      return api.removeUserFromGroup(api.getCurrentUserID(), targetID);
    }, 1200);

  } catch (error) {
    return api.sendMessage("⚠️ ┃ حَـدَثَ خَـطَأٌ أَثْـنَاءَ اَلْـمُغَـادَرَةِ.", threadID, messageID);
  }
};
