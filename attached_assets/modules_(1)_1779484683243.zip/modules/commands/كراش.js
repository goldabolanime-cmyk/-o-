const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
    name: "كراش",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "عبدو / RIO BOT",
    description: "إِظْـهَارُ اِهْـتِمَامِـكَ بِـشَخْصٍ مَـا بِـأُسْلُوبٍ مَلَكِيٍّ",
    commandCategory: "ترفيه",
    usages: "[تاغ] أو [رد على رسالة]",
    cooldowns: 5
};

module.exports.run = async function ({ api, event, args, Users }) {
    const { threadID, messageID, messageReply, mentions } = event;

    // 1. تحديد الشخص المستهدف
    let targetID;
    if (Object.keys(mentions).length > 0) {
        targetID = Object.keys(mentions)[0];
    } else if (messageReply) {
        targetID = messageReply.senderID;
    } else {
        return api.sendMessage("💖 ┃ مَـنْ هُـوَ اَلْـكَـرَاشُ؟ قُـمْ بِـعَمَلِ تَـاغ لَـهُ أَوْ رَدٍّ عَـلَى رِسَـالَتِـهِ.", threadID, messageID);
    }

    // 2. مصفوفة الروابط العشوائية (GIFs)
    const gifLinks = [
        "https://i.postimg.cc/1zK2zQSB/fullmetal-alchemist-roy-mustang.gif",
        "https://i.postimg.cc/xTkw3hGM/witch-watch.gif"
    ];
    
    // اختيار رابط عشوائي
    const randomGif = gifLinks[Math.floor(Math.random() * gifLinks.length)];
    const pathImg = __dirname + `/cache/crush_${threadID}.gif`;

    api.sendMessage("⏳ ┃ جَـارِي تَـجْهِيـزُ مَـشَاعِـرِ اَلْـكَرَااشِ...", threadID, messageID);

    try {
        const name = await Users.getNameUser(targetID);
        
        // تحميل الـ GIF المختار
        const response = await axios.get(randomGif, { responseType: "arraybuffer" });
        fs.writeFileSync(pathImg, Buffer.from(response.data, "utf-8"));

        const msg = {
            body: `┏━━━━━━━ ♛ ━━━━━━━┓\n   😍 ┃ رِيُـو كَـرَاشْ نْـيُوزْ\n┗━━━━━━━━━━━━━━━━━━┛\n\n✨ ┃ اَلْكَـرَاشُ اَلْـمُقَدَّسُ: 『 ${name} 』\n\n💌 ┃ " أَنَـا أَهْـتَمُّ لِأَجْـلِ هَـذَا اَلـشَّخْصِ جِـدّاً "\n\n━━━━━━━━━━━━━━━\n🔱 ┃ اَلْـمُطَـوِّرُ: عـبـدو`,
            attachment: fs.createReadStream(pathImg)
        };

        return api.sendMessage(msg, threadID, () => {
            if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
        }, messageID);

    } catch (e) {
        console.error(e);
        return api.sendMessage("❌ ┃ عُـذْراً، حَـدَثَ خَـطَأٌ فِي تَـحْمِيـلِ اَلْـمَشَاعِرِ.", threadID, messageID);
    }
};