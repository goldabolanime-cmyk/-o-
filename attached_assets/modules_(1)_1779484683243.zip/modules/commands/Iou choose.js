module.exports.config = {
  name: "لوخيروك",
  version: "2.7.0",
  hasPermssion: 0,
  credits: "عمر & ريو بوت",
  description: "لعبة لو خيروك بـ 3 محاولات كل ساعتين وزخرفة احترافية",
  commandCategory: "ألعاب",
  usages: "لوخيروك",
  cooldowns: 5,
};

// مخزن المحاولات (يبقى شغال طالما البوت يعمل)
if (!global.rioAttempts) global.rioAttempts = new Map();

module.exports.run = async function({ api, event, Currencies }) {
    const { threadID, messageID, senderID } = event;
    
    // --- نظام المحاولات ---
    const cooldownTime = 2 * 60 * 60 * 1000; // ساعتين بالملي ثانية
    const maxAttempts = 3;
    const userStats = global.rioAttempts.get(senderID) || { count: 0, lastReset: Date.now() };

    // إذا مرت ساعتين، صفر المحاولات
    if (Date.now() - userStats.lastReset > cooldownTime) {
        userStats.count = 0;
        userStats.lastReset = Date.now();
    }

    if (userStats.count >= maxAttempts) {
        const timeLeft = cooldownTime - (Date.now() - userStats.lastReset);
        const hours = Math.floor(timeLeft / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        return api.sendMessage(`⚠️ | عذراً أيها الملك، لقد استنفدت محاولاتك الـ ${maxAttempts}!\n\n⏳ | انتظر: ${hours} ساعة و ${minutes} دقيقة لتجديد طاقتك.`, threadID, messageID);
    }
    // ----------------------

    const questions = [
        ["تأكل ملعقة شطة حارة", "تأكل ليمونة كاملة بقشرها"],
        ["تعيش في غابة مليئة بالحيوانات", "تعيش في مدينة مهجورة تماماً"],
        ["امتلاك قوة الطيران", "امتلاك قوة الاختفاء"],
        ["يكون شعرك أخضر للأبد", "تكون أصلع تماماً للأبد"],
        ["تسافر للمستقبل وتشوف أحفادك", "ترجع للماضي وتشوف أجدادك"],
        ["تأكل بيتزا بالشكولاتة", "تأكل آيس كريم بالثوم"],
        ["العيش بدون إنترنت لمدة سنة", "العيش بدون هاتف لمدة سنتين"],
        ["تكون غني جداً وحزين", "تكون فقير جداً وسعيد"],
        ["تنام في مقبرة ليلة واحدة", "تسبح في مسبح فيه تماسيح"],
        ["تتحدث كل لغات العالم", "تتحدث مع الحيوانات وتفهمها"],
        ["تخسر حاسة الشم", "تخسر حاسة التذوق"],
        ["تكون بطل خارق مكروه", "تكون شرير محبوب"],
        ["تمشي حافي القدمين بالشارع", "تخرج بملابس النوم للسوق"],
        ["تعيش في القطب المتجمد", "تعيش في الصحراء القاحلة"],
        ["شرب عصير بصل", "أكل بيضة نيئة"],
        ["نوم فوق ناطحة سحاب", "نوم في غواصة تحت المحيط"],
        ["أذكى شخص بالعالم وقبيح", "أجمل شخص بالعالم وغبي"],
        ["تحصل على 10 مليون دولار الآن", "تحصل على 100 ألف دولار شهرياً"],
        ["تتوقف عن أكل اللحم للأبد", "تتوقف عن أكل الحلويات للأبد"],
        ["انظر ماذا كان وراء كل باب مغلق", "تخمين مجموعة كل خزنة من المحاولة الأولى"]
    ];

    const randomQ = questions[Math.floor(Math.random() * questions.length)];
    const option1 = randomQ[0];
    const option2 = randomQ[1];

    const msg = `🤔 | لــو خــيــروك\n` +
                `╭──────────────╮\n` +
                `1️⃣ ┋ ${option1}\n` +
                `2️⃣ ┋ ${option2}\n` +
                `╰──────────────╯\n` +
                `↩ | رُد بـ 1 أو 2 للاختيار\n\n` +
                `💰 | الربح: +80$ | الخسارة: -40$\n` +
                `🛡️ | المحاولات المتبقية: ${maxAttempts - userStats.count - 1}`;

    return api.sendMessage(msg, threadID, (err, info) => {
        // تحديث عدد المحاولات
        userStats.count += 1;
        global.rioAttempts.set(senderID, userStats);

        global.client.handleReply.push({
            name: this.config.name,
            messageID: info.messageID,
            author: senderID,
            option1: option1,
            option2: option2
        });
    }, messageID);
};

module.exports.handleReply = async function({ api, event, handleReply, Currencies }) {
    const { threadID, messageID, body, senderID } = event;
    if (handleReply.author != senderID) return;

    const choice = body.trim();
    if (choice != "1" && choice != "2") return;

    const reactEmoji = choice == "1" ? "🟦" : "🟥";
    api.setMessageReaction(reactEmoji, messageID, () => {}, true);

    const p1 = Math.floor(Math.random() * 60) + 20; 
    const p2 = 100 - p1;

    const drawBar = (percent) => {
        const size = 10;
        const fill = Math.round((percent / 100) * size);
        return `▕${"█".repeat(fill)}${"░".repeat(size - fill)}▏ ${percent}%`;
    };

    const isOption1Winner = p1 >= p2;
    const winnerText = isOption1Winner ? "الأول" : "الثاني";

    let resultMsg = "";
    if ((choice == "1" && isOption1Winner) || (choice == "2" && !isOption1Winner)) {
        await Currencies.increaseMoney(senderID, 80);
        resultMsg = `✅ تهانينا! لقد ربحت 80$`;
    } else {
        await Currencies.decreaseMoney(senderID, 40);
        resultMsg = `❌ للأسف! خسرت 40$`;
    }

    const finalMsg = `📊 | نـتـائـج الـتـصـويـت (عالمياً)\n` +
                     `━━━━━━━━━━━━━━\n` +
                     `${isOption1Winner ? "✅ " : ""}1️⃣ ${handleReply.option1}\n` +
                     `${drawBar(p1)}\n\n` +
                     `${!isOption1Winner ? "✅ " : ""}2️⃣ ${handleReply.option2}\n` +
                     `${drawBar(p2)}\n` +
                     `━━━━━━━━━━━━━━\n` +
                     `💡 عالمياً، الأغلبية اختارت الخيار ${winnerText}!\n` +
                     `${resultMsg}`;

    api.unsendMessage(handleReply.messageID);
    return api.sendMessage(finalMsg, threadID, messageID);
};