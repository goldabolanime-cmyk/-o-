module.exports.config = {
  name: "فيس",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "تَـنْـزِيلُ اَلْـفِيـدْيُو أَوِ اَلـصَّـوْتِ مِـنَ اَلْـفَيْـسْبُوكْ",
  commandCategory: "خدمات",
  usages: "[صوت/فيديو] [رابط الفيديو]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const axios = require('axios');
  const fs = require("fs-extra");
  const { threadID, messageID } = event;

  if (!args[0] || !args[1]) {
    return api.sendMessage(`┏━━━━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑭𝑩 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫 ♛\n┗━━━━━━━━━━━━━━━━━━━━┛\n\n💡 ┃ يُـرْجَى اِسْـتِخْـدَامُ اَلْأَمْرِ هَكَـذَا:\n👈 [ فيس فيديو + رابط ]\n👈 [ فيس صوت + رابط ]\n\n🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`, threadID, messageID);
  }

  const type = args[0].toLowerCase();
  const url = args[1];
  const path = __dirname + `/cache/fb_rio.${type === 'صوت' ? 'mp3' : 'mp4'}`;

  api.sendMessage(`⏳ ┃ جَـارِي تَـحْمِيـلِ اَلـ${type === 'صوت' ? 'صَّـوْتِ' : 'فِيـدْيُو'} اَلْـمَلَـكِي، اِنْـتَظِـرْ يَا عـبـدو...`, threadID, messageID);

  try {
    // استعمال API فعال لتنزيل فيديوهات الفيسبوك
    const res = await axios.get(`https://api.vyturex.com/facebook?url=${encodeURIComponent(url)}`);
    const downloadUrl = res.data.video || res.data.audio;

    if (!downloadUrl) throw new Error("Link not found");

    const getFile = (await axios.get(downloadUrl, { responseType: 'arraybuffer' })).data;
    fs.writeFileSync(path, Buffer.from(getFile, "utf-8"));

    return api.sendMessage({
      body: `┏━━━━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑬𝑫 ♛\n┗━━━━━━━━━━━━━━━━━━━━┛\n\n✅ ┃ تَـمَّ اَلـتَّحْـمِيـلُ بِـنَـجَاحٍ\n✨ ┃ اَلـنَّـوْعُ: 『 ${type} 』\n\n🔱 ┃ بِـوَاسِـطَـةِ: عـبـدو`,
      attachment: fs.createReadStream(path)
    }, threadID, () => fs.unlinkSync(path), messageID);

  } catch (err) {
    console.error(err);
    return api.sendMessage(`❌ ┃ عـذراً يَا عـبـدو، مَـا قْـدَرْتـشْ نْـنَـزّلْ اَلـفِيـدْيُو. تَـأَكَّـدْ أَنَّ اَلـرَّابِـطَ عَـامٌّ (Public).`, threadID, messageID);
  }
};