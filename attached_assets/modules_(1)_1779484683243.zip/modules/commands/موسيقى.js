const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "تيك_موسيقى",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "اِسْتِخْرَاجُ اَلْمُوسِيقَى وَاَلْأَغَانِي مِـنْ تِيـكْ تُـوكْ بِنِـظَـامٍ مَـلَـكِيٍّ",
  commandCategory: "الوسائط",
  usages: "[كلمة بحث] أو [رابط المقطع]",
  cooldowns: 10
};

const TIKWM_BASE = "https://www.tikwm.com";
const cacheDir = path.join(__dirname, "cache");

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const choice = parseInt(body);
  if (isNaN(choice) || choice < 1 || choice > handleReply.videos.length) {
    return api.sendMessage("⚠️ ┃ سَـيِّـدِي ، اِخْـتَـرْ رَقْـمـاً صَـحِيـحاً مِـنَ اَلْـقَـائِـمَـةِ.", threadID, messageID);
  }

  const video = handleReply.videos[choice - 1];
  api.sendMessage("⏳ ┃ جَـارِي اِسْـتِخْـرَاجُ اَلـصَّـوْتِ مِـنْ سِـيـرْفَـرَاتِ تِيـكْ تُـوكْ . . .", threadID, messageID);

  try {
    const musicUrl = TIKWM_BASE + video.music; // جلب رابط الموسيقى مباشرة
    const filePath = path.join(cacheDir, `tikaudio_${senderID}_${Date.now()}.mp3`);
    
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

    const res = await axios.get(musicUrl, { responseType: "arraybuffer", timeout: 30000 });
    fs.writeFileSync(filePath, Buffer.from(res.data));

    return api.sendMessage({
      body: `✅ ┃ تَـمَّ اِسْـتِخْـرَاجُ اَلـصَّـوْتِ بِنَـجَـاحٍ\n━━━━━━━━━━━━━━━\n🎵 ┃ اَلْأُغْـنِيَّـةُ: ${video.music_info.title}\n👤 ┃ اَلْـفَـنَّـانُ: ${video.music_info.author}\n⏱️ ┃ اَلـمُـدَّةُ: ${video.duration} ثانية\n━━━━━━━━━━━━━━━\n👑 ┃ رِيُـو بُـوت - طَـرَبُ اَلـتِّيـكْ تُـوكْ`,
      attachment: fs.createReadStream(filePath)
    }, threadID, () => {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ فَـشَـلَ جَـلْبُ اَلْـمُوسِيـقَى، جَـرِّبْ مَـرَّةً أُخْـرَى.", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const input = args.join(" ");

  if (!input) return api.sendMessage(
    "⚠️ ┃ سَـيِّـدِي ، أَدْخِـلْ اِسْمَ اَلْأُغْـنِيَّـةِ أَوْ رَابِـطَ اَلْـمَقْـطَعِ.\n━━━━━━━━━━━━━━━\n📌 ┃ مِـثَـال: .تيك_موسيقى أغنية حزينة",
    threadID, messageID
  );

  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  // التحميل المباشر عبر الرابط
  if (input.includes("tiktok.com")) {
    api.sendMessage("⏳ ┃ جَـارِي جَـلْبُ اَلـصَّـوْتِ مِـنَ اَلـرَّابِـطِ . . .", threadID, messageID);
    try {
      const res = await axios.post(TIKWM_BASE + "/api/",
        new URLSearchParams({ url: input }),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" }, timeout: 15000 }
      );

      const data = res.data?.data;
      if (!data || !data.music) throw new Error("لم يتم جلب الموسيقى");

      const musicUrl = data.music;
      const filePath = path.join(cacheDir, `tikaudio_${senderID}_${Date.now()}.mp3`);

      const musicRes = await axios.get(musicUrl, { responseType: "arraybuffer", timeout: 30000 });
      fs.writeFileSync(filePath, Buffer.from(musicRes.data));

      return api.sendMessage({
        body: `✅ ┃ تَـمَّ اَلـتَّحْـمِيـلُ بِنَـجَـاحٍ\n━━━━━━━━━━━━━━━\n🎵 ┃ اَلـلَّحْـنُ: ${data.music_info.title}\n👤 ┃ اَلـنَّـاشِـرُ: ${data.author.nickname}\n━━━━━━━━━━━━━━━\n👑 ┃ رِيُـو بُـوت - نِـظَـامُ اَلـصَّـوْتِ`,
        attachment: fs.createReadStream(filePath)
      }, threadID, () => {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      }, messageID);

    } catch (e) {
      return api.sendMessage("❌ ┃ اَلـرَّابِـطُ غَـيْـرُ صَـحِيـحٍ أَوْ لَا يَـحْتَـوِي عَـلَى صَوْتٍ مَـتَـاحٍ.", threadID, messageID);
    }
  }

  // البحث بالكلمات
  api.sendMessage("🔍 ┃ جَـارِي اَلْـبَحْـثُ عَنْ مَـقَـاطِـعَ صَـوْتِيَّـةٍ . . .", threadID, messageID);
  try {
    const searchRes = await axios.get(
      `${TIKWM_BASE}/api/feed/search?keywords=${encodeURIComponent(input)}&count=6&web=1`,
      { timeout: 15000 }
    );

    const videos = searchRes.data?.data?.videos || [];
    if (videos.length === 0) return api.sendMessage("❌ ┃ لَـمْ أَجِـدْ أَيَّ أُغْـنِيَّـةٍ بِـهَـذَا اَلِاسْمِ.", threadID, messageID);

    let msg = `┏━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑻𝑰𝑲𝑻𝑶𝑲 𝑴𝑼𝑺𝑰𝑪 ♛\n┗━━━━━━━━━━━━━━━━━┛\n🔍 ┃ اَلْـبَحْـثُ: [ ${input} ]\n━━━━━━━━━━━━━━━\n\n`;

    videos.forEach((v, i) => {
      msg += `【 ${i + 1} 】 🎵 ${v.music_info.title.slice(0, 45)}\n`;
      msg += `👤 ┃ اَلْـفَـنَّـانُ: ${v.music_info.author}\n`;
      msg += `━━━━━━━━━━━━━━━\n`;
    });

    msg += "📥 ┃ رُدَّ بِـرَقْـمِ اَلْأُغْـنِيَّـةِ لِـتَحْـمِيـلِـهَا MP3.";

    return api.sendMessage(msg, threadID, (err, info) => {
      if (!global.client.handleReply) global.client.handleReply = [];
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        videos
      });
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي اَلِاتِّـصَـالِ بِمَـكْتَـبَـةِ اَلـتِّيـكْ تُـوكْ.", threadID, messageID);
  }
};