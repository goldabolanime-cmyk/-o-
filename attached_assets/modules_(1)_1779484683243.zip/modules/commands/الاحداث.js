const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
    name: "الأحداث",
    version: "3.0.0",
    hasPermssion: 2,
    credits: "عبدو / RIO BOT",
    description: "إدارة متكاملة للأحداث: تفعيل، تعطيل، عرض الكود، وتعديله مباشرة",
    commandCategory: "نظام",
    usages: "[تفعيل/تعطيل/معلومات/عرض/تعديل] + الرقم",
    cooldowns: 5
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
    const { threadID, messageID, body, senderID } = event;
    const { eventFiles, folderPath, configPath, type, eventFileName } = handleReply;

    // 1. منطق التعديل (عندما يرسل المستخدم الكود الجديد)
    if (type === "editing") {
        if (senderID !== handleReply.author) return;
        try {
            const filePath = path.join(folderPath, eventFileName);
            fs.writeFileSync(filePath, body, "utf-8");
            return api.sendMessage(`✅ ┃ سَـيِّـدِي عـبـدو، تَمَّ تَـحْـدِيـثُ كُـودِ اَلْـحَـدَثِ [ ${eventFileName} ] بِنَـجَـاحٍ.\n\n⚠️ مـلاحظة: يـرجى إعـادة تـشـغـيـل الـبوت (Restart).`, threadID, messageID);
        } catch (e) {
            return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ أثْـنَـاءَ حِـفْـظِ اَلْـمَـلَفِّ.", threadID, messageID);
        }
    }

    // 2. منطق الأوامر الأساسية (تفعيل، تعطيل، معلومات، عرض، تعديل)
    const input = body.trim().split(/\s+/);
    const action = input[0];
    const index = parseInt(input[1]) - 1;

    const validActions = ["تفعيل", "تعطيل", "معلومات", "عرض", "تعديل"];
    if (!validActions.includes(action) || isNaN(index) || index < 0 || index >= eventFiles.length) {
        return api.sendMessage("⚠️ ┃ رِيُـو يـقول: يـرجى إدخـال أمـر صـحيح ورقـم الـملف، مـثل: (عرض 1)", threadID, messageID);
    }

    const selectedFile = eventFiles[index];
    const eventName = selectedFile.replace(".js", "");
    const fullPath = path.join(folderPath, selectedFile);

    // --- ميزة عرض الكود ---
    if (action === "عرض") {
        try {
            const content = fs.readFileSync(fullPath, "utf-8");
            return api.sendMessage(`📄 ┃ كُـودُ اَلْـحَـدَثِ [ ${selectedFile} ]:\n\n${content}`, threadID, messageID);
        } catch (e) {
            return api.sendMessage("❌ ┃ فَـشَـلَ فِـي قِـرَاءَةِ اَلْـمَـلَفِّ.", threadID, messageID);
        }
    }

    // --- ميزة التعديل ---
    if (action === "تعديل") {
        return api.sendMessage(`📝 ┃ سَـيِّـدِي عـبـدو، أَرْسِـلِ اَلْـكُـودَ اَلْـجَـدِيـدَ لِـلْـحَـدَثِ [ ${selectedFile} ] اَلآنَ . . .`, threadID, (err, info) => {
            global.client.handleReply.push({
                name: this.config.name,
                messageID: info.messageID,
                author: senderID,
                type: "editing",
                eventFileName: selectedFile,
                folderPath
            });
        }, messageID);
    }

    // --- ميزة المعلومات ---
    if (action === "معلومات") {
        try {
            const eventModule = require(fullPath);
            const conf = eventModule.config;
            const infoMsg = `┏━━━━━━━━━━━━━━┓\n  ℹ️ ┃ مَـعْـلُومَاتُ اَلْـحَـدَثِ\n┗━━━━━━━━━━━━━━┛\n\n📝 ┃ اَلِاسْـمُ: ${conf.name || eventName}\n💎 ┃ اَلْإِصْـدَارُ: ${conf.version || "1.0.0"}\n👤 ┃ اَلْـمُـطَـوِّرُ: ${conf.credits || "غير معروف"}\n📖 ┃ اَلْـوَصْـفُ: ${conf.description || "لا يوجد وصف"}\n\n━━━━━━━━━━━━━━━\n👑 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;
            return api.sendMessage(infoMsg, threadID, messageID);
        } catch (e) {
            return api.sendMessage("❌ ┃ فَـشَـلَ فِـي جَـلْبِ مَـعْـلُومَاتِ اَلْـمُـدْيُـولِ.", threadID, messageID);
        }
    }

    // --- ميزة التفعيل والتعطيل ---
    if (action === "تفعيل" || action === "تعطيل") {
        try {
            let config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
            if (!config.eventDisabled) config.eventDisabled = [];
            const isDisabled = config.eventDisabled.includes(eventName);

            if (action === "تفعيل") {
                if (!isDisabled) return api.sendMessage(`💡 ┃ اَلْـحَـدَثُ [ ${eventName} ] مُـفَـعَّـلٌ مسبقاً.`, threadID, messageID);
                config.eventDisabled = config.eventDisabled.filter(e => e !== eventName);
            } else {
                if (isDisabled) return api.sendMessage(`💡 ┃ اَلْـحَـدَثُ [ ${eventName} ] مُـعَـطَّـلٌ مسبقاً.`, threadID, messageID);
                config.eventDisabled.push(eventName);
            }

            fs.writeFileSync(configPath, JSON.stringify(config, null, 4));
            return api.sendMessage(`✨ ┃ تَمَّ ${action} اَلْـحَـدَثِ [ ${eventName} ] بِنَـجَـاحٍ.`, threadID, messageID);
        } catch (e) {
            return api.sendMessage("❌ ┃ خَـطَأٌ فِـي مَـلَفِّ الإعدادات.", threadID, messageID);
        }
    }
};

module.exports.run = async function ({ api, event }) {
    const { threadID, messageID } = event;

    // مسارات Replit الافتراضية
    const folderPath = path.join(__dirname, "..", "events");
    const configPath = path.join(__dirname, "..", "..", "config.json");

    if (!fs.existsSync(folderPath)) return api.sendMessage("❌ ┃ مَـسَـارُ اَلْأَحْـدَاثِ غَـيْـرُ صَـحِيـحٍ.", threadID, messageID);

    const eventFiles = fs.readdirSync(folderPath).filter(file => file.endsWith(".js"));
    if (eventFiles.length === 0) return api.sendMessage("📭 ┃ لَا تُـوجَـدُ أَحْـدَاثٌ.", threadID, messageID);

    let msg = `┏━━━━━━━━━━━━━━┓\n  ⚙️ ┃ إِدَارَةُ أَحْـدَاثِ رِيُـو\n┗━━━━━━━━━━━━━━┛\n\n`;
    eventFiles.forEach((file, i) => {
        msg += `${i + 1} ❯ ${file.replace(".js", "")}\n`;
    });

    msg += `\n━━━━━━━━━━━━━━━\n💡 ┃ رُدَّ بِـ: [تعطيل/تفعيل/معلومات/عرض/تعديل] + الرقم\n━━━━━━━━━━━━━━━\n👑 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;

    return api.sendMessage(msg, threadID, (err, info) => {
        global.client.handleReply.push({
            name: this.config.name,
            messageID: info.messageID,
            author: event.senderID,
            eventFiles,
            folderPath,
            configPath
        });
    }, messageID);
};