module.exports.config = {
  name: "رمضان",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "عمر & ريو بوت",
  description: "نظام رمضان الذكي بتوقيت المغرب - دقة عالية",
  commandCategory: "خدمات",
  cooldowns: 5
};

module.exports.run = function ({ event, api }) {
    const { threadID, messageID } = event;
    
    // ضبط الوقت بناءً على توقيت المغرب (نظام GMT)
    // ملاحظة: JavaScript تعتمد التوقيت العالمي، سنقوم بالتعديل ليتناسب مع المغرب
    const now = new Date();
    const moroccoTime = new Date(now.toLocaleString("en-US", {timeZone: "Africa/Casablanca"}));

    // تواريخ ثابتة بناءً على رؤية 2026
    const firstDayOfRamadan = new Date("February 18, 2026 00:00:00"); 
    const eidAlFitr = new Date("March 20, 2026 00:00:00"); // المتوقع لعيد الفطر في المغرب

    // قائمة النفحات الرمضانية الملكية
    const quotes = [
        "خلوف فم الصائم أطيب عند الله من ريح المسك.",
        "اللهم إنك عفو تحب العفو فاعف عنا.",
        "الصيام ليس مجرد امتناع عن الأكل، بل هو تهذيب للروح.",
        "في أواخر رمضان، اجتهد لعلها تكون ليلة القدر.",
        "تسحروا فإن في السحور بركة."
    ];
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

    // دالة حساب الفارق الزمني
    function getTimeDiff(target) {
        const t = Date.parse(target) - Date.parse(moroccoTime);
        return {
            total: t,
            days: Math.floor(t / (1000 * 60 * 60 * 24)),
            hours: Math.floor((t / (1000 * 60 * 60)) % 24),
            minutes: Math.floor((t / (1000 * 60)) % 60),
            seconds: Math.floor((t / 1000) % 60)
        };
    }

    let msg = "";

    // التحقق إذا كنا في رمضان (بناءً على تاريخ اليوم 16 مارس = 26 رمضان)
    if (moroccoTime >= firstDayOfRamadan && moroccoTime < eidAlFitr) {
        const diffEid = getTimeDiff(eidAlFitr);
        
        // حساب يوم رمضان بدقة (16 مارس هو اليوم الـ 26)
        const dayOfRamadan = Math.floor((moroccoTime - firstDayOfRamadan) / (1000 * 60 * 60 * 24)) + 1;

        msg = `『 ♚ ┋ ديـوان رمـضـان - الـمـغـرب ┋ ♚ 』\n` +
              `━━━━━━━━━━━━━━\n` +
              `🌙 ┋ الـيـوم الـمـبـارك: الـيـوم ${dayOfRamadan} رمـضـان\n` +
              `⏰ ┋ تـوقـيـت الـمـغرب: ${moroccoTime.getHours()}:${moroccoTime.getMinutes().toString().padStart(2, '0')}\n` +
              `🎊 ┋ الـمـتبقي لـلـعـيد: ${diffEid.days} أيام و ${diffEid.hours} ساعة\n` +
              `━━━━━━━━━━━━━━\n` +
              `✨ ┋ نـفـحـات رمـضـانـيـة:\n` +
              `💬 "${randomQuote}"\n` +
              `━━━━━━━━━━━━━━\n` +
              `💡 ┋ تقبل الله صيامكم بمزيد من الأجر والمغفرة\n` +
              `『 ♚ ┋ ريـو بـوت الـمـلـكـي ┋ ♚ 』`;
    } 
    else {
        // في حال انتهى رمضان أو لم يبدأ بعد
        const diffRamadan = getTimeDiff(new Date("February 8, 2027 00:00:00")); // رمضان القادم
        msg = `『 ♚ ┋ ريـو بـوت الـمـلـكـي ┋ ♚ 』\n` +
              `━━━━━━━━━━━━━━\n` +
              `⏳ ┋ رمضان انتهى أو لم يحن بعد..\n` +
              `المتبقي لرمضان القادم:\n` +
              `» ${diffRamadan.days} يـوم و ${diffRamadan.hours} سـاعـة\n` +
              `━━━━━━━━━━━━━━\n` +
              `『 ♚ ┋ حـفـظ الله الـمـغـرب ┋ ♚ 』`;
    }

    return api.sendMessage(msg, threadID, messageID);
};