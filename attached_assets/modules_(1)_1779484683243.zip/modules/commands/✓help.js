const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "اوامر",
  version: "3.5.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "قائمة الأوامر الملكية المتطورة - ريو بوت",
  commandCategory: "نظام",
  usages: "[الكل / رقم الصفحة / اسم الأمر]",
  cooldowns: 5,
  envConfig: {
    autoUnsend: true,
    delayUnsend: 60 
  }
};

module.exports.run = async function({ api, event, args }) {
  const { commands } = global.client;
  const { threadID, messageID, senderID } = event;
  const threadSetting = global.data.threadData.get(parseInt(threadID)) || {};
  const prefix = (threadSetting.hasOwnProperty("PREFIX")) ? threadSetting.PREFIX : global.config.PREFIX;

  const input = (args[0] || "").toLowerCase();
  const allCommands = Array.from(commands.keys());
  
  // روابط الوسائط
  const gifUrl = "https://i.postimg.cc/Y9kmYYKB/kakashi-hatake-falling-snow-anime-naruto-gif-preview-desktop-wallpaper.gif";
  const normalImages = [
    "https://i.postimg.cc/y8djSqXC/e83669f7ec2be41c19f95560ec13276a-fgraphic-1.jpg"
  ];

  let imageUrl = normalImages[Math.floor(Math.random() * normalImages.length)];
  let isAll = false;

  // --- 1. عرض تفاصيل أمر محدد ---
  if (input && commands.has(input)) {
    const command = commands.get(input);
    const config = command.config;
    const permission = (config.hasPermssion == 0) ? "مستخدم عادي" : (config.hasPermssion == 1) ? "أدمن المجموعة" : "المطور الأساسي";

    const infoMsg = `╭───────────────◊
•——[تـفـاصـيـل الأمـر]——•
❏ الإسم : 『${config.name}』
❏ الوصف : 『${config.description || "لا يوجد وصف"}』
❏ الفئة : 『${config.commandCategory}』
❏ الإستخدام : 『${prefix}${config.name} ${config.usages || ""}』
❏ الإنتظار : 『${config.cooldowns} ثانية』
❏ الصلاحية : 『${permission}』
╰───────────────◊`;
    
    return api.sendMessage(infoMsg, threadID, messageID);
  }

  // --- 2. إعداد النصوص والوسائط بناءً على المدخل ---
  let menuText = `╭───────────────◊\n•——[قائمة جميع الأوامر]——•\n`;
  let pageInfo = "";

  if (input === "الكل") {
    isAll = true;
    imageUrl = gifUrl; // استخدام الـ GIF حصراً في خيار الكل
    for (let cmd of allCommands) {
      menuText += `❏ الإسم : 『${cmd}』\n`;
    }
    pageInfo = `❏ الـنـمـط : 『عـرض الـكـل』\n`;
  } else {
    // نظام الصفحات
    const page = parseInt(input) || 1;
    const commandsPerPage = 30;
    const totalPages = Math.ceil(allCommands.length / commandsPerPage);

    if (page > totalPages || page < 1) return api.sendMessage(`⚠️ ┃ عذراً يا سيدي، الصفحة ${page} غير موجودة. المتاح من 1 إلى ${totalPages}.`, threadID, messageID);

    let start = (page - 1) * commandsPerPage;
    let end = start + commandsPerPage;
    let pageCommands = allCommands.slice(start, end);

    for (let cmd of pageCommands) {
      menuText += `❏ الإسم : 『${cmd}』\n`;
    }
    pageInfo = `❏ الصفحة : 『${page}/${totalPages}』\n`;
  }

  menuText += `━━━━━━━━━━━━━━━━\n`;
  menuText += `❏ إجمالي الأوامر : 『${allCommands.length}』\n`;
  menuText += pageInfo;
  menuText += `❏ المطور : 『عبدو』\n`;
  menuText += `❏ الـبـوت : 『ريـو بُـوت』\n`;
  menuText += `╰───────────────◊`;

  const path = __dirname + `/cache/rio_menu_${senderID}.${imageUrl.split('.').pop()}`;

  try {
    const response = await axios.get(imageUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(path, Buffer.from(response.data, "utf-8"));

    return api.sendMessage({
      body: menuText,
      attachment: fs.createReadStream(path)
    }, threadID, async (error, info) => {
      if (fs.existsSync(path)) fs.unlinkSync(path);
      if (this.config.envConfig.autoUnsend && info) {
        await new Promise(resolve => setTimeout(resolve, this.config.envConfig.delayUnsend * 1000));
        return api.unsendMessage(info.messageID);
      }
    }, messageID);
  } catch (e) {
    return api.sendMessage(menuText, threadID, messageID);
  }
};