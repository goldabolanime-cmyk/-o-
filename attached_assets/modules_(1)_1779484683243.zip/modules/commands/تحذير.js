const fs = require("fs-extra");
const path = __dirname + "/cache/warns.json";

module.exports.config = {
  name: "تحذير",
  version: "1.0.0",
  hasPermssion: 1, // لآدمن البوت والمجموعات
  credits: "عبدو / RIO BOOT",
  description: "نظام تحذيرات ريو الملكي مع طرد آلي",
  commandCategory: "إدارة",
  usages: "[الرد على المستخدم]",
  cooldowns: 5,
  dependencies: { "fs-extra": "" }
};

// إنشاء قاعدة البيانات إذا لم توجد
if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));

module.exports.run = async function({ api, event, args, Users }) {
  const { threadID, messageID, senderID, messageReply, type } = event;
  const devID = "100090081489341"; // آيدي المطور عبدو

  // 1. التحقق من الرد على رسالة
  if (type !== "message_reply") {
    return api.sendMessage("⚠️ ┃ يـرجـى الـرد عـلـى رسـالـة الـشـخـص الـمـراد تـحـذيـره.", threadID, messageID);
  }

  const targetID = messageReply.senderID;

  // 2. حماية المطور عبدو
  if (targetID == devID) {
    return api.sendMessage("👑 ┃ هـل تـحـاول تـحـذير الـمـطـور عـبـدو؟\n⚖️ ┃ الـقـانـون لـا يـطـبـق عـلـى صـانـع الـنـظـام يا صديقي.", threadID, messageID);
  }

  // 3. منع البوت من تحذير نفسه أو الآدمن من تحذير نفسه
  if (targetID == api.getCurrentUserID()) return;
  if (targetID == senderID) return api.sendMessage("⚠️ ┃ لـا يـمـكـنـك تـحـذير نـفـسـك.", threadID, messageID);

  // 4. معالجة البيانات
  let data = JSON.parse(fs.readFileSync(path));
  if (!data[threadID]) data[threadID] = {};
  if (!data[threadID][targetID]) data[threadID][targetID] = 0;

  data[threadID][targetID]++;
  const warnsCount = data[threadID][targetID];

  // إعداد شريط التحذير البصري
  let bar = "";
  if (warnsCount == 1) bar = " [ ⚠️ ⬛ ⬛ ]";
  if (warnsCount == 2) bar = " [ ⚠️ ⚠️ ⬛ ]";
  if (warnsCount == 3) bar = " [ ⚠️ ⚠️ ⚠️ ]";

  const targetName = await Users.getNameUser(targetID);

  // 5. حالة الوصول للحد الأقصى (الطرد)
  if (warnsCount >= 3) {
    delete data[threadID][targetID]; // تصفير التحذيرات بعد الطرد
    fs.writeFileSync(path, JSON.stringify(data, null, 2));

    api.sendMessage(`🚫 ┃ تـم اسـتـبـعـاد مـسـتـخـدم زاد عـن حـده\n━━━━━━━━━━━━━━━\n👤 ┃ الـاسـم: ${targetName}\n🆔 ┃ الـآيـدي: ${targetID}\n⚖️ ┃ الـسـبـب: تـجـاوز 3 تـحـذيـرات أمـنـيـة.\n━━━━━━━━━━━━━━━\n⌛ ┃ جـاري الـطـرد الـفـوري...`, threadID, () => {
      api.removeUserFromGroup(targetID, threadID);
    });
  } else {
    // 6. إرسال تحذير عادي
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
    return api.sendMessage(`⚠️ ┃ نـظـام تـحـذيـرات ريـو ┃ ⚠️\n━━━━━━━━━━━━━━━\n👤 ┃ الـمـحـذر: ${targetName}\n📈 ┃ الـمـسـتـوى: ${warnsCount}/3\n📊 ┃ الـحـالـة: ${bar}\n━━━━━━━━━━━━━━━\n❗ ┃ عـنـد الـوصـول لـلـتـحـذير الـثـالـث سـتـطـرد تـلـقـائـيـاً.`, threadID, messageID);
  }
};