const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "اعلام",
  version: "9.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "لعبة الأعلام: جائزة 90-110$ | خصم 50$ عند الفشل بعد 2د",
  commandCategory: "تسلية",
  usages: ".اعلام",
  cooldowns: 5
};

module.exports.run = async function({ api, event, Currencies }) {
  const { threadID, messageID, senderID } = event;
  const pathImg = __dirname + "/cache/rio_flag.png";

  const flagDatabase = [
    // --- القائمة الكاملة التي زودتني بها يا عبدو ---
    { name: "المغرب", link: "https://flagcdn.com/w640/ma.png" },
    { name: "مصر", link: "https://flagcdn.com/w640/eg.png" },
    { name: "السعودية", link: "https://flagcdn.com/w640/sa.png" },
    { name: "الجزائر", link: "https://flagcdn.com/w640/dz.png" },
    { name: "تونس", link: "https://flagcdn.com/w640/tn.png" },
    { name: "فلسطين", link: "https://flagcdn.com/w640/ps.png" },
    { name: "العراق", link: "https://flagcdn.com/w640/iq.png" },
    { name: "سوريا", link: "https://flagcdn.com/w640/sy.png" },
    { name: "لبنان", link: "https://flagcdn.com/w640/lb.png" },
    { name: "الأردن", link: "https://flagcdn.com/w640/jo.png" },
    { name: "الكويت", link: "https://flagcdn.com/w640/kw.png" },
    { name: "الإمارات", link: "https://flagcdn.com/w640/ae.png" },
    { name: "قطر", link: "https://flagcdn.com/w640/qa.png" },
    { name: "البحرين", link: "https://flagcdn.com/w640/bh.png" },
    { name: "عمان", link: "https://flagcdn.com/w640/om.png" },
    { name: "اليمن", link: "https://flagcdn.com/w640/ye.png" },
    { name: "ليبيا", link: "https://flagcdn.com/w640/ly.png" },
    { name: "السودان", link: "https://flagcdn.com/w640/sd.png" },
    { name: "موريتانيا", link: "https://flagcdn.com/w640/mr.png" },
    { name: "جيبوتي", link: "https://flagcdn.com/w640/dj.png" },
    { name: "الصومال", link: "https://flagcdn.com/w640/so.png" },
    { name: "جزر القمر", link: "https://flagcdn.com/w640/km.png" },
    { name: "فرنسا", link: "https://flagcdn.com/w640/fr.png" },
    { name: "إسبانيا", link: "https://flagcdn.com/w640/es.png" },
    { name: "ألمانيا", link: "https://flagcdn.com/w640/de.png" },
    { name: "إيطاليا", link: "https://flagcdn.com/w640/it.png" },
    { name: "البرازيل", link: "https://flagcdn.com/w640/br.png" },
    { name: "الأرجنتين", link: "https://flagcdn.com/w640/ar.png" },
    { name: "اليابان", link: "https://flagcdn.com/w640/jp.png" },
    { name: "البرتغال", link: "https://flagcdn.com/w640/pt.png" },
    { name: "تركيا", link: "https://flagcdn.com/w640/tr.png" },
    { name: "روسيا", link: "https://flagcdn.com/w640/ru.png" },
    { name: "بريطانيا", link: "https://flagcdn.com/w640/gb.png" },
    { name: "الولايات المتحدة", link: "https://flagcdn.com/w640/us.png" },
    { name: "الصين", link: "https://flagcdn.com/w640/cn.png" },
    { name: "كندا", link: "https://flagcdn.com/w640/ca.png" },
    { name: "أستراليا", link: "https://flagcdn.com/w640/au.png" },
    { name: "كوريا الجنوبية", link: "https://flagcdn.com/w640/kr.png" },
    { name: "المكسيك", link: "https://flagcdn.com/w640/mx.png" },
    { name: "الهند", link: "https://flagcdn.com/w640/in.png" },
    { name: "هولندا", link: "https://flagcdn.com/w640/nl.png" },
    { name: "بلجيكا", link: "https://flagcdn.com/w640/be.png" },
    { name: "سويسرا", link: "https://flagcdn.com/w640/ch.png" },
    { name: "النمسا", link: "https://flagcdn.com/w640/at.png" },
    { name: "اليونان", link: "https://flagcdn.com/w640/gr.png" },
    { name: "السويد", link: "https://flagcdn.com/w640/se.png" },
    { name: "النرويج", link: "https://flagcdn.com/w640/no.png" },
    { name: "الدنمارك", link: "https://flagcdn.com/w640/dk.png" },
    { name: "كرواتيا", link: "https://flagcdn.com/w640/hr.png" },
    { name: "بولندا", link: "https://flagcdn.com/w640/pl.png" },
    { name: "أوكرانيا", link: "https://flagcdn.com/w640/ua.png" },
    { name: "إيران", link: "https://flagcdn.com/w640/ir.png" },
    { name: "باكستان", link: "https://flagcdn.com/w640/pk.png" },
    { name: "إندونيسيا", link: "https://flagcdn.com/w640/id.png" },
    { name: "ماليزيا", link: "https://flagcdn.com/w640/my.png" },
    { name: "تايلاند", link: "https://flagcdn.com/w640/th.png" },
    { name: "جنوب أفريقيا", link: "https://flagcdn.com/w640/za.png" },
    { name: "نيجيريا", link: "https://flagcdn.com/w640/ng.png" },
    { name: "السنغال", link: "https://flagcdn.com/w640/sn.png" },
    { name: "الكاميرون", link: "https://flagcdn.com/w640/cm.png" },
    { name: "غانا", link: "https://flagcdn.com/w640/gh.png" },
    { name: "ساحل العاج", link: "https://flagcdn.com/w640/ci.png" },
    { name: "أوروغواي", link: "https://flagcdn.com/w640/uy.png" },
    { name: "كولومبيا", link: "https://flagcdn.com/w640/co.png" },
    { name: "تشيلي", link: "https://flagcdn.com/w640/cl.png" },
    { name: "بيرو", link: "https://flagcdn.com/w640/pe.png" },
    { name: "فنلندا", link: "https://flagcdn.com/w640/fi.png" },
    { name: "أيرلندا", link: "https://flagcdn.com/w640/ie.png" },
    { name: "آيسلندا", link: "https://flagcdn.com/w640/is.png" },
    { name: "رومانيا", link: "https://flagcdn.com/w640/ro.png" },
    { name: "تشيكيا", link: "https://flagcdn.com/w640/cz.png" },
    { name: "المجر", link: "https://flagcdn.com/w640/hu.png" },
    { name: "نيوزيلندا", link: "https://flagcdn.com/w640/nz.png" },
    { name: "سنغافورة", link: "https://flagcdn.com/w640/sg.png" },
    { name: "صربيا", link: "https://flagcdn.com/w640/rs.png" },
    { name: "أفغانستان", link: "https://flagcdn.com/w640/af.png" },
    { name: "فيتنام", link: "https://flagcdn.com/w640/vn.png" },
    { name: "مالي", link: "https://flagcdn.com/w640/ml.png" },
    { name: "غينيا", link: "https://flagcdn.com/w640/gn.png" },
    { name: "كوبا", link: "https://flagcdn.com/w640/cu.png" },
    { name: "جامايكا", link: "https://flagcdn.com/w640/jm.png" },
    { name: "بنما", link: "https://flagcdn.com/w640/pa.png" },
    { name: "باراغواي", link: "https://flagcdn.com/w640/py.png" },
    { name: "ألبانيا", link: "https://flagcdn.com/w640/al.png" },
    { name: "بلغاريا", link: "https://flagcdn.com/w640/bg.png" },
    { name: "قبرص", link: "https://flagcdn.com/w640/cy.png" },
    { name: "جورجيا", link: "https://flagcdn.com/w640/ge.png" },
    { name: "أذربيجان", link: "https://flagcdn.com/w640/az.png" },
    { name: "أرمينيا", link: "https://flagcdn.com/w640/am.png" },
    { name: "كازاخستان", link: "https://flagcdn.com/w640/kz.png" },
    { name: "أوزبكستان", link: "https://flagcdn.com/w640/uz.png" },
    { name: "الفلبين", link: "https://flagcdn.com/w640/ph.png" },
    { name: "سريلانكا", link: "https://flagcdn.com/w640/lk.png" },
    { name: "كينيا", link: "https://flagcdn.com/w640/ke.png" },
    { name: "إثيوبيا", link: "https://flagcdn.com/w640/et.png" },
    { name: "مدغشقر", link: "https://flagcdn.com/w640/mg.png" },
    { name: "لوكسمبورغ", link: "https://flagcdn.com/w640/lu.png" },
    { name: "سان مارينو", link: "https://flagcdn.com/w640/sm.png" },
    { name: "أندورا", link: "https://flagcdn.com/w640/ad.png" },
    { name: "موناكو", link: "https://flagcdn.com/w640/mc.png" }
  ];

  const randomFlag = flagDatabase[Math.floor(Math.random() * flagDatabase.length)];

  try {
    const response = await axios.get(randomFlag.link, { responseType: "arraybuffer" });
    fs.writeFileSync(pathImg, Buffer.from(response.data, "utf-8"));

    const msg = {
      body: `🚩 ┃ مـمـلـكـة الأعـلام ┃ 🚩\n━━━━━━━━━━━━━━━\n✨ | خـمـن اسـم هـذه الـدولـة؟\n⏳ | الـوقـت: 2 دقيقة\n💰 | الـجـائزة: 90$ - 110$\n⚠️ | الـخـصـم: 50$ لـتـأخـيـر الـبوت\n━━━━━━━━━━━━━━━\n👑 ┃ ريـو بـوت - مـطـور عـبـدو`,
      attachment: fs.createReadStream(pathImg)
    };

    return api.sendMessage(msg, threadID, (err, info) => {
      if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
      
      const gameInfo = {
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        answer: randomFlag.name,
        isResolved: false
      };
      
      global.client.handleReply.push(gameInfo);

      // مؤقت دقيقتين (120000 مللي ثانية)
      setTimeout(async () => {
        const currentReply = global.client.handleReply.find(i => i.messageID === info.messageID);
        if (currentReply && !currentReply.isResolved) {
          api.unsendMessage(info.messageID);
          await Currencies.decreaseMoney(senderID, 50);
          api.sendMessage(`⌛ | انـتـهـى الـوقـت!\n━━━━━━━━━━━━━━━\n🌍 | الإجـابـة الـصـحـيـحـة هـي: ${randomFlag.name}\n❌ | تـم خـصـم 50$ مـن حـسابـك لإضـاعـة وقـت الـبـوت.`, threadID);
          
          // إزالة من القائمة
          const index = global.client.handleReply.indexOf(currentReply);
          if (index > -1) global.client.handleReply.splice(index, 1);
        }
      }, 120000);

    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ | فشل في تحميل صورة العلم، حاول مجدداً.", threadID, messageID);
  }
};

module.exports.handleReply = async function({ api, event, handleReply, Currencies }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.name !== this.config.name) return;

  const userAnswer = body.trim().toLowerCase();
  const correctAnswer = handleReply.answer.toLowerCase();

  if (userAnswer === correctAnswer || userAnswer === `ال${correctAnswer}`) {
    handleReply.isResolved = true; // نغير الحالة لكي لا يعمل مؤقت الخصم
    const reward = Math.floor(Math.random() * (110 - 90 + 1)) + 90;
    
    await Currencies.increaseMoney(senderID, reward);

    api.unsendMessage(handleReply.messageID);
    return api.sendMessage(`✅ | إجـابـة صـحـيـحـة يـا بـطـل!\n━━━━━━━━━━━━━━━\n🌍 | الـدولـة: ${handleReply.answer}\n💰 | تـم إيـداع ${reward}$ فـي حـسـابـك الـبـنـكـي!`, threadID, messageID);
  } else {
    return api.sendMessage("❌ | إجابة خاطئة، حاول مجدداً!", threadID, messageID);
  }
};
