module.exports.config = {
  name: "اختراق",
  version: "2.7.0",
  hasPermssion: 0,
  credits: "Abdou",
  description: "محاكاة اختراق متقدمة مع تصحيح نظام كشف الجنس",
  commandCategory: "ترفيه",
  usages: "[تاغ / رد على رسالة]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args, Users }) {
  const { threadID, messageID, senderID, messageReply, type, mentions } = event;

  // 1. تحديد الضحية
  let targetID = type === "message_reply" ? messageReply.senderID : (Object.keys(mentions).length > 0 ? Object.keys(mentions)[0] : senderID);
  
  // 🛡️ هويات الحماية
  const devID = "100090081489341"; 
  const botID = api.getCurrentUserID(); 

  // ⛔ حماية المطور (عبدو)
  if (targetID == devID && senderID != devID) {
    return api.sendMessage("🛡️┃تَـوقَّفْ أَيُّـهَا الْـمُـغَفَّل! تُـحَـاوِلُ اخْـتِـرَاقَ سَـيِّـدِكَ [ Abdou ]؟\n⚠️┃تَـمَّ كَـشْفُ هُـوِيَّـتِـكَ وَتَـجْـمِيـدُ نِـظَـامِـكَ حَـالاً!", threadID, messageID);
  }

  // 🤖 حماية البوت
  if (targetID == botID) {
    return api.sendMessage("👑┃هَـلْ تَـجْرُؤُ عَـلَى اخْـتِـرَاقِي بِـأَمْـرٍ مِـنْ أَوَامِـرِي؟\n🎭┃إِنَّـكَ تَـلْـعَبُ مَـعَ الـكَـبِيـرِ.. نِـظَـامِي مُـحَصَّنٌ بِـقُـوَّةِ رِيـو بُـوت!", threadID, messageID);
  }

  try {
    const name = await Users.getNameUser(targetID);
    const userInfo = await api.getUserInfo(targetID);
    
    // 🔍 نظام كشف الجنس المضبوط
    let genderTxt = "غير محدد";
    if (userInfo[targetID]) {
      let g = userInfo[targetID].gender;
      if (g == 2 || g == "male") genderTxt = "ذكر ♂️";
      else if (g == 1 || g == "female") genderTxt = "أنثى ♀️";
    }
    
    api.sendMessage(`⌛ | جـاري الاتصال بـخوادم Meta...\n📡 | تم العثور على ثغرة في بروتوكول SSL للضحية [ ${name} ]`, threadID);

    const randomIP = () => `${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
    const randomStatus = () => Math.random() > 0.5 ? "✅ مـفـعلة" : "❌ غـير مـفـعلة";
    const devices = ["Samsung S24 Ultra", "iPhone 15 Pro Max", "Windows 11 / Chrome", "Nokia 3310"];

    setTimeout(() => {
      const report = `
┏━━━━━━━━━━━━━━━━━━┓
      💻  SYSTEM BREACH SUCCESS  💻
┗━━━━━━━━━━━━━━━━━━┛

👤 | نـظرة عامة على الـحساب:
──────────────────
● الاسم: ${name}
● الأيدي: ${targetID}
● الجنس: ${genderTxt}
● الرابط: https://facebook.com/${targetID}

🔐 | الـحماية والأمـان:
──────────────────
● المصادقة الثنائية (2FA): ${randomStatus()}
● قفل الملف الشخصي: ${randomStatus()}
● نسبة حماية الحساب: ${Math.floor(Math.random() * 40 + 10)}% (ضـعـيفة)
● آخـر IP مـسجل: ${randomIP()} [New ⚠️]

📱 | الأجهزة والاتصال:
──────────────────
● الأجهزة المتصلة حالياً: ${Math.floor(Math.random() * 3 + 1)}
● نـوع الجهاز الأساسي: ${devices[Math.floor(Math.random() * devices.length)]}
● المسكن: ${userInfo[targetID]?.vanity || "مخفي/غير محدد"}

📊 | إحصائيات الـحساب:
──────────────────
● عدد الأصدقاء: ${Math.floor(Math.random() * 4000 + 500)} صـديق
● عدد المجموعات المنضم لها: ${Math.floor(Math.random() * 100 + 20)}
● آخـر نـشاط: مـنذ ${Math.floor(Math.random() * 59 + 1)} دقيقة

⚠️ | الـبيانات الـحساسة (Encrypted):
──────────────────
[ !! ] تـم سـحب 412 رسـالة مـن الـمجموعات.
[ !! ] تـم كـشف كـلمة مـرور مـشفرة (Hash).
[ !! ] تـم الـحصول على صـور الـمعرض الـخاصة.

🛡️ | تـم تـشفير الـبيانات وإرسالها لـقاعدة بـيانات RIO BOOT.
      `;

      return api.sendMessage(report, threadID, messageID);
    }, 4000); 

  } catch (e) {
    console.log(e);
    api.sendMessage("❌ | فشل الاختراق.. الضحية يمتلك جدار حماية قوي جداً!", threadID, messageID);
  }
};