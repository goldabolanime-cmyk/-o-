const fs = require("fs-extra");
const path = __dirname + "/cache/protections.json";

module.exports.config = {
  name: "حماية",
  version: "3.1.0",
  hasPermssion: 1,
  credits: "عبدو",
  description: "نسخة الاستضافات المحدودة - حماية وطرد",
  commandCategory: "إدارة المجموعات",
  usages: "[تشغيل / ايقاف]",
  cooldowns: 5
};

// تهيئة الملف بطريقة تضمن العمل على الاستضافة
module.exports.onLoad = () => {
  if (!fs.existsSync(__dirname + "/cache")) fs.mkdirSync(__dirname + "/cache", { recursive: true });
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
};

module.exports.handleEvent = async function ({ api, event }) {
  const { threadID, logMessageType, author, isGroup, logMessageData } = event;
  if (!isGroup || !logMessageType) return;

  // استثناء عبدو والبوت
  const botID = api.getCurrentUserID();
  const admins = global.config.ADMINBOT || [];
  if (admins.includes(author) || author == botID) return;

  // قراءة البيانات بحذر
  let data = {};
  try {
    data = JSON.parse(fs.readFileSync(path));
  } catch (e) { return; }

  if (!data[threadID] || data[threadID].status == false) return;

  // وظيفة العقاب (الطرد)
  const punish = (reason) => {
    api.removeUserFromGroup(author, threadID, (err) => {
      if (!err) {
        api.sendMessage(`🚫 | ريـو يـنـفـذ الـعـدالـة!\n━━━━━━━━━━━━━━━\nتـم طـرد الـعـضـو لـمـحـاولـة: ${reason}`, threadID);
      }
    });
  };

  // مراقبة التغييرات
  if (logMessageType == "log:thread-name") {
    api.setTitle(data[threadID].namebox, threadID);
    punish("تغيير اسم المجموعة");
  } 
  else if (logMessageType == "log:thread-icon") {
    punish("تغيير صورة المجموعة");
  } 
  else if (logMessageType == "log:user-nickname" && logMessageData.participantID == botID) {
    const oldNick = data[threadID].status ? `⛔️ 𝗥𝗜𝗢 𝗕𝗢𝗢𝗧 ⛔️` : `✅️ 𝗥𝗜𝗢 𝗕𝗢𝗢𝗧 ✅️`;
    api.setNickname(oldNick, threadID, botID);
    punish("التلاعب بكنية البوت");
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
  
  let data = JSON.parse(fs.readFileSync(path));
  let threadInfo = await api.getThreadInfo(threadID);

  if (!data[threadID]) {
    data[threadID] = { namebox: threadInfo.threadName, status: true };
  } else {
    data[threadID].status = !data[threadID].status;
    data[threadID].namebox = threadInfo.threadName;
  }

  const newNick = data[threadID].status ? `⛔️ 𝗥𝗜𝗢 𝗕𝗢𝗢𝗧 ⛔️` : `✅️ 𝗥𝗜𝗢 𝗕𝗢𝗢𝗧 ✅️`;
  api.setNickname(newNick, threadID, api.getCurrentUserID());

  fs.writeFileSync(path, JSON.stringify(data, null, 2));
  
  const msg = data[threadID].status ? "تـم تـفـعـيـل الـدرع ⛔️" : "تـم تـعـطـيـل الـدرع ✅️";
  return api.sendMessage(`⛩️🔥 حـمـايـة الـمـلـك 🔥⛩️\n━━━━━━━━━━━━━━━\n🛡️ الـحـالـة: ${msg}\n🦾 تـطـويـر: سـيـدك عـبـدو`, threadID, messageID);
};