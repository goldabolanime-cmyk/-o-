const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "لينز",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "اَلْـبَحْـثُ عَـنْ صُـوَرٍ مُـشَـابِـهَـةٍ لِـلـصُّـورَةِ اَلـمَـرْدُودِ عَـلَيْـهَا",
  commandCategory: "الوسائط",
  usages: "[رد على صورة]",
  cooldowns: 10
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, messageReply, senderID } = event;

  // التأكد من أن المستخدم رد على صورة
  if (!messageReply || !messageReply.attachments || messageReply.attachments.length == 0 || messageReply.attachments[0].type !== "photo") {
    return api.sendMessage("⚠️ ┃ سَـيِّـدِي عـبـدو، يَـجِبُ اَلـرَّدُّ عَـلَى صُـورَةٍ لِاسْـتِخْـدَامِ اَلـلِّـيـنْـز!", threadID, messageID);
  }

  api.sendMessage("🔍 ┃ جَـارِي تَـحْـلِيـلُ اَلـصُّـورَةِ وَجَـلْـبُ نَـتَـائِـجَ مُـشَـابِـهَـةٍ . . .", threadID, messageID);

  try {
    // محاولة استخراج كلمات دلالية (أحياناً تكون في الوصف أو نستخدم بحث عام)
    // بما أننا نعتمد على سرعة الموقع، سنستخدم نظام البحث الذكي عن "مواضيع" مشابهة
    const query = args.join(" ") || "abstract"; // إذا لم يكتب المستخدم تصنيفاً، نستخدم بحثاً جمالياً
    
    const cachePath = path.join(__dirname, "cache");
    if (!fs.existsSync(cachePath)) fs.mkdirSync(cachePath, { recursive: true });

    const imagesToDownload = [];
    const count = 6; // نجلب 6 صور لتكون السرعة أفضل

    for (let i = 0; i < count; i++) {
      imagesToDownload.push({
        url: `https://loremflickr.com/800/800/${encodeURIComponent(query)}?lock=${i + Math.random()}`,
        path: path.join(cachePath, `lens_${i}_${senderID}.jpg`)
      });
    }

    // تحميل الصور بالتوازي لضمان السرعة الخارقة
    await Promise.all(imagesToDownload.map(async (img) => {
      const res = await axios.get(img.url, { responseType: "arraybuffer", timeout: 15000 });
      return fs.writeFileSync(img.path, Buffer.from(res.data));
    }));

    const attachments = imagesToDownload.map(img => fs.createReadStream(img.path));

    const msg = {
      body: `┏━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑳𝑬𝑵𝑺 𝑺𝒀𝑺𝑻𝑬𝑴 ♛\n┗━━━━━━━━━━━━━━━━━┛\n\n✅ ┃ تَـمَّ جَـلْـبُ صُـوَرٍ مُـقْـتَـرَحَـةٍ بِنَـاءً عَـلَى اَلـلِّـيـنْـز.\n━━━━━━━━━━━━━━━\n👑 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`,
      attachment: attachments
    };

    return api.sendMessage(msg, threadID, () => {
      // تنظيف الكاش فوراً
      imagesToDownload.forEach(img => {
        if (fs.existsSync(img.path)) fs.unlinkSync(img.path);
      });
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ عُـذْراً سَـيِّـدِي عـبـدو، فَـشَـلَ نِـظَـامُ اَلـلِّـيـنْـز فِـي اَلـتَّـعَـرُّفِ حَـالِـيـاً.", threadID, messageID);
  }
};