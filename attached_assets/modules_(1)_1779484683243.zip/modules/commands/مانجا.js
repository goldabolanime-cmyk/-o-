const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "مانجا",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "البحث عن المانجا وقراءة الفصول كصور بالرد",
  commandCategory: "خدمات",
  usages: "[اسم المانجا بالانجليزي]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const mangaName = args.join(" ");

  if (!mangaName) return api.sendMessage("⚠️ ┃ يرجى كتابة اسم المانجا (بالانجليزية) للبحث عنها.\nمثال: .مانجا One Piece", threadID, messageID);

  try {
    api.sendMessage("🔍 ┃ جـاري الـبـحث فـي الأرشـيـف الـمـلـكِي...", threadID, messageID);

    const searchRes = await axios.get(`https://api.mangadex.org/manga`, {
      params: { title: mangaName, limit: 1 }
    });

    if (searchRes.data.data.length === 0) return api.sendMessage("❌ ┃ عذراً، لم أجد أي مانجا بهذا الاسم.", threadID, messageID);

    const manga = searchRes.data.data[0];
    const mangaID = manga.id;
    const title = manga.attributes.title.en || manga.attributes.title.ja || "بدون عنوان";
    const status = manga.attributes.status;
    const year = manga.attributes.year || "غير محدد";

    const coverRel = manga.relationships.find(r => r.type === "cover_art");
    let coverUrl = "";
    if (coverRel) {
      const coverRes = await axios.get(`https://api.mangadex.org/cover/${coverRel.id}`);
      coverUrl = `https://uploads.mangadex.org/covers/${mangaID}/${coverRes.data.data.attributes.fileName}`;
    }

    const path = __dirname + `/cache/manga_${senderID}.jpg`;
    const getImg = (await axios.get(coverUrl, { responseType: "arraybuffer" })).data;
    fs.writeFileSync(path, Buffer.from(getImg, "utf-8"));

    const msg = `📖 ┃ تـفـاصـيـل الـمـانـجـا الـمـلـكِيـة\n━━━━━━━━━━━━━━━\n✨ ┃ الاسـم: ${title}\n📅 ┃ الـسـنـة: ${year}\n🚦 ┃ الـحـالـة: ${status}\n━━━━━━━━━━━━━━━\n💡 ┃ لـلـقـراءة: رد عـلـى هـذه الـرسـالـة بـكـلـمة [ فصل ] مـتـبـوعـة بـالـرقـم.\n📌 مـثـال: فصل 1\n━━━━━━━━━━━━━━━\n🔗 ┃ الـرابـط: https://mangadex.org/title/${mangaID}`;

    return api.sendMessage({ body: msg, attachment: fs.createReadStream(path) }, threadID, (err, info) => {
      if (fs.existsSync(path)) fs.unlinkSync(path);
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        mangaID: mangaID
      });
    }, messageID);

  } catch (error) {
    return api.sendMessage("❌ ┃ حدث خطأ في جلب البيانات.", threadID, messageID);
  }
};

module.exports.handleReply = async function({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const input = body.split(" ");
  if (input[0].toLowerCase() != "فصل") return;
  const chapterNum = input[1];

  api.sendMessage(`⏳ ┃ جـاري تـحـمـيـل الـفـصـل ${chapterNum}.. يـرجـى الـإنـتـظـار`, threadID, messageID);

  try {
    const chapters = await axios.get(`https://api.mangadex.org/manga/${handleReply.mangaID}/feed`, {
      params: { limit: 100, "translatedLanguage[]": ["en"], order: { chapter: "asc" } }
    });

    const chapter = chapters.data.data.find(c => c.attributes.chapter == chapterNum);
    if (!chapter) return api.sendMessage(`❌ ┃ الـفـصـل ${chapterNum} غـيـر مـتـوفـر بالـلغة الإنجليزية.`, threadID, messageID);

    const server = await axios.get(`https://api.mangadex.org/at-home/server/${chapter.id}`);
    const hash = server.data.chapter.hash;
    const pages = server.data.chapter.data;

    const attachments = [];
    // جلب أول 10 صفحات لضمان استقرار الإرسال في فيسبوك
    for (let i = 0; i < Math.min(pages.length, 10); i++) {
      const url = `https://uploads.mangadex.org/data/${hash}/${pages[i]}`;
      const imgData = (await axios.get(url, { responseType: "arraybuffer" })).data;
      const imgPath = __dirname + `/cache/m_${i}_${senderID}.jpg`;
      fs.writeFileSync(imgPath, Buffer.from(imgData));
      attachments.push(fs.createReadStream(imgPath));
    }

    api.sendMessage({
      body: `✅ ┃ تـم جـلـب الـفـصـل ${chapterNum}\n📖 اسـتـمـتـع بـالـقـراءة يـا مـلـك!`,
      attachment: attachments
    }, threadID, () => {
      attachments.forEach(att => { if (fs.existsSync(att.path)) fs.unlinkSync(att.path); });
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ فشل جلب صور الفصل، قد يكون السيرفر مضغوطاً.", threadID, messageID);
  }
};