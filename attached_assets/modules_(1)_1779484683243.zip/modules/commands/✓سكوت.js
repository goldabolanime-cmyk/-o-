const fs = require("fs-extra");

module.exports.config = {
  name: "سكوت",
  version: "2.0.0",
  hasPermssion: 0, // التحقق يدوي بالداخل للمساعدين والادمن
  credits: "عبدو / RIO BOOT",
  description: "طرد أي عضو يتكلم عند تفعيل وضع السكوت",
  commandCategory: "الادمن",
  usages: "سكوت [تشغيل/ايقاف]",
  cooldowns: 5
};

// مصفوفة لتخزين المجموعات المفعل فيها السكوت أثناء تشغيل البوت
if (typeof global.rio_silence === "undefined") {
  global.rio_silence = new Array();
}

module.exports.handleEvent = async ({ api, event, Users }) => {
  const { threadID, senderID, type } = event;
  
  // إذا كان السكوت غير مفعل في هذه المجموعة أو الرسالة ليست نصية
  if (!global.rio_silence.includes(threadID) || type !== "message") return;

  const adminBot = ["100090081489341"]; // أيدي عبدو
  const assistantsPath = __dirname + "/cache/assistants.json";
  let assistants = fs.existsSync(assistantsPath) ? fs.readJsonSync(assistantsPath) : [];

  // استثناء المطور، المساعدين، البوت نفسه، وادمن المجموعة
  const threadInfo = await api.getThreadInfo(threadID);
  const isGroupAdmin = threadInfo.adminIDs.some(admin => admin.id == senderID);
  
  if (senderID == api.getCurrentUserID() || 
      adminBot.includes(senderID) || 
      assistants.includes(senderID) || 
      isGroupAdmin) return;

  // تنفيذ الطرد
  const name = await Users.getNameUser(senderID);
  api.removeUserFromGroup(senderID, threadID, (err) => {
    if (!err) {
      api.sendMessage({
        body: `⚠️ | هـدوء تـام..\n━━━━━━━━━━━━━━━\n👤 | الـعـضـو: ${name}\n❌ | الـسـبـب: الـتـكـلـم فـي وضـع الـسـكـوت\n📌 | تـم الـطـرد بـنـجـاح!`,
        mentions: [{ tag: name, id: senderID }]
      }, threadID);
    }
  });
};

module.exports.run = async function ({ api, args, event }) {
  const { threadID, messageID, senderID } = event;
  const adminBot = "100090081489341";
  const assistantsPath = __dirname + "/cache/assistants.json";
  let assistants = fs.existsSync(assistantsPath) ? fs.readJsonSync(assistantsPath) : [];

  // التحقق من الصلاحية (مطور، مساعد، أو ادمن المجموعة)
  const threadInfo = await api.getThreadInfo(threadID);
  const isGroupAdmin = threadInfo.adminIDs.some(admin => admin.id == senderID);

  if (senderID !== adminBot && !assistants.includes(senderID) && !isGroupAdmin) {
    return api.sendMessage("⚠️ | عـذراً، هـذا الأمـر لـلـمـطـور أو مـسـاعـديـه أو مـشـرفـي الـمـجـمـوعة فـقـط!", threadID, messageID);
  }

  if (args[0] == "تشغيل") {
    if (global.rio_silence.includes(threadID)) return api.sendMessage("📌 | وضـع الـسـكـوت مـفـعـل بـالـفـعـل!", threadID, messageID);
    
    global.rio_silence.push(threadID);
    return api.sendMessage("🔇 ┃ تـم تـفـعـيـل وضـع الـسـكـوت\n━━━━━━━━━━━━━━━\n🚫 | أي شـخـص يـتـكـلـم (غـيـر الـمـشـرفـيـن) سـيـتـم طـرده فـوراً!", threadID, messageID);
  } 
  
  else if (args[0] == "ايقاف") {
    const index = global.rio_silence.
