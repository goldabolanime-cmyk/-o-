const axios = require("axios");
const fs = require("fs-extra");
const Jimp = require("jimp");
const path = require("path");

module.exports.config = {
  name: "قلب",
  version: "1.5.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "جَـلْبُ صُـورَةِ بْـرُوفَـايْـلِكَ وَعَـكْسُ أَلْـوَانِـهَا (Invert)",
  commandCategory: "الوسائط",
  usages: " ",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, senderID } = event;
  const TOKEN = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662"; // التوكن الخاص بك

  // 1. التفاعل بساعة رملية (بدء العملية)
  api.setMessageReaction("⏳", messageID, () => {}, true);

  try {
    const cachePath = path.join(__dirname, "cache");
    if (!fs.existsSync(cachePath)) fs.mkdirSync(cachePath, { recursive: true });

    const avatarPath = path.join(cachePath, `avatar_${senderID}.png`);
    const invertedPath = path.join(cachePath, `inverted_${senderID}.png`);

    // 2. جلب صورة البروفايل بجودة عالية
    const avatarUrl = `https://graph.facebook.com/${senderID}/picture?height=720&width=720&access_token=${TOKEN}`;
    const response = await axios.get(avatarUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(avatarPath, Buffer.from(response.data));

    // 3. معالجة الصورة: عكس الألوان
    const image = await Jimp.read(avatarPath);
    await image.invert().writeAsync(invertedPath);

    // 4. التفاعل بـ "تم" عند الانتهاء
    api.setMessageReaction("✅", messageID, () => {}, true);

    const msg = {
      body: `┏━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑰𝑵𝑽𝑬𝑹𝑻 𝑺𝒀𝑺𝑻𝑬𝑴 ♛\n┗━━━━━━━━━━━━━━━━━┛\n\n✨ ┃ سَـيِّـدِي ، تَمَّ عَـكْسُ أَلْـوَانِ بْـرُوفَـايْـلِكَ\n━━━━━━━━━━━━━━━\n👑 ┃ اَلْـمُـطَـوِّرُ : عـبـدو`,
      attachment: fs.createReadStream(invertedPath)
    };

    return api.sendMessage(msg, threadID, () => {
      // تنظيف الكاش
      if (fs.existsSync(avatarPath)) fs.unlinkSync(avatarPath);
      if (fs.existsSync(invertedPath)) fs.unlinkSync(invertedPath);
    }, messageID);

  } catch (e) {
    console.error(e);
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage("❌ ┃ عُـذْراً سَـيِّـدِي، فَـشَـلَ عَـكْسُ أَلْـوَانِ اَلـصُّـورَةِ.", threadID, messageID);
  }
};