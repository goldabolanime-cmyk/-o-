const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");

module.exports.config = {
    name: "كهف",
    version: "2.0.0",
    hasPermssion: 0,
    credits: "RIO BOOT",
    description: "العمل في الكهوف العالمية للحصول على الأموال (مرتين كل 5 ساعات)",
    commandCategory: "الاموال",
    cooldowns: 5
};

module.exports.run = async ({ event, api, Currencies }) => {
    const { threadID, messageID, senderID } = event;
    
    // --- إعدادات الوقت (مرتين كل 5 ساعات) ---
    const cooldownTime = 5 * 60 * 60 * 1000; // 5 ساعات بالملي ثانية
    let data = (await Currencies.getData(senderID)).data || {};
    if (typeof data.caveWork === "undefined") data.caveWork = { count: 0, lastTime: 0 };

    const now = Date.now();
    if (now - data.caveWork.lastTime < cooldownTime && data.caveWork.count >= 2) {
        const remaining = cooldownTime - (now - data.caveWork.lastTime);
        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
        return api.sendMessage(`⚠️ ┇ مـولي، لـقـد اسـتـنـفـذت طـاقـتـك الـيـوم!\n━━━━━━━━━━━━━━━\n⌛ ┇ يـمـكـنـك الـعـودة بـعـد: ${hours} سـاعـة و ${minutes} دقـيـقـة.`, threadID, messageID);
    }

    const msg = {
        body: "⛏️ ┇ مَـنْـجَـمُ الـكَـهـوفِ الـمَـلَـكِي ┃ 💎\n━━━━━━━━━━━━━━━\n" +
              "1 ≻ 🇻🇳 كـهـوف فـيـتـنـام\n" +
              "2 ≻ 🇨🇳 كـهـوف الـصـيـن\n" +
              "3 ≻ 🇯🇵 كـهـوف الـيـابـان\n" +
              "4 ≻ 🇹🇭 كـهـوف تـايـلانـد\n" +
              "5 ≻ 🇺🇸 كـهـوف أمـريـكـا\n" +
              "6 ≻ 🇰🇭 كـهـوف كـمـبـوديـا\n" +
              "7 ≻ 🇲🇦 كـهـوف الـمـغـرب (مغارة هرقل)\n" +
              "8 ≻ 🇪🇬 كـهـوف مـصـر (وادي الحيتان)\n" +
              "9 ≻ 🇮🇸 كـهـوف آيـسـلـنـدا الـجـلـيـديـة\n" +
              "10 ≻ 🇲🇽 كـهـوف الـمـكـسـيـك (الكريستال)\n" +
              "11 ≻ 🇴🇲 كـهـوف عُـمـان (مجلس الجن)\n" +
              "━━━━━━━━━━━━━━━\n" +
              "📌 ┇ رد عـلـى الـرسـالـة بـرقـم الـكـهـف لـلـبـدء!",
    };

    return api.sendMessage(msg, threadID, (err, info) => {
        global.client.handleReply.push({
            name: this.config.name,
            messageID: info.messageID,
            author: senderID,
            type: "choose"
        });
    }, messageID);
};

module.exports.handleReply = async ({ event, api, handleReply, Currencies }) => {
    const { threadID, messageID, senderID, body } = event;
    if (handleReply.author != senderID) return api.sendMessage("❌ ┇ عـذراً مـولـي، هـذا الـطـلـب لـيـس لـك!", threadID, messageID);

    const caves = {
        "1": "فـيـتـنـام", "2": "الـصـيـن", "3": "الـيـابـان", "4": "تـايـلانـد", 
        "5": "أمـريـكـا", "6": "كـمـبـوديـا", "7": "الـمـغـرب", "8": "مـصـر", 
        "9": "آيـسـلـنـدا", "10": "الـمـكـسـيـك", "11": "عُـمـان"
    };

    const choice = body.trim();
    if (!caves[choice]) return api.sendMessage("⚠️ ┇ مـولـي، اخـتـر رقـمـاً مـن 1 إلـى 11 فـقـط!", threadID, messageID);

    const moneyEarned = Math.floor(Math.random() * (5000 - 1000 + 1)) + 1000;
    const caveName = caves[choice];

    let data = (await Currencies.getData(senderID)).data || {};
    if (typeof data.caveWork === "undefined") data.caveWork = { count: 0, lastTime: 0 };

    // تحديث نظام التوقيت
    const now = Date.now();
    if (now - data.caveWork.lastTime > 5 * 60 * 60 * 1000) {
        data.caveWork.count = 1;
        data.caveWork.lastTime = now;
    } else {
        data.caveWork.count += 1;
    }

    await Currencies.increaseMoney(senderID, moneyEarned);
    await Currencies.setData(senderID, { data });

    api.unsendMessage(handleReply.messageID);
    return api.sendMessage(`✅ ┇ تـمَّ الـقـبـول!\n━━━━━━━━━━━━━━━\n⛏️ ┇ لـقـد عـمـلـت بـجـد فـي كـهـوف [ ${caveName} ]\n💰 ┇ وحـصـلـت عـلـى: ${moneyEarned}$\n━━━━━━━━━━━━━━━\n📊 ┇ مـحـاولاتـك: (${data.caveWork.count}/2)`, threadID, messageID);
};