module.exports.config = {
  name: "ايديت",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "نظام تعديل الصور الملكي - 25 فلتر متطور",
  commandCategory: "تسلية",
  usages: "[رد على صورة + رقم الفلتر]",
  cooldowns: 5
};

const filters = [
  { name: "🎬 سينـمائي (Cinematic)", type: "sepia" },
  { name: "🎥 أفـلام قـديـمة (Vintage)", type: "grayscale" },
  { name: "🧟 رُعــب (Horror)", type: "color", params: { r: 60, g: -60, b: -60 } },
  { name: "🎭 درامــا (Cold)", type: "color", params: { r: -30, g: -10, b: 50 } },
  { name: "🌟 نـضـارة (Bright)", type: "brightness", params: 0.3 },
  { name: "🌑 غـموض (Dark)", type: "brightness", params: -0.4 },
  { name: "🌀 تـشـويـش (Pixel)", type: "pixelate", params: 8 },
  { name: "🎨 تـلويـن مـلكي (Royal Colors)", type: "royal_color" },
  { name: "🌆 غـروب (Sunset)", type: "color", params: { r: 40, g: -10, b: -20 } },
  { name: "🍃 طـبيعة (Nature)", type: "color", params: { r: -10, g: 30, b: -10 } },
  { name: "👻 شـبحي (Ghost)", type: "opacity", params: 0.6 },
  { name: "💎 كـريستال (Posterize)", type: "posterize", params: 5 },
  { name: "🕯️ كـلاسـيك (Classic)", type: "color", params: { r: 10, g: 10, b: -30 } },
  { name: "👾 سـايـبر (Cyberpunk)", type: "color", params: { r: 50, g: -30, b: 50 } },
  { name: "🖤 أبـيض وأسـود (Noir)", type: "low_contrast_gray" },
  // الفلاتر الـ 10 الجديدة
  { name: "👑 جودة مـلـكية (4K Ultra)", type: "hd_royal" },
  { name: "📸 تـحميض (Negative)", type: "invert" },
  { name: "🖍️ رسـم كرتوني (Cartoon)", type: "posterize", params: 3 },
  { name: "🌊 انـعـكاس (Blur)", type: "blur", params: 5 },
  { name: "🔥 حـراري (Thermal)", type: "color", params: { r: 100, g: -50, b: -100 } },
  { name: "🍬 حـلويات (Candy)", type: "color", params: { r: 30, g: -20, b: 30 } },
  { name: "📡 رادار (Green Scan)", type: "color", params: { r: -100, g: 100, b: -100 } },
  { name: "🛸 فـضائي (Alien)", type: "color", params: { r: -50, g: 80, b: -50 } },
  { name: "🏜️ صـحراوي (Desert)", type: "color", params: { r: 40, g: 20, b: -40 } },
  { name: "🌈 فـانتازيا (Vibrant)", type: "color", params: { r: 20, g: 20, b: 20 } }
];

const royalColors = {
  "أصفر": { r: 40, g: 40, b: -30 },
  "أخضر": { r: -30, g: 50, b: -30 },
  "بني": { r: 30, g: 10, b: -30 },
  "رمادي": { r: 0, g: 0, b: 0, desaturate: true },
  "أرجواني": { r: 30, g: -30, b: 40 },
  "أزرق": { r: -20, g: -20, b: 50 },
  "ذهبي": { r: 45, g: 35, b: -40 },
  "أحمر": { r: 60, g: -20, b: -20 }
};

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID, senderID, messageReply, type } = event;

  // إذا لم يقم بالرد على صورة أو لم يضع رقماً، تظهر القائمة
  if (type !== "message_reply" || !args[0]) {
    let list = "🎭 ━━━━【 قـائمة إيـديت ريـو 】━━━━ 🎭\n\n";
    filters.forEach((f, i) => {
      list += `【 ${i + 1} 】- ${f.name}\n`;
    });
    list += "\n📍 كـيفية الاسـتخدام:\n1. قم بالـرد على صورة.\n2. اكتب: ايديت [رقم الفلتر]";
    list += "\n📝 مـثال: ايديت 16 (للجودة الملكية)";
    
    return api.sendMessage(list, threadID, messageID);
  }

  const index = parseInt(args[0]) - 1;
  const colorName = args.slice(1).join(" ");

  if (isNaN(index) || !filters[index]) {
    return api.sendMessage("❌ يـرجى اخـتيار رقم فلتر صـحيح من القائمة!", threadID, messageID);
  }

  // الحصول على رابط الصورة من الرد
  const imgUrl = messageReply.attachments[0]?.url;
  if (!imgUrl || messageReply.attachments[0].type !== "photo") {
    return api.sendMessage("❌ يـجب الـرد على (صـورة) لتـطبيق الإيـديت!", threadID, messageID);
  }

  // معالجة الفلتر رقم 8 (تلوين ملكي)
  if (index === 7 && (!colorName || !royalColors[colorName])) {
    let msg = "🎨 ━━━━【 ألـوان مـلكيـة 】━━━━ 🎨\n\n";
    Object.keys(royalColors).forEach(c => msg += `✨ ${c}\n`);
    msg += "\n📝 اسـتخدم: ايديت 8 [اسم اللون]";
    return api.sendMessage(msg, threadID, messageID);
  }

  return applyFilter(api, event, index, imgUrl, colorName);
};

async function applyFilter(api, event, index, imgUrl, colorName) {
  const jimp = require("jimp");
  const fs = require("fs-extra");
  const { threadID, messageID } = event;

  try {
    api.sendMessage("⏳ جـارٍ تـنفيذ الإيـديت الـمـلكي...", threadID, messageID);

    const image = await jimp.read(imgUrl);
    const selected = filters[index];

    switch (selected.type) {
      case "sepia": image.sepia(); break;
      case "grayscale": image.grayscale(); break;
      case "pixelate": image.pixelate(selected.params); break;
      case "brightness": image.brightness(selected.params); break;
      case "posterize": image.posterize(selected.params); break;
      case "opacity": image.opacity(selected.params); break;
      case "invert": image.invert(); break;
      case "blur": image.blur(selected.params); break;
      case "hd_royal": 
        image.convolute([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]]) // Sharpen
             .contrast(0.2)
             .brightness(0.1); 
        break;
      case "low_contrast_gray": image.grayscale().contrast(0.2); break;
      case "color": 
        image.color([
          { apply: "red", params: [selected.params.r] },
          { apply: "green", params: [selected.params.g] },
          { apply: "blue", params: [selected.params.b] }
        ]); 
        break;
      case "royal_color":
        const c = royalColors[colorName];
        if (c.desaturate) image.grayscale();
        image.color([
          { apply: "red", params: [c.r] },
          { apply: "green", params: [c.g] },
          { apply: "blue", params: [c.b] }
        ]);
        break;
    }

    const pathImg = __dirname + `/cache/edit_${Date.now()}.png`;
    await image.writeAsync(pathImg);

    return api.sendMessage({
      body: `✅ تـم تـطبيق فـلتر: ${selected.name}`,
      attachment: fs.createReadStream(pathImg)
    }, threadID, () => fs.unlinkSync(pathImg), messageID);

  } catch (e) {
    console.log(e);
    return api.sendMessage("❌ حـدث خـطأ أثناء مـعالجة الـصورة.", threadID, messageID);
  }
}