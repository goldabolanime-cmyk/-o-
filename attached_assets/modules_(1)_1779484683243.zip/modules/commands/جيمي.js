const axios = require("axios");

module.exports.config = {
  name: "جيمي",
  version: "2.5.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "ذكاء ريو الاصطناعي عبر Chipp AI المستقر",
  commandCategory: "ذكاء اصطناعي",
  usages: "[النص]",
  cooldowns: 3, // وقت انتظار قصير لأنه سريع
  aliases: ["بوت", "ai"]
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const prompt = args.join(" ");

  if (!prompt) return api.sendMessage("أنا ريو، كيف يمكنني مساعدتك؟", threadID, messageID);

  // إظهار علامة الكتابة لتبدو الاستجابة طبيعية
  api.sendTypingIndicator(threadID);

  try {
    // جلب الرد من سكراب API مستقر يتعامل مع محرك Chipp
    // هذا الرابط مصمم لتحمل الضغط العالي
    const res = await axios.get(`https://api.sandipbaruwal.com.np/chippai?prompt=${encodeURIComponent(prompt)}`);
    
    // استخراج النص من النتيجة (تعديل المسار حسب بنية الـ API)
    const answer = res.data.answer || res.data.reply || res.data.response;

    if (!answer) throw new Error("Empty Response");

    // رد بسيط ومباشر بدون زخارف مع بصمة المطور فقط
    const finalMessage = `${answer}\n\n🔱 ┃ المطور: عبدو`;

    return api.sendMessage(finalMessage, threadID, messageID);

  } catch (error) {
    console.error(error);
    // رسالة خطأ رسمية وبسيطة
    return api.sendMessage("السيرفر مشغول حالياً، يرجى المحاولة لاحقاً.", threadID, messageID);
  }
};