module.exports.config = {
  name: "سبام",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "إرسال رسالة تنظيف الشات الطويلة في حالات الطوارئ",
  commandCategory: "نظام المطور",
  usages: "[عدد المرات]",
  cooldowns: 2
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const adminID = "100090081489341"; // الأيدي الخاص بك يا عبدو

  // --- 1. التحقق من الهوية (أنت فقط) ---
  if (senderID !== adminID) {
    return api.sendMessage("⚠️ ┃ هَـذَا اَلْأَمْـرُ لِـحَـالَاتِ اَلـطَّـوَارِئِ وَيُـسْتَخْـدَمُ مِـنْ قِـبَلِ اَلْـمُطَـوِّرِ عَـبْـدُو فَـقَـطْ.", threadID, messageID);
  }

  // --- 2. تحديد عدد التكرار (افتراضياً 1 إذا لم تذكر عدداً) ---
  let count = parseInt(args[0]) || 1;
  if (count > 10) count = 10; // حماية للبوت من الحظر (أقصى حد 10 في المرة)

  // --- 3. الرسالة الطويلة (نظام النقاط) ---
  const longMessage = `.\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n..\n\n\n\n\n\n\n\n\n\n\n\n\n\n. `;

  // --- 4. التنفيذ ---
  for (let i = 0; i < count; i++) {
    api.sendMessage(longMessage, threadID);
  }
};