module.exports.config = {
  name: "عكس",
  version: "1.0.5",
  hasPermssion: 0,
  credits: "عبدو",
  description: "لعبة عكس الكلمات مع جوائز مالية",
  usages: "لعبة",
  commandCategory: "العاب",
  cooldowns: 2
};

const questions = [
  { question: "الـنُّـور", answer: "الظلام" },
  { question: "الـشَّـقَـاء", answer: "السعادة" },
  { question: "الـفَـقْـر", answer: "الثروة" },
  { question: "الـبَـرْد", answer: "الحرارة" },
  { question: "الـجَـفَـاف", answer: "الرطوبة" },
  { question: "الـصَّـمْـت", answer: "الضوضاء" },
  { question: "الـحَـيَـاة", answer: "الموت" },
  { question: "الـبِـدَايَـة", answer: "النهاية" },
  { question: "الـأَعْـلَـى", answer: "الأدنى" },
  { question: "الـدَّاخِـل", answer: "الخارج" },
  { question: "الـأَمَـام", answer: "الخلف" },
  { question: "الـيَـمِـيـن", answer: "اليسار" },
  { question: "الـسَّـهْـل", answer: "الصعب" },
  { question: "الـفَـرَح", answer: "الحزن" },
  { question: "الـحُـب", answer: "الكراهية" },
  { question: "الـصِّـدْق", answer: "الكذب" },
  { question: "الـعَـدْل", answer: "الظلم" },
  { question: "الـخَـيْـر", answer: "الشر" },
  { question: "الـأَمَـل", answer: "اليأس" },
  { question: "الـإِيـمَـان", answer: "الكفر" }
];

module.exports.handleReply = async function ({ api, event, handleReply, Currencies, Users }) {
  const { senderID, threadID, body, messageID } = event;
  const userAnswer = body.trim();
  const correctAnswer = handleReply.correctAnswer;
  const userName = await Users.getNameUser(senderID);

  if (userAnswer === correctAnswer) {
      await Currencies.increaseMoney(senderID, 20);
      api.unsendMessage(handleReply.messageID); 
      return api.sendMessage(`✨ ┃ تـَهَانِينَا يَا ${userName}!\n\n✅ ┃ إِجَـابَـتُـكَ صَـحِـيـحَـة: 【 ${correctAnswer} 】\n💰 ┃ لَـقَـدْ حَـصَـلْتَ عَـلَى 20 دُولَار بَـنْـكِـيَّة.`, threadID, messageID);
  } else {
      return api.sendMessage(`❌ ┃ لَـلْأَسَـفِ يَا ${userName}.. الإِجَـابَـةُ خَـاطِـئَـة!\n💡 ┃ حَـاوِلْ مَـرَّةً أُخْـرَى بِـتَـرْكِـيـزٍ أَكْـبَـر.`, threadID, messageID);
  }
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
  const correctAnswer = randomQuestion.answer;
  const question = randomQuestion.question;

  const msg = {
    body: `⚔️ ┃ لـُعْـبَـةُ الـعَـكْـسِ الـمَـلَـكِـيَّـة\n\n❓ ┃ مَـا هُـوَ عَـكْـسُ كَـلِـمَـةِ: ( ${question} ) ؟\n\n✨ ┃ قُـمْ بِـالـرَّدِّ عَـلَى هَـذِهِ الـرِّسَـالَـةِ بِـالإِجَـابَـةِ!`
  };

  return api.sendMessage(msg, threadID, (error, info) => {
      if (!error) {
          global.client.handleReply.push({
              name: this.config.name,
              messageID: info.messageID,
              correctAnswer: correctAnswer
          });
      }
  });
};
