module.exports.config = {
  name: "ميمز",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "صناعة ميم Drake الملكي - النص الأول (خطأ) ثم النص الثاني (صح)",
  commandCategory: "ترفيه",
  usages: "[النص الأول]\n[النص الثاني]",
  cooldowns: 10,
  dependencies: {
    "canvas": "",
    "axios": "",
    "fs-extra": ""
  }
};

// دالة تنسيق الأسطر الاحترافية (wrapText) لضمان بقاء النص داخل المربعات
// ملاحظة: قمت بزيادة maxWidth ليتناسب مع المساحة البيضاء الواسعة
module.exports.wrapText = (ctx, text, maxWidth) => {
  return new Promise(resolve => {
    const words = text.split(' ');
    const lines = [];
    let line = '';
    for (let n = 0; n < words.length; n++) {
      let testLine = line + words[n] + ' ';
      let metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && n > 0) {
        lines.push(line.trim());
        line = words[n] + ' ';
      } else {
        line = testLine;
      }
    }
    lines.push(line.trim());
    resolve(lines);
  });
}

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID, body } = event;
  const { loadImage, createCanvas } = require("canvas");
  const fs = require("fs-extra");
  const axios = require("axios");
  
  const pathImg = __dirname + `/cache/rio_meme_${senderID}.png`;
  
  // تقسيم النص بناءً على السطر الجديد (Enter)
  const content = body.slice(body.indexOf(args[0])).split('\n');
  
  if (content.length < 2) {
    return api.sendMessage("👑 ┃ سيدي، يرجى كتابة النص بالصيغة التالية:\n\n.ميمز النص الأول (الخطأ)\nالنص الثاني (الصحيح)", threadID, messageID);
  }

  const textTop = content[0].trim();
  const textBottom = content[1].trim();

  try {
    // جلب الصورة الأصلية من الرابط المباشر الجديد
    const imageUrl = "https://i.postimg.cc/8z5gqHn5/drake-clean.jpg";
    const imageBuffer = (await axios.get(imageUrl, { responseType: 'arraybuffer' })).data;
    fs.writeFileSync(pathImg, Buffer.from(imageBuffer, 'utf-8'));

    const baseImage = await loadImage(pathImg);
    const canvas = createCanvas(baseImage.width, baseImage.height);
    const ctx = canvas.getContext("2d");

    ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);

    // إعدادات الخط (لون أسود فخم - نفس لون ترامب)
    ctx.fillStyle = "#000000"; // لون أسود للنص
    ctx.textAlign = "start"; // محاذاة النص لليسار
    
    // ضبط حجم الخط ليناسب المساحة البيضاء
    // جعلت الخط أصغر قليلاً ليسمح بكتابة نصوص أطول
    let fontSize = 35; 
    ctx.font = `bold ${fontSize}px Arial, sans-serif`;

    // معالجة الأسطر للخانة الأولى (الأعلى)
    // العرض الأقصى للنص 550 بكسل
    const linesTop = await this.wrapText(ctx, textTop, 550);
    
    // كتابة النص في الخانة الأولى (الأعلى)
    // الإحداثيات الدقيقة لوسط المربع الأبيض الأعلى
    ctx.fillText(linesTop.join('\n'), 600, 200);

    // معالجة الأسطر للخانة الثانية (الأسفل)
    const linesBottom = await this.wrapText(ctx, textBottom, 550);
    
    // كتابة النص في الخانة الثانية (الأسفل)
    // الإحداثيات الدقيقة لوسط المربع الأبيض الأسفل
    ctx.fillText(linesBottom.join('\n'), 600, 750);

    const resultBuffer = canvas.toBuffer();
    fs.writeFileSync(pathImg, resultBuffer);

    return api.sendMessage({
      body: "👑 ┃ تم استنتاج المقارنة الملكية بنجاح:",
      attachment: fs.createReadStream(pathImg)
    }, threadID, () => fs.unlinkSync(pathImg), messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حدث خطأ فني أثناء معالجة الصورة، تأكد من تثبيت Canvas.", threadID, messageID);
  }
}