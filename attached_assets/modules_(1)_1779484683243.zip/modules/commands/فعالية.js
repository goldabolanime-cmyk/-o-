module.exports.config = {
  name: "فعالية",
  version: "9.0.0",
  hasPermssion: 0,
  credits: "RIO BOOT & Gemini",
  description: "سباق الجولات بنظام انتظار الإجابات وفحصها بعد 20 ثانية",
  commandCategory: "تسلية",
  usages: "[انضمام / بدء / ايقاف]",
  cooldowns: 5
};

if (!global.rio_game) global.rio_game = new Map();

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, senderID, body } = event;
  const gameData = global.rio_game.get(threadID);

  if (!gameData || gameData.status !== "playing") return;
  if (!gameData.players.includes(senderID)) return;
  if (handleReply.type !== "waiting_answer") return;

  // تسجيل إجابة اللاعب إذا كانت صحيحة (بدون إنهاء الجولة فوراً)
  if (body.trim().toLowerCase() === handleReply.correctAnswer.toLowerCase()) {
    if (!gameData.roundWinners.includes(senderID)) {
      gameData.roundWinners.push(senderID);
    }
  }
};

async function endRound(api, threadID) {
  const gameData = global.rio_game.get(threadID);
  if (!gameData) return;

  // إضافة النقاط للفائزين في هذه الجولة
  for (let winnerID of gameData.roundWinners) {
    gameData.scores[winnerID] = (gameData.scores[winnerID] || 0) + 1;
  }

  let roundNum = gameData.round;
  gameData.round += 1;

  // ترتيب اللاعبين للنقاط الإجمالية
  const sortedPlayers = gameData.players.sort((a, b) => (gameData.scores[b] || 0) - (gameData.scores[a] || 0));
  
  // تجهيز قائمة المراكز الثلاثة الأولى
  let winnersList = ["لا يوجد", "لا يوجد", "لا يوجد"];
  for (let i = 0; i < 3; i++) {
    if (sortedPlayers[i] && gameData.scores[sortedPlayers[i]] > 0) {
      winnersList[i] = (await api.getUserInfo(sortedPlayers[i]))[sortedPlayers[i]].name;
    }
  }

  // بناء الرسالة بالزخرفة الملكية المطلوبة
  let msg = `⛩️🔥 مــــســـابـــقــــة 🔥⛩️\n`;
  msg += `⛩️🔥 رســــمــــيــــــــة 🔥⛩️\n`;
  msg += `الـجـولـة [ ${roundNum} ]\n`;
  msg += `••••••••••••••••••••••••••••••••••••\n`;
  
  // عرض النقاط الحالية لجميع المشاركين
  for (let pID of gameData.players) {
    const name = (await api.getUserInfo(pID))[pID].name;
    msg += `❀- ${name} : [ ${gameData.scores[pID] || 0} ]\n`;
  }

  msg += `••••••••••••••••••••••••••••••••••••\n`;
  msg += `🔴- الـحـكـم : ريـو بـوت\n`;
  msg += `🔵- الـفـوز عـلى : 10 جولات ㊗️\n`;
  msg += `⚫- الـنـوع : مـنـــــو؏ 💙❄\n`;
  msg += `•••••••••••••••••••••••••••••••••••••\n`;
  msg += `🏅 الـــــفــــــــائـــــــــزون 🏅\n`;
  msg += `======================\n`;
  msg += `الـــفـائـز الأول 🥇 : ${winnersList[0]}\n`;
  msg += `الــفـائــز الثاني 🥈 : ${winnersList[1]}\n`;
  msg += `الـفـائـز الـثـالث 🥉 : ${winnersList[2]}\n`;

  await api.sendMessage(msg, threadID);

  if (gameData.round > 10) {
    global.rio_game.delete(threadID);
    return api.sendMessage("🏁 ┃ انـتـهـت الـمـسـابـقـة الـرسمـيـة! شـكـراً لـلمـشـاركـة ✨", threadID);
  }

  gameData.roundWinners = []; // تصفير فائزي الجولة للقادمة
  setTimeout(() => sendNewQuestion(api, threadID), 3000);
}

async function sendNewQuestion(api, threadID) {
  const gameData = global.rio_game.get(threadID);
  if (!gameData) return;

  const games = [
    { q: "من هو خاتم الأنبياء؟", a: "محمد", t: "دينية" },
    { q: "ما هي عاصمة اليابان؟", a: "طوكيو", t: "ثقافية" },
    { q: "ف ل س ط ي ن (جمعها)", a: "فلسطين", t: "تجميع" },
    { q: "أكبر محيط في العالم؟", a: "الهادي", t: "عالمية" },
    { q: "الجزائر (فككها بمسافات)", a: "ا ل ج ز ا ئ ر", t: "تفكيك" },
    { q: "مصر (فككها بمسافات)", a: "م ص ر", t: "تفكيك" },
    { q: "ما هو الكوكب الأحمر؟", a: "المريخ", t: "علمية" },
    { q: "كم عدد ألوان قوس قزح؟", a: "7", t: "ثقافية" },
    { q: "صوت الأسد يسمى؟", a: "زئير", t: "حيوانات" },
    { q: "أين يوجد برج إيفل؟", a: "باريس", t: "سياحة" }
  ];

  const game = games[Math.floor(Math.random() * games.length)];
  const msg = `╔════════════════╗\n      الـجـولـة [ ${gameData.round} / 10 ]      \n╚════════════════╝\n📂 ┃ النوع: ${game.t}\n💡 ┃ السؤال: 【 ${game.q} 】\n━━━━━━━━━━━━━━━\n⏳ ┃ معكم 20 ثانية للإجابة!`;

  api.sendMessage(msg, threadID, (err, info) => {
    gameData.timerID = setTimeout(() => endRound(api, threadID), 20000); // 20 ثانية

    global.client.handleReply.push({
      name: "فعالية",
      messageID: info.messageID,
      correctAnswer: game.a,
      type: "waiting_answer"
    });
  });
}

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;

  if (!global.rio_game.has(threadID)) {
    global.rio_game.set(threadID, { status: "joining", players: [], scores: {}, timerID: null, round: 1, roundWinners: [] });
  }

  const gameData = global.rio_game.get(threadID);

  if (args[0] === "انضمام") {
    if (gameData.status === "playing") return api.sendMessage("⚠️ ┃ الفعالية بدأت بالفعل!", threadID, messageID);
    if (gameData.players.includes(senderID)) return api.sendMessage("⚠️ ┃ أنت مسجل مسبقاً!", threadID, messageID);
    
    gameData.players.push(senderID);
    gameData.scores[senderID] = 0;
    return api.sendMessage(`✅ ┃ تم تسجيلك! اللاعب رقم [ ${gameData.players.length} ]`, threadID, messageID);
  }

  if (args[0] === "بدء") {
    if (gameData.players.length < 1) return api.sendMessage("⚠️ ┃ يجب انضمام لاعب واحد على الأقل!", threadID, messageID);
    if (gameData.status === "playing") return;

    api.setMessageReaction("🐸", messageID, (err) => {}, true);
    gameData.status = "playing";
    api.sendMessage("⛩️🔥 جــــاري تــحــضـيـر الـمـسـابـقـة... 🔥⛩️", threadID);
    
    setTimeout(() => sendNewQuestion(api, threadID), 2000);
  }

  if (args[0] === "ايقاف") {
    clearTimeout(gameData.timerID);
    global.rio_game.delete(threadID);
    return api.sendMessage("🛑 ┃ تم إيقاف الفعالية بنجاح.", threadID, messageID);
  }
};