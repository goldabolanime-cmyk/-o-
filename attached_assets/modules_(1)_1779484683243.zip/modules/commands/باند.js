const fs = require("fs-extra");
const path = require("path");

// تأكد من أن المسار يؤدي لمجلد البيانات الخاص ببوتك
const blacklistPath = path.join(__dirname, "cache", "blacklist.json");

module.exports.config = {
  name: "باند",
  version: "2.6.0",
  hasPermssion: 2, 
  credits: "عبدو / RIO BOOT",
  description: "حظر نهائي وطرد تلقائي (نظام الحماية الحديدي)",
  commandCategory: "نظام الحماية",
  usages: "رد على الشخص واكتب .باند",
  cooldowns: 5
};

// إنشاء الملف إذا لم يكن موجوداً لضمان عدم حدوث خطأ
if (!fs.existsSync(blacklistPath)) fs.writeJsonSync(blacklistPath, {});

module.exports.handleEvent = async function({ api, event }) {
  const { threadID, logMessageType, logMessageData, author } = event;
  const adminID = "100090081489341"; // أيدي المطور عبدو

  // مراقبة انضمام الأعضاء الجدد
  if (logMessageType === "log:subscribe") {
    const blacklists = fs.readJsonSync(blacklistPath);
    if (!blacklists[threadID]) return;

    const addedParticipants = logMessageData.addedParticipants;
    const threadBlacklist = blacklists[threadID];

    for (let participant of addedParticipants) {
      const userID = participant.userFbId;

      // إذا كان الشخص في القائمة السوداء ولم يضفه عبدو
      if (threadBlacklist.includes(userID) && author !== adminID) {
        return api.removeUserFromGroup(userID, threadID, (err) => {
          if (!err) {
            api.sendMessage(`🛡️ ┃ نـظـام الـحـمـايـة الـتـلـقـائـي\n━━━━━━━━━━━━━━━\n🚫 ┃ الـمـسـتـخـدم: ${userID}\n⚖️ ┃ مـحـظـور سـابـقـاً بـأمـر الـمـطـور عـبـدو.\n⛔ ┃ تـمـت الإزالـة فـوراً.`, threadID);
          }
        });
      }
    }
  }
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, messageReply, senderID } = event;
  const adminID = "100090081489341";

  // التحقق من هوية المطور
  if (senderID !== adminID) return api.sendMessage("❌ ┃ عـذراً يا ملك، هـذا الأمـر خـاص بالـمـطـور عـبـدو فـقـط!", threadID, messageID);

  let targetID;
  if (event.type === "message_reply") {
    targetID = messageReply.senderID;
  } else if (args.length > 0) {
    targetID = args[0]; // دعم الحظر عبر الآيدي مباشرة
  } else {
    return api.sendMessage("⚠️ ┃ رُد عـلـى الشخص أو ضـع الأيدي الخاص به!", threadID, messageID);
  }

  if (targetID === adminID) return api.sendMessage("⚠️ ┃ لا تـحـظر نـفـسـك يـا مـطـور!", threadID, messageID);

  try {
    const blacklists = fs.readJsonSync(blacklistPath);
    if (!blacklists[threadID]) blacklists[threadID] = [];

    if (!blacklists[threadID].includes(targetID)) {
      blacklists[threadID].push(targetID);
      fs.writeJsonSync(blacklistPath, blacklists);
    }

    api.removeUserFromGroup(targetID, threadID, (err) => {
      if (err) return api.sendMessage("❌ ┃ تـعـذر الـطـرد! تـأكـد أنـنـي مـسـؤول (Admin) هـنـا.", threadID, messageID);
      
      return api.sendMessage({
        body: `🛡️ ┃ تـم الإدراج فـي الـقـائـمـة الـسـوداء\n━━━━━━━━━━━━━━━\n👤 ┃ الأيدي: ${targetID}\n🚫 ┃ الـحـالـة: طـرد + بـانـد نـهـائـي\n⚖️ ┃ لـن يـتـمـكـن مـن الـبـقـاء حـتـى لـو عـاد.\n━━━━━━━━━━━━━━━\n👑 ┃ بـواسـطـة الـمـطـور عـبـدو`
      }, threadID);
    });
  } catch (e) {
    return api.sendMessage("❌ ┃ حـدث خـطأ فـي قـاعدة الـبـيـانـات!", threadID, messageID);
  }
};