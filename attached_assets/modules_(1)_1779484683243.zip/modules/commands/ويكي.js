module.exports.config = {
  name: "بحث",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "البحث في ويكيبيديا بتنسيق ريو الأنيق",
  commandCategory: "خدمات",
  usages: "[نص البحث]",
  cooldowns: 2,
  dependencies: {
    "wikijs": ""
  }
};

module.exports.run = async function ({ event, args, api }) {
  const wiki = require("wikijs").default;
  const startTime = Date.now(); 
  let content = args.join(" ");
  let url = 'https://ar.wikipedia.org/w/api.php';

  // التحقق من وجود نص للبحث
  if (!content) {
    return api.sendMessage("⚠️ | ريـو يـقول لك: أدخـل مـا تـريـد الـبحث عـنـه أولاً.", event.threadID, event.messageID);
  }

  // دعم البحث بالإنجليزية إذا بدأ المستخدم بكلمة en
  if (args[0] == "en") {
    url = 'https://en.wikipedia.org/w/api.php';
    content = args.slice(1).join(" ");
  }

  try {
    // إرسال إشارة جاري الكتابة
    api.sendTypingIndicator(event.threadID);

    // عملية البحث
    const page = await wiki({ apiUrl: url }).page(content);
    const summary = await page.summary();
    
    const endTime = Date.now();
    const timeTaken = ((endTime - startTime) / 1000).toFixed(2);

    // تقصير النص إذا كان طويلاً جداً لكي لا يرفضه الفيسبوك
    const finalSummary = summary.length > 1500 ? summary.slice(0, 1500) + "..." : summary;

    const response = 
      `┏━━━━━━━━━━━━━━┓\n` +
      `  ✨ ┃ نـتـيـجـة الـبـحث الـمـطلـوبة\n` +
      `┗━━━━━━━━━━━━━━┛\n\n` +
      `${finalSummary}\n\n` +
      `━━━━━━━━━━━━━━━\n` +
      `🔍 ┃ الـمـصـدر: ويـكـيـبـيـديـا\n` +
      `🤖 ┃ الـبـوت: ريـو\n` +
      `👑 ┃ الـمـطـور: عـبـدو\n` +
      `⏳ ┃ الـوقت الـمسـتـغـرق: ${timeTaken} ثانية\n` +
      `━━━━━━━━━━━━━━━`;

    return api.sendMessage(response, event.threadID, event.messageID);

  } catch (error) {
    // إذا لم يجد الصفحة
    return api.sendMessage(`❌ | لـلأسـف يـا سـيـدي، لـم أجـد نـتـائـج لـبـحثـك عن: ${content}`, event.threadID, event.messageID);
  }
};
