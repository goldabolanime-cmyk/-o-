const axios = require("axios");

module.exports.config = {
  name: "آذان",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "معرفة أوقات الصلاة في أي مكان بالعالم",
  commandCategory: "إسلاميات",
  usages: "[رقم الصلاة] [اسم المدينة/الدولة]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;

  // خريطة الصلوات المتاحة
  const prayerMap = {
    "1": "Fajr",
    "2": "Dhuhr",
    "3": "Asr",
    "4": "Maghrib",
    "5": "Isha"
  };

  const prayerNamesAr = {
    "Fajr": "الـفـجـر",
    "Dhuhr": "الـظـهـر",
    "Asr": "الـعـصـر",
    "Maghrib": "الـمـغـرب",
    "Isha": "الـعـشـاء"
  };

  const choice = args[0];
  const location = args.slice(1).join(" ");

  if (!choice || !location || !prayerMap[choice]) {
    return api.sendMessage(`⚠️ ┃ اسـتـخدام خـاطـئ يـا عـبـدو!\n━━━━━━━━━━━━━━━\n💡 ┃ الـطـريـقة:\n.آذان [الرقم] [المدينة]\n\n1 ➔ الـفـجـر\n2 ➔ الـظـهـر\n3 ➔ الـعـصـر\n4 ➔ الـمـغـرب\n5 ➔ الـعـشـاء\n\n📝 ┃ مـثـال: .آذان 4 الـدار الـبـيـضـاء`, threadID, messageID);
  }

  try {
    // جلب البيانات من API أوقات الصلاة العالمي
    const res = await axios.get(`https://api.aladhan.com/v1/timingsByAddress?address=${encodeURIComponent(location)}`);
    const timings = res.data.data.timings;
    const date = res.data.data.date;

    const prayerKey = prayerMap[choice];
    const prayerTime = timings[prayerKey];
    const prayerAr = prayerNamesAr[prayerKey];

    const msg = `
┏━━━━━━━ 🕋 ━━━━━━━┓
   ✨ مـواقـيـت الـصـلاة ✨
┗━━━━━━━ 🕋 ━━━━━━━┛

📍 ┃ الـمـكـان: ${location}
📅 ┃ الـتـاريـخ: ${date.readable}
🕌 ┃ الـصـلاة: ${prayerAr}

⏰ ┃ الـمـوعـد: 【 ${prayerTime} 】

━━━━━━━━━━━━━━━━━━━━
🍀 ┃ لـا تـنـسَ ذكـر الـلـه يـا عـبـدو ┃ 🍀`;

    return api.sendMessage(msg, threadID, messageID);

  } catch (error) {
    return api.sendMessage("❌ ┃ لـم أسـتـطـع الـعـثـور عـلـى هـذه الـمـديـنـة. تـأكـد مـن كـتـابـة الإسـم بـشـكـل صـحـيـح.", threadID, messageID);
  }
};
