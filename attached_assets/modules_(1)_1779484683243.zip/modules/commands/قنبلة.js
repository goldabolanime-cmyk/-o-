const fs = require("fs-extra");

module.exports.config = {
  name: "قنبلة",
  version: "2.5.0",
  hasPermssion: 0,
  credits: "Gemini",
  description: "لعبة تفكيك القنبلة بالأسلاك العمودية",
  commandCategory: "الألعاب",
  usages: "[ابدأ اللعبة]",
  cooldowns: 5
};

if (!global.bombGame) global.bombGame = new Map();

module.exports.handleReply = async ({ api, event, handleReply, Currencies }) => {
  const { threadID, messageID, senderID, body } = event;
  if (handleReply.author != senderID) return;

  let game = global.bombGame.get(senderID);
  if (!game) return;

  const input = body.trim().toLowerCase();

  // خيار المتابعة
  if (handleReply.step === "continue_choice") {
    if (input === "متابعة") {
      return startRound(api, threadID, senderID, messageID, game);
    } else {
      global.bombGame.delete(senderID);
      return api.sendMessage("🏁 ┇ تـم إنـهـاء الـعـمـلـيـة.. حـمـاك الله مـن الانـفـجـار!", threadID, messageID);
    }
  }

  // منطق قطع السلك
  if (!game.wires.includes(input)) {
    return api.sendMessage(`⚠️ ┇ الـلـون "${input}" غـيـر مـوجـود فـي الـقـنـبـلـة!`, threadID, messageID);
  }

  if (input === game.correctWire) {
    game.wires = game.wires.filter(w => w !== input);
    
    if (game.wires.length <= 3) {
      await Currencies.increaseMoney(senderID, 200);
      global.bombGame.delete(senderID);
      return api.sendMessage("🎊 ┇ مـبـرووك! لـقـد فـكـكـت الـشـيـفـرة بـأمـان!\n💰 ┇ الـجـائـزة الـنـهـائـيـة: 200 عـمـلـة.", threadID, messageID);
    }

    await Currencies.increaseMoney(senderID, 100);
    const msg = `✅ ┇ سـلـك صـحـيـح! لـقـد نـجـوت هـذه الـمـرة.\n💰 ┇ ربـحـت: 100 عـمـلـة.\n──────────\n❓ ┇ هـل تـريـد الـ "متابعة" أم الـتـوقـف؟`;
    
    api.sendMessage(msg, threadID, (err, info) => {
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        step: "continue_choice"
      });
    }, messageID);

  } else {
    await Currencies.decreaseMoney(senderID, 50);
    global.bombGame.delete(senderID);
    return api.sendMessage("💥 ┇ بـوووووووم!!!\n⚠️ ┇ لـقـد كـان سـلـكاً مـلـغـومـاً.. انـفـجـرت الـقـنـبـلـة!\n💸 ┇ خـسـرت 50 عـمـلـة 💀", threadID, messageID);
  }
};

module.exports.run = async ({ api, event }) => {
  const { threadID, messageID, senderID } = event;
  const initialWires = ["أحمر", "أخضر", "أزرق", "أصفر", "أسود", "أبيض", "بنفسجي"];
  
  let game = {
    wires: initialWires,
    correctWire: ""
  };

  global.bombGame.set(senderID, game);
  return startRound(api, threadID, senderID, messageID, game);
};

async function startRound(api, threadID, senderID, messageID, game) {
  game.correctWire = game.wires[Math.floor(Math.random() * game.wires.length)];

  const wireIcons = {
    "أحمر": "🔴", "أخضر": "🟢", "أزرق": "🔵", "أصفر": "🟡", 
    "أسود": "⚫", "أبيض": "⚪", "بنفسجي": "🟣"
  };

  // عرض الأسلاك بشكل عمودي (واحد تحت الآخر)
  let list = game.wires.map(w => `${wireIcons[w] || "🔘"} ┇ ${w}`).join("\n");

  const msg = `🧨 ┇ تـفـكـيـك الـقـنـبـلـة الـمـوقـوتـة\n──────────\n${list}\n──────────\n⚠️ ┇ احـذر وتـأكـد مـن قـرارك!\n📝 ┇ أرسـل اسـم الـلـون لـقـطـعـه..`;

  return api.sendMessage(msg, threadID, (err, info) => {
    global.client.handleReply.push({
      name: "قنبلة",
      messageID: info.messageID,
      author: senderID,
      step: "cutting"
    });
  }, messageID);
}
