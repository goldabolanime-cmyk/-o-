const config = {
    name: "مملكتي",
    description: "نظام الرتب الملكية القائم على التزامك (الستريك)",
    usage: "",
    cooldown: 10,
    permissions: [0, 1, 2],
    credits: "RIO BOOT"
}

const langData = {
    "ar_SY": {
        "noData": "⏳ ┇ عذراً مولي، يجب أن تبدأ تحدياً أولاً باستخدام أمر (.عداد بدء).",
        "details": "┏━━━━━━━ 👑 ━━━━━━━┓\n   سِـجِـلُ الـمَـمْـلَـكَـةِ الـرَّسْـمِيّ   \n┗━━━━━━━ 👑 ━━━━━━━┛\n\n[👤] الـمُـحارب: {name}\n[🎖️] الـرُّتـبـة: {rank}\n[🔥] الـقُـوة (الأيام): {days}\n[🛡️] الـحـالـة: {status}\n\n━━━━━━━━━━━━━━━━━━━\n[📜] نـصـيـحـة الـمَـلِـك:\n{quote}\n━━━━━━━━━━━━━━━━━━━\n[•] رِيُـو بُـوت - سُـلـطَـةُ الـتَّـقَـدُّم"
    }
}

function getRank(days) {
    if (days >= 100) return "الإمبراطور الخالد 🔱";
    if (days >= 50) return "الملك الأسطوري 👑";
    if (days >= 30) return "الدوق العظيم 🏰";
    if (days >= 15) return "الفارس النبيل ⚔️";
    if (days >= 7) return "المحارب الشجاع 🛡️";
    if (days >= 3) return "الجندي المستجد 🗡️";
    return "مواطن طموح 🌱";
}

function getQuote(days) {
    const quotes = [
        "البدايات صعبة، لكن العظمة تستحق العناء.",
        "الاستمرار هو السر الذي لا يعرفه الكثيرون.",
        "كل يوم يمر يزيد من هيبتك في المملكة.",
        "لقد أصبحت قدوة للمحاربين الجدد هنا!",
        "القمة لا تتسع إلا لمن رفض الاستسلام."
    ];
    return quotes[Math.floor(Math.random() * quotes.length)];
}

async function onCall({ message, getLang, data }) {
    try {
        const userdata = data?.user?.data;
        const streakData = userdata?.streak || {};

        if (!userdata || !streakData.start) {
            return message.reply(getLang("noData"));
        }

        const { start, stopped } = streakData;
        let elapsed = (stopped ? stopped : Date.now()) - start;
        let days = Math.floor(elapsed / (1000 * 60 * 60 * 24));
        
        const rank = getRank(days);
        const quote = getQuote(days);
        const status = stopped ? "في استراحة محارب 💤" : "في قلب المعركة 🔥";

        return message.reply(getLang("details", {
            name: data.user.name,
            rank: rank,
            days: days,
            status: status,
            quote: quote
        }));

    } catch (e) {
        console.error(e);
        return message.reply("❌ ┇ عذراً مولي، تعذر الوصول للسجلات الملكية.");
    }
}

// التعديل الجوهري هنا ليتوافق مع نظامك:
module.exports = { config, langData, onCall }