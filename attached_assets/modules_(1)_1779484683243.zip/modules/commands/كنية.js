module.exports.config = {
  name: "كنيتي",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "تغيير كنية شخص أو جميع الأعضاء الحاليين",
  commandCategory: "إدارة المجموعة",
  usages: "[الكنية] بالرد على شخص | الكل [الكنية]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID, messageReply } = event;

  // --- 1. حالة تغيير كنية الكل (الأعضاء الموجودين حالياً) ---
  if (args[0] === "الكل") {
    const threadInfo = await api.getThreadInfo(threadID);
    const isAdmin = threadInfo.adminIDs.some(item => item.id == senderID);
    
    if (!isAdmin) return api.sendMessage("⚠️ | عـذراً، هـذا الأمـر مـخصـص لـلـمشرفين فـقط لـتغيير كـنيات الـكل.", threadID, messageID);

    const newNickAll = args.slice(1).join(" ");
    if (!newNickAll) return api.sendMessage("❌ | يـرجى كـتابة الـكنية الـتي تـريد تـعميمها على الـكل.", threadID, messageID);

    const members = threadInfo.participantIDs; // هؤلاء هم الأعضاء الموجودون فعلياً الآن
    api.sendMessage(`⏳ | جـاري تـغيير كـنية (${members.length}) عـضواً حالـياً...`, threadID);

    for (const id of members) {
      try {
        await api.changeNickname(newNickAll, threadID, id);
        // تأخير بسيط لتجنب حظر الفيسبوك في المجموعات الكبيرة
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (e) { 
        console.log(`فشل تغيير كنية العضو: ${id}`);
      }
    }
    return api.sendMessage(`✅ | تـم تـحديث كـنية جـميع الأعـضاء الـمتواجدين إلـى: 【 ${newNickAll} 】`, threadID);
  }

  // --- 2. حالة تغيير كنية شخص محدد (بالرد عليه) ---
  if (messageReply) {
    const nickToSet = args.join(" ");
    if (!nickToSet) return api.sendMessage("❌ | يـرجى كـتابة الـكنية بـعد الأمـر.", threadID, messageID);

    try {
      await api.changeNickname(nickToSet, threadID, messageReply.senderID);
      return api.sendMessage(`✅ | تـم تـغيير كـنية الـعضو بـنجاح.`, threadID, messageID);
    } catch (err) {
      return api.sendMessage("❌ | لـم أتـمكن مـن تـغيير الـكنية. تـأكد مـن صـلاحيات الـبوت.", threadID, messageID);
    }
  } else {
    return api.sendMessage("💡 | كـيف تـستخدمني؟\n1- رد على شخص واكتب: .كنية [الاسم الجديد]\n2- لتغيير الكل اكتب: .كنية الكل [الاسم الجديد]", threadID, messageID);
  }
};
