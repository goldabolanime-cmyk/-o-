const fs = require("fs-extra");
const path = __dirname + "/cache/autoReply.json";

module.exports.config = {
  name: "رد",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "يعلم البوت ردوداً تلقائية (تعلم / حذف / قائمة)",
  commandCategory: "تسلية",
  usages: "[تعلم كلمة => رد] أو [حذف كلمة] أو [قائمة]",
  cooldowns: 2
};

module.exports.onLoad = () => {
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
};

module.exports.handleEvent = async function ({ api, event }) {
  const { threadID, messageID, body } = event;
  if (!body) return;

  let replies = JSON.parse(fs.readFileSync(path));
  const input = body.toLowerCase().trim();

  if (replies[input]) {
    return api.sendMessage(replies[input], threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  let replies = JSON.parse(fs.readFileSync(path));
  const action = args[0];

  // 1. أمر التعلم: تلقائي تعلم [كلمة] => [رد]
  if (action === "تعلم") {
    const content = args.slice(1).join(" ");
    if (!content.includes("=>")) return api.sendMessage("❌ | الـتنسيق خـاطئ! اسـتخدم: تعلم [الكلمة] => [الرد]", threadID, messageID);

    const [key, ...valueArr] = content.split("=>");
    const value = valueArr.join("=>").trim();
    const cleanKey = key.trim().toLowerCase();

    if (!cleanKey || !value) return api.sendMessage("❌ | يـرجى كـتابة الـكلمة والـرد بـشكل صـحيح.", threadID, messageID);

    replies[cleanKey] = value;
    fs.writeFileSync(path, JSON.stringify(replies, null, 2));
    return api.sendMessage(`✅ | تـم الـتعلم! عـندما تـقول "${cleanKey}" سـأرد بـ "${value}"`, threadID, messageID);
  }

  // 2. أمر الحذف: تلقائي حذف [كلمة]
  if (action === "حذف") {
    const key = args.slice(1).join(" ").toLowerCase().trim();
    if (!replies[key]) return api.sendMessage("⚠️ | هـذه الـكلمة غـير مـوجودة فـي ذاكـرتي.", threadID, messageID);

    delete replies[key];
    fs.writeFileSync(path, JSON.stringify(replies, null, 2));
    return api.sendMessage(`🗑️ | تـم حـذف الـرد الـخاص بـكلمة "${key}" بـنجاح.`, threadID, messageID);
  }

  // 3. أمر القائمة: تلقائي قائمة
  if (action === "قائمة") {
    const keys = Object.keys(replies);
    if (keys.length === 0) return api.sendMessage("⚠️ | ذاكـرتي فارغـة حـالياً، لـم أتـعلم شـيئاً بـعد.", threadID, messageID);

    let msg = "📜 ┃ الـردود الـتي تـعلمتها:\n\n";
    keys.forEach((k, i) => msg += `${i + 1} - ${k} ➔ ${replies[k]}\n`);
    return api.sendMessage(msg, threadID, messageID);
  }

  return api.sendMessage("💡 | كـيف تـستخدمني؟\n1- للـتعلم: رد تعلم محمد => عمك\n2- للـحذف: رد حذف محمد\n3- للـقائمة: رد قائمة", threadID, messageID);
};
