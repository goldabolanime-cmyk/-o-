module.exports.config = {
  name: "لقب",
  version: "1.0.2",
  hasPermssion: 0,
  credits: "عمر / تعديل عبدو",
  description: "يضع لك لقباً مزخرفاً عشوائياً",
  commandCategory: "خدمات",
  cooldowns: 5,
  dependencies: {
    "request": ""
  },
  envConfig: {
    "APIKEY": "mi451266190"
  }
};

module.exports.run = async ({ api, event }) => {
  const request = require("request");
  const { threadID, senderID } = event;

  // دالة لتحويل الحروف العادية إلى حروف الزخرفة المطلوبة
  function decorate(text) {
    const map = {
      'a': 'Ꭿ', 'b': 'Ᏸ', 'c': 'Ꮸ', 'd': 'Ꭰ', 'e': 'Ꭼ', 'f': 'Ꮀ', 'g': 'Ꮆ', 'h': 'Ꮋ', 'i': '𝓘', 
      'j': 'Ꮰ', 'k': 'Ꮶ', 'l': 'Ꮭ', 'm': 'Ꮇ', 'n': 'Ꮑ', 'o': 'Ꮻ', 'p': 'Ꮲ', 'q': 'Ꭴ', 'r': 'Ꮢ', 
      's': 'Ꮪ', 't': 'Ꮏ', 'u': 'Ꮼ', 'v': 'Ꮙ', 'w': 'Ꮿ', 'x': 'Ꮸ', 'y': 'Ꮍ', 'z': 'Ꮓ'
    };
    return text.toLowerCase().split('').map(char => map[char] || char).join('');
  }

  const apiKey = global.configModule[this.config.name].APIKEY;
  const url = `https://www.behindthename.com/api/random.json?usage=jap&gender=f&key=${apiKey}`;

  return request(url, (err, response, body) => {
    if (err) return api.sendMessage("❌ | حدث خطأ في جلب اللقب.", threadID);
    
    try {
      const data = JSON.parse(body);
      const rawNickname = `${data.names[0]} ${data.names[1]}`;
      const decoratedNickname = decorate(rawNickname);

      api.changeNickname(decoratedNickname, threadID, senderID, (err) => {
        if (err) return api.sendMessage("❌ | لا يمكنني تغيير لقبك، تأكد من صلاحيات البوت.", threadID);
        api.sendMessage(`✅ | تـم مـنـحـك الـلـقـب الـمـزخـرف: 【 ${decoratedNickname} 】`, threadID);
      });
    } catch (e) {
      api.sendMessage("❌ | خطأ في تحليل البيانات من المصدر.", threadID);
    }
  });
}
