const axios = require("axios");

module.exports.config = {
  name: "سورة",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "جلب آيات القرآن الكريم مع تنظيف تلقائي للبحث",
  commandCategory: "إسلاميات",
  usages: "[اسم السورة] [رقم الآية]",
  cooldowns: 5
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body } = event;
  if (handleReply.author != event.senderID) return;

  const { surahId, verseNum } = handleReply;

  try {
    if (body == "1") {
      const res = await axios.get(`https://api.alquran.cloud/v1/ayah/${surahId}:${verseNum}/ar.jalalayn`);
      const explanation = res.data.data.text;
      
      let msg = `✨ ══━━━✥ ﴿ شَرْحُ الآيَةِ ﴾ ✥━━━══ ✨\n\n`;
      msg += `📖 ┇ الـتـفـسـيـر:\n« ${explanation} »\n\n`;
      msg += `✨ ══━━━━━━━✥━━━━━━━══ ✨\n`;
      msg += `👑 ┇ رِيُـو بُـوتْ لِـخِـدْمَةِ الـقُـرآنِ`;
      return api.sendMessage(msg, threadID, messageID);
    }

    if (body == "2") {
      const res = await axios.get(`https://api.alquran.cloud/v1/surah/${surahId}`);
      const info = res.data.data;
      
      let msg = `✨ ══━━━✥ ﴿ مَعْلُومَاتُ السُّورَةِ ﴾ ✥━━━══ ✨\n\n`;
      msg += `🔖 ┇ الاسـم: سـورة ${info.name}\n`;
      msg += `🔢 ┇ الـتـرتـيـب: ${info.number}\n`;
      msg += `🕋 ┇ الـحـالـة: ${info.revelationType === "Meccan" ? "مـكـيـة" : "مـدنـيـة"}\n`;
      msg += `📏 ┇ عـدد الآيـات: ${info.numberOfAyahs}\n`;
      msg += `📜 ┇ نـزلت بـعد سـورة: [${info.number - 1}]\n`;
      msg += `💡 ┇ الـمـسـتـفـاد: تـقـوى الله والـتـدبـر.\n\n`;
      msg += `✨ ══━━━━━━━✥━━━━━━━══ ✨\n`;
      return api.sendMessage(msg, threadID, messageID);
    }
  } catch (e) {
    return api.sendMessage("❌ ┇ عـذراً، تـعـذر جـلـب الـمـعـلومـات الآن.", threadID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  
  // وظيفة لتنظيف النص من الزخارف والرموز لضمان نجاح البحث
  function cleanText(text) {
    return text
      .replace(/[أإآ]/g, "ا")
      .replace(/ة/g, "ه")
      .replace(/ى/g, "ي")
      .replace(/[\u064B-\u065F]/g, "") // حذف التشكيل
      .trim();
  }

  const surahInput = args[0] ? cleanText(args[0]) : null;
  const verseNum = args[1];

  if (!surahInput || !verseNum) return api.sendMessage("⚠️ ┇ يـرجـى كـتـابـة: [ سورة النازعات 2 ] مـثـلاً.", threadID, messageID);

  try {
    api.sendMessage("⏳ ┇ جـارٍ الـبحث فـي الـمكتبة الـملكية..", threadID, messageID);

    const surahRes = await axios.get(`https://api.alquran.cloud/v1/surah`);
    const surah = surahRes.data.data.find(s => {
        let nameClean = cleanText(s.name);
        return nameClean.includes(surahInput) || s.englishName.toLowerCase().includes(surahInput.toLowerCase());
    });

    if (!surah) return api.sendMessage("❌ ┇ لـم أجـد سـورة بـهذا الاسـم، تأكد مـن الـكتابة الـصحيحة.", threadID, messageID);

    const ayahRes = await axios.get(`https://api.alquran.cloud/v1/ayah/${surah.number}:${verseNum}/ar.alafasy`);
    const ayahText = ayahRes.data.data.text;

    let msg = `✨ ══━━━✥ ﴿ الـقُـرآنُ الـكَـرِيـمُ ﴾ ✥━━━══ ✨\n\n`;
    msg += `📖 ┇ سُـورَةُ: ${surah.name}\n`;
    msg += `📍 ┇ الآيـة: [ ${verseNum} ]\n\n`;
    msg += `﴿ ${ayahText} ﴾\n\n`;
    msg += `━━━━━━━━━━━━━━━\n`;
    msg += `📥 ┇ رُد بـالـرقـم لـلـإجـراء:\n`;
    msg += `1️⃣ ┇ مـعـلـومـات الآيـة (شـرح)\n`;
    msg += `2️⃣ ┇ مـعـلـومـات الـسُّـورَة الـكـامـلـة\n`;
    msg += `━━━━━━━━━━━━━━━\n`;
    msg += `👑 ┇ نـظـام رِيُـو الـمـطـور ┇ 👑`;

    return api.sendMessage(msg, threadID, (err, info) => {
      global.client.handleReply.push({
        name: this.config.name,
        author: event.senderID,
        messageID: info.messageID,
        surahId: surah.number,
        verseNum: verseNum,
        type: "reply"
      });
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┇ تـأكـد مـن رقـم الآيـة (هـل هـي مـوجودة فـي هـذه الـسورة؟).", threadID, messageID);
  }
};