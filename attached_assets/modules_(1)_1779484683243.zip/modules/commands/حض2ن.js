const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const jimp = require("jimp");

module.exports.config = {
  name: "حضن2",
  version: "4.8.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "حضن ملكي: المرسل (ولد) والمستهدف (بنت)",
  commandCategory: "صور",
  usages: "[@منشن / رد على رسالة]",
  cooldowns: 5
};

async function circle(url) {
  const img = await jimp.read(url);
  img.circle();
  return await img.getBufferAsync(jimp.MIME_PNG);
}

module.exports.run = async function ({ event, api }) {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  const devID = "100090081489341"; // آيدي المطور عبدو
  const cacheDir = path.join(__dirname, "cache", "canvas");
  
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  let targetID;

  // تحديد الهدف (المستهدف سيكون في دور البنت)
  if (type === "message_reply") {
    targetID = messageReply.senderID;
  } 
  else if (Object.keys(mentions).length > 0) {
    targetID = Object.keys(mentions)[0];
  } 
  else {
    return api.sendMessage("🥰 ┇ يـرجى مـنشنة شـخص أو الـرد عـلى رسـالته لـتطبييق الـحضن!", threadID, messageID);
  }

  // 🛡️ درع حماية المطور عبدو
  if (targetID == devID && senderID !== devID) {
    const roastMessages = [
      "⚠️ ┇ الـمطور عـبدو خـط أحـمر! لا يـمكنك حضنه يا شاطر.",
      "👑 ┇ تـوقف! عـبدو مـطور الـنظام وتـاج رأسـك، الـزم حدودك.",
      "🚫 ┇ نـظام الـحماية: مـمنوع الاقـتراب مـن الـمطور مـلك الـتطوير."
    ];
    const randomRoast = roastMessages[Math.floor(Math.random() * roastMessages.length)];
    return api.sendMessage(`━━━━━━━━━━━━━━━\n${randomRoast}\n━━━━━━━━━━━━━━━`, threadID, messageID);
  }

  api.setMessageReaction("🥰", messageID, () => {}, true);
  api.sendMessage("⏳ ┇ جـارٍ تـجـهـيـز الـصـورة (أنـت الـولد وهـي الـبنت).. انـتـظر.", threadID, messageID);

  const outputPath = path.join(cacheDir, `hug2_${senderID}_${targetID}.png`);
  const baseUrl = "https://i.postimg.cc/d3GffPSm/received-854208751007248.jpg"; 
  const token = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662";

  try {
    const avatarSenderUrl = `https://graph.facebook.com/${senderID}/picture?width=512&height=512&access_token=${token}`;
    const avatarTargetUrl = `https://graph.facebook.com/${targetID}/picture?width=512&height=512&access_token=${token}`;

    const [baseBg, senderBuf, targetBuf] = await Promise.all([
      jimp.read(baseUrl),
      circle(avatarSenderUrl),
      circle(avatarTargetUrl)
    ]);

    const imgSender = await jimp.read(senderBuf); // صورة اللي كتب الأمر (الولد)
    const imgTarget = await jimp.read(targetBuf); // صورة اللي رد عليه (البنت)

    // الدمج بناءً على طلبك:
    // الإحداثيات تم ضبطها ليكون المرسل هو الولد والمستهدف هو البنت
    baseBg.composite(imgSender.resize(165, 165), 305, 105) // وجه الولد (المرسل)
          .composite(imgTarget.resize(145, 145), 215, 235); // وجه البنت (المستهدف)

    const buffer = await baseBg.getBufferAsync(jimp.MIME_PNG);
    fs.writeFileSync(outputPath, buffer);

    return api.sendMessage({
      body: "👑 ┇ تـمَّ الـحـضـن الـمـلكي بـنجاح!\n━━━━━━━━━━━━━━━\n🥰 ┇ أنـت الـسـند وهـي الأمـان.. مـودة رِيُـو بـوت\n━━━━━━━━━━━━━━━",
      attachment: fs.createReadStream(outputPath)
    }, threadID, () => {
      if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    }, messageID);

  } catch (e) {
    console.error("Error in hug2:", e);
    return api.sendMessage("❌ ┇ تـعذر إتـمام الـتصميم، تـأكد من الـسيرفر.", threadID, messageID);
  }
};