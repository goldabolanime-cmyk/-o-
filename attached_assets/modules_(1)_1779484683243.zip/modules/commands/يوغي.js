const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "يوغي",
  version: "1.0.5",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "جلب بطاقات يوغي بجودة عالية",
  commandCategory: "ترفيه",
  usages: "[اسم البطاقة بالإنجليزية]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const cardName = args.join(" ");

  if (!cardName) return api.sendMessage("🃏 ┃ يـرجـى كـتـابـة اسـم الـبطـاقـة.\nمـثـال: .يوغي Dark Magician", threadID, messageID);

  try {
    api.sendMessage("✨ ┃ جـاري سـحـب الـبطـاقـة مـن الـمـبـارزة...", threadID, messageID);

    // الرابط المباشر والسريع لبيانات يوغي
    const res = await axios.get(`https://db.ygoprodeck.com/api/v7/cardinfo.php?fname=${encodeURIComponent(cardName)}`);
    
    if (!res.data.data || res.data.data.length === 0) {
        return api.sendMessage("❌ ┃ لـم أجـد هـذه الـبطـاقـة.", threadID, messageID);
    }

    const card = res.data.data[0];
    const imgUrl = card.card_images[0].image_url;
    const path = __dirname + `/cache/yugi_${senderID}.jpg`;

    // تحميل الصورة بطريقة الـ Buffer المضمونة في ريبلت
    const imageRes = await axios.get(imgUrl, { responseType: 'arraybuffer' });
    fs.writeFileSync(path, Buffer.from(imageRes.data, 'utf-8'));

    const msg = {
      body: `🃏 ┃ بـطـاقـة الـمُـبـارز الـمَـلَـكِيـة\n━━━━━━━━━━━━━━━\n✨ ┃ الاسم: ${card.name}\n🎭 ┃ النوع: ${card.type}\n⚔️ ┃ الهجوم: ${card.atk || "---"} | 🛡️ ┃ الدفاع: ${card.def || "---"}\n━━━━━━━━━━━━━━━\n📝 ┃ الوصف:\n${card.desc.slice(0, 300)}...`,
      attachment: fs.createReadStream(path)
    };

    return api.sendMessage(msg, threadID, () => {
      if (fs.existsSync(path)) fs.unlinkSync(path);
    }, messageID);

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ ┃ حـدث خـطأ، تأكد من اتصال السيرفر بالإنترنت.", threadID, messageID);
  }
};