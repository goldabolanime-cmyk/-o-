const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "قائمتي",
  version: "1.5.0",
  hasPermssion: 0, // التحقق من الآيدي يدويًا داخل الكود لضمان الحماية
  credits: "Gemini",
  description: "حصري للمطور: عرض التوب 10 ومنح مكافآت",
  commandCategory: "المطور",
  usages: "",
  cooldowns: 5
};

module.exports.run = async ({ api, event, Currencies, Users }) => {
  const { threadID, messageID, senderID } = event;
  
  // 🛡️ التحقق من آيدي المطور الخاص بك
  const developerID = "100090081489341";
  if (senderID !== developerID) {
    return api.sendMessage("⚠️ ┇ عـذراً، هـذا الأمـر مـخـصـص فـقـط لـمـطـور الـبـوت!", threadID, messageID);
  }

  const cacheDir = path.join(__dirname, "cache");
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  try {
    api.sendMessage("📊 ┇ جـاري تـحـلـيـل الـبـيـانـات وتـحـديـد الـنـخـبـة...", threadID, messageID);

    // 1. جلب جميع المستخدمين وترتيبهم حسب التفاعل (exp)
    const allUsers = await Currencies.getAll(['userID', 'exp', 'money']);
    const top10 = allUsers
      .sort((a, b) => b.exp - a.exp)
      .slice(0, 10);

    let msg = "👑 ┇ أصـحـاب الـمـراكـز الـعـشـرة الأوائل\n──────────────\n";
    let attachments = [];

    for (let i = 0; i < top10.length; i++) {
      const user = top10[i];
      const info = await Users.getData(user.userID);
      const name = info.name || "مستـخدم مـجهول";
      const exp = user.exp || 0;
      const reward = 10000; // قيمة المكافأة اليومية (10 آلاف)

      // 2. منح المكافأة
      await Currencies.increaseMoney(user.userID, reward);

      // 3. كتابة المعلومات في الرسالة
      msg += `${i + 1} ┇ ${name}\n✨ ┇ الـتـفـاعـل: ${exp}\n💰 ┇ الـمـكـافـأة: +${reward}$\n──────────────\n`;

      // 4. جلب صور أفضل 3 متفاعلين فقط (لضمان سرعة الإرسال)
      if (i < 3) {
        try {
          const avatarURL = `https://graph.facebook.com/${user.userID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
          const imgPath = path.join(cacheDir, `top_dev_${i}.png`);
          const imgRes = await axios.get(avatarURL, { responseType: "arraybuffer" });
          fs.writeFileSync(imgPath, Buffer.from(imgRes.data, "utf-8"));
          attachments.push(fs.createReadStream(imgPath));
        } catch (e) { console.log(`خطأ في جلب صورة: ${user.userID}`); }
      }
    }

    msg += "✅ ┇ تـم تـوزيع الـمـكـافآت عـلى الـقـائـمة بـنـجاح!";

    // 5. إرسال النتيجة النهائية
    return api.sendMessage({
      body: msg,
      attachment: attachments
    }, threadID, (err) => {
      // تنظيف الكاش بعد الإرسال
      const files = fs.readdirSync(cacheDir).filter(f => f.startsWith("top_dev_"));
      for (const file of files) fs.unlinkSync(path.join(cacheDir, file));
    }, messageID);

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ ┇ حـدث خـطأ أثـناء تـنفيذ الأمـر يـا مـطوري.", threadID, messageID);
  }
};
