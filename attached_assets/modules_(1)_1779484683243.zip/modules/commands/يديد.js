const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');

module.exports.config = {
  name: "دمج",
  version: "2.0",
  hasPermssion: 0,
  credits: "عمر / إصلاح ريو",
  description: "دمج اثنين من الإيموجي في صورة واحدة",
  commandCategory: "العاب",
  usages: "[إيموجي1/إيموجي2]",
  cooldowns: 5,
  dependencies: {
    "axios": "",
    "fs-extra": ""
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  
  // دمج الأرقام المدخلة ثم فصلها عبر علامة /
  const content = args.join(" ");
  if (!content.includes("/")) {
    return api.sendMessage("⚠️ ┃ يرجى وضع علامة / بين الإيموجيات.\nمثال: .دمج 🙂/😉", threadID, messageID);
  }

  const emojis = content.split("/");
  const emoji1 = emojis[0].trim();
  const emoji2 = emojis[1].trim();

  if (!emoji1 || !emoji2) {
    return api.sendMessage("⚠️ ┃ تأكد من كتابة إيموجيين بشكل صحيح.", threadID, messageID);
  }

  api.sendMessage("⏳ ┃ جـارٍ دمج الإيموجيات...", threadID, messageID);

  try {
    // محاولة جلب الدمج من الرابط
    const url = `https://goatbotserver.onrender.com/taoanhdep/emojimix?emoji1=${encodeURIComponent(emoji1)}&emoji2=${encodeURIComponent(emoji2)}`;
    
    const cachePath = path.join(__dirname, 'cache', `emojimix_${Date.now()}.png`);
    if (!fs.existsSync(path.join(__dirname, 'cache'))) fs.mkdirSync(path.join(__dirname, 'cache'), { recursive: true });

    const response = await axios({
      method: 'get',
      url: url,
      responseType: 'arraybuffer'
    });

    // إذا كان الرد يحتوي على صورة فعلاً وليس خطأ
    if (response.data.length > 100) { 
      fs.writeFileSync(cachePath, Buffer.from(response.data));

      return api.sendMessage({
        body: `✅ ┃ تم دمج ${emoji1} مع ${emoji2} بنجاح:`,
        attachment: fs.createReadStream(cachePath)
      }, threadID, () => {
        if (fs.existsSync(cachePath)) fs.unlinkSync(cachePath);
      }, messageID);
    } else {
      throw new Error("Invalid Image");
    }

  } catch (e) {
    console.error(e);
    return api.sendMessage(`❌ ┃ عذراً، لا يمكن دمج ${emoji1} مع ${emoji2} حالياً. جرب إيموجيات أخرى.`, threadID, messageID);
  }
};