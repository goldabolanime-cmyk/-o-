module.exports.config = {
  name: "نقاط",
  version: "2.0.0",
  hasPermssion: 2,
  credits: "عبدو / RIO BOOT",
  description: "التحكم الملكي في نقاط الخبرة والمستويات",
  commandCategory: "المطور",
  usages: "[رفع / del / uid] [تاك أو ايدي] [القيمة]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args, Currencies, Users }) {
  const { threadID, messageID, senderID, mentions } = event;
  
  // قائمة المطورين المسموح لهم (أضف أيديهك هنا)
  const developers = ["100090081489341", "61556064038238"]; 
  if (!developers.includes(senderID)) return api.sendMessage("⚠️ ┃ هـذا الأمـر مـخصص لـلمـطور عـبدو فـقط.", threadID, messageID);

  const header = "👑 ═══ ﴿ الـتَّـحَـكُّـمُ الـمَـلَـكِـي ﴾ ═══ 👑\n\n";

  // 1. حالة الرفع (تعديل نقاطك أنت)
  if (args[0] == 'رفع') {
    let amount = parseInt(args[1]);
    if (isNaN(amount)) return api.sendMessage(`${header}📍 يرجى تحديد رقم صحيح للنقاط.`, threadID, messageID);
    
    await Currencies.setData(senderID, { exp: amount });
    return api.sendMessage(`${header}✅ تـم تـعديـل نـقاط خـبرتـك إلـى: 【 ${amount} 】 نـقـطة.`, threadID, messageID);
  }

  // 2. حالة الحذف (تصفير النقاط)
  if (args[0] == "del") {
    if (args[1] == 'نقاطي') {
      await Currencies.setData(senderID, { exp: 0 });
      return api.sendMessage(`${header}🗑️ تـم تـصـفـيـر نـقاط خـبرتـك بـنـجـاح.`, threadID, messageID);
    } 
    else if (Object.keys(mentions).length > 0) {
      let mentionID = Object.keys(mentions)[0];
      await Currencies.setData(mentionID, { exp: 0 });
      return api.sendMessage(`${header}🗑️ تـم تـصـفـيـر نـقاط الـعـضو: ${mentions[mentionID].replace("@", "")}`, threadID, messageID);
    }
  }

  // 3. حالة التعديل عبر الـ UID
  if (args[0] == "uid") {
    let targetID = args[1];
    let amount = parseInt(args[2]);
    if (isNaN(amount)) return api.sendMessage(`${header}📍 الاستخدام: نقاط uid [الأيدي] [النقاط]`, threadID, messageID);
    
    try {
      let userData = await Users.getData(targetID);
      await Currencies.setData(targetID, { exp: amount });
      return api.sendMessage(`${header}✅ تـم تـعديـل نـقاط ${userData.name} إلـى: 【 ${amount} 】 نـقـطة.`, threadID, messageID);
    } catch (e) {
      return api.sendMessage(`${header}❌ لـم يـتم الـعـثور عـلى مـستـخدم بهـذا الأيـدي.`, threadID, messageID);
    }
  }

  // 4. حالة التعديل عبر التاك (المنشن) المباشر
  if (Object.keys(mentions).length > 0) {
    let mentionID = Object.keys(mentions)[0];
    let amount = parseInt(args[args.length - 1]); // يأخذ آخر كلمة في الأمر كقيمة رقمية
    
    if (isNaN(amount)) return api.sendMessage(`${header}📍 يرجى كتابة الرقم في نهاية الأمر.`, threadID, messageID);
    
    await Currencies.setData(mentionID, { exp: amount });
    return api.sendMessage({
      body: `${header}✅ تـم تـغييـر نـقاط ${mentions[mentionID].replace("@", "")} إلـى: 【 ${amount} 】 نـقـطة.`,
      mentions: [{ tag: mentions[mentionID].replace("@", ""), id: mentionID }]
    }, threadID, messageID);
  }

  // رسالة المساعدة في حال الخطأ
  return api.sendMessage(`${header}📍 طُـرُقُ الـاسْـتِـخْـدَامِ:\n1️⃣ نقاط رفع [العدد]\n2️⃣ نقاط [تاك] [العدد]\n3️⃣ نقاط uid [الأيدي] [العدد]\n4️⃣ نقاط del [نقاطي / تاك]`, threadID, messageID);
};