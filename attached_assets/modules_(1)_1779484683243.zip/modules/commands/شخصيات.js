module.exports.config = {
  name: "وايفو",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "احزر اسم الشخصيه من الصوره - نسخة ريو الملكية",
  usages: ["لعبة"],
  commandCategory: "العاب",
  cooldowns: 5
};

const fs = require('fs-extra');
const axios = require('axios');
const path = require('path');

module.exports.handleReply = async function ({ api, event, handleReply, Currencies, Users }) {
  const { body, senderID, threadID, messageID } = event;
  if (handleReply.author && senderID !== handleReply.author) return;
  
  const userAnswer = body.trim().toLowerCase();
  const correctAnswer = handleReply.correctAnswer.toLowerCase();
  const userName = await Users.getNameUser(senderID);

  if (userAnswer === correctAnswer) {
      await Currencies.increaseMoney(senderID, 100);
      api.sendMessage(`✨ 🎊 ﴿ تَهْنِئَةٌ مَلَكِيَّةٌ ﴾ 🎊 ✨\n━━━━━━━━━━━━━━━━━━\n👤 الـمُـبْـدِع: ${userName}\n✅ الإجـابـة صـحيـحة: 【 ${handleReply.correctAnswer} 】\n💰 الـجـائزة: 100 عـملـة\n━━━━━━━━━━━━━━━━━━\n👑 رِيـو بُـوت - ذَكَـاءٌ وَتَـرْفِـيـه`, threadID, messageID);
      api.unsendMessage(handleReply.messageID);
  } else {
      api.sendMessage(`❌ ┃ لـلأسـف يـا سـيـدي، الإجـابـة خـاطـئة. حـاول مـرة أخـرى!`, threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, Users }) {
  const { threadID, messageID, senderID } = event;
  const questions = [
    { image: "https://i.imgur.com/yrEx6fs.jpg", answer: "كورومي" },
    { image: "https://i.imgur.com/cAFukZB.jpg", answer: "الينا" },
    { image: "https://i.pinimg.com/236x/63/c7/47/63c7474adaab4e36525611da528a20bd.jpg", answer: "فوليت" },
    { image: "https://i.pinimg.com/236x/b3/cd/6a/b3cd6a25d9e3451d68628b75da6b2d9e.jpg", answer: "ليفاي" },
    { image: "https://i.pinimg.com/236x/eb/a1/c6/eba1c6ed1611c3332655649ef405490a.jpg", answer: "مايكي" },
    { image: "https://i.pinimg.com/236x/34/81/ba/3481ba915d12d27c1b2a094cb3369b4c.jpg", answer: "كاكاشي" },
    { image: "https://i.pinimg.com/236x/3a/df/87/3adf878c1b6ef2a90ed32abf674b780c.jpg", answer: "ميدوريا" },
    { image: "https://i.pinimg.com/236x/26/6e/8d/266e8d8e9ea0a9d474a8316b9ed54207.jpg", answer: "غوجو" },
    { image: "https://i.pinimg.com/474x/e5/2f/a3/e52fa34886b53184b767b04c70ce0885.jpg", answer: "دازاي" },
    { image: "https://i.pinimg.com/236x/bd/9d/5a/bd9d5a5040e872d4ec9e9607561e22da.jpg", answer: "زيرو تو" }
  ];

  const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
  const cacheDir = path.join(__dirname, "cache");
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
  const tempPath = path.join(cacheDir, `char_${senderID}_${Date.now()}.jpg`);

  try {
    const response = await axios.get(randomQuestion.image, { responseType: "arraybuffer" });
    fs.writeFileSync(tempPath, Buffer.from(response.data, "binary"));

    api.sendMessage({ 
      body: `👤 ┃ مَـنْ هِـذِهِ الـشَّـخْـصِـيَّـةُ ؟\n━━━━━━━━━━━━━━━\n❐ قُـمْ بِـالـرَّدِّ عـلـى هـذه الـرِّسـالـة بـاسـم الـشـخـصـيـة.`, 
      attachment: fs.createReadStream(tempPath) 
    }, threadID, (error, info) => {
        if (!error) {
            global.client.handleReply.push({
                name: this.config.name,
                messageID: info.messageID,
                correctAnswer: randomQuestion.answer,
                author: senderID
            });
        }
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    }, messageID);
  } catch (e) {
    api.sendMessage("❌ ┃ حـدث خـطـأ فـي تـحـمـيـل الـصـورة، حـاول مـجـدداً.", threadID, messageID);
  }
};