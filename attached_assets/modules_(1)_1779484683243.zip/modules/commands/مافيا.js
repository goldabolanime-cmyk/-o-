const fs = require("fs-extra");
const axios = require("axios");
const path = require("path");

module.exports.config = {
  name: "مافيا",
  version: "3.5.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "لعبة رعب المافيا في البيت المهجور (2-5 لاعبين)",
  commandCategory: "ألعاب",
  usages: "[تسجيل/بدء/انسحاب]",
  cooldowns: 5
};

// --- مساعدات بصرية (أشرطة الدم والطاقة) ---
function createBar(current, max) {
    let char = "█"; 
    let empty = "░";
    let size = 5;
    let percent = Math.max(0, Math.round((current / max) * size));
    return char.repeat(percent) + empty.repeat(size - percent);
}

module.exports.run = async function({ api, event, args, Users }) {
    const { threadID, messageID, senderID } = event;
    if (!global.mafia) global.mafia = new Map();

    let game = global.mafia.get(threadID);

    // --- أمر التسجيل ---
    if (args[0] === "تسجيل") {
        if (game && game.status === "started") return api.sendMessage("🛑 ┃ الـلـعـبـة بـدأت بـالـفـعـل فـي هـذا الـبـيـت الـمـهـجـور.", threadID);
        if (!game) {
            game = { status: "open", players: [], threadID: threadID };
            global.mafia.set(threadID, game);
        }
        
        if (game.players.find(p => p.id === senderID)) return api.sendMessage("🩸 ┃ أَنْـتَ مُـسَـجَّـلٌ بِـالـفِـعْـلِ فِـي قَـائِـمَـةِ الـضَّـحَـايَـا.", threadID, messageID);
        if (game.players.length >= 5) return api.sendMessage("❌ ┃ الـبَـيْـتُ لَا يَـتَّـسِـعُ لِـأَكْـثَـرَ مِـنْ 5 أَشْـخَـاصٍ.", threadID, messageID);

        let name = await Users.getNameUser(senderID);
        game.players.push({ id: senderID, name: name, hp: 100, energy: 100, status: "alive" });
        
        return api.sendMessage(`📜 ┃ تَـمَّ تَـسْـجِـيـلُ الـضَّـحِـيَّـةِ: ${name}\n👥 ┃ الـعَـدَدُ الـحَـالِي: ${game.players.length}/5\n💡 ┃ اكْـتُـبْ [ مافيا بدء ] عِـنْـدَمَـا يَـكْـتَـمِـلُ الـفَـرِيـقُ.`, threadID, messageID);
    }

    // --- أمر البدء ---
    if (args[0] === "بدء") {
        if (!game || game.players.length < 2) return api.sendMessage("⚠️ ┃ يَـجِـبُ تَـسْـجِـيـلُ لَـاعِـبَـيْـنِ عَـلَى الـأَقَـلِّ لِـدُخُـولِ الـمَـجْـزَرَةِ.", threadID, messageID);
        if (game.status === "started") return api.sendMessage("🛑 ┃ الـلَّـعْـبَـةُ مُـسْـتَـمِـرَّةٌ بِـالـفِـعْـلِ.", threadID, messageID);

        game.status = "started";
        api.sendMessage("⏳ ┃ يَـتِـمُّ الـآنَ تَـحْـضِـيـرُ الـأَرْوَاحِ... سَـتَـبْـدَأُ الـلَّـعْـبَـةُ بَـعْـدَ 10 ثَـوَانٍ.", threadID);

        setTimeout(() => {
            playRound(api, threadID, game);
        }, 10000);
        return;
    }

    // --- أمر الانسحاب ---
    if (args[0] === "انسحاب") {
        if (!game || game.status === "started") return api.sendMessage("🛑 ┃ لَا يُـمْـكِـنُ الِانْـسِـحَـابُ بَـعْـدَ بَدْءِ الـمَـجْـزَرَةِ.", threadID, messageID);
        game.players = game.players.filter(p => p.id !== senderID);
        if (game.players.length === 0) global.mafia.delete(threadID);
        return api.sendMessage("🏃 ┃ تَـمَّ انْـسِـحَـابُـكَ مِـنَ الـبَـيْـتِ الـمَـهْـجُـورِ بـأمـان.", threadID, messageID);
    }
};

async function playRound(api, threadID, game) {
    const alivePlayers = game.players.filter(p => p.status === "alive");

    if (alivePlayers.length <= 1) {
        let winner = alivePlayers[0];
        let msg = winner ? `🏆 ┃ الـنَّـاجِي الـوَحِـيـدُ مِـنَ الـمَـجْـزَرَةِ هُـوَ: ${winner.name}` : `💀 ┃ لَـمْ يَـنْـجُ أَحَـدٌ... الـجَـمِـيـعُ هَـلَـكُـوا.`;
        api.sendMessage(`🛑 ┃ انْـتَـهَـتِ الـمُـغَـامَـرَةُ ┃ 🛑\n━━━━━━━━━━━━━━━\n${msg}\n━━━━━━━━━━━━━━━`, threadID);
        global.mafia.delete(threadID);
        return;
    }

    const events = [
        { title: "الـقَـبْـو الـمُـظْـلِـم", damage: 20, energy: -10, msg: "تَـعَـثَّـرْتَ فِـي جُـثَّـةٍ هَـامِـدَةٍ وَنَـزَفْـتَ بَـعْـضَ الـدَّمِ." },
        { title: "فَـخُّ الـمَافْـيَا", damage: 40, energy: -20, msg: "أَصَـابَـكَ سَـهْـمٌ مَـسْـمُـومٌ مِـنْ أَحَـدِ الـجُـدْرَانِ." },
        { title: "رُوحٌ مُـعَـذَّبَـة", damage: 15, energy: -30, msg: "شَـبَـحُ امْـرَأَةٍ صَـارِخَـةٍ امْـتَـصَّ طَـاقَـتَـكَ." },
        { title: "صُـنْـدُوقُ الـإِسْـعَـاف", damage: -25, energy: 15, msg: "وَجَـدْتَ ضِـمَادَاتٍ قَـدِيـمَـةً بِـقُـرْبِ هَـيْـكَـلٍ عَـظْـمِيٍّ." },
        { title: "الـظَّـلَامُ الـحَـالِـك", damage: 5, energy: -5, msg: "الـخَوْفُ يَـتَـمَـلَّـكُـكَ وَقَـلْـبُـكَ يَـكُـادُ يَـتَـوَقَّـفُ." }
    ];

    let roundMsg = "🩸 ┃ أَحْـدَاثُ الـلَّـيْـلَـةِ الـمُـرْعِـبَـةِ ┃ 🩸\n━━━━━━━━━━━━━━━\n";

    game.players.forEach(player => {
        if (player.status === "alive") {
            let randEvent = events[Math.floor(Math.random() * events.length)];
            player.hp -= randEvent.damage;
            player.energy += randEvent.energy;

            if (player.hp > 100) player.hp = 100;
            if (player.hp <= 0) { player.hp = 0; player.status = "dead"; }
            if (player.energy < 0) player.energy = 0;
            if (player.energy > 100) player.energy = 100;

            roundMsg += `👤 ❯ ${player.name}\n`;
            roundMsg += `💢 ❯ الـحَـدَثُ: ${randEvent.title}\n`;
            roundMsg += `🩸 ❯ الـدَّمُ: [${createBar(player.hp, 100)}] ${player.hp}%\n`;
            roundMsg += `⚡ ❯ الـطَّـاقَـةُ: [${createBar(player.energy, 100)}] ${player.energy}%\n`;
            roundMsg += `💬 ❯ ${randEvent.msg}\n`;
            if (player.status === "dead") roundMsg += `💀 ❯ لَـقَـدْ فَـارَقَ الـحَـيَـاةَ...\n`;
            roundMsg += "━━━━━━━━━━━━━━━\n";
        }
    });

    api.sendMessage(roundMsg, threadID);

    setTimeout(() => {
        playRound(api, threadID, game);
    }, 12000); 
}
