module.exports.config = {
  name: "ترجمة",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "ترجمة النصوص مع إشعار جارِ المعالجة",
  commandCategory: "خدمات",
  usages: "[النص / بالرد على رسالة]",
  cooldowns: 5,
  dependencies: {
    "axios": ""
  }
};

module.exports.run = async ({ api, event, args }) => {
  const axios = require("axios");
  const { threadID, messageID, type, messageReply } = event;
  
  let translateThis = args.join(" ");
  let lang = "ar"; // اللغة الهدف الافتراضية

  // التحقق من وجود نص أو رد على رسالة
  if (!translateThis && type !== "message_reply") {
    return api.sendMessage("☆ يُـرجى كِـتابَةُ نَـصٍّ أو اَلـرَّدُّ عَـلَى رِسَـالَةٍ لِـتَرْجَمَتِهَا.", threadID, messageID);
  }

  if (type === "message_reply") {
    translateThis = messageReply.body;
  }

  // إرسال رسالة انتظار مزخرفة
  const waitMsg = await api.sendMessage("╔════════════════════╗\n   ☆ جَـارِ تَـحْـلِـيلِ وَتَـرْجَـمَـةِ اَلـنَّـصِّ...\n╚════════════════════╝", threadID);

  try {
    const apiUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(translateThis)}`;
    const res = await axios.get(apiUrl);
    const retrieve = res.data;
    
    let text = "";
    retrieve[0].forEach(item => (item[0]) ? text += item[0] : "");
    
    const fromLang = retrieve[2]; // اللغة المصدر المكتشفة تلقائياً

    const finalMsg = `╔════════════════════╗\n` +
                     `   ☆ تَـمَّـتِ اَلـتَّـرْجَـمَـةُ بِـنَـجَـاحٍ ☆\n` +
                     `╚════════════════════╝\n\n` +
                     `‹ اَلـنَّـصُّ اَلـمُـتَـرْجَـمُ › ::\n${text}\n\n` +
                     `◈━━━━━━━━━━━━━━◈\n\n` +
                     `‹ مِـنْ لُـغَـةِ › :: [ ${fromLang.toUpperCase()} ]\n` +
                     `‹ إِ لَـى لُـغَـةِ › :: [ ${lang.toUpperCase()} ]\n\n` +
                     `☆ رِيُـو بُـوتْ - نِـظَـامُ اَلـلُّـغَـاتِ`;

    // حذف رسالة الانتظار وإرسال النتيجة
    api.unsendMessage(waitMsg.messageID);
    return api.sendMessage(finalMsg, threadID, messageID);

  } catch (err) {
    api.unsendMessage(waitMsg.messageID);
    return api.sendMessage("☆ حَـدَثَ خَـطَأٌ فِـي اَلْاتِّـصَالِ بِـخِدْمَةِ اَلـتَّـرْجَـمَةِ.", threadID, messageID);
  }
};