const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "فوطو",
  version: "1.0.0",
  hasPermssion: 1, // 0 للجميع، 1 للمسؤولين فقط (يفضل 1 لحماية المجموعة)
  credits: "عبدو / RIO BOOT",
  description: "تغيير صورة المجموعة عبر الرد على صورة",
  commandCategory: "إدارة المجموعات",
  usages: "قم بالرد على صورة واكتب .فوطو",
  cooldowns: 5
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID, type, messageReply } = event;

  // 1. التأكد من أن المستخدم رد على رسالة
  if (type !== "message_reply") {
    return api.sendMessage("❌ | يا سيدي، يجب أن ترد على صورة أولاً لكي أقوم بتغييرها.", threadID, messageID);
  }

  // 2. التأكد من أن الرسالة التي تم الرد عليها تحتوي على صورة (Photo)
  if (!messageReply.attachments || messageReply.attachments.length == 0 || messageReply.attachments[0].type !== "photo") {
    return api.sendMessage("❌ | هذه ليست صورة! أرجوك رد على صورة حقيقية.", threadID, messageID);
  }

  try {
    const imgUrl = messageReply.attachments[0].url;
    const pathImg = __dirname + `/cache/group_image_${threadID}.png`;

    // 3. تحميل الصورة مؤقتاً
    const getImg = (await axios.get(imgUrl, { responseType: "arraybuffer" })).data;
    fs.writeFileSync(pathImg, Buffer.from(getImg, "utf-8"));

    // 4. تغيير صورة المجموعة
    return api.changeGroupImage(fs.createReadStream(pathImg), threadID, (err) => {
      if (err) {
        return api.sendMessage("⚠️ | فشلت في تغيير الصورة. تأكد أنني (أدمن) في المجموعة يا سيدي.", threadID, messageID);
      } else {
        // حذف الملف المؤقت بعد النجاح
        fs.unlinkSync(pathImg);
        return api.sendMessage("✅ | تـم تـحـديـث هـويـة الـمـجـمـوعـة بـنـجـاح.. نـظـرة جـديـدة تـلـيـق بـنـا!", threadID, messageID);
      }
    });

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ | حـدث خـطأ غـيـر مـتـوقـع أثناء مـعـالـجـة الـصورة.", threadID, messageID);
  }
};
