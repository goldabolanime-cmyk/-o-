const axios = require("axios");

module.exports.config = {
    name: "جزاء",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "عمر / تعديل ريو",
    description: "لعبة ضربات الجزاء",
    commandCategory: "العاب",
    usages: "[المبلغ]",
    cooldowns: 5
};

module.exports.run = async ({ api, event, args, Currencies }) => {
    const { threadID, messageID, senderID } = event;
    const bet = parseInt(args[0]);

    if (!bet || isNaN(bet) || bet <= 0) return api.sendMessage('⚽ | يـرجى وضـع رهان صـحيح لـضربة الـجزاء!', threadID, messageID);
    
    const userData = await Currencies.getData(senderID);
    if (userData.money < bet) return api.sendMessage(`❌ | رصـيدك لا يـكفي لـهذا الـرهان!`, threadID, messageID);

    await Currencies.decreaseMoney(senderID, bet);

    try {
        const gifUrl = "https://i.postimg.cc/bJ60WRwL/20220728-113119.gif";
        const msg = { 
            body: `⚽ | ضـربات الـجـزاء\n━━━━━━━━━━━━━━━\nاخـتر لاعـباً لـتسديد الـكرة:\n1. ريـال مـدريد (سـهل)\n2. بـرشلونة (مـتوسط)\n3. مـانشستر (صـعب)\n4. كـرستيـانو (أسـطوري)\n━━━━━━━━━━━━━━━\n📩 | رد بـرقـم الـلاعب للـتسديد!`,
            attachment: (await axios.get(gifUrl, { responseType: "stream" })).data
        };

        return api.sendMessage(msg, threadID, (err, info) => {
            global.client.handleReply.push({
                name: this.config.name,
                messageID: info.messageID,
                author: senderID,
                bet: bet
            });
        }, messageID);
    } catch (e) {
        return api.sendMessage("❌ | خـطأ فـي بـدء الـلعبة.", threadID, messageID);
    }
};

module.exports.handleReply = async ({ api, Currencies, event, handleReply }) => {
    const { threadID, senderID, messageID, body } = event;
    if (handleReply.author !== senderID) return;

    const choice = parseInt(body);
    if (isNaN(choice) || choice < 1 || choice > 4) return api.sendMessage("❌ | اخـتر رقـماً صـحيحاً!", threadID, messageID);

    api.unsendMessage(handleReply.messageID);
    api.sendMessage(`⚽ | ${handleReply.author === senderID ? 'تـسديد...' : ''}`, threadID);

    setTimeout(async () => {
        const odds = [0, 0.7, 0.5, 0.3, 0.1];
        const win = Math.random() < odds[choice];
        const mult = [0, 1.5, 2.5, 5, 20];
        const prize = Math.floor(handleReply.bet * mult[choice]);

        if (win) {
            await Currencies.increaseMoney(senderID, prize);
            api.sendMessage(`🥅 | هــــــــدف! لـقد سـجلت وربـحت ${prize}$.`, threadID, messageID);
        } else {
            api.sendMessage(`🧤 | تـصدى لـها الـحارس! خـسرت رهانـك.`, threadID, messageID);
        }
    }, 2500);
};