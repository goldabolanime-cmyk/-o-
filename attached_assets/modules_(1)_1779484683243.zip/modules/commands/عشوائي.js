module.exports.config = {
  name: "عشوائي",
  version: "1.0.0",
  hasPermssion: 2, // صلاحية للمطور فقط (أو الإداريين حسب نظامك)
  credits: "RIO BOOT",
  description: "اختيار صديق عشوائي وإضافته للمجموعة عبر عجلة الحظ",
  commandCategory: "أدوات",
  usages: ".عشوائي",
  cooldowns: 20
};

module.exports.run = async ({ api, event, Users }) => {
  const { threadID, messageID } = event;

  try {
    // 1. جلب قائمة الأصدقاء الخاصة بالبوت
    const friendsList = await api.getFriendsList();
    
    if (!friendsList || friendsList.length === 0) {
      return api.sendMessage("❌ | عذراً، قائمة أصدقاء البوت فارغة حالياً.", threadID, messageID);
    }

    // 2. إرسال رسالة البداية
    api.sendMessage("🎡 | جاري لف عجلة الحظ... انتظر 10 ثوانٍ لمعرفة الفائز!", threadID);

    // 3. الانتظار لمدة 10 ثوانٍ
    setTimeout(async () => {
      
      // 4. اختيار شخص عشوائي من القائمة
      const randomFriend = friendsList[Math.floor(Math.random() * friendsList.length)];
      const friendID = randomFriend.userID;
      const friendName = randomFriend.fullName;

      // 5. محاولة إضافة الشخص للمجموعة
      api.addUserToGroup(friendID, threadID, async (err) => {
        if (err) {
          return api.sendMessage(`🎰 | عجلة الحظ اختارت: [ ${friendName} ]\n❌ | تعذر إدخاله للمجموعة (ربما بسبب إعدادات الخصوصية لديه أو البوت ليس مسؤولاً).`, threadID);
        }

        // 6. رسالة الترحيب والنجاح
        api.sendMessage(`🎉 | عجلة الحظ اختارت الفائز... \n🌟 | الاسم: ${friendName}\n🆔 | الآيدي: ${friendID}\n✨ | مرحبا بك معنا في المجموعة!`, threadID);
      });

    }, 10000); // 10000 ميلي ثانية تعادل 10 ثوانٍ

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ | حدث خطأ أثناء محاولة تشغيل عجلة الحظ.", threadID, messageID);
  }
};