const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "محكمة",
  version: "5.5.0",
  hasPermssion: 1, 
  credits: "RIO BOOT",
  description: "جلسة محاكمة بالصور مع ميزة العفو الملكي للمطور",
  commandCategory: "إدارة",
  usages: "[رد على الشخص]",
  cooldowns: 10
};

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { threadID, messageID, senderID, body } = event;
  if (handleReply.type !== "court_vote") return;

  const vote = body.trim();
  const devID = "100090081489341"; // أيدي المطور عبدو

  // ميزة العفو الملكي (خاصة بالمطور فقط)
  if (vote === "عفو" && senderID === devID) {
    handleReply.afws = true; // تفعيل حالة العفو
    api.setMessageReaction("👑", messageID, () => {}, true);
    return api.sendMessage("👑 ┃ قَـرَارٌ سِيَـادِي: صَدَرَ عَفْوٌ مَلَكِيٌّ مِنَ الْمُطَوِّرِ.. رُفِعَتِ الْجَلْسَةُ وَتَمَّتْ تَبْرِئَةُ الْمُتَّهَمِ فَوْرًا!", threadID, messageID);
  }

  // منع التصويت المكرر للمستخدمين
  if (handleReply.voters.includes(senderID)) {
    return api.sendMessage("🚫 ┃ لـقـد قـمـت بـالـتـصويـت مـسـبـقـاً!", threadID, messageID);
  }

  if (vote === "إدانة") {
    handleReply.idanes++;
    handleReply.voters.push(senderID);
    api.setMessageReaction("🔥", messageID, () => {}, true);
  } 
  else if (vote === "تبرئة") {
    handleReply.tabrias++;
    handleReply.voters.push(senderID);
    api.setMessageReaction("🛡️", messageID, () => {}, true);
  }
};

module.exports.run = async function ({ api, event, Users, Currencies }) {
  const { threadID, messageID, senderID, messageReply, type } = event;
  const devID = "100090081489341";

  if (type !== "message_reply") return api.sendMessage("⚠️ ┃ يـرجى الـرد عـلى الـمتـهم لافـتـتـاح الـمـحـكـمـة!", threadID, messageID);

  const victimID = messageReply.senderID;
  if (victimID == devID) return api.sendMessage("🚫 ┃ لا يـمـكـن مـحـاكـمـة الـمـطور.. لـه الـحصـانـة الـمـطـلـقـة!", threadID, messageID);
  if (victimID == api.getCurrentUserID()) return api.sendMessage("⚖️ ┃ أنـا الـقاضـي هـنا.. لا أحـاكـم نـفـسـي!", threadID, messageID);

  const victimName = await Users.getNameUser(victimID);
  
  const threadInfo = await api.getThreadInfo(threadID);
  const participants = threadInfo.participantIDs.filter(id => id != victimID && id != api.getCurrentUserID());
  
  const prosecutorID = participants[Math.floor(Math.random() * participants.length)];
  const jury1 = participants[Math.floor(Math.random() * participants.length)];
  const jury2 = participants[Math.floor(Math.random() * participants.length)];
  
  const prosecutorName = await Users.getNameUser(prosecutorID);
  const jury1Name = await Users.getNameUser(jury1);
  const jury2Name = await Users.getNameUser(jury2);

  const imgPath = __dirname + `/cache/court_${Date.now()}.jpg`;
  const imgUrl = "https://i.postimg.cc/qvmCXSww/360-F-229309417-s-Qpmx-V6JEK5PBlhrj-Sp-Tz6WGHZa-Zv6od.jpg";

  try {
    const response = await axios.get(imgUrl, { responseType: 'arraybuffer' });
    fs.writeFileSync(imgPath, Buffer.from(response.data, 'binary'));

    let introMsg = `⚖️ ┃ جـلـسـة الـمـحـاكـمة الـعـلـنـيـة\n━━━━━━━━━━━━━━━\n`;
    introMsg += `👨‍⚖️ ┃ الـقـاضـي: رِيُـو بُـوت\n`;
    introMsg += `👤 ┃ الـمـتـهـم: ${victimName}\n`;
    introMsg += `🕵️‍♂️ ┃ الـمـدعـي الـعـام: ${prosecutorName}\n`;
    introMsg += `👥 ┃ الـمحـلـفين: ${jury1Name}, ${jury2Name}\n`;
    introMsg += `━━━━━━━━━━━━━━━\n📢 ┃ لـلـجـمـهـور: رُد عـلـى الـصـورة بـكلمة:\n[ إدانـة ] 🔥 أو [ تـبـرئـة ] 🛡️\n👑 ┃ (للمطور فقط حق العفو الملكي)\n⏰ ┃ الـوقت: 3 دقـائق لـصـدور الـحـكـم.`;

    return api.sendMessage({
      body: introMsg,
      attachment: fs.createReadStream(imgPath)
    }, threadID, (err, info) => {
      fs.unlinkSync(imgPath);
      
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        victimID: victimID,
        idanes: 0,
        tabrias: 0,
        afws: false,
        voters: [],
        type: "court_vote"
      });

      setTimeout(async () => {
        let session = global.client.handleReply.find(i => i.messageID == info.messageID);
        // إذا تم تفعيل العفو الملكي (afws)، نوقف العملية فوراً
        if (!session || session.afws) return;

        const total = session.idanes + session.tabrias;
        if (total === 0) return api.sendMessage(`⚖️ ┃ لـم يـحضر أحـد لـلـتـصويـت.. بـراءة لـ [ ${victimName} ] لـعـدم كـفـايـة الأدلة.`, threadID);

        const idanesPercent = Math.round((session.idanes / total) * 100);
        const tabriasPercent = 100 - idanesPercent;

        let finalMsg = `⚖️ ┃ نـطـق الـحـكم الـنهائي لـلـقـاضـي رِيُـو:\n━━━━━━━━━━━━━━━\n⚖️ نـسـبة الإدانـة: ${idanesPercent}%\n⚖️ نـسـبة الـتـبـرئـة: ${tabriasPercent}%\n━━━━━━━━━━━━━━━\n`;

        if (idanesPercent > tabriasPercent) {
          const userData = await Currencies.getData(victimID);
          const money = userData.money || 0;

          if (money < 500) {
            api.sendMessage(finalMsg + `🔥 ┃ بـسـبب فـقـر الـمـتـهـم وعـدم كـفـايـة رصـيـده..\n🚫 ┃ الـقـرار: الـطرد الـفـوري مـن الـمـجموعة.`, threadID);
            api.removeUserFromGroup(victimID, threadID);
          } else {
            await Currencies.decreaseMoney(victimID, 500);
            api.sendMessage(finalMsg + `💰 ┃ الـقـرار: تـغـريـم الـمـتـهـم 500 عـمـلـة لـلـخـزيـنـة الـمـلـكـيـة.`, threadID);
          }
        } else {
          api.sendMessage(finalMsg + `✅ ┃ بـنـاءً عـلى رأي الـشـعب.. الـمـتـهـم [ ${victimName} ] بـريء!`, threadID);
        }
        
        global.client.handleReply = global.client.handleReply.filter(i => i.messageID != info.messageID);
      }, 180000); 
    }, messageID);

  } catch (error) {
    console.error(error);
  }
};