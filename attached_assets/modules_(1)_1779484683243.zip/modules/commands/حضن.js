const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const jimp = require("jimp");

module.exports.config = {
  name: "حضن",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "حضن شخص مع حماية ملكية للمطور 🥰",
  commandCategory: "ترفيه",
  usages: "[@منشن / رد على رسالة]",
  cooldowns: 5
};

const cacheDir = path.join(__dirname, "cache", "canvas");

module.exports.onLoad = async () => {
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
  const imagePath = path.join(cacheDir, "hugv1.png");
  if (!fs.existsSync(imagePath)) {
    try {
      const res = await axios.get("https://i.ibb.co/3YN3T1r/q1y28eqblsr21.jpg", { responseType: "arraybuffer" });
      fs.writeFileSync(imagePath, Buffer.from(res.data, "binary"));
    } catch (e) {
      console.error("❌ خطأ في تحميل خلفية الحضن:", e.message);
    }
  }
};

async function circle(url) {
  const img = await jimp.read(url);
  img.circle();
  return await img.getBufferAsync(jimp.MIME_PNG);
}

module.exports.run = async function ({ event, api }) {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  const devID = "100090081489341"; // آيدي المطور عبدو
  
  let targetID;

  if (type === "message_reply") {
    targetID = messageReply.senderID;
  } 
  else if (Object.keys(mentions).length > 0) {
    targetID = Object.keys(mentions)[0];
  } 
  else {
    return api.sendMessage("🥰 ┇ يـرجى مـنشنة شـخص أو الـرد عـلى رسـالته لـحضنه!", threadID, messageID);
  }

  // 🛡️ حماية المطور عبدو (الاستثناء الملكي)
  if (targetID == devID && senderID !== devID) {
    return api.sendMessage(
      `⚠️ ┇ تَـحْـذِيـرٌ مَـلَـكِـي\n━━━━━━━━━━━━━━━\n` +
      `🤨 ┇ هـل تـحـاول حـضـن الـمـطـور عـبـدو؟\n` +
      `👊 ┇ روح احـضـن حـبـيـبـتـك مـولـي..\n` +
      `👑 ┇ الـمـطـور عـبـدو تـاج فـوق راسـك!\n` +
      `━━━━━━━━━━━━━━━\n` +
      `[•] رِيُـو بُـوت - نِـظَـامُ الـهَـيْـبَـة`, 
      threadID, messageID
    );
  }

  try {
    api.sendMessage("⏳ ┇ جـارٍ تـجهيز الـحضن الـملكي...", threadID, messageID);
    
    // إعداد الروابط والصور
    const imagePath = path.join(cacheDir, "hugv1.png");
    const outputPath = path.join(cacheDir, `hug_${senderID}_${targetID}.png`);
    const avatarOne = `https://graph.facebook.com/${senderID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
    const avatarTwo = `https://graph.facebook.com/${targetID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;

    const [bg, imgOneBuf, imgTwoBuf] = await Promise.all([
      jimp.read(imagePath),
      circle(avatarOne),
      circle(avatarTwo)
    ]);

    const imgOne = await jimp.read(imgOneBuf);
    const imgTwo = await jimp.read(imgTwoBuf);

    bg.composite(imgOne.resize(150, 150), 320, 100)
      .composite(imgTwo.resize(130, 130), 280, 280);

    const buffer = await bg.getBufferAsync(jimp.MIME_PNG);
    fs.writeFileSync(outputPath, buffer);
    
    return api.sendMessage({ 
      body: "🥰 ┇ تـمَّ الـحـضـن بـنـجـاح يـا مـولـي!", 
      attachment: fs.createReadStream(outputPath) 
    }, threadID, () => {
      if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    }, messageID);
    
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┇ عـذراً مـولي، تـعذر إتـمام الـحضن الآن.", threadID, messageID);
  }
};