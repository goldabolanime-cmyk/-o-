module.exports.config = {
  name: "حظر",
  version: "3.0.0",
  hasPermssion: 2,
  credits: "عبدو / RIO BOOT",
  description: "نظام الحظر الشامل للمطور (يمنع استخدام الأوامر فقط)",
  commandCategory: "المطور",
  usages: "[هنا / السيرفر / @تاغ / قائمة / وقت (رقم)]",
  cooldowns: 2
};

module.exports.run = async ({ event, api, Users, Threads, args }) => {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  const header = "🚫 ═══ ﴿ مَـرْكَـز اَلْـحَـظْـرِ اَلـشَّـامِـلِ ﴾ ═══ 🚫\n\n";

  // دالة فك الحظر التلقائي
  const autoUnban = async (id, type, minutes) => {
    setTimeout(async () => {
      if (type === "user") {
        const data = (await Users.getData(id)).data || {};
        data.banned = false;
        await Users.setData(id, { data });
        global.data.userBanned.delete(id);
      } else {
        const data = (await Threads.getData(id)).data || {};
        data.banned = false;
        await Threads.setData(id, { data });
        global.data.threadBanned.delete(id);
      }
    }, minutes * 60000);
  };

  switch (args[0]) {
    case 'قائمة':
    case 'القائمة': {
      let msg = `${header}📜 ┃ قَـائِـمَةُ اَلْـمَحْـظُـورِيـنَ حَـالِيّـاً:\n\n`;
      let userBans = Array.from(global.data.userBanned.keys());
      let threadBans = Array.from(global.data.threadBanned.keys());

      msg += `👤 ┃ اَلْـمُسْـتَخْـدِمُونَ (${userBans.length}):\n`;
      for (let id of userBans) {
        const name = (await Users.getData(id)).name || "مستخدم غير معروف";
        msg += `• ${name} ⮕ (${id})\n`;
      }

      msg += `\n🏘️ ┃ اَلْـمَجْـمُوعَاتُ (${threadBans.length}):\n`;
      for (let id of threadBans) {
        const tInfo = (await Threads.getData(id)).threadInfo || {};
        msg += `• ${tInfo.threadName || "مجموعة غير معروفة"} ⮕ (${id})\n`;
      }

      if (userBans.length == 0 && threadBans.length == 0) msg += "• لَا يُـوجَدُ مَحْـظُورُونَ فِـي اَلـسِّـجِـلَّاتِ.";
      return api.sendMessage(msg, threadID, messageID);
    }

    case 'هنا':
    case 'المجموعة': {
      const data = (await Threads.getData(threadID)).data || {};
      data.banned = true;
      data.reason = args.slice(1).join(" ") || "بِـدُونِ سَـبَـبٍ مُـحَدَّدٍ";
      await Threads.setData(threadID, { data });
      global.data.threadBanned.set(threadID, data.reason);
      return api.sendMessage(`${header}⚠️ تَـمَّ حَـظْـرُ اَلْـمَجْـمُوعَـةِ مِـنِ اِسْـتِخْـدَامِ اَلْأَوَامِـرِ.\n📝 اَلـسَّـبَـبُ: ${data.reason}`, threadID, messageID);
    }

    default: {
      let targetID;
      let minutes = isNaN(args[0]) ? null : parseInt(args[0]);
      
      if (type == "message_reply") targetID = messageReply.senderID;
      else if (Object.keys(mentions).length > 0) targetID = Object.keys(mentions)[0];
      
      if (!targetID) return api.sendMessage("⚠️ ┃ مِـنْ فَـضْـلِـكَ رُدَّ عَـلَى رِسَـالَةٍ أَوْ ضَـعْ تَـاغْ لِـلْـحَـظْـرِ.", threadID, messageID);

      const data = (await Users.getData(targetID)).data || {};
      data.banned = true;
      data.reason = minutes ? `حَـظْـرٌ مُـؤَقَّـتٌ لِـمُـدَّةِ ${minutes} دَقِيـقَةٍ` : (args.slice(1).join(" ") || "بِـدُونِ سَـبَـبٍ مُـحَدَّدٍ");
      
      await Users.setData(targetID, { data });
      global.data.userBanned.set(targetID, data.reason);
      
      if (minutes) autoUnban(targetID, "user", minutes);

      return api.sendMessage(`${header}✅ تَـمَّ حَـظْـرُ اَلْـعُـضْـوِ بِنَـجَـاحٍ.\n👤 اَلْأَيْـدِي: ${targetID}\n⏳ اَلـنَّـوعُ: ${minutes ? `مُـؤَقَّـتٌ (${minutes} د)` : "دَائِـمٌ"}`, threadID, messageID);
    }
  }
};