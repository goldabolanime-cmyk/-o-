const ytdl = require('ytdl-core');
const ytSearch = require('youtube-search-api');
const fs = require('fs-extra');
const axios = require('axios');

module.exports.config = {
  name: "فيد",
  version: "1.5.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "تحميل مقاطع الفيديو من يوتيوب بجودة ملكية",
  commandCategory: "ترفيه",
  usages: "[اسم الفيديو أو الرابط]",
  cooldowns: 15
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const searchQuery = args.join(" ");

  if (!searchQuery) return api.sendMessage("🎬 ┇ يرجى كتابة اسم الفيديو أو الرابط يا ملك.", threadID, messageID);

  try {
    api.sendMessage(`📥 ┇ جـارٍ الـبحث وتـحضير الـعرض الـملكي.. اـنتظر قليلاً.`, threadID, messageID);

    // البحث عن الفيديو
    const searchResults = await ytSearch.GetListByKeyword(searchQuery, false, 1);
    const video = searchResults.items[0];
    if (!video) return api.sendMessage("❌ ┇ لم أجد هذا المقطع في سجلات اليوتيوب.", threadID, messageID);

    const videoID = video.id;
    const videoUrl = `https://www.youtube.com/watch?v=${videoID}`;
    const path = __dirname + `/cache/${videoID}.mp4`;

    // تحميل الفيديو بجودة 360p (لضمان سرعة الإرسال وعدم تجاوز حجم ملفات فيسبوك)
    const videoStream = ytdl(videoUrl, { 
      quality: 'highestvideo',
      filter: format => format.container === 'mp4' && format.hasAudio
    });

    videoStream.pipe(fs.createWriteStream(path)).on('finish', () => {
      // التحقق من حجم الملف (فيسبوك يسمح بـ 25MB كحد أقصى)
      const stats = fs.statSync(path);
      const fileSizeInBytes = stats.size;
      const fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);

      if (fileSizeInMegabytes > 25) {
        fs.unlinkSync(path);
        return api.sendMessage("⚠️ ┇ عذراً يا ملك، حجم الفيديو ضخم جداً (أكثر من 25MB)، لا يمكنني إرساله هنا.", threadID, messageID);
      }

      let msg = `🎬 ═══ ﴿ عَرْض رِيُو الـمَلَكِي ﴾ ═══ 🎬\n\n`;
      msg += `📌 ┇ الـعنوان: ${video.title}\n`;
      msg += `⏱️ ┇ الـمدة: ${video.length.simpleText || "غير معروفة"}\n`;
      msg += `━━━━━━━━━━━━━━━\n`;
      msg += `✨ ┇ مـشاهدة مـمتعة لـلملك رِيـو ┇ ✨`;

      return api.sendMessage({
        body: msg,
        attachment: fs.createReadStream(path)
      }, threadID, () => fs.unlinkSync(path), messageID);
    });

  } catch (e) {
    console.log(e);
    return api.sendMessage("❌ ┇ حدث خطأ ملكي أثناء تحميل الفيديو.", threadID, messageID);
  }
};
