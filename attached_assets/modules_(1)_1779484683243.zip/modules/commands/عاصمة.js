module.exports.config = {
  name: "عاصمة",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدالرحمن",
  description: "لعبة تخمين عواصم الدول",
  usages: "عواصم",
  commandCategory: "العاب",
  cooldowns: 5
};

const questions = [
  { question: "ما هي عاصمة الجزائر؟", answer: "الجزائر" },
  { question: "ما هي عاصمة المغرب؟", answer: "الرباط" },
  { question: "ما هي عاصمة تونس؟", answer: "تونس" },
  { question: "ما هي عاصمة مصر؟", answer: "القاهرة" },
  { question: "ما هي عاصمة السعودية؟", answer: "الرياض" },
  { question: "ما هي عاصمة فلسطين؟", answer: "القدس" },
  { question: "ما هي عاصمة العراق؟", answer: "بغداد" },
  { question: "ما هي عاصمة سوريا؟", answer: "دمشق" },
  { question: "ما هي عاصمة الأردن؟", answer: "عمان" },
  { question: "ما هي عاصمة لبنان؟", answer: "بيروت" },
  { question: "ما هي عاصمة الإمارات؟", answer: "أبو ظبي" },
  { question: "ما هي عاصمة قطر؟", answer: "الدوحة" },
  { question: "ما هي عاصمة الكويت؟", answer: "الكويت" },
  { question: "ما هي عاصمة البحرين؟", answer: "المنامة" },
  { question: "ما هي عاصمة عمان؟", answer: "مسقط" },
  { question: "ما هي عاصمة اليمن؟", answer: "صنعاء" },
  { question: "ما هي عاصمة ليبيا؟", answer: "طرابلس" },
  { question: "ما هي عاصمة السودان؟", answer: "الخرطوم" },
  { question: "ما هي عاصمة فرنسا؟", answer: "باريس" },
  { question: "ما هي عاصمة إسبانيا؟", answer: "مدريد" },
  { question: "ما هي عاصمة إيطاليا؟", answer: "روما" },
  { question: "ما هي عاصمة ألمانيا؟", answer: "برلين" },
  { question: "ما هي عاصمة بريطانيا؟", answer: "لندن" },
  { question: "ما هي عاصمة روسيا؟", answer: "موسكو" },
  { question: "ما هي عاصمة تركيا؟", answer: "أنقرة" },
  { question: "ما هي عاصمة اليابان؟", answer: "طوكيو" },
  { question: "ما هي عاصمة الصين؟", answer: "بكين" },
  { question: "ما هي عاصمة كوريا الجنوبية؟", answer: "سيول" },
  { question: "ما هي عاصمة أمريكا؟", answer: "واشنطن" },
  { question: "ما هي عاصمة البرازيل؟", answer: "برازيليا" },
  { question: "ما هي عاصمة الأرجنتين؟", answer: "بوينس آيرس" },
  { question: "ما هي عاصمة كندا؟", answer: "أوتاوا" },
  { question: "ما هي عاصمة أستراليا؟", answer: "كانبرا" },
  { question: "ما هي عاصمة الهند؟", answer: "نيودلهي" },
  { question: "ما هي عاصمة إيران؟", answer: "طهران" }
];

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { body, senderID, threadID, messageID } = event;
  const userAnswer = body.trim().toLowerCase();
  const correctAnswer = handleReply.correctAnswer.toLowerCase();

  if (userAnswer === correctAnswer) {
      Currencies.increaseMoney(senderID, 50);
      api.sendMessage(`✅ أحسنت! إجابة صحيحة، لقد كسبت 50 دولار 💰`, threadID, messageID);
      return api.unsendMessage(handleReply.messageID); 
  } else {
      return api.sendMessage(`❌ خطأ، حاول مرة أخرى!`, threadID, messageID);
  }
};

module.exports.run = async function ({ api, event }) {
  const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
  const { question, answer } = randomQuestion;

  const message = `🌍 تـحـدي الـعـواصـم الـسـريـع 🌍\n\nاسرع شخص يحزر: 【 ${question} 】`;

  api.sendMessage(message, event.threadID, (error, info) => {
      if (!error) {
          global.client.handleReply.push({
              name: this.config.name,
              messageID: info.messageID,
              correctAnswer: answer
          });
      }
  });
};
