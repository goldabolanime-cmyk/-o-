const axios = require("axios");

module.exports.config = {
  name: "وصف",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "تحليل الصور باستخدام أقوى محركات الذكاء الاصطناعي",
  commandCategory: "الذكاء الاصطناعي",
  usages: "[رد على صورة]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, type, messageReply } = event;

  // التحقق من الرد على صورة
  if (type !== "message_reply" || !messageReply.attachments || messageReply.attachments[0].type !== "photo") {
    return api.sendMessage("⚠️ ┃ مِـنْ فَـضْـلِـكَ رُدَّ عَـلَى صُـورَةٍ لِـأَصِـفَـهَـا لَـكَ.", threadID, messageID);
  }

  const imageUrl = messageReply.attachments[0].url;
  api.sendMessage("🔍 ┃ جـاري فحص الصورة بدقة، لحظات...", threadID, messageID);

  try {
    // محرك بحث GPT-4o أو Gemini عبر سكراب عالي الأداء
    const response = await axios.get(`https://api.sandipbaruwal.com.np/gemini-vision?prompt=${encodeURIComponent("Describe this image in very high detail in English for professional use")}&url=${encodeURIComponent(imageUrl)}`);
    
    // استخراج النص (يتكيف مع ردود السيرفر المختلفة)
    const description = response.data.answer || response.data.response || response.data.message;

    if (!description) throw new Error("Empty API response");

    const msg = 
      `📸 ┃ Detailed Description:\n` +
      `━━━━━━━━━━━━━━━\n\n` +
      `${description}\n\n` +
      `━━━━━━━━━━━━━━━\n` +
      `🔱 ┃ المطور: عبدو`;

    return api.sendMessage(msg, threadID, messageID);

  } catch (error) {
    console.error(error);
    // محاولة أخيرة بمحرك احتياطي في حالة فشل الأول
    try {
        const backup = await axios.get(`https://api.samir.com.np/api/vision?url=${encodeURIComponent(imageUrl)}&prompt=describe%20this%20image`);
        const backupDesc = backup.data.response;
        if (backupDesc) {
            return api.sendMessage(`✅ ┃ (Backup Engine):\n\n${backupDesc}\n\n🔱 ┃ المطور: عبدو`, threadID, messageID);
        }
    } catch (e) {
        return api.sendMessage("❌ ┃ عذراً، جميع المحركات مضغوطة حالياً. حاول بعد ثوانٍ.", threadID, messageID);
    }
  }
};