const axios = require("axios");
const fs = require("fs-extra");
const path = __dirname + "/cache/rules_pro.json";

module.exports.config = {
  name: "قوانين",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "إدارة قوانين المجموعة (إضافة، حذف، قائمة) مع زخرفة ملكية",
  commandCategory: "إدارة المجموعة",
  usages: "[إضافة + نص] | [حذف + رقم] | [قائمة]",
  cooldowns: 2
};

module.exports.onLoad = () => {
  if (!fs.existsSync(__dirname + "/cache")) fs.mkdirSync(__dirname + "/cache");
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  let rulesData = JSON.parse(fs.readFileSync(path));
  if (!rulesData[threadID]) rulesData[threadID] = [];

  const action = args[0];
  const rulesImageURL = "https://i.ibb.co/vYm6m8j/rules-banner.png"; // رابط صورة إعلامي

  // --- 1. إضافة قانون جديد ---
  if (action === "إضافة" || action === "اضافة") {
    const threadInfo = await api.getThreadInfo(threadID);
    if (!threadInfo.adminIDs.some(item => item.id == senderID)) 
      return api.sendMessage("⚠️ | عـذراً، هـذا الأمـر لـلـقادة فـقط.", threadID, messageID);

    const newRule = args.slice(1).join(" ");
    if (!newRule) return api.sendMessage("❌ | اكـتب الـقانون الـذي تـريد إضـافته.", threadID, messageID);

    rulesData[threadID].push(newRule);
    fs.writeFileSync(path, JSON.stringify(rulesData, null, 2));
    return api.sendMessage(`✅ | تـم إضـافة الـقانون رقـم (${rulesData[threadID].length}) بـنجاح.`, threadID, messageID);
  }

  // --- 2. حذف قانون معين ---
  if (action === "حذف") {
    const threadInfo = await api.getThreadInfo(threadID);
    if (!threadInfo.adminIDs.some(item => item.id == senderID)) 
      return api.sendMessage("⚠️ | عـذراً، هـذا لـلمشرفين فـقط.", threadID, messageID);

    const index = parseInt(args[1]) - 1;
    if (isNaN(index) || !rulesData[threadID][index]) 
      return api.sendMessage("❌ | يـرجى كـتابة رقـم الـقانون الـصحيح لـحذفه.\nمـثال: قوانين حذف 1", threadID, messageID);

    const removed = rulesData[threadID].splice(index, 1);
    fs.writeFileSync(path, JSON.stringify(rulesData, null, 2));
    return api.sendMessage(`🗑️ | تـم حـذف الـقانون: (${removed})`, threadID, messageID);
  }

  // --- 3. عرض قائمة القوانين ---
  if (action === "قائمة" || !action) {
    if (rulesData[threadID].length === 0) {
      return api.sendMessage("⚠️ | لا تـوجد قـوانـين مـسجلة حالـياً.\n💡 | لـلإضـافة: [قوانين إضافة + النص]", threadID, messageID);
    }

    let rulesList = rulesData[threadID].map((rule, i) => `║ ❯ ${i + 1}. ${rule}`).join("\n");

    const msg = `
╔════════ ۩۞۩ ════════╗
    ✨ قـوانـيـن الـمـجـمـوعـة ✨
╚════════ ۩۞۩ ════════╝
║
${rulesList}
║
╚══════════════════════╝
⚠️ | الـتـزامـك بـالـنـظـام يـعـبـر عـن رُقـيـك.
✨ | ريـو بـوت - RIO BOOT | ✨
━━━━━━━━━━━━━━━━━━━`.trim();

    try {
      const imagePath = __dirname + `/cache/rules_pro_${threadID}.png`;
      const res = await axios.get(rulesImageURL, { responseType: "arraybuffer" });
      fs.writeFileSync(imagePath, Buffer.from(res.data, "utf-8"));

      return api.sendMessage({
        body: msg,
        attachment: fs.createReadStream(imagePath)
      }, threadID, () => fs.unlinkSync(imagePath), messageID);
    } catch (e) {
      return api.sendMessage(msg, threadID, messageID);
    }
  }
};
