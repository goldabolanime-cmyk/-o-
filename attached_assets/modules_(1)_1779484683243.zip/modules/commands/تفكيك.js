module.exports.config = {
  name: "تفكيك",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "عبدالرحمن / تعديل ريو",
  description: "لعبة تفكيك الكلمات والجمل مع جوائز ملكية",
  usages: ["تفكيك"],
  commandCategory: "العاب",
  cooldowns: 5
};

const questions = [
  { question: "بيت", answer: "ب ي ت", type: "word" },
  { question: "رجل", answer: "ر ج ل", type: "word" },
  { question: "سيارة", answer: "س ي ا ر ة", type: "word" },
  { question: "مدرسة", answer: "م د ر س ة", type: "word" },
  { question: "طائرة", answer: "ط ا ئ ر ة", type: "word" },
  { question: "ريو بوت", answer: "ر ي و ب و ت", type: "special" },
  { question: "المطور عبدو", answer: "ا ل م ط و ر ع ب د و", type: "special" },
  { question: "مملكة البرمجة", answer: "م م ل ك ة ا ل ب ر م ج ة", type: "special" },
  { question: "ذكاء اصطناعي", answer: "ذ ك ا ء ا ص ط n ا ع ي", type: "special" },
  { question: "المغرب العربي", answer: "ا ل م غ ر ب ا ل ع ر ب ي", type: "special" },
  { question: "سباق الخيول", answer: "س ب ا ق ا ل خ ي و ل", type: "word" },
  { question: "قهوة الصباح", answer: "ق ه و ة ا ل ص ب ا ح", type: "special" },
  { question: "هاتف ذكي", answer: "ه ا ت ف ذ ك ي", type: "word" },
  { question: "كتاب القواعد", answer: "ك ت ا ب ا ل ق و ا ع د", type: "special" },
  { question: "مدينة الدار البيضاء", answer: "م د ي ن ة ا ل د ا ر ا ل ب ي ض ا ء", type: "special" },
  // --- إضافة 30 سؤالاً جديداً ---
  { question: "برمجة كود", answer: "ب ر م ج ة ك و د", type: "word" },
  { question: "قمر اصطناعي", answer: "ق م ر ا ص ط ن ا ع ي", type: "special" },
  { question: "نظام الملفات", answer: "ن ظ ا م ا ل م ل ف ا ت", type: "special" },
  { question: "شاشة كمبيوتر", answer: "ش ا ش ة ك م ب ي و ت ر", type: "word" },
  { question: "مملكة المغرب", answer: "م م ل ك ة ا ل م غ ر ب", type: "special" },
  { question: "سيرفر ريبلت", answer: "س ي ر ف ر ر ي ب ل ت", type: "special" },
  { question: "لغة البرمجة", answer: "ل غ ة ا ل ب ر م ج ة", type: "word" },
  { question: "مطور برامج", answer: "م ط و ر ب ر ا م ج", type: "word" },
  { question: "جهاز لوحي", answer: "ج ه ا ز ل و ح ي", type: "word" },
  { question: "عالم الأرقام", answer: "ع ا ل م ا ل أ ر ق ا م", type: "word" },
  { question: "تطبيق فيسبوك", answer: "ت ط ب ي ق ف ي س ب و ك", type: "special" },
  { question: "شبكة إنترنت", answer: "ش ب ك ة إ ن ت ر ن ت", type: "word" },
  { question: "أمن المعلومات", answer: "أ م ن ا ل م ع ل و م ا ت", type: "special" },
  { question: "قاعدة بيانات", answer: "ق ا ع د ة ب ي ا ن ا ت", type: "special" },
  { question: "تشفير البيانات", answer: "ت ش ف ي ر ا ل ب ي ا ن ا ت", type: "special" },
  { question: "فضاء واسع", answer: "ف ض ا ء و ا س ع", type: "word" },
  { question: "كوكب الأرض", answer: "ك و ك ب ا ل أ ر ض", type: "word" },
  { question: "نجوم السماء", answer: "ن ج و م ا ل س م ا ء", type: "word" },
  { question: "كود الجافا", answer: "ك و د ا ل ج ا ف ا", type: "special" },
  { question: "إبداع وتطوير", answer: "إ ب د ا ع و ت ط و ي ر", type: "word" },
  { question: "سرعة البرق", answer: "س ر ع ة ا ل ب ر ق", type: "word" },
  { question: "عقل بشري", answer: "ع ق ل ب ش ر ي", type: "word" },
  { question: "صورة بروفايل", answer: "ص و ر ة ب ر و ف ا ي ل", type: "special" },
  { question: "رسالة قصيرة", answer: "ر س ا ل ة ق ص ي ر ة", type: "word" },
  { question: "أيقونة ذهبية", answer: "أ ي ق و ن ة ذ ه ب ي ة", type: "word" },
  { question: "منصة الألعاب", answer: "م ن ص ة ا ل أ ل ع ا ب", type: "special" },
  { question: "عاصمة الرباط", answer: "ع ا ص م ة ا ل ر ب ا ط", type: "special" },
  { question: "هواء نقي", answer: "ه و ا ء ن ق ي", type: "word" },
  { question: "زهرة الياسمين", answer: "ز ه ر ة ا ل ي ا س م ي ن", type: "word" },
  { question: "روبوت متطور", answer: "ر و ب و ت م ت ط و ر", type: "special" }
];

module.exports.handleReply = async function ({ api, event, handleReply, Currencies, Users }) {
  const { body, senderID, threadID, messageID } = event;
  const userAnswer = body.trim().replace(/\s+/g, ' '); 
  const correctAnswer = handleReply.correctAnswer;
  const type = handleReply.type;

  if (userAnswer === correctAnswer) {
      let min = type === "special" ? 60 : 50;
      let max = 80;
      const prize = Math.floor(Math.random() * (max - min + 1)) + min;

      const name = await Users.getNameUser(senderID);
      
      await Currencies.increaseMoney(senderID, prize);
      
      const msg = {
          body: `🎊 ┇ تَـهَانِينَا يَا @${name}\n━━━━━━━━━━━━━━━\n✨ ┇ لـقـد كـنـت الأسـرع فـي الـتـفكـيك!\n💰 ┇ الـجـائـزة: ${prize}$\n━━━━━━━━━━━━━━━\n[•] رِيُـو بُـوت - نِـظَـامُ الألْـعَـاف`,
          mentions: [{ tag: name, id: senderID }]
      };

      api.sendMessage(msg, threadID, () => api.unsendMessage(handleReply.messageID));
  } else {
      api.sendMessage("❌ ┇ خـطـأ! حـاول مـرة أخـرى يـا بـطـل.", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
  
  const msg = `🎮 ┇ لُـعْـبَـةُ الـتَّـفْـكِـيـكِ الـمَـلَـكِـيَّـة\n━━━━━━━━━━━━━━━\n💡 ┇ أَسْـرَعُ شَـخْـصٍ يُـفَـكِّـكُ الـكَـلِـمَـة:\n\n➛ [ ${randomQuestion.question} ]\n\n━━━━━━━━━━━━━━━\n📌 ┇ رُدَّ عَـلَـى الـرِّسَـالَـةِ بِـالـحُـرُوفِ مَـعَ مَـسَـافَات!`;

  return api.sendMessage(msg, threadID, (error, info) => {
      global.client.handleReply.push({
          name: this.config.name,
          messageID: info.messageID,
          correctAnswer: randomQuestion.answer,
          type: randomQuestion.type
      });
  }, messageID);
};