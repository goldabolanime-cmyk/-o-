const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const yts = require("yt-search");
const ytdl = require("ytdl-core");

module.exports.config = {
  name: "اغنية",
  version: "8.0.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "بحث يوتيوب داخلي باستخدام ytdl & yt-search",
  commandCategory: "الوسائط",
  usages: "[اسم الأغنية]",
  cooldowns: 10,
  dependencies: { "yt-search": "", "ytdl-core": "", "axios": "", "fs-extra": "" }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const choice = parseInt(body);
  if (isNaN(choice) || choice < 1 || choice > handleReply.list.length) {
    return api.sendMessage("⚠️ ┃ اختر رقماً صحيحاً.", threadID, messageID);
  }

  api.unsendMessage(handleReply.messageID);
  const selected = handleReply.list[choice - 1];
  
  api.sendMessage(`⏳ ┃ جـاري معالجة الصوت لـ 『 ${selected.title} 』...`, threadID, messageID);

  try {
    const filePath = path.join(__dirname, "cache", `${Date.now()}.mp3`);
    
    // استخدام ytdl-core لتحميل الصوت مباشرة من يوتيوب
    const stream = ytdl(selected.url, { filter: 'audioonly', quality: 'highestaudio' });
    
    stream.pipe(fs.createWriteStream(filePath)).on('finish', () => {
      return api.sendMessage({
        body: `✅ ┃ تم التحميل بنجاح\n🎵 ┃ العنوان: ${selected.title}\n⏱️ ┃ المدة: ${selected.timestamp}\n\n🔱 ┃ المطور: عبدو`,
        attachment: fs.createReadStream(filePath)
      }, threadID, () => { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); }, messageID);
    });

  } catch (e) {
    return api.sendMessage("❌ ┃ عذراً، يوتيوب تمنع التحميل حالياً، جرب لاحقاً.", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const query = args.join(" ");

  if (!query) return api.sendMessage("أرسل اسم ما تريد البحث عنه.", threadID, messageID);

  try {
    // البحث باستخدام yt-search
    const r = await yts(query);
    const results = r.videos.slice(0, 4);

    if (results.length === 0) return api.sendMessage("❌ ┃ لم أجد نتائج.", threadID, messageID);

    const attachments = [];
    let msg = `✨ ┃ نـتـائـج اَلـبَـحْـثِ: ${query}\n━━━━━━━━━━━━━━━\n\n`;

    for (let i = 0; i < results.length; i++) {
      const v = results[i];
      msg += `【 ${i + 1} 】 ${v.title}\n⏱️ المدة: ${v.timestamp}\n━━━━━━━━━━━━━━━\n`;
      
      const imgPath = path.join(__dirname, "cache", `yt_${i}.jpg`);
      const imgRes = await axios.get(v.thumbnail, { responseType: "arraybuffer" });
      fs.writeFileSync(imgPath, Buffer.from(imgRes.data));
      attachments.push(fs.createReadStream(imgPath));
    }

    msg += "\n📥 ┃ رد برقم المقطع لتحميله mp3.";

    return api.sendMessage({ body: msg, attachment: attachments }, threadID, (err, info) => {
      attachments.forEach(s => { if (fs.existsSync(s.path)) fs.unlinkSync(s.path); });
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        list: results
      });
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ حدث خطأ في محرك البحث الداخلي.", threadID, messageID);
  }
};