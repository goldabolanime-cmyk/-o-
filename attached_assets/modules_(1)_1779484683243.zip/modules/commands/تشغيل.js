const fs = require('fs-extra');
const path = __dirname + '/cache/bot_status.json';

module.exports.config = {
    name: "الادمن_فقط",
    version: "1.2.0",
    hasPermssion: 2,
    credits: "عبدو",
    description: "تفعيل/تعطيل استجابة البوت للمستخدمين (وضع الأدمن)",
    commandCategory: "النظام",
    usages: "[ايقاف / تشغيل]",
    cooldowns: 2,
    usePrefix: false
};

// هذا الجزء هو المسؤول عن منع المستخدمين العاديين حتى لو ملف listen مشفر
module.exports.handleEvent = async function({ api, event }) {
    if (!fs.existsSync(path)) return;
    const status = fs.readJsonSync(path);
    const { ADMINBOT } = global.config;

    // إذا كان وضع الأدمن مفعل والمرسل ليس أدمن، يتم تجاهل الرسالة تماماً
    if (status.onlyAdmin && !ADMINBOT.includes(event.senderID)) {
        return; 
    }
};

module.exports.run = async function({ api, event, args }) {
    const { threadID, messageID, senderID } = event;
    const { ADMINBOT } = global.config;
    
    // التحقق من أن المستخدم أدمن أو المطور عبدو
    if (!ADMINBOT.includes(senderID)) {
        return api.sendMessage("╭─── 👑  𝗥𝗜𝗢 𝗕𝗢𝗧 👑  ───╮\n\n⚠️ ┇ عذراً، هذا الأمر مخصص للمطور عبدو والأدمن فقط!\n\n╰──────────────╯", threadID, messageID);
    }
    
    if (!fs.existsSync(path)) {
        fs.writeJsonSync(path, { onlyAdmin: false });
    }
    
    let botStatus = fs.readJsonSync(path);

    if (args[0] === "ايقاف") {
        botStatus.onlyAdmin = true;
        fs.writeJsonSync(path, botStatus);
        return api.sendMessage("╭─── 👑  𝗥𝗜𝗢 𝗕𝗢𝗧 👑  ───╮\n\n🔴 ┇ تـم تـفـعـيـل وضـع الأدمن.\n🚫 ┇ الـبوت لـن يـستـجيب للمـستـخدمين العـاديـين الآن.\n\n╰──────────────╯", threadID, messageID);
    } 
    else if (args[0] === "تشغيل") {
        botStatus.onlyAdmin = false;
        fs.writeJsonSync(path, botStatus);
        return api.sendMessage("╭─── 👑  𝗥𝗜𝗢 𝗕𝗢𝗧 👑  ───╮\n\n🟢 ┇ تـم إيـقاف وضـع الأدمن.\n✅ ┇ الـبوت يـعمل ويـستـجيب للـجميع بـشكل طـبيعي.\n\n╰──────────────╯", threadID, messageID);
    } 
    else {
        return api.sendMessage("╭─── 👑  𝗥𝗜𝗢 𝗕𝗢𝗧 👑  ───╮\n\n❓ ┇ يرجى اختيار الحالة:\n🔹 تشغيل (للرد على الجميع)\n🔸 ايقاف (للرد على الأدمن فقط)\n\n╰──────────────╯", threadID, messageID);
    }
};