const axios = require("axios");
const fs = require("fs-extra");
const ytSearch = require("youtube-search-api");
const path = require("path");

module.exports.config = {
  name: "وصفة",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "RIO BOOT & Gemini",
  description: "جلب وصفات طبخ ملكية مع المقادير والخطوات التفصيلية من يوتيوب",
  commandCategory: "خدمات",
  usages: "[اسم الأكلة]",
  cooldowns: 10
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const query = args.join(" ");

  if (!query) return api.sendMessage("👨‍🍳 ┇ يرجى كتابة اسم الأكلة التي ترغب بوصفها يا ملك.", threadID, messageID);

  try {
    api.sendMessage("⏳ ┇ جـارٍ الـبحث فـي الـمطبخ الـملكي عـن أدق الـوصفات..", threadID, messageID);

    // 1. البحث عن الفيديو
    const searchResults = await ytSearch.GetListByKeyword(query + " طريقة عمل وصفة", false, 1);
    if (!searchResults.items || searchResults.items.length === 0) {
      return api.sendMessage("❌ ┇ عذراً يا ملك، لم أجد وصفة لهذه الأكلة حالياً.", threadID, messageID);
    }

    const video = searchResults.items[0];
    const videoId = video.id;
    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

    // 2. محاولة جلب معلومات الفيديو التفصيلية (الوصف والترجمة)
    // ملاحظة: سنعتمد هنا على مكتبة البحث لجلب الوصف إذا توفر أو إرسال الرابط مع شرح مبسط
    // لتحسين الكود وجلب "المقادير بالضبط" يفضل فحص وصف الفيديو (Description)
    
    const videoDetails = await ytSearch.GetVideoDetails(videoId);
    const description = videoDetails.description || "";
    
    // محاولة استخراج المقادير من الوصف (نبحث عن كلمات مفتاحية)
    let ingredients = "المقادير مذكورة بالتفصيل داخل فيديو الوصفة.";
    if (description.includes("المقادير") || description.includes("المكونات")) {
        const parts = description.split(/المقادير|المكونات/i);
        if (parts[1]) {
            ingredients = parts[1].split("\n\n")[0].trim().substring(0, 500) + "..."; 
        }
    }

    const thumbnail = video.thumbnail.thumbnails[0].url;
    const title = video.title;

    // مسار مؤقت للصورة
    const cacheDir = path.join(__dirname, "cache");
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
    
    const filePath = path.join(cacheDir, `${videoId}_${Date.now()}.jpg`);
    const imgResponse = await axios.get(thumbnail, { responseType: 'arraybuffer' });
    fs.writeFileSync(filePath, Buffer.from(imgResponse.data));

    // تنسيق الرسالة الملكية
    let msg = `🏰 ═══ ﴿ مَطْبَخ رِيُو الـمَلَكِي ﴾ ═══ 🏰\n\n`;
    msg += `🍴 ┇ الـأكلة: ${query}\n`;
    msg += `📺 ┇ الـعنوان: ${title}\n\n`;
    msg += `📜 ┇ الـمقادير الـمستخرجة:\n`;
    msg += `━━━━━━━━━━━━━━━\n`;
    msg += `${ingredients}\n\n`;
    msg += `👨‍🍳 ┇ طـريقة الـتحضير:\n`;
    msg += `━━━━━━━━━━━━━━━\n`;
    msg += `✨ 1. شـاهد الـخطوات الـعملية بـالدقة الـعالية عـبر الـرابط.\n`;
    msg += `✨ 2. اتـبع تـعليمات الـشيف لـضمان نـجاح الـوصفة الـملكية.\n\n`;
    msg += `🔗 ┇ رابـط الـفيديو:\n`;
    msg += `${videoUrl}\n\n`;
    msg += `━━━━━━━━━━━━━━━\n`;
    msg += `🍳 ┇ بـالـهناء والـشفاء لـلملك رِيـو ┇ ✨`;

    return api.sendMessage({
      body: msg,
      attachment: fs.createReadStream(filePath)
    }, threadID, () => {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }, messageID);

  } catch (e) {
    console.log(e);
    return api.sendMessage("❌ ┇ عذراً، حدث خطأ أثناء جلب الوصفة الملكية.", threadID, messageID);
  }
};