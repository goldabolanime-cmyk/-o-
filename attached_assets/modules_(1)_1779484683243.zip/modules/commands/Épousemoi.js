const axios = require("axios");
const fs = require("fs-extra");
const path = __dirname + "/cache/marriage_data.json";

module.exports.config = {
  name: "زوجني",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "نِـظَـامُ اَلـزَّوَاجِ، اَلـطَّلَاقِ، وَاَلْـعَائِلَةِ اَلْـمَـلَـكِيّ",
  commandCategory: "ترفيه",
  usages: "[مساعدة / طلاق / عرض / اولاد / عائلة]",
  cooldowns: 5
};

module.exports.onLoad = () => {
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
};

module.exports.run = async function({ api, event, args, Users, Currencies }) {
  const { threadID, messageID, senderID } = event;
  let dataMatch = JSON.parse(fs.readFileSync(path));
  const TOKEN = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662";

  // 0. قـائـمـة الـمـسـاعـدة
  if (args[0] === "مساعدة") {
    let helpMsg = `🏰 ━━━━【 خَـدَمَاتُ زَوِّجْـنِي 】━━━━ 🏰\n\n`;
    helpMsg += `💍 ┃ .زوجني : لِـلـزَّوَاجِ اَلْـمَـلَـكِيّ (200$)\n`;
    helpMsg += `💔 ┃ .زوجني طلاق : لِـلِانْفِصَالِ اَلـرَّسْـمِيّ\n`;
    helpMsg += `👶 ┃ .زوجني اولاد : لِإِنْـجَـابِ طِـفْـلٍ عَـشْـوَائِيّ\n`;
    helpMsg += `🖼️ ┃ .زوجني عرض : لِـرُؤْيَـةِ صُـورَةِ اَلـزَّوْجَيْـنِ\n`;
    helpMsg += `👨‍👩‍👧‍👦 ┃ .زوجني عائلة : لِـعَرْضِ شَـجَـرَةِ اَلْـعَـائِلَـةِ\n\n`;
    helpMsg += `👑 ┃ رِيُـو بُـوت - نِـظَـامُ اَلْـعَـلَاقَاتِ`;
    return api.sendMessage(helpMsg, threadID, messageID);
  }

  // 1. نـظـام الـزواج
  if (!args[0]) {
    if (dataMatch[senderID]) {
      const partnerID = dataMatch[senderID].partner;
      const partnerName = (await Users.getData(partnerID)).name;
      return api.sendMessage(`⚠️ ┃ نَـصِيـحَة مِـنْ عـبـدو: خَـلِيـك مْـقَـنَّـع بـ 【 ${partnerName} 】!\nاَلْـخِيَـانَة مَـاشِي مِـنْ طَـبْع اَلـرِّجَـال اَلْأَحْـرَار. 🤨`, threadID, messageID);
    }

    let userMoney = (await Currencies.getData(senderID)).money;
    if (userMoney < 200) return api.sendMessage("💸 ┃ اَلْـمَهْـرُ اَلْـمَـلَـكِي 200$.. سِـيرْ تـخْـدَمْ عْـلَى رَاسْـك هُـوَ اَلْأَوَّلْ!", threadID, messageID);

    let participants = event.participantIDs.filter(id => id !== senderID && id !== api.getCurrentUserID());
    let partnerID = participants[Math.floor(Math.random() * participants.length)];
    
    dataMatch[senderID] = { partner: partnerID, time: Date.now(), kids: [] };
    dataMatch[partnerID] = { partner: senderID, time: Date.now(), kids: [] };
    fs.writeFileSync(path, JSON.stringify(dataMatch, null, 2));
    await Currencies.setData(senderID, { money: userMoney - 200 });

    api.setMessageReaction("💛", messageID, () => {}, true); // قلب أصفر للزواج
    return api.sendMessage(`💍 ┃ مَـبْـرُوك اَلـزَّوَاج اَلْـمَـلَـكِيّ!\n━━━━━━━━━━━━━━━\n💞 ┃ تَمَّ جَمْعُكَ بِـ: @${(await Users.getData(partnerID)).name}\n💰 ┃ دَفَعْتِ مَهْراً قَدْرُهُ 200$\n━━━━━━━━━━━━━━━\n👑 ┃ رِيُـو بُـوت`, threadID, { mentions: [{ tag: (await Users.getData(partnerID)).name, id: partnerID }] });
  }

  // 2. نـظـام الـطـلاق
  if (args[0] === "طلاق") {
    if (!dataMatch[senderID]) return api.sendMessage("⚠️ ┃ مَـا مْـزَوْجْ مَـا وَالُـو وبَـاغِي تْـطَلَّـق؟ سِـيـرْ تَـكْـمَّـشْ! 😂", threadID, messageID);
    
    const partnerID = dataMatch[senderID].partner;
    delete dataMatch[partnerID];
    delete dataMatch[senderID];
    fs.writeFileSync(path, JSON.stringify(dataMatch, null, 2));

    api.setMessageReaction("💔", messageID, () => {}, true);
    return api.sendMessage("🥀 ┃ تَـمَّ اَلـطَّلَاقُ رَسْـمِيّـاً.. عُـدْتَ إِلَى عَـالَمِ اَلْـحُـرِّيَّـة (اَلـسِّـنْجَلْ)! ✨", threadID, messageID);
  }

  // 3. نـظـام اَلْـعَـرْض (صور الزوجين)
  if (args[0] === "عرض") {
    if (!dataMatch[senderID]) return api.sendMessage("⚠️ ┃ لَا تُـوجَـدُ عَـائِلَـة لَـدَيْكَ حَـالِيـاً.", threadID, messageID);
    
    const info = dataMatch[senderID];
    const partnerData = await Users.getData(info.partner);
    const senderData = await Users.getData(senderID);

    api.setMessageReaction("💚", messageID, () => {}, true); // تفاعل أخضر للعرض
    try {
      const img1 = (await axios.get(`https://graph.facebook.com/${senderID}/picture?height=720&width=720&access_token=${TOKEN}`, { responseType: "arraybuffer" })).data;
      const img2 = (await axios.get(`https://graph.facebook.com/${info.partner}/picture?height=720&width=720&access_token=${TOKEN}`, { responseType: "arraybuffer" })).data;
      
      const p1 = __dirname + `/cache/p1_${senderID}.png`;
      const p2 = __dirname + `/cache/p2_${senderID}.png`;
      fs.writeFileSync(p1, Buffer.from(img1));
      fs.writeFileSync(p2, Buffer.from(img2));

      const msg = {
        body: `👑 ┃ بـروفـايـل اَلـزَّوْجَيْـن اَلْـمَـلَـكِي\n━━━━━━━━━━━━━━━\n🤵 ┃ اَلـزَّوْج: ${senderData.name}\n👰 ┃ اَلـزَّوْجَـة: ${partnerData.name}\n👶 ┃ عَـدَد اَلْأَوْلَاد: ${info.kids.length}\n━━━━━━━━━━━━━━━`,
        attachment: [fs.createReadStream(p1), fs.createReadStream(p2)]
      };
      return api.sendMessage(msg, threadID, () => { fs.unlinkSync(p1); fs.unlinkSync(p2); }, messageID);
    } catch(e) { return api.sendMessage("❌ ┃ فَـشَـلَ جَـلْبُ اَلـصُّـوَرِ، اَلـتُّوكِـن قَـدْ يَـكُونُ مَـنْـتَـهِـيـاً.", threadID); }
  }

  // 4. نـظـام اَلْأَوْلَاد
  if (args[0] === "اولاد" || args[0] === "أولاد") {
    if (!dataMatch[senderID]) return api.sendMessage("⚠️ ┃ تْـزَوَّجْ بَـعْدَا عـاد فْـكَـر فـ اَلْـوِلَادَة! 🤰", threadID, messageID);
    
    let participants = event.participantIDs.filter(id => id !== senderID && id !== dataMatch[senderID].partner && id !== api.getCurrentUserID());
    if (participants.length === 0) return api.sendMessage("⚠️ ┃ لَا يُـوجَـدُ أَشْـخَـاصٌ كَـافُونَ لِـيَـكُونُوا أَبْـنَـاءً!", threadID, messageID);
    
    let kidID = participants[Math.floor(Math.random() * participants.length)];
    let kidName = (await Users.getData(kidID)).name;

    dataMatch[senderID].kids.push(kidID);
    dataMatch[dataMatch[senderID].partner].kids.push(kidID);
    fs.writeFileSync(path, JSON.stringify(dataMatch, null, 2));

    api.setMessageReaction("🤍", messageID, () => {}, true); // تفاعل أبيض للأولاد
    return api.sendMessage(`👶 ┃ مَـبْـرُوك! رُزِقْـتُـمَا بِمَـوْلُودٍ جَـدِيـدٍ:\n━━━━━━━━━━━━━━━\n✨ ┃ اَلْإِبْـن/اَلْإِبْـنَـة: ${kidName}\n👪 ┃ اَلْآنَ عَـائِـلَـتُـكُـم تَـكْـبُـر!`, threadID, messageID);
  }

  // 5. نـظـام اَلْـعَـائِلَـة (صور العائلة كاملة)
  if (args[0] === "عائلة") {
    if (!dataMatch[senderID]) return api.sendMessage("⚠️ ┃ مَـا عَـنْدَك عـائـلـة، سِـيـرْ تـزوج!", threadID, messageID);
    
    const info = dataMatch[senderID];
    const kids = info.kids;
    api.setMessageReaction("🖤", messageID, () => {}, true); // تفاعل أسود للعائلة

    let attachments = [];
    try {
      // إضافة صورة الزوج والزوجة
      const ids = [senderID, info.partner, ...kids.slice(0, 3)]; // حد أقصى 5 صور لتجنب البطء
      for (let id of ids) {
        let img = (await axios.get(`https://graph.facebook.com/${id}/picture?height=480&width=480&access_token=${TOKEN}`, { responseType: "arraybuffer" })).data;
        let p = __dirname + `/cache/fam_${id}.png`;
        fs.writeFileSync(p, Buffer.from(img));
        attachments.push(fs.createReadStream(p));
      }

      return api.sendMessage({
        body: `👨‍👩‍👧‍👦 ┃ شَـجَـرَةُ العَـائِلَـةِ  اَلْـمَـلَـكِيَّة\n━━━━━━━━━━━━━━━\n👨‍⚖️ ┃ اَلْأَب وَاَلْأُم + ${kids.length} مِـنَ اَلْأَبْـنَـاء\n━━━━━━━━━━━━━━━`,
        attachment: attachments
      }, threadID, () => {
        ids.forEach(id => { try { fs.unlinkSync(__dirname + `/cache/fam_${id}.png`); } catch(e) {} });
      }, messageID);
    } catch(e) { return api.sendMessage("❌ ┃ فَـشَـلَ عـرضُ صُـوَرِ اَلْـعَـائِلَـةِ.", threadID); }
  }
};