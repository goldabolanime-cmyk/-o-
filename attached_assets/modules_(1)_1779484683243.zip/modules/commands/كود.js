const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "كود",
  version: "6.5.0",
  hasPermssion: 2, 
  credits: "عبدو / RIO BOOT",
  description: "نظام إدارة الملفات: عرض، تعديل، حذف، وقائمة",
  commandCategory: "نظام المطور",
  usages: "[اسم الأمر] أو [تعديل] [الاسم] [الكود] أو [حذف] [الاسم] أو [قائمة]",
  cooldowns: 0
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID, body } = event;
  const devID = "100090081489341"; // أيدي المطور عبدو

  if (senderID !== devID) return api.sendMessage("👑 ┃ هـذا الأمـر مـخـصـص لـلـمُـطَـوِّرِ عـبـدو فَـقَـطْ!", threadID, messageID);

  const dirPath = __dirname;
  const files = fs.readdirSync(dirPath).filter(file => file.endsWith(".js"));

  // --- [ خيار قائمة الملفات ] ---
  if (args[0] === "قائمة") {
    api.setMessageReaction("📋", messageID, () => {}, true);
    let msg = "━━━『 مَـلَـفَّـاتُ الأَوَامِـرِ 』━━━\n\n";
    files.forEach((file, index) => {
      msg += `${index + 1} ❯ ${file}\n`;
    });
    msg += `\n━━━━━━━━━━━━━━━\n🔹 إِجْـمَـالِي الـمَـلَـفَّـاتِ: ${files.length}`;
    return api.sendMessage(msg, threadID, messageID);
  }

  if (args.length === 0) return api.sendMessage("⚠️ ┃ يُـرْجَى كِـتَـابَـةُ اسْـمِ الأَمْـرِ، مِـثْـلًا: .كود زبالة أَوْ .كود قائمة", threadID, messageID);

  // تحديد نوع العملية: تعديل، حذف، أو عرض
  const isEdit = args[0] === "تعديل";
  const isDelete = args[0] === "حذف";
  const targetName = (isEdit || isDelete) ? args[1] : args[0];

  let fileName = "";
  let filePath = "";

  for (const file of files) {
    const p = path.join(dirPath, file);
    try {
      if (file === targetName || file === targetName + ".js") {
        fileName = file;
        filePath = p;
        break;
      }
      const command = require(p);
      if (command.config && command.config.name === targetName) {
        fileName = file;
        filePath = p;
        break;
      }
    } catch (e) { continue; }
  }

  if (!filePath) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ ┃ لَـمْ يَـتَّـمَّ الـعُـثُـورُ عَـلَى [ ${targetName} ]`, threadID, messageID);
  }

  // --- [ الحالة 1: حـذف الـمـلـف ] ---
  if (isDelete) {
    try {
      api.setMessageReaction("🗑️", messageID, () => {}, true);
      fs.unlinkSync(filePath); // حذف الملف نهائياً
      
      // إزالة الأمر من ذاكرة البوت إذا كان محملاً
      if (global.client.commands.has(targetName)) {
        global.client.commands.delete(targetName);
      }
      
      return api.sendMessage(`✅ ┃ تَـمَّ حَـذْفُ مَـلَـفِّ [ ${fileName} ] بِـنَـجَـاحٍ مِنَ الـنِّـظَـامِ.`, threadID, messageID);
    } catch (err) {
      api.setMessageReaction("⚠️", messageID, () => {}, true);
      return api.sendMessage(`❌ ┃ فَـشَـلَ الـحَـذْفُ: ${err.message}`, threadID, messageID);
    }
  }

  // --- [ الحالة 2: عرض الكود ] ---
  if (!isEdit && !isDelete) {
    api.setMessageReaction("⏳", messageID, () => {}, true);
    
    try {
      const code = fs.readFileSync(filePath, "utf-8");
      setTimeout(() => {
        api.setMessageReaction("✅", messageID, () => {}, true);
        return api.sendMessage(code, threadID, (err, info) => {
          api.sendMessage("⏳ ┃ سَـيَـتِـمُّ حَـذْفُ الـكُـودِ بَـعْـدَ 2 دَقِـيـقَـةٍ لِـلْـخُـصُـوصِـيَّـةِ.", threadID, (err, nInfo) => {
            setTimeout(() => {
              api.unsendMessage(info.messageID);
              api.unsendMessage(nInfo.messageID);
            }, 120000);
          });
        }, messageID);
      }, 5000);
      return; 
    } catch (err) {
      api.setMessageReaction("⚠️", messageID, () => {}, true);
      return api.sendMessage("❌ ┃ خَـطَـأٌ فِـي قِـرَاءَةِ الـمَـلَـفِّ.", threadID, messageID);
    }
  }

  // --- [ الحالة 3: التعديل والحفظ ] ---
  if (isEdit) {
    if (!args[1]) return api.sendMessage("⚠️ ┃ يُـرْجَى كِـتَـابَـةُ اسْـمِ الأَمْـرِ بَـعْـدَ كَـلِـمَـةِ تَـعْـدِيـلٍ.", threadID, messageID);

    const searchString = args[1];
    const startIndex = body.indexOf(searchString) + searchString.length;
    const newCode = body.substring(startIndex).trim();

    if (!newCode) return api.sendMessage("⚠️ ┃ لَـمْ تَـضَـعِ الـكُـودَ الـجَـدِيـدَ بَـعْـدَ الاسْـمِ!", threadID, messageID);

    try {
      fs.writeFileSync(filePath, newCode, "utf-8");
      api.setMessageReaction("✅", messageID, () => {}, true);

      try {
        delete require.cache[require.resolve(filePath)];
        const updated = require(filePath);
        if (updated.config && updated.config.name) {
          global.client.commands.set(updated.config.name, updated);
        }
      } catch (e) {
        return api.sendMessage(`⚠️ ┃ تَـمَّ الـحَـفْـظُ، وَلَـكِـنْ هُـنَـاكَ خَـطَـأٌ بَـرْمَـجِيٌّ:\n\n${e.message}`, threadID, messageID);
      }

      return api.sendMessage(`✅ ┃ تَـمَّ تَـعْـدِيـلُ وَحَـفْـظُ [ ${fileName} ] بِـنَـجَـاحٍ!`, threadID, messageID);
    } catch (err) {
      api.setMessageReaction("❌", messageID, () => {}, true);
      return api.sendMessage(`❌ ┃ فَـشَـلَ الـحَـفْـظُ:\n${err.message}`, threadID, messageID);
    }
  }
};
