module.exports.config = {
  name: "أضف",
  version: "1.5.0",
  hasPermssion: 1, // مسؤول المجموعة والمطور فقط
  credits: "عبدو / RIO BOT",
  description: "إِضَافَةُ عُضْوٍ إِلَى اَلْمَجْمُوعَةِ عَبْرَ اَلْأَيْدِي أَوْ اَلرَّابِطِ",
  commandCategory: "نظام",
  usages: "[الأيدي / رابط الحساب]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const botID = api.getCurrentUserID();

  // التحقق من وجود مدخلات (أيدي أو رابط)
  if (!args[0]) return api.sendMessage("⚠️ ┃ مِـنْ فَـضْـلِـكَ أَدْخِـلْ أَيْـدِي اَلْـحِسَـابِ أَوْ رَابِـطَ اَلـبْـرُوفَـايـلِ لِإِضَـافَـتِـهِ.", threadID, messageID);

  // التأكد من أن البوت مسؤول لكي يتمكن من الإضافة
  api.getThreadInfo(threadID, (err, info) => {
    if (err) return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي جَـلْبِ بَيَـانَاتِ اَلْـمَجْـمُوعَـةِ.", threadID, messageID);
    if (!info.adminIDs.some(item => item.id == botID)) {
      return api.sendMessage("⚠️ ┃ يَـجِبُ أَنْ أَكُـونَ مَـسْـؤُولاً (ADMIN) لِأَتَـمَكَّـنَ مِـنْ إِضَـافَـةِ اَلْأَعْـضَـاءِ.", threadID, messageID);
    }

    let input = args[0];

    // دالة تنفيذ الإضافة النهائية
    const performAdd = (uid) => {
      api.addUserToGroup(uid, threadID, (err) => {
        if (err) {
          return api.sendMessage(`❌ ┃ لَـمْ أَسْـتَطِـعْ إِضَـافَـةَ اَلْـعُـضْـوِ.\n💡 اَلـسَّـبَـبُ: قَـدْ يَـكُـونُ اَلْـحِسَـابُ مَـحْـظُوراً أَوْ لَـدَيْـهِ إِعْـدَادَاتُ خُـصُوصِيَّـةٍ تَمْـنَـعُ اَلْإِضَـافَـةَ.`, threadID, messageID);
        }
        return api.sendMessage(`✅ ┃ تَـمَّتِ اَلْإِضَـافَـةُ بِنَـجَـاحٍ لِـلْأَيْـدِي: ${uid}`, threadID);
      });
    };

    // إذا كان المدخل رابطاً، نحاول استخراج الأيدي (UID)
    if (input.includes("facebook.com") || input.includes("fb.com")) {
      api.getUID(input, (err, uid) => {
        if (err || !uid) {
          return api.sendMessage("❌ ┃ فَـشَـلَ اَلـنِّـظَـامُ فِـي اِسْـتِخْـرَاجِ اَلْأَيْـدِي مِـنْ هَـذَا اَلـرَّابِـطِ.", threadID, messageID);
        }
        performAdd(uid);
      });
    } else {
      // إذا كان المدخل أيدي مباشر
      if (isNaN(input)) return api.sendMessage("⚠️ ┃ اَلْأَيْـدِي اَلَّـذِي أَدْخَـلْـتَـهُ غَـيْـرُ صَـحِيـحٍ.", threadID, messageID);
      performAdd(input);
    }
  });
};