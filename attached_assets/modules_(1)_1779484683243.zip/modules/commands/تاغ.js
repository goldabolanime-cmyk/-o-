module.exports.config = {
  name: "تاغ",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "منشن للكل أو حسب الحرف (للمطور والمسؤولين فقط)",
  commandCategory: "نظام",
  usages: "[الكل / حرف]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args, Users }) {
  const { threadID, messageID, senderID } = event;
  const adminID = "100090081489341"; // الأيدي الخاص بك يا عبدو

  try {
    // --- 1. التحقق من الصلاحيات (المطور أو الأدمن) ---
    const threadInfo = await api.getThreadInfo(threadID);
    const participantIDs = threadInfo.participantIDs;
    const isGroupAdmin = threadInfo.adminIDs.some(admin => admin.id == senderID);
    
    if (senderID !== adminID && !isGroupAdmin) {
      return api.sendMessage("❌ ┃ عُـذْراً، هَـذَا اَلْأَمْـرُ مَـخْـصُوصٌ لِـلْـمُطَـوِّرِ عَـبْـدُو وَمَـسْـؤُولِي اَلْـمَجْـمُوعَـةِ فَـقَـطْ.", threadID, messageID);
    }

    let listTarget = [];
    let msgHeader = "";

    // --- 2. حالة تاغ الكل ---
    if (args[0] === "الكل") {
      msgHeader = "📣 ┃ نِـدَاءٌ مَـلَـكِيٌّ لِـجَـمِـيعِ اَلْأَعْـضَاءِ:\n━━━━━━━━━━━━━━━\n";
      const mentions = participantIDs.map(id => ({
        tag: "@الكل",
        id: id
      }));
      return api.sendMessage({ body: `${msgHeader}@الكل`, mentions }, threadID);
    } 
    
    // --- 3. حالة التاك حسب الحرف الأول ---
    else if (args[0] && args[0].length === 1) {
      const char = args[0].toLowerCase();
      msgHeader = `🔍 ┃ نِـظَـامُ اَلـتَّصْـفِيَةِ لِـحَرْفِ: 『 ${char.toUpperCase()} 』\n━━━━━━━━━━━━━━━\n`;
      
      for (const id of participantIDs) {
        const name = await Users.getNameUser(id);
        if (name.toLowerCase().startsWith(char)) {
          listTarget.push({ id, name });
        }
      }

      if (listTarget.length === 0) {
        return api.sendMessage(`⚠️ ┃ لَـمْ أَجِـدْ أَعْـضَاءً تَـبْـدَأُ أَسْـمَاؤُهُمْ بِـالْـحَرْفِ اَلْـمَطْـلُوبِ.`, threadID, messageID);
      }

      const mentions = listTarget.map(u => ({ tag: `@${u.name}`, id: u.id }));
      const tagText = msgHeader + listTarget.map(u => `@${u.name}`).join(" ");
      
      return api.sendMessage({ body: tagText, mentions }, threadID);
    } 
    
    // --- 4. دليل الاستخدام ---
    else {
      return api.sendMessage("💡 ┃ كَـيْـفِيَّةُ اَلْاسْتِخْدَامِ:\n\n• [ تاغ الكل ] لِـمَنْشَنَةِ اَلْجَمِيعِ بِصِيغَةِ @الكل.\n• [ تاغ حرف ] لِـمَنْشَنَةِ مَنْ يَبْدَأُ اِسْمُهُ بِهَذَا اَلْحَرْفِ.", threadID, messageID);
    }

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي نِـظَـامِ اَلـتَّـاكِ اَلْـجَـمَـاعِيِّ.", threadID, messageID);
  }
};