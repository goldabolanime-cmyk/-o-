module.exports.config = {
    name: "طرد",
    version: "1.1.0",
    hasPermssion: 1, // للمشرفين فقط
    credits: "XaviaTeam / تعديل Gemini",
    description: "إزالة عضو من المجموعة مع حماية المطور",
    commandCategory: "إشراف",
    usages: "[منشن / رد]",
    cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
    const { threadID, messageID, senderID, mentions, type, messageReply } = event;
    const developerID = "100090081489341"; // الآيدي الخاص بك

    try {
        // 1. التحقق من وجود أعضاء
        if (event.participantIDs.length <= 1) return; 

        // 2. تحديد الشخص المستهدف
        let targetIDs = [];
        if (type == "message_reply") {
            targetIDs.push(messageReply.senderID);
        } else if (Object.keys(mentions).length > 0) {
            targetIDs = Object.keys(mentions);
        }

        if (targetIDs.length == 0) {
            return api.sendMessage("━━━━━━━━━━━━━\n「 ⚠️ 」يُـرجـى تـحـديـد الـشـخـص (مـنـشـن أو رد عـلى رسـالـتـه).\n━━━━━━━━━━━━━", threadID, messageID);
        }

        // 3. جلب معلومات المجموعة وتحقق من صلاحيات البوت
        const threadInfo = await api.getThreadInfo(threadID);
        const adminIDs = threadInfo.adminIDs.map(e => e.id);
        const botID = api.getCurrentUserID();

        if (!adminIDs.includes(botID)) {
            return api.sendMessage("━━━━━━━━━━━━━\n「 🚫 」يـجـب أن أكـون مـسـؤولاً (Admin) لأسـتـطـيـع طـرد الـمُـخـالـفـيـن.\n━━━━━━━━━━━━━", threadID, messageID);
        }

        // 4. معالجة الحالات الخاصة والاستثناءات
        
        // استثناء المطور
        if (targetIDs.includes(developerID)) {
            return api.sendMessage("━━━━━━━━━━━━━\n「 🛡️ 」لا يـمـكـن طـرد مـطـور الـبـوت.. هـل تـحـاول الـتـمـرد؟ 🤨\n━━━━━━━━━━━━━", threadID, messageID);
        }

        // استثناء البوت نفسه
        if (targetIDs.includes(botID)) {
            return api.sendMessage("「 🤨 」تـريـد طـردي أنـا؟ هـل هـذا جـزاء الإحـسـان؟", threadID, messageID);
        }

        // استثناء الشخص لنفسه
        if (targetIDs.includes(senderID)) {
            return api.sendMessage("「 🙃 」لـمـاذا تـريـد طـرد نـفـسـك؟ اسـتـخـدم أمـر (اطردني).", threadID, messageID);
        }

        // 5. عملية الطرد الجماعي
        let processed = 0;
        let success = 0;
        let fail = 0;

        for (const targetID of targetIDs) {
            api.removeUserFromGroup(targetID, threadID, (err) => {
                processed++;
                if (err) {
                    fail++;
                } else {
                    success++;
                }
                
                // إرسال النتيجة النهائية بعد معالجة الجميع
                if (processed === targetIDs.length) {
                    let finalMsg = "━━━━━━━━━━━━━\n";
                    if (success > 0) finalMsg += `「 ✅ 」تـم طـرد ${success} عـضـو بـنـجـاح.\n`;
                    if (fail > 0) finalMsg += `「 ❌ 」فـشـل طـرد ${fail} عـضـو (ربما أدمن أو لديه حماية).\n`;
                    finalMsg += "━━━━━━━━━━━━━";
                    api.sendMessage(finalMsg, threadID);
                }
            });
        }

    } catch (e) {
        console.error(e);
        api.sendMessage("「 ⚙️ 」حـدث خـطأ تـقـني عـند مـحاولـة الـطرد.", threadID, messageID);
    }
};
