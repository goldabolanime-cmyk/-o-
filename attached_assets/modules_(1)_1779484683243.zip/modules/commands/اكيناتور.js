const { Aki } = require('akinator-api');

module.exports.config = {
  name: "اكيناتور",
  version: "2.5.0",
  hasPermssion: 0,
  credits: "Abdou - Rio System",
  description: "الارتباط المباشر بموقع قارئ الأفكار الملكي",
  usages: ["لعب"],
  commandCategory: "العاب",
  cooldowns: 5
};

// مخزن الجلسات لضمان عدم تداخل اللاعبين
const sessions = new Map();

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID !== handleReply.author) return;

  const aki = sessions.get(senderID);
  if (!aki) return;

  // تحويل رد المستخدم ليفهمه منطق الموقع
  const input = body.trim();
  let answer;
  if (input == "0" || input == "نعم") answer = 0;
  else if (input == "1" || input == "لا") answer = 1;
  else if (input == "2" || input == "لا اعلم" || input == "لا أعلم") answer = 2;
  else if (input == "3" || input == "من الممكن") answer = 3;
  else if (input == "4" || input == "من المستبعد") answer = 4;
  else if (input == "5" || input == "رجوع") {
    await aki.back();
    api.unsendMessage(handleReply.messageID);
    return sendQuestion(api, event, aki);
  } else {
    return api.sendMessage("⚠️ أجب برقم (0-5) أو الكلمة المناسبة فقط!", threadID, messageID);
  }

  try {
    api.unsendMessage(handleReply.messageID); // تنظيف الشات ليبقى ملكياً
    await aki.step(answer);

    // التحقق هل حزر المارد الشخصية؟ (بناءً على نسبة التقدم في موقعك)
    if (aki.progress >= 85 || aki.currentStep >= 79) {
      await aki.win();
      const result = aki.answers[0];
      
      const winMsg = `👑 𝐑𝐈𝐎 𝐀𝐊𝐈𝐍𝐀𝐓𝐎𝐑 𝐑𝐄𝐒𝐔𝐋𝐓 👑\n` +
                     `━━━━━━━━━━━━━━━\n` +
                     `🧞‍♂️ لقد قرأت أفكارك بنجاح!\n\n` +
                     `👤 الشخصية: ${result.name}\n` +
                     `📝 الوصف: ${result.description}\n` +
                     `━━━━━━━━━━━━━━━\n` +
                     `✨ تم التخمين في ${aki.currentStep} سؤالاً.\n` +
                     `🔗 رابط موقعك: https://guess-my-muse.lovable.app/`;

      sessions.delete(senderID);
      return api.sendMessage({
        body: winMsg,
        attachment: await global.utils.getStreamFromURL(result.absolute_picture_path)
      }, threadID);
    }

    // إرسال السؤال التالي بنفس تنسيق الموقع
    sendQuestion(api, event, aki);

  } catch (e) {
    sessions.delete(senderID);
    api.sendMessage("❌ انقطع الاتصال بموقع قارئ الأفكار، حاول مجدداً.", threadID);
  }
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, senderID } = event;

  api.sendMessage("🔮 جاري فتح البوابة لموقع قارئ الأفكار... 🪄", threadID, messageID);

  try {
    const aki = new Aki({ region: 'ar' }); // لغة عربية 100%
    await aki.start();
    sessions.set(senderID, aki);
    
    sendQuestion(api, event, aki);
  } catch (e) {
    api.sendMessage("❌ تعذر الاتصال بالموقع حالياً، تأكد من جودة السيرفر.", threadID, messageID);
  }
};

// دالة إرسال السؤال بتنسيق "ريو" الفخم
async function sendQuestion(api, event, aki) {
  const qMsg = `🔱 𝐑𝐈𝐎 𝐒𝐘𝐒𝐓𝐄𝐌 🔮 𝐀𝐊𝐈𝐍𝐀𝐓𝐎𝐑 🔱\n` +
               `━━━━━━━━━━━━━━━\n` +
               `❓ السؤال رقم [ ${aki.currentStep + 1} ]\n\n` +
               `📢 ${aki.question}\n` +
               `━━━━━━━━━━━━━━━\n` +
               `0️⃣ نعم  |  1️⃣ لا\n` +
               `2️⃣ لا أعلم\n` +
               `3️⃣ من الممكن | 4️⃣ من المستبعد\n` +
               `5️⃣ رجوع (تصحيح الخطأ)\n\n` +
               `✨ تقدم التخمين: 【${Math.floor(aki.progress)}%】`;

  return api.sendMessage(qMsg, event.threadID, (err, info) => {
    global.client.handleReply.push({
      name: "اكيناتور",
      messageID: info.messageID,
      author: event.senderID
    });
  });
}