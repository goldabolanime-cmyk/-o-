module.exports.config = {
  name: "معلوماتي",
  version: "1.7.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "عرض معلومات حسابك مع السيارات التي تمتلكها",
  commandCategory: "خدمات",
  usages: "",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, Users, Threads, Currencies }) {
  const { threadID, messageID, senderID } = event;
  const fs = require("fs-extra");
  const axios = require("axios");

  try {
    // جلب بيانات المستخدم والمجموعة
    const userData = await api.getUserInfo(senderID);
    const threadInfo = await api.getThreadInfo(threadID);
    const userName = userData[senderID].name;
    const userLink = `https://www.facebook.com/${senderID}`;
    
    // جلب بيانات البنك والسيارات
    const userBalance = await Currencies.getData(senderID);
    const money = userBalance.money || 0;
    // جلب قائمة السيارات من الـ data وإذا كانت فارغة نضع نصاً افتراضياً
    const myCars = userBalance.data && userBalance.data.cars ? userBalance.data.cars.join(", ") : "لا توجد سيارات بعد";

    // جلب الإحصائيات والترتيب
    const threadData = await Threads.getInfo(threadID);
    const allStats = threadData.threadStats || [];
    const totalMsg = threadInfo.messageCount;
    const userStats = allStats.find(i => i.senderID == senderID) || { count: 0 };
    const userMsgCount = userStats.count;

    allStats.sort((a, b) => b.count - a.count);
    const rank = allStats.findIndex(i => i.senderID == senderID) + 1;

    // مسار تخزين صورة البروفايل
    const avatarPath = __dirname + `/cache/${senderID}.png`;
    const getAvatar = (await axios.get(`https://graph.facebook.com/${senderID}/picture?width=720&height=720&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, { responseType: "arraybuffer" })).data;
    fs.writeFileSync(avatarPath, Buffer.from(getAvatar, "utf-8"));

    const msg = `
━━━━━━━━━━━━━━━
  رِيُـو بُـوتْ - مَـعْـلُـومَاتِي
━━━━━━━━━━━━━━━

❯ اسْـمُ الـحِـسَابِ: ${userName}
❯ الأَيْـدِي الـخَـاصُّ: ${senderID}
❯ رَصِـيـدُكَ: ${money} 🇲🇦

❯ تَـرْتِـيـبُـكَ: ${rank || "غـيـر مـصـنـف"}
❯ رَسَـائـلُـكَ: ${userMsgCount}

🚗 مَـرْأَبُ الـسَّـيَّـارَاتِ:
[ ${myCars} ]

━━━━━━━━━━━━━━━
  رَابِـطُ الـحِـسَـابِ: 
${userLink}
━━━━━━━━━━━━━━━
    `.trim();

    return api.sendMessage({
      body: msg,
      attachment: fs.createReadStream(avatarPath)
    }, threadID, () => fs.unlinkSync(avatarPath), messageID);

  } catch (e) {
    console.log(e);
    return api.sendMessage("حَـدَثَ خَـطَـأٌ فِـي اسْـتِـخْـرَاجِ الـبَـيَـانَاتِ", threadID, messageID);
  }
};