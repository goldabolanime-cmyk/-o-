module.exports.config = {
  name: "فريند",
  version: "2.0.0",
  hasPermssion: 2,
  credits: "عبدو / RIO BOOT",
  description: "إدارة أصدقاء البوت (حذف فردي أو شامل) مع حماية المطور",
  commandCategory: "المطور",
  usages: "[رقم الصفحة] أو [الكل]",
  cooldowns: 5
};

module.exports.handleReply = async function ({ api, args, Users, handleReply, event }) {
  const { threadID, messageID, senderID, body } = event;
  const devID = "100090081489341"; // الأيدي الخاص بك يا عبدو

  if (parseInt(senderID) !== parseInt(handleReply.author)) return;

  switch (handleReply.type) {
    case "reply":
      {
        let msg = "", count = 0;
        const nums = body.split(" ").map(n => parseInt(n));
        
        for (let num of nums) {
          const name = handleReply.nameUser[num - 1];
          const uidUser = handleReply.uidUser[num - 1];
          const urlUser = handleReply.urlUser[num - 1];

          if (uidUser == devID) {
            msg += `🚫 ┃ تـم تـخـطي [ ${name} ] لأنـه الـمـطـور الملكي!\n`;
            continue;
          }

          api.unfriend(uidUser);
          msg += `✅ ┃ تـم حـذف: ${name}\n🔗 ┃ الرابط: ${urlUser}\n`;
          count++;
        }

        api.sendMessage(`✨ ┃ نـتـيـجـة الـتـنـظـيـف:\n\n${msg}\n📊 ┃ الإجـمـالي: تـم حـذف ${count} صـديـق.`, threadID, () =>
          api.unsendMessage(handleReply.messageID));
      }
      break;
  }
};

module.exports.run = async function ({ event, api, args }) {
  const { threadID, messageID, senderID } = event;
  const devID = "100090081489341"; // الأيدي الخاص بك يا عبدو

  try {
    const dataFriend = await api.getFriendsList();
    const countFr = dataFriend.length;

    // --- ميزة حذف الكل ---
    if (args[0] === "الكل") {
      api.sendMessage(`⏳ ┃ جـاري حـذف جـمـيـع الأصـدقـاء (${countFr})...\n🛡️ ┃ سـيـتـم اسـتـثـنـاء الـمـطـور عـبـدو تـلـقـائـيـاً.`, threadID);
      let deletedCount = 0;
      for (let friend of dataFriend) {
        if (friend.userID == devID) continue;
        await api.unfriend(friend.userID);
        deletedCount++;
      }
      return api.sendMessage(`✅ ┃ تـم تـصـفـيـة الـقـائمة بـنـجـاح!\n🗑️ ┃ تـم حـذف: ${deletedCount} صـديـق.\n👑 ┃ حـسـاب الـمـطـور لا يـزال مـوجـوداً.`, threadID);
    }

    // --- عرض القائمة العادية ---
    var listFriend = dataFriend.map(f => ({
      name: f.fullName || "بدون اسم",
      uid: f.userID,
      gender: f.gender,
      vanity: f.vanity,
      profileUrl: f.profileUrl
    }));

    var nameUser = [], urlUser = [], uidUser = [];
    var page = parseInt(args[0]) || 1;
    var limit = 10;
    var numPage = Math.ceil(listFriend.length / limit);
    var msg = `🎭 ┃ هـناك [ ${countFr} ] صـديق لـريـو بـوت\n\n`;

    for (var i = limit * (page - 1); i < limit * (page - 1) + limit; i++) {
      if (i >= listFriend.length) break;
      let info = listFriend[i];
      msg += `${i + 1}. ${info.name} ${info.uid == devID ? "👑" : ""}\n🆔 ┃ الأيدي: ${info.uid}\n🌐 ┃ الرابط: ${info.profileUrl}\n\n`;
      nameUser.push(info.name);
      urlUser.push(info.profileUrl);
      uidUser.push(info.uid);
    }

    msg += `✎﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏\n📖 ┃ الـصـفـحـة ${page}/${numPage}\n💡 ┃ رُد بـأرقـام لـلـحـذف أو اكـتـب [.فريند الكل]`;

    return api.sendMessage(msg, threadID, (e, data) =>
      global.client.handleReply.push({
        name: this.config.name,
        author: senderID,
        messageID: data.messageID,
        nameUser,
        urlUser,
        uidUser,
        type: 'reply'
      })
    );
  } catch (e) {
    return console.log(e);
  }
};
