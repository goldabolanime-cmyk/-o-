const cron = require("node-cron");
const moment = require("moment-timezone");

module.exports.config = {
  name: "اذكار",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "عبدو & ريو بوت",
  description: "أذكار شاملة (نصوص كاملة) مجدولة حسب الوقت",
  commandCategory: "إسلاميات",
  usages: "اذكار",
  cooldowns: 5,
};

// --- قاعدة بيانات الأذكار التفصيلية ---
const azkarData = {
  "أَذْكَارُ الْفَجْرِ": "• سورة الإخلاص والمعوذتين (3 مرات).\n• أصبحنا وأصبح الملك لله والحمد لله.\n• اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور.",
  "أَذْكَارُ الصَّبَاحِ": "• آية الكرسي.\n• سورة الإخلاص والمعوذتين.\n• رضيت بالله ربا وبالإسلام دينا وبمحمد صلى الله عليه وسلم نبيا.\n• حَسبيَ اللَّهُ لا إِلهَ إِلّا هُوَ عَلَيهِ تَوَكَّلتُ وَهُوَ رَبُّ العَرشِ العَظيمِ (7 مرات).",
  "أَذْكَارُ الضُّحَى": "• سُبْحَانَ اللهِ وَبِحَمْدِهِ (100 مرة).\n• لا إلَهَ إلَّا اللَّهُ وحْدَهُ لا شَرِيكَ له، له المُلْكُ وله الحَمْدُ، وهو علَى كُلِّ شيءٍ قَدِيرٌ (10 مرات).\n• اللهم إني أسألك علماً نافعاً ورزقاً طيباً.",
  "أَذْكَارُ الْمَسَاءِ": "• آية الكرسي.\n• اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير.\n• أمسينا وأمسى الملك لله والحمد لله.\n• أعوذ بكلمات الله التامات من شر ما خلق (3 مرات).",
  "أَذْكَارُ النَّوْمِ": "• سورة الملك.\n• آية الكرسي.\n• باسمك ربي وضعت جنبي وبك أرفعه.\n• اللهم قني عذابك يوم تبعث عبادك (3 مرات)."
};

const scheduleList = [
  { h: 6, m: 0, name: "أَذْكَارُ الْفَجْرِ" },
  { h: 7, m: 0, name: "أَذْكَارُ الصَّبَاحِ" },
  { h: 13, m: 0, name: "أَذْكَارُ الضُّحَى" },
  { h: 17, m: 0, name: "أَذْكَارُ الْمَسَاءِ" },
  { h: 22, m: 0, name: "أَذْكَارُ النَّوْمِ" }
];

module.exports.onLoad = function ({ api }) {
  scheduleList.forEach((item) => {
    let cronTime = `${item.m} ${item.h} * * *`;
    cron.schedule(cronTime, async () => {
      const allThreads = global.data.allThreadID || [];
      const zekrText = azkarData[item.name];
      const msg = `✨ ━━━━━━━ 𝙍𝙄𝙊 𝘽𝙊𝙏 ━━━━━━━ ✨\n\n🕌 ┇ حان الآن موعد: ${item.name}\n\n📜 ┇ الأذكار :\n${zekrText}\n\n✨ ━━━━━━━━━━━━━━━━━━━━━ ✨`;
      
      allThreads.forEach((id) => {
        api.sendMessage(msg, id, (err) => {
           if(err) console.log(`خطأ في الإرسال للمجموعة ${id}`);
        });
      });
    }, { timezone: "Africa/Casablanca" });
  });
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID } = event;
  const tz = "Africa/Casablanca";
  const now = moment().tz(tz);

  const randomAzkar = [
    "لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ.",
    "يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ.",
    "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.",
    "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي.",
    "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ.",
    "اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ.",
    "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ.",
    "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ."
  ];

  const randomZekr = randomAzkar[Math.floor(Math.random() * randomAzkar.length)];

  let nextTask = null;
  for (let item of scheduleList) {
    let taskTime = moment().tz(tz).hours(item.h).minutes(item.m).seconds(0);
    if (taskTime.isAfter(now)) {
      nextTask = { ...item, time: taskTime };
      break;
    }
  }

  if (!nextTask) {
    nextTask = { 
      ...scheduleList[0], 
      time: moment().tz(tz).add(1, 'day').hours(scheduleList[0].h).minutes(scheduleList[0].m).seconds(0) 
    };
  }

  const diff = moment.duration(nextTask.time.diff(now));
  const timeLeft = `${diff.hours()} ساعة ، ${diff.minutes()} دقيقة ، ${diff.seconds()} ثانية`;

  const msg = `✨ ━━━━━━━ 𝙍𝙄𝙊 𝘽𝙊𝙏 ━━━━━━━ ✨\n\n` +
              `📜 ┇ ذِكْـرٌ عَـشْـوَائِـيٌّ :\n` +
              `« ${randomZekr} »\n\n` +
              `⏳ ┇ يَتَبَقَّى عَلَى :\n` +
              `〔 ${nextTask.name} 〕\n` +
              `⏱️ ┇ ${timeLeft}\n\n` +
              `✨ ━━━━━━━━━━━━━━━━━━━━━ ✨`;

  return api.sendMessage(msg, threadID, messageID);
};