const GryKJ = {};

GryKJ.config = {
    name: "اهداء",
    version: "2.7.0",
    hasPermssion: 0,
    credits: "Abdou",
    description: "إرسال إهداء للخاص (حل مشكلة فشل الإرسال)",
    commandCategory: "إيجابية",
    usages: "[رد على رسالة / أيدي] [النص]",
    cooldowns: 5,
};

GryKJ.run = async function ({ api, event, args }) {
    const { threadID, messageID, senderID, messageReply, type } = event;
    const devID = "100090081489341";

    if (senderID !== devID) return api.sendMessage("🔒 | هذا الأمر للمطور عبدو فقط.", threadID, messageID);

    let targetID;
    let msgIndex;

    // تحديد الشخص
    if (type === "message_reply") {
        targetID = messageReply.senderID;
        msgIndex = 0;
    } else {
        targetID = args[0];
        msgIndex = 1;
    }

    const content = args.slice(msgIndex).join(" ");
    if (!targetID || !content) return api.sendMessage("⚠️ | رد على رسالة الشخص واكتب النص الذي تريد إرساله.", threadID, messageID);

    const giftMessage = `🎁┃إهداء مـن المطور Abdou:\n\n« ${content} »\n\n✨┃نتمنى لك يوماً سعيداً!`;

    // 🛠️ التعديل: إرسال الرسالة مع معالجة الخطأ بطريقة متقدمة
    return api.sendMessage(giftMessage, targetID, (err) => {
        if (err) {
            console.log(err); // سيظهر لك سبب الفشل الحقيقي في كونسول Replit
            return api.sendMessage(`❌┃فشل الإرسال.\nالسبب التقني: ${err.error || "قيود من فيسبوك"}\nنصيحة: تأكد أن البوت لم يتم حظره من المراسلة بسبب السبام القديم.`, threadID, messageID);
        }
        return api.sendMessage(`✅┃تم إرسال الإهداء بنجاح إلى الخاص!`, threadID, messageID);
    });
};

module.exports = GryKJ;