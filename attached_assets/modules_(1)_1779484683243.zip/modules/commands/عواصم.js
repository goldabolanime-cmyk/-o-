module.exports.config = {
  name: "عواصم",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدالرحمن",
  description: "لعبة عواصم الدول مع مكافآت",
  usages: ["لعبة"],
  commandCategory: "العاب",
  cooldowns: 5
};

const questions = [
  { "question": "ما هي عاصمة الجزائر؟", "answer": "الجزائر" },
  { "question": "ما هي عاصمة البحرين؟", "answer": "المنامة" },
  { "question": "ما هي عاصمة مصر؟", "answer": "القاهرة" },
  { "question": "ما هي عاصمة العراق؟", "answer": "بغداد" },
  { "question": "ما هي عاصمة الأردن؟", "answer": "عمان" },
  { "question": "ما هي عاصمة الكويت؟", "answer": "الكويت" },
  { "question": "ما هي عاصمة لبنان؟", "answer": "بيروت" },
  { "question": "ما هي عاصمة ليبيا؟", "answer": "طرابلس" },
  { "question": "ما هي عاصمة موريتانيا؟", "answer": "نواكشوط" },
  { "question": "ما هي عاصمة المغرب؟", "answer": "الرباط" },
  { "question": "ما هي عاصمة قطر؟", "answer": "الدوحة" },
  { "question": "ما هي عاصمة السعودية؟", "answer": "الرياض" },
  { "question": "ما هي عاصمة الصومال؟", "answer": "مقديشو" },
  { "question": "ما هي عاصمة سوريا؟", "answer": "دمشق" },
  { "question": "ما هي عاصمة تونس؟", "answer": "تونس" },
  { "question": "ما هي عاصمة الإمارات العربية المتحدة؟", "answer": "ابوظبي" },
  { "question": "ما هي عاصمة اليمن؟", "answer": "صنعاء" },
  { "question": "ما هي عاصمة فرنسا؟", "answer": "باريس" },
  { "question": "ما هي عاصمة إيطاليا؟", "answer": "روما" },
  { "question": "ما هي عاصمة اليابان؟", "answer": "طوكيو" }
];

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { word, author } = handleReply;
  if (event.senderID != author) return api.sendMessage("ليس دورك للإجابة!", event.threadID);

  if (event.body.toLowerCase() === word.toLowerCase()) {
    await Currencies.increaseMoney(event.senderID, 50);
    api.unsendMessage(handleReply.messageID);
    return api.sendMessage(`✨ أحسنت إجابة صحيحة!\n💰 تم إضافة 50$ إلى حسابك.`, event.threadID);
  } else {
    return api.sendMessage("❌ إجابة خاطئة، حاول مرة أخرى!", event.threadID);
  }
};

module.exports.run = async function ({ api, event }) {
  const item = questions[Math.floor(Math.random() * questions.length)];
  const msg = `👑 𝐑𝐈𝐎 𝐒𝐘𝐒𝐓𝐄𝐌 👑\n\n` +
              `┏━━━━━━━┓\n` +
              `  🌍 السؤال: ${item.question}\n` +
              `┗━━━━━━━┛\n\n` +
              `⏱️ لديك 30 ثانية للإجابة!\n` +
              `💸 المكافأة: 50$`;

  return api.sendMessage(msg, event.threadID, (err, info) => {
    global.client.handleReply.push({
      name: this.config.name,
      messageID: info.messageID,
      author: event.senderID,
      word: item.answer
    });

    // مؤقت المسح بعد 30 ثانية
    setTimeout(() => {
      api.unsendMessage(info.messageID);
    }, 30000);
  });
};