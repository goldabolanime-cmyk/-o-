const axios = require("axios");

module.exports.config = {
    name: "سباق",
    version: "2.0.0",
    hasPermssion: 0,
    credits: "RIO BOOT",
    description: "سباق خيول ملكي (رهان وتفاعل)",
    commandCategory: "الألعاب الملكية",
    usages: "سباق [رقم الحصان 1-5] [المبلغ]",
    cooldowns: 5
};

module.exports.run = async function({ api, event, args, Currencies }) {
    const { threadID, messageID, senderID } = event;
    
    // 1. التحقق من المدخلات
    if (args[0] == "تسجيل") {
        return api.sendMessage("⚠️ ┇ مـولـي، طـريـقـة الـتـسـجـيـل: [سباق رقم_الحصان المبلغ]\n💡 ┇ مـثـال: سباق 3 5000", threadID, messageID);
    }

    const horseID = parseInt(args[0]);
    const betAmount = parseInt(args[1]);
    const userMoney = (await Currencies.getData(senderID)).money;

    if (isNaN(horseID) || horseID < 1 || horseID > 5) return api.sendMessage("⚠️ ┇ مـولـي، اخـتـر حـصـانـاً مـن (1 إلـى 5) فـقـط.", threadID, messageID);
    if (isNaN(betAmount) || betAmount < 100) return api.sendMessage("⚠️ ┇ أقـل مـبـلـغ لـلـرهـان هـو 100$.", threadID, messageID);
    if (userMoney < betAmount) return api.sendMessage(`❌ ┇ رصـيـدك غـيـر كـافٍ! مـعـك فـقـط ${userMoney}$.`, threadID, messageID);

    // 2. رسالة التأكيد بالتفاعل
    return api.sendMessage(`🏇 ┇ تـأكـيـد مـراهـنـة رِيُـو بـوت\n━━━━━━━━━━━━━━━\n👤 ┇ الـمـراهـن: ${senderID}\n🐎 ┇ الـحـصـان الـمـخـتـار: ${horseID}\n💰 ┇ الـمـبـلـغ: ${betAmount}$\n━━━━━━━━━━━━━━━\n✅ ┇ تـفـاعـل بـ (👍) لـتـأكـيـد مـراهـنـتـك ودخـول الـسـبـاق!`, threadID, (err, info) => {
        global.client.handleReaction.push({
            name: this.config.name,
            messageID: info.messageID,
            author: senderID,
            horse: horseID,
            bet: betAmount,
            type: "confirm_race"
        });
    }, messageID);
};

module.exports.handleReaction = async function({ api, event, handleReaction, Currencies }) {
    if (event.reaction !== "👍" || event.userID !== handleReaction.author) return;

    const { threadID, messageID } = event;
    const { horse, bet, author } = handleReaction;

    // البدء في العد التنازلي للسباق (محاكاة 120 ثانية أو البدء الفوري للتجربة)
    api.unsendMessage(handleReaction.messageID);
    api.sendMessage(`🏁 ┇ تـم تـسـجـيـل رهانك يـا مـولي! سـيـبـدأ الـسـبـاق بـعـد قـلـيل...`, threadID);

    setTimeout(async () => {
        const winnerHorse = Math.floor(Math.random() * 5) + 1;
        const horsesEmoji = ["🐎", "🏇", "🐎", "🏇", "🐎"];
        
        let raceAnimate = `🏁 ┇ انـطـلـق الـسـبـاق الـمـلـكـي! ┇ 🏁\n━━━━━━━━━━━━━━━\n`;
        for (let i = 1; i <= 5; i++) {
            raceAnimate += `${i} ┇ ${i === winnerHorse ? "🚩──────🏆" : "───🐎───"}\n`;
        }
        raceAnimate += `━━━━━━━━━━━━━━━\n`;

        if (horse === winnerHorse) {
            const prize = bet * 2;
            await Currencies.increaseMoney(author, bet); // زيادة الربح (الضعف)
            raceAnimate += `🎊 ┇ مـبـرووك يـا مـولي! لـقـد فـاز الـحـصـان (${winnerHorse})\n💰 ┇ ربـحـت: ${prize}$`;
        } else {
            await Currencies.decreaseMoney(author, bet); // سحب الخسارة
            raceAnimate += `❌ ┇ حـظـاً أوفـر.. فـاز الـحـصـان (${winnerHorse})\n💸 ┇ خـسـرت مـبـلـغ الـرهـان: ${bet}$`;
        }

        api.sendMessage(raceAnimate, threadID);
    }, 5000); // وضعتها 5 ثواني للتجربة السريعة، يمكنك تغييرها لـ 120000
};