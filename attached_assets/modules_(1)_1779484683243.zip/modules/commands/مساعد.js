const fs = require("fs-extra");
const path = __dirname + "/cache/assistants.json";

module.exports.config = {
  name: "مساعد",
  version: "1.0.0",
  hasPermssion: 2, // للمطور فقط لاستخدامه
  credits: "عبدو / RIO",
  description: "إضافة أو إزالة مساعد للمطور",
  commandCategory: "المطور",
  usages: "[اضافة/ازالة] [تاغ/رد]",
  cooldowns: 2
};

module.exports.run = async ({ api, event, args, Users }) => {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  const adminID = "100090081489341"; // الأيدي الخاص بك يا عبدو

  // التأكد من أن المطور فقط هو من يستخدم الأمر
  if (senderID !== adminID) return api.sendMessage("⚠️ | عـذراً، هـذا الأمـر مـخـصص لـلـمـطور عـبـدو فـقـط!", threadID, messageID);

  // إنشاء الملف إذا لم يكن موجوداً
  if (!fs.existsSync(path)) fs.writeJsonSync(path, []);
  let assistants = fs.readJsonSync(path);

  const action = args[0];
  let targetID;

  // تحديد الـ ID (رد أو تاغ)
  if (type == "message_reply") {
    targetID = messageReply.senderID;
  } else if (Object.keys(mentions).length > 0) {
    targetID = Object.keys(mentions)[0];
  } else {
    return api.sendMessage("🚩 | يـرجـى الـرد عـلى شـخص أو عـمل تـاغ لإضـافـتـه كمساعد.", threadID, messageID);
  }

  const name = await Users.getNameUser(targetID);

  if (action === "اضافة" || action === "إضافة") {
    if (assistants.includes(targetID)) return api.sendMessage(`📌 | ${name} مـوجـود بـالـفعل فـي قـائـمة الـمساعدين.`, threadID, messageID);
    
    assistants.push(targetID);
    fs.writeJsonSync(path, assistants);
    return api.sendMessage(`✅ | تـم تـعـيـين الـمـسـتـخدم [ ${name} ] كـمساعد لـلـمـطـور بـنـجـاح!`, threadID, messageID);
  } 
  
  else if (action === "ازالة" || action === "إزالة") {
    if (!assistants.includes(targetID)) return api.sendMessage(`📌 | هـذا الـمـسـتخدم لـيـس مـسـاعـداً أصـلاً.`, threadID, messageID);
    
    assistants = assistants.filter(id => id !== targetID);
    fs.writeJsonSync(path, assistants);
    return api.sendMessage(`🗑️ | تـم إزالـة [ ${name} ] مـن قـائـمـة الـمساعديـن.`, threadID, messageID);
  }

  else {
    return api.sendMessage("❓ | اسـتخدام خـاطئ! اسـتخدم: .مساعد [اضافة/ازالة]", threadID, messageID);
  }
};
