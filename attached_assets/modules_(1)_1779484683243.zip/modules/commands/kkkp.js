module.exports.config = {
  name: "مقص",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "لعبة حجر ورقة مقص مع رهان مالي بزخرفة ملكية",
  commandCategory: "العاب",
  usages: "[حجر/ورقة/مقص] [المبلغ]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args, Currencies }) {
  const { threadID, messageID, senderID } = event;
  const fs = require("fs-extra");
  const axios = require("axios");
  
  // جلب بيانات الأموال
  const userData = await Currencies.getData(senderID);
  const money = userData.money;

  const listIMG = [
    'https://i.imgur.com/EOZx1tL.jpg', // حجر (0)
    'https://i.imgur.com/2WSbVaK.jpg', // ورق (1)
    'https://i.imgur.com/1uBAGlO.jpg'  // مقص (2)
  ];
  const listItem = ['حجر', 'ورق', 'مقص'];
  const out = ['👊', '✋', '✌️'];

  const botChoice = listItem[Math.floor(Math.random() * listItem.length)];
  const userChoice = args[0];
  const betAmount = parseInt(args[1]);

  // التحقق من البيانات المدخلة
  if (!userChoice || !listItem.includes(userChoice)) {
    return api.sendMessage(`⚠️ ┃ يرجى اختيار [حجر أو ورق أو مقص] بعد اسم الأمر.\nمثال: مقص ورق 100`, threadID, messageID);
  }
  if (isNaN(betAmount) || betAmount < 50) {
    return api.sendMessage(`💸 ┃ الحد الأدنى للرهان هو 50 عملة يا سيدي.`, threadID, messageID);
  }
  if (money < betAmount) {
    return api.sendMessage(`🚫 ┃ رصيدك الحالي (${money}) لا يكفي للرهان بمبلغ ${betAmount}.`, threadID, messageID);
  }

  const uIdx = listItem.indexOf(userChoice);
  const bIdx = listItem.indexOf(botChoice);

  let result; // 0: خسارة, 1: فوز, 2: تعادل
  if (userChoice === botChoice) result = 2;
  else if (
    (userChoice === 'حجر' && botChoice === 'مقص') ||
    (userChoice === 'ورق' && botChoice === 'حجر') ||
    (userChoice === 'مقص' && botChoice === 'ورق')
  ) result = 1;
  else result = 0;

  // معالجة الأموال والرسائل
  let msg = "";
  if (result === 1) {
    await Currencies.increaseMoney(senderID, betAmount);
    msg = `✨ 🎊 ﴿ تَهْنِئَةٌ مَلَكِيَّةٌ ﴾ 🎊 ✨\n━━━━━━━━━━━━━━━━━━\n✅ لـقـد فُـزتَ فـي الـتَّـحَـدِّي!\n🎎 أَنْتَ: ${out[uIdx]} 𝐕𝐒 🤖 رِيـو: ${out[bIdx]}\n💰 الـجـائزة: +${betAmount} عـمـلـة\n━━━━━━━━━━━━━━━━━━\n👑 رِيـو بُـوت - سَيِّدُ الأَلْعَابِ`;
  } else if (result === 0) {
    await Currencies.decreaseMoney(senderID, betAmount);
    msg = `❌ ┃ لـلأَسَـف لـقـد خَـسِـرْتَ..\n━━━━━━━━━━━━━━━━━━\n🎎 أَنْتَ: ${out[uIdx]} 𝐕𝐒 🤖 رِيـو: ${out[bIdx]}\n💸 الـخـسـارة: -${betAmount} عـمـلـة\n━━━━━━━━━━━━━━━━━━\n👑 رِيـو بُـوت - حَظّاً أَوْفَر مَرَّةً أُخْرَى`;
  } else {
    msg = `⚖️ ┃ نَـتِـيـجَـةٌ مُـتَـعَـادِلَـةٌ!\n━━━━━━━━━━━━━━━━━━\n🎎 أَنْتَ: ${out[uIdx]} 𝐕𝐒 🤖 رِيـو: ${out[bIdx]}\n💰 لَمْ تَخْسَرْ شَيْئاً.\n━━━━━━━━━━━━━━━━━━\n👑 رِيـو بُـوت - جَرِّبْ مَرَّةً أُخْرَى`;
  }

  // معالجة الصور
  const pathUser = __dirname + `/cache/user_${senderID}.png`;
  const pathBot = __dirname + `/cache/bot_${senderID}.png`;

  try {
    const imgUser = (await axios.get(listIMG[uIdx], { responseType: "arraybuffer" })).data;
    const imgBot = (await axios.get(listIMG[bIdx], { responseType: "arraybuffer" })).data;
    
    fs.writeFileSync(pathUser, Buffer.from(imgUser, "utf-8"));
    fs.writeFileSync(pathBot, Buffer.from(imgBot, "utf-8"));

    const attachments = [fs.createReadStream(pathUser), fs.createReadStream(pathBot)];
    
    return api.sendMessage({ body: msg, attachment: attachments }, threadID, () => {
      if (fs.existsSync(pathUser)) fs.unlinkSync(pathUser);
      if (fs.existsSync(pathBot)) fs.unlinkSync(pathBot);
    }, messageID);
    
  } catch (err) {
    return api.sendMessage(msg, threadID, messageID); // إرسال النص إذا فشلت الصور
  }
};