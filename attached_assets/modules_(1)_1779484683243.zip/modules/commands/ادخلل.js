module.exports.config = {
  name: "ادخل",
  version: "1.0.0",
  hasPermssion: 2, // للمطور عبدو فقط لضمان الخصوصية
  credits: "عبدو / RIO BOOT",
  description: "إدخال مستخدم إلى مجموعة أخرى يتواجد فيها البوت",
  commandCategory: "نظام المطور",
  usages: "[رقم المجموعة] بالرد على الشخص",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, type, messageReply, senderID } = event;

  try {
    // 1. جلب قائمة المجموعات التي يتواجد فيها البوت
    const allThreads = await api.getThreadList(50, null, ["INBOX"]);
    const groupList = allThreads.filter(t => t.isGroup && t.threadID !== threadID);

    // 2. إذا لم يحدد رقم، يعرض القائمة
    if (!args[0]) {
      let msg = "🏰 ┃ مـمـالـك ريـو بـوت الـمـتـاحـة ┃ 🏰\n━━━━━━━━━━━━━━━\n";
      groupList.forEach((group, index) => {
        msg += `[ ${index + 1} ] ┃ ${group.name || "مجموعة بدون اسم"}\n🆔 ┃ ${group.threadID}\n━━━━━━━━━━━━━━━\n`;
      });
      msg += "💡 ┃ لـإدخـال شـخـص: رد عـلـى رسـالـتـه واكـتـب [.ادخـل + رقـم الـمـجـمـوعـة]";
      return api.sendMessage(msg, threadID, messageID);
    }

    // 3. التحقق من الرد على الشخص
    if (type !== "message_reply") {
      return api.sendMessage("⚠️ ┃ يـا سـيـدي عـبـدو، يـجـب أن تـرد عـلـى رسـالـة الـشـخص الـذي تـريـد نـقـلـه.", threadID, messageID);
    }

    const targetID = messageReply.senderID;
    const groupIndex = parseInt(args[0]) - 1;

    if (isNaN(groupIndex) || !groupList[groupIndex]) {
      return api.sendMessage("❌ ┃ رقـم الـمـجـمـوعـة غـيـر صـحيح أو غـير مـوجود فـي الـقائمة.", threadID, messageID);
    }

    const targetGroup = groupList[groupIndex];

    // 4. محاولة إضافة الشخص للمجموعة المختارة
    return api.addUserToGroup(targetID, targetGroup.threadID, (err) => {
      if (err) {
        return api.sendMessage(`⚠️ ┃ لـم أسـتـطـع إضـافـتـه لـ "${targetGroup.name}". لـعـلـه مـغـادر مـسـبـقاً أو أنـنـي لـسـت أدمن هـناك.`, threadID, messageID);
      } else {
        return api.sendMessage(`✅ ┃ تـم سـحـب الـمـسـتـخـدم بـنـجـاح إلـى:\n🏰 ┃ ${targetGroup.name}`, threadID, messageID);
      }
    });

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ ┃ حـدث خـطأ أثـناء مـحـاولة جـلـب الـمـجـموعات.", threadID, messageID);
  }
};
