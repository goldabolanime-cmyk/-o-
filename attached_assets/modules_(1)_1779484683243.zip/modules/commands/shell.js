module.exports.config = {
  name: "shell",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "وصف الأمر هنا",
  commandCategory: "عام",
  usages: "",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args }) => {
  api.sendMessage("تـم تـشـغـيـل الأمـر بـنـجـاح ✅", event.threadID);
};