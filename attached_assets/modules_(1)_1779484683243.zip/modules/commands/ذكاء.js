module.exports.config = {
    name: "ذكاء",
    version: "3.0.0",
    hasPermssion: 0,
    credits: "عبدو / RIO BOOT",
    description: "🤖 أحدث ذكاء اصطناعي مستقر من قناة معلومات مبرمج",
    commandCategory: "الذكاء الاصطناعي",
    usages: ".ذكاء [نصك]",
    cooldowns: 2
};

const axios = require("axios");

module.exports.run = async function ({ api, event, args }) {
    const { threadID, messageID } = event;
    const prompt = args.join(" ");

    if (!prompt) return api.sendMessage("أكتب سؤالك يا عبدو! مثال: .ذكاء من أنت؟", threadID, messageID);

    try {
        // إظهار أن البوت يكتب الآن (Typing) ليعطي طابعاً واقعياً
        api.sendTypingIndicator(threadID);

        // هذا الـ API هو الأكثر تداولاً حالياً في القنوات لسرعته الفائقة
        const res = await axios.get(`https://api.shanti.xyz/gpt4?prompt=${encodeURIComponent(prompt)}`);
        
        // استخراج الإجابة
        const answer = res.data.answer || res.data.result || res.data.response;

        if (!answer) throw new Error("Empty Response");

        const decoratedMsg = `
✨ ━━━━━『 𝐑𝐈𝐎-𝐀𝐈 』━━━━━ ✨

${answer}

✨ ━━━━━━━━━━━━━━━━━━━━ ✨`.trim();

        return api.sendMessage(decoratedMsg, threadID, messageID);

    } catch (e) {
        // في حال تعطل الأول، نستخدم الرابط الاحتياطي (Back-up) مباشرة دون إظهار خطأ
        try {
            const res2 = await axios.get(`https://api.kenliejugarap.com/blackboxai/?text=${encodeURIComponent(prompt)}`);
            const answer2 = res2.data.response;
            return api.sendMessage(`🤖 (إجابة احتياطية):\n\n${answer2}`, threadID, messageID);
        } catch (err) {
            return api.sendMessage("⚠️ | عذراً يا عبدو، يبدو أن هناك ضغط كبير على السيرفرات العالمية حالياً. حاول مجدداً بعد ثوانٍ.", threadID, messageID);
        }
    }
};
