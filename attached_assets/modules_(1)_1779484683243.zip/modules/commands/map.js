const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "خريطة",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "جَـلْبُ مَـعْـلُومَاتِ وَخَـرِيطَةِ أَيِّ دَوْلَةٍ",
  commandCategory: "خدمات",
  usages: "[اسم الدولة]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  let country = args.join(" ");

  if (!country) return api.sendMessage("⚠️ ┃ يُـرْجَى كِـتَابَةُ اِسْـمِ اَلـدَّوْلَةِ لِـلْـبَحْـثِ.", threadID, messageID);

  try {
    // استعمال API بديل وأكثر استقراراً لجلب بيانات الدول
    const res = await axios.get(`https://restcountries.com/v3.1/name/${encodeURIComponent(country)}?fullText=false`);
    const data = res.data[0];

    const name = data.translations.ara ? data.translations.ara.common : data.name.common;
    const capital = data.capital ? data.capital[0] : "غير متوفر";
    const population = (data.population / 1000000).toFixed(1);
    const area = data.area.toLocaleString();
    const region = data.subregion || data.region;
    const currencies = data.currencies ? Object.values(data.currencies)[0].name : "غير متوفر";
    const languages = data.languages ? Object.values(data.languages).join(", ") : "غير متوفر";
    const lat = data.latlng[0];
    const lng = data.latlng[1];
    const timezone = data.timezones[0];

    // جلب الخريطة عبر Yandex Static Maps بوضوح عالٍ
    const mapUrl = `https://static-maps.yandex.ru/1.x/?lang=ar_RU&ll=${lng},${lat}&z=4&l=map&size=600,450`;
    const path = __dirname + `/cache/map_rio.png`;

    const response = await axios({
      method: 'get',
      url: mapUrl,
      responseType: 'stream'
    });

    const writer = fs.createWriteStream(path);
    response.data.pipe(writer);

    writer.on('finish', () => {
      const msg = 
        `●─────── ⌬ ───────●\n` +
        ` ⦿ ⟬ خَـرِيـطَـةُ ${name} 🗺 ⟭ ⦿\n` +
        `┝━━━━━━━━━━━━━━━\n` +
        `┇ 📍 اَلْـمَوْقِـعُ: ${name}\n` +
        `┇ 🌐 خَـطُّ اَلـطُّولِ: ${lng}°\n` +
        `┇ 🧭 خَـطُّ اَلْـعَرْضِ: ${lat}°\n` +
        `┇ 📌 اَلْإِحْـدَاثِيَّـاتُ: ${lat}, ${lng}\n` +
        `┝━━━━━━━━━━━━━━━\n` +
        `┇ 👥 عَدَدُ اَلـسُّكَّـانِ: ${population} مَـلْـيُـون\n` +
        `┇ 🏛 اَلْـعَـاصِـمَةُ: ${capital}\n` +
        `┇ 📐 اَلْـمِـسَـاحَةُ: ${area} كـم²\n` +
        `┇ 🌍 اَلْـمِـنْـطَـقَةُ: ${region}\n` +
        `┇ 💰 اَلْـعُـمْـلَةُ: ${currencies}\n` +
        `┇ 🗣 اَلـلُّـغَـاتُ: ${languages}\n` +
        `┇ ⏰ اَلـtَّـوْقِيـتُ: ${timezone}\n` +
        `●─────── ⌬ ───────●\n\n` +
        `🔱 ┃ بِـوَاسِـطَـةِ: عـبـدو`;

      return api.sendMessage({
        body: msg,
        attachment: fs.createReadStream(path)
      }, threadID, () => {
          if (fs.existsSync(path)) fs.unlinkSync(path);
      }, messageID);
    });

  } catch (err) {
    console.error(err);
    return api.sendMessage("❌ ┃ لَـمْ أَسْـتَطِـعْ إِيـجَـادَ هَـذِهِ اَلـدَّوْلَةِ، تَـأَكَّـدْ مِـنَ اَلْإِسْـمِ.", threadID, messageID);
  }
};