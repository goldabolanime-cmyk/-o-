const axios = require("axios");
const fs = require("fs-extra");
const request = require("request");

module.exports.config = {
  name: "خلفيات",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "جَـلْبُ خَـلْفِيَّاتٍ مَـلَـكِيَّةٍ حَـسَبَ اَلـصِّنْـفِ",
  commandCategory: "صور",
  usages: "[اختر من القائمة]",
  cooldowns: 10
};

module.exports.run = async function({ api, event, args }) {
    const { threadID, messageID, senderID } = event;

    // قائمة الأصناف المزخرفة
    const listMsg = 
      `┏━━━━━━━━━━━━━━━━━━━━┓\n` +
      `   ♛ 𝑹𝑰𝑶 𝑾𝑨𝑳𝑳𝑷𝑨𝑷𝑬𝑹𝑺 ♛\n` +
      `┗━━━━━━━━━━━━━━━━━━━━┛\n\n` +
      `✨ ┃ اِخْـتَـرْ نَـوْعَ اَلْـخَـلْفِيَّـةِ:\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `1 ┃ هَـاتِـف (Phone Wallpapers)\n` +
      `2 ┃ كُـومْـبِيُـوتَر (PC Wallpapers)\n` +
      `3 ┃ عَـشْـوَائِي (Random Mix)\n` +
      `4 ┃ أَنْـمِي (Anime Art)\n` +
      `5 ┃ مَـانْـجَـا (Manga Aesthetic)\n` +
      `6 ┃ رُعْـب (Horror Backgrounds)\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `💡 ┃ رُدَّ عَـلَى اَلـرِّسَـالَـةِ بِـالـرَّقْـمِ اَلْـمُـنَـاسِبِ\n` +
      `🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;

    return api.sendMessage(listMsg, threadID, (err, info) => {
        global.client.handleReply.push({
            name: this.config.name,
            messageID: info.messageID,
            author: senderID
        });
    }, messageID);
};

module.exports.handleReply = async function({ api, event, handleReply }) {
    const { threadID, messageID, body, senderID } = event;
    if (handleReply.author !== senderID) return;

    const types = {
        "1": "Phone Wallpapers 4k Aesthetic",
        "2": "PC Wallpapers 4k Ultra HD",
        "3": "Aesthetic Random Wallpapers",
        "4": "Anime Wallpapers HD",
        "5": "Manga Wallpapers Aesthetic",
        "6": "Horror Dark Backgrounds HD"
    };

    const query = types[body];
    if (!query) return api.sendMessage("⚠️ ┃ رُدَّ بِـرَقْـمٍ صَـحِيحٍ مِـنَ اَلْـقَائِـمَةِ (1-6).", threadID, messageID);

    api.unsendMessage(handleReply.messageID);
    api.sendMessage(`⏳ ┃ جَـارِي جَـلْبُ 4 خَـلْفِيَّاتٍ مَـلَـكِيَّةٍ لِـصِنْـفِ 『 ${body} 』...`, threadID, messageID);

    try {
        const headers = {
            'authority': 'www.pinterest.com',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            'cookie': 'csrftoken=92c7c57416496066c4cd5a47a2448e28; _auth=1;'
        };

        const options = {
            url: `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(query)}&rs=typed`,
            headers: headers
        };

        request(options, async function(error, response, html) {
            if (error || response.statusCode !== 200) return api.sendMessage("❌ ┃ خَـطَأٌ فِـي اَلْإِتِّـصَالِ بِمَـصْدَرِ اَلـصُّـوَرِ.", threadID, messageID);

            const arrMatch = html.match(/https:\/\/i\.pinimg\.com\/originals\/[^.]+\.jpg/g);
            if (!arrMatch || arrMatch.length < 4) return api.sendMessage("❌ ┃ لَـمْ أَجِـدْ نَـتَـائِجَ كَـافِيَـةً.", threadID, messageID);

            // ميزة التنوع: اختيار 4 صور عشوائية من أول 50 نتيجة لضمان عدم التكرار
            const shuffled = arrMatch.slice(0, 50).sort(() => 0.5 - Math.random());
            const selected = shuffled.slice(0, 4);

            const attachments = [];
            for (let i = 0; i < selected.length; i++) {
                const path = __dirname + `/cache/wall_${i}.jpg`;
                const res = await axios.get(selected[i], { responseType: "arraybuffer" });
                fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));
                attachments.push(fs.createReadStream(path));
            }

            api.sendMessage({
                body: `┏━━━━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑾𝑨𝑳𝑳𝑷𝑨𝑷𝑬𝑹𝑺 ♛\n┗━━━━━━━━━━━━━━━━━━━━┛\n\n✅ ┃ تَـمَّ جَـلْبُ اَلـصُّـوَرِ بِنَجَاحٍ\n✨ ┃ اَلـنَّـوْعُ: 『 ${query.split(' ')[0]} 』\n\n🔱 ┃ اَلْـمُطَـوِّرُ: عـبـدو`,
                attachment: attachments
            }, threadID, () => {
                for (let i = 0; i < 4; i++) {
                    const path = __dirname + `/cache/wall_${i}.jpg`;
                    if (fs.existsSync(path)) fs.unlinkSync(path);
                }
            }, messageID);
        });

    } catch (e) {
        console.error(e);
        api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ غَـيْرُ مَـتَوَقَّـعٍ.", threadID, messageID);
    }
};
