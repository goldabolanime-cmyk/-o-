module.exports.config = {
  name: "طلبات",
  version: "2.7.0",
  hasPermssion: 1,
  credits: "عبدو / RIO BOT",
  description: "إدارة طلبات الصداقة والمجموعات (متوافق مع الإصدارات القديمة)",
  commandCategory: "نظام",
  usages: "[صداقة / مجموعة]",
  cooldowns: 5
};

module.exports.handleReply = async function ({ api, event, handleReply, Users }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID != handleReply.author) return;

  const args = body.trim().split(/\s+/);
  const action = args[0].toLowerCase(); 
  const index = parseInt(args[1]) - 1;
  const requests = handleReply.list;

  // --- معالجة طلبات الصداقة ---
  if (handleReply.type === "friend_requests") {
    if (action === "الكل") {
      api.sendMessage("⏳ ┃ جَـارِي قَـبُولُ اَلْـكُلِّ يَا سَـيِّـدِي عـبـدو . . .", threadID);
      for (let req of requests) {
        await new Promise(res => api.handleFriendRequest(req.userID, true, () => res()));
        await new Promise(res => setTimeout(res, 1500)); // تأخير للأمان
      }
      return api.sendMessage("✅ ┃ تَمَّ قَـبُولُ جَمِيـعِ اَلـطَّلَبَاتِ بِنَـجَـاحٍ!", threadID);
    }

    const target = requests[index];
    if (!target) return api.sendMessage("⚠️ ┃ اَلـرَّقْـمُ غَـيْـرُ مَـوْجُـودٍ.", threadID, messageID);

    const isAccept = (action === "قبول" || action === "أقبل" || action === "اقبل");
    
    api.handleFriendRequest(target.userID, isAccept, (err) => {
      if (err) return api.sendMessage(`❌ ┃ حَـدَثَ خَـطَأٌ: ${err.errorDescription || "فشل الإجراء"}`, threadID, messageID);
      return api.sendMessage(`✨ ┃ تَمَّ ${isAccept ? "قَـبُولُ" : "رَفْـضُ"} طَـلَبِ: ${target.name}`, threadID, messageID);
    });
  }

  // --- معالجة طلبات المجموعة ---
  if (handleReply.type === "group_requests") {
    const target = requests[index];
    if (!target) return api.sendMessage("⚠️ ┃ اَلـرَّقْـمُ غَـيْـرُ مَـوْجُـودٍ.", threadID, messageID);

    const isAccept = (action === "قبول" || action === "أقبل" || action === "اقبل");

    api.handleGroupJoinRequest(target.userID, threadID, isAccept, (err) => {
      if (err) return api.sendMessage("❌ ┃ فَـشَـلَ اَلْإِجْـرَاءُ، تَأَكَّدْ أَنَّ اَلْـبُـوتَ مَـسْـؤُولٌ.", threadID, messageID);
      return api.sendMessage(`✅ ┃ تَمَّ ${isAccept ? "قَـبُولُ" : "رَفْـضُ"} اَلْـعُضْـوِ بِنَـجَـاحٍ.`, threadID, messageID);
    });
  }
};

module.exports.run = async function ({ api, event, args, Users }) {
  const { threadID, messageID, senderID } = event;

  if (args[0] === "صداقة") {
    api.getFriendRequests(async (err, list) => {
      if (err) return api.sendMessage("❌ ┃ لَا يُـمْـكِنُ جَـلْبُ اَلـطَّلَبَاتِ حَـالِيـاً.", threadID, messageID);
      if (!list || list.length === 0) return api.sendMessage("📭 ┃ لَا تُـوجَـدُ طَـلَبَاتُ صَـدَاقَـةٍ.", threadID, messageID);

      api.sendMessage("⏳ ┃ جَـارِي جَـلْبُ أَسْـمَـاءِ اَلْأَصْـدِقَـاءِ . . .", threadID);

      let detailedList = [];
      let msg = "⚜️ ┃ طَـلَبَاتُ اَلـصَّدَاقَـةِ اَلْـوَارِدَةِ ┃ ⚜️\n━━━━━━━━━━━━━━━━━━\n";

      for (let i = 0; i < list.length; i++) {
        let name = "مستخدم فيسبوك";
        try {
          const info = await api.getUserInfo(list[i].userID);
          name = info[list[i].userID].name;
        } catch (e) { name = list[i].name || "بدون اسم"; }
        
        detailedList.push({ name, userID: list[i].userID });
        msg += `[ ${i + 1} ] ❯ ${name}\n🆔 ❯ ${list[i].userID}\n\n`;
      }

      msg += "━━━━━━━━━━━━━━━━━━\n💡 ┃ رُد بـ: (قبول/رفض + الرقم)";
      
      return api.sendMessage(msg, threadID, (err, info) => {
        global.client.handleReply.push({
          name: this.config.name,
          messageID: info.messageID,
          author: senderID,
          list: detailedList,
          type: "friend_requests"
        });
      }, messageID);
    });
  }

  else if (args[0] === "مجموعة") {
    api.getThreadInfo(threadID, async (err, info) => {
      if (err) return api.sendMessage("❌ ┃ فَـشَـلَ جَـلْبُ بَيَـانَاتِ اَلْـمَـجْـمُوعَـةِ.", threadID, messageID);
      
      const requests = info.approvalQueue || [];
      if (requests.length === 0) return api.sendMessage("📭 ┃ لَا تُـوجَـدُ طَـلَبَاتُ اِنْـضِمَـامٍ.", threadID, messageID);

      let msg = "🏢 ┃ طَـلَبَاتُ اِنْـضِمَـامِ اَلْـمَـجْـمُوعَـةِ ┃ 🏢\n━━━━━━━━━━━━━━━━━━\n";
      let detailedGroupList = [];

      for (let i = 0; i < requests.length; i++) {
        let name = "مستخدم جديد";
        try {
          const uInfo = await api.getUserInfo(requests[i].userID);
          name = uInfo[requests[i].userID].name;
        } catch (e) {}
        
        detailedGroupList.push({ name, userID: requests[i].userID });
        msg += `[ ${i + 1} ] ❯ ${name}\n🆔 ❯ ${requests[i].userID}\n\n`;
      }

      msg += "━━━━━━━━━━━━━━━━━━\n💡 ┃ رُد بـ: (قبول/رفض + الرقم)";

      return api.sendMessage(msg, threadID, (err, infoMsg) => {
        global.client.handleReply.push({
          name: this.config.name,
          messageID: infoMsg.messageID,
          author: senderID,
          list: detailedGroupList,
          type: "group_requests"
        });
      }, messageID);
    });
  }
  else {
    return api.sendMessage("❓ ┃ سَـيِّـدِي عـبـدو، حَـدِّدِ اَلـنَّـوْعَ:\n\n1️⃣ .طلبات صداقة\n2️⃣ .طلبات مجموعة", threadID, messageID);
  }
};