module.exports.config = {
  name: "تصنيف",
  version: "2.2.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "عَـرْضُ قَـائِمَةِ اَلْأَعْـضَاءِ اَلـنَّشَاطِيـنَ (حَتَّى لَوْ شَخْصٌ وَاحِدٌ)",
  commandCategory: "نظام",
  usages: "",
  cooldowns: 5,
  aliases: ["النشاط", "نشاط"]
};

module.exports.run = async function ({ api, event, Currencies }) {
  const { threadID, messageID } = event;

  try {
    // 1. جلب بيانات كل المستخدمين وتصفية أعضاء المجموعة
    const allUsers = await Currencies.getAll();
    const threadInfo = await api.getThreadInfo(threadID);
    const participantIDs = threadInfo.participantIDs;

    let activeMembers = [];

    for (let user of allUsers) {
      if (participantIDs.includes(user.userID)) {
        // نأخذ أي مستخدم موجود في المجموعة، حتى لو نشاطه 0 لكي تظهر القائمة دائماً
        const userExp = user.data.exp || 0;
        activeMembers.push({
          id: user.userID,
          exp: userExp
        });
      }
    }

    // 2. الترتيب من الأكثر نشاطاً
    activeMembers.sort((a, b) => b.exp - a.exp);

    // 3. أخذ التوب 10 (سيشتغل الكود حتى لو كان هناك شخص واحد فقط)
    const topLimit = activeMembers.slice(0, 10);

    // 4. بناء الرسالة الملكية
    let msg = `┏━━━━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑨𝑪𝑻𝑰𝑽𝑰𝑻𝒀 𝑹𝑨𝑵𝑲 ♛\n┗━━━━━━━━━━━━━━━━━━━━┛\n\n`;

    for (let i = 0; i < topLimit.length; i++) {
      const userInfo = await api.getUserInfo(topLimit[i].id);
      const name = userInfo[topLimit[i].id].name;
      const exp = topLimit[i].exp;

      let rankIcon = "";
      if (i === 0) rankIcon = "🥇 ┃ اَلْـقَـائِـدُ:";
      else if (i === 1) rankIcon = "🥈 ┃ اَلْـوَزِيـرُ:";
      else if (i === 2) rankIcon = "🥉 ┃ اَلْـفَـارِسُ:";
      else rankIcon = `【 ${i + 1} 】-`;

      msg += `${rankIcon} 『 ${name} 』\n✨ ┃ اَلـرَّسَـائِـلُ: [ ${exp} ]\n`;
      
      if (i < topLimit.length - 1) msg += `┈┈┈┈┈┈┈┈┈┈┈┈┈\n`;
    }

    msg += `\n━━━━━━━━━━━━━━━\n🔱 ┃ اَلْـمُطَـوِّرُ: عـبـدو\n[•] رِيُـو بُـوتْ - نِـظَـامُ اَلْإِحْـصَـائِيَّـات`;

    return api.sendMessage(msg, threadID, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ أَثْـنَاءَ جَـلْبِ اَلـتَّصْنِيـفِ اَلْـمَلَكِيِّ.", threadID, messageID);
  }
};