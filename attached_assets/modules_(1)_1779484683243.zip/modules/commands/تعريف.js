const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "تعريف",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "عرض بطاقة تعريف ريو بوت بالزخرفة الملكية السوداء",
  commandCategory: "نظام",
  usages: "تعريف",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, Users }) {
  const { threadID, messageID } = event;
  const botID = api.getCurrentUserID();
  const adminID = "100090081489341"; 

  try {
    const botInfo = await Users.getData(botID);
    const prefix = global.config.PREFIX || ".";

    // جلب صورة البروفايل
    const pathImg = __dirname + `/cache/bot_profile.png`;
    const avatarUrl = `https://graph.facebook.com/${botID}/picture?width=720&height=720&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
    const getAvatar = (await axios.get(avatarUrl, { responseType: "arraybuffer" })).data;
    fs.writeFileSync(pathImg, Buffer.from(getAvatar, "binary"));

    const msg = `╔════════════════════╗\n` +
                `   ☆  هَـوِيَّـةُ اَلـرِّيـو اَلْـمَـلَـكِيَّـةِ  ☆\n` +
                `╚════════════════════╝\n\n` +
                `‹ اِسْـمُ اَلـنِّـظَـامِ › :: رِيُـو\n` +
                `‹ لُـغَـةُ اَلـبِـنَـاءِ › :: جَـافَـا سْـكْرِيـبْت\n` +
                `‹ رَمْـزُ اَلـبَـادِئَـةِ › :: [ ${prefix} ]\n` +
                `‹ اَلْـعُـمْرُ اَلـذَّهَـبِيُّ › :: 13 عَـامـاً\n\n` +
                `◈━━━━━━━━━━━━━━◈\n\n` +
                `‹ مَـوطِـنُ اَلـبُـوتِ › :: اَلْـمَـغْرِبُ ☆\n` +
                `‹ سَـيِّـدُ اَلـنِّـظَـامِ › :: عَـبْـدُو\n\n` +
                `◈━━━━━━━━━━━━━━◈\n\n` +
                `‹ رَابِـطُ اَلْـحِـسَابِ › ::\n` +
                `fb.com/${botID}\n\n` +
                `‹ رَابِـطُ اَلْـمُـطَـوِّرِ › ::\n` +
                `fb.com/${adminID}\n\n` +
                `◈━━━━━━━━━━━━━━◈\n\n` +
                `☆ لِلـتَّـواصُـلِ اِسْـتَـخْدِمْ [ ${prefix}ابلاغ ]\n` +
                `  جَـمِيـعُ اَلْـحُـقُـوقِ مَـحْـفُوظَـةٌ 2026`;

    return api.sendMessage({
      body: msg,
      attachment: fs.createReadStream(pathImg)
    }, threadID, () => {
      if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("☆ حَـدَثَ خَـطَأٌ فِـي عَـرْضِ اَلْـهَـوِيَّـةِ.", threadID, messageID);
  }
};