module.exports.config = {
  name: "سكرين",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "فحص أمان المواقع والحصول على لقطة شاشة احترافية",
  commandCategory: "خدمات",
  cooldowns: 5,
  dependencies: {
      "fs-extra": "",
      "path": "",
      "axios": ""
  }
};

module.exports.onLoad = async () => {
  const fs = require("fs-extra");
  const path = require("path");
  const cachePath = path.resolve(__dirname, "cache", "pornlist.txt");

  if (!fs.existsSync(path.resolve(__dirname, "cache"))) fs.mkdirSync(path.resolve(__dirname, "cache"));

  if (!fs.existsSync(cachePath)) {
    try {
      const axios = require("axios");
      const res = await axios.get("https://raw.githubusercontent.com/blocklistproject/Lists/master/porn.txt");
      fs.writeFileSync(cachePath, res.data);
    } catch (e) {
      console.log("⚠️ فشل تحميل قائمة المواقع المحظورة");
    }
  }
};

module.exports.run = async ({ event, api, args }) => {
  const fs = require("fs-extra");
  const axios = require("axios");
  const { threadID, messageID } = event;
  const urlArg = args[0];

  if (!urlArg) return api.sendMessage("⚠️ ┃ يرجى إدخال رابط الموقع المراد فحصه.\nمثال: سكرين google.com", threadID, messageID);

  // تنسيق الرابط للتأكد من صحته
  let fullUrl = urlArg;
  if (!urlArg.startsWith("http")) fullUrl = "https://" + urlArg;

  try {
    const hostName = new URL(fullUrl).hostname;
    const pornListPath = __dirname + "/cache/pornlist.txt";

    if (fs.existsSync(pornListPath)) {
      const pornList = fs.readFileSync(pornListPath, "utf-8");
      if (pornList.includes(hostName)) {
        return api.sendMessage(`🚫 ﴿ تَـحْـذِيـرٌ أَمْـنِـيٌّ ﴾ 🚫\n━━━━━━━━━━━━━━━━━━\n⚠️ الـموقع: ${hostName}\n❌ الـحالة: غـيـر آمـن (محتوى محظور)\n━━━━━━━━━━━━━━━━━━\n👑 رِيـو بُـوت - حِـمَـايَـتُـكَ أَوْلَـوِيَّـتُـنَا`, threadID, messageID);
      }
    }

    api.sendMessage("⏳ ┃ جـاري فـحـص الـموقع والـتـقاط الـصورة، انـتـظر لـحظة...", threadID, messageID);

    const pathImg = __dirname + `/cache/screen-${threadID}.png`;
    const screenshotUrl = `https://image.thum.io/get/width/1920/crop/400/fullpage/noanimate/${fullUrl}`;
    
    const response = await axios.get(screenshotUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(pathImg, Buffer.from(response.data, "binary"));

    const msg = `✨ ﴿ مَـعْـلُـومَاتُ الـمَـوْقِـعِ ﴾ ✨\n━━━━━━━━━━━━━━━━━━\n🌐 الـرابط: ${hostName}\n✅ الـحالة: آمـن لـلـتصفح\n📸 الـمعاينة: مـرفـقة أدناه\n━━━━━━━━━━━━━━━━━━\n👑 رِيـو بُـوت - خِـدْمَـةٌ سَـرِيـعَةٌ`;

    return api.sendMessage({ body: msg, attachment: fs.createReadStream(pathImg) }, threadID, () => fs.unlinkSync(pathImg), messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ عـذراً! لـم أتـمكـن من الـتعرف على الـموقع. تأكد من صـحة الـرابط.", threadID, messageID);
  }
};