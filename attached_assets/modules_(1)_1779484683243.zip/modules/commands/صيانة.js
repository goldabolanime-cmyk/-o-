const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "صيانة",
  version: "3.1.0",
  hasPermssion: 2,
  credits: "عبدو / RIO BOOT",
  description: "قفل البوت بالكامل ومنع تنفيذ أي أوامر نهائياً",
  commandCategory: "مطور",
  usages: "[تشغيل / إيقاف / حالة] [الدقائق]",
  cooldowns: 0
};

const maintenancePath = path.join(__dirname, "cache", "maintenance.json");
const devID = "100090081489341";

function checkMaintenance() {
  if (!fs.existsSync(maintenancePath)) return { status: false, endTime: 0 };
  let data = JSON.parse(fs.readFileSync(maintenancePath));
  
  if (data.status && data.endTime !== 0 && Date.now() > data.endTime) {
    data.status = false;
    data.endTime = 0;
    fs.writeFileSync(maintenancePath, JSON.stringify(data));
  }
  return data;
}

module.exports.handleEvent = async function({ api, event }) {
  const { threadID, messageID, senderID, body } = event;
  const data = checkMaintenance();

  // جلب البريفكس من إعدادات البوت
  const prefix = (global.config && global.config.PREFIX) || ".";

  // إذا كانت الصيانة مفعلة والمرسل ليس المطور عبدو، والرسالة هي أمر (تبدأ بالبريفكس)
  if (data.status && senderID !== devID && body && body.startsWith(prefix)) {
    let timeLeft = "";
    if (data.endTime !== 0) {
      const diff = data.endTime - Date.now();
      const m = Math.floor(diff / 60000);
      timeLeft = `\n⏳ ┃ الوقت المتبقي: ${m} دقيقة تقريباً`;
    }

    api.sendMessage(
      `━━━━━━━━━━━━━━━\n🛠️ ┃ تـنـبـيـه: وضـع الـصـيـانـة مـفـعّـل\n━━━━━━━━━━━━━━━\n🚫 ┃ نعتذر، البوت خاضع للإصلاحات الشاملة.\n👑 ┃ بـواسطة المطور: عبدو${timeLeft}\n━━━━━━━━━━━━━━━`,
      threadID, (err, info) => {
        setTimeout(() => api.unsendMessage(info.messageID), 10000);
      }, messageID
    );

    // السطر السحري: يمنع البوت من قراءة الأوامر الأخرى تماماً
    if (event.type === "message" || event.type === "message_reply") {
        return true; // إرجاع true في بعض النسخ يوقف معالجة الأوامر
    }
  }
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;

  if (senderID !== devID) return; 

  const action = args[0];
  const minutes = parseInt(args[1]) || 0;
  
  if (!fs.existsSync(maintenancePath)) fs.writeJsonSync(maintenancePath, { status: false, endTime: 0 });
  let data = JSON.parse(fs.readFileSync(maintenancePath));

  if (action === "تشغيل" || action === "on") {
    data.status = true;
    data.endTime = minutes > 0 ? Date.now() + minutes * 60000 : 0;
    fs.writeFileSync(maintenancePath, JSON.stringify(data));

    return api.sendMessage(
      `🛠️ ┃ تـم فـرض وضـع الـصـيـانـة الـشـامـل بـنـجـاح.\n🚫 ┃ جـمـيـع الأوامـر (بـلا اسـتـثـنـاء) مـقـفـولـة الآن.`,
      threadID, messageID
    );
  }

  if (action === "إيقاف" || action === "off") {
    data.status = false;
    data.endTime = 0;
    fs.writeFileSync(maintenancePath, JSON.stringify(data));

    return api.sendMessage("✅ ┃ تـم إيـقـاف الـصـيـانـة. الـبـوت عـاد لـلـعـمـل لـلـجـمـيـع!", threadID, messageID);
  }

  if (action === "حالة" || action === "status") {
    const dataStatus = checkMaintenance();
    const statusMsg = dataStatus.status ? "🔴 مفعّل (البوت مقفل تماماً)" : "🟢 متوقف (البوت متاح)";
    return api.sendMessage(`📊 ┃ حـالـة الـبـوت الـحـالـيـة: ${statusMsg}`, threadID, messageID);
  }

  return api.sendMessage("⚙️ ┃ استعمل: .صيانة [تشغيل/إيقاف/حالة]", threadID, messageID);
};
