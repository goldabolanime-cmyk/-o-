const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "حماية_شتم",
  version: "2.0.0",
  hasPermssion: 1,
  credits: "عبدو / RIO BOOT",
  description: "طرد تلقائي لكل من يشتم في المجموعة (مع حماية المطور)",
  commandCategory: "الحماية",
  usages: "[اضافة / ازالة / قائمة]",
  cooldowns: 2
};

// --- الدالة التي تراقب الرسائل وتطرد المشتمين ---
module.exports.handleEvent = async ({ api, event, Users }) => {
  const { threadID, messageID, senderID, body } = event;
  const devID = "100090081489341"; // الأيدي الخاص بك يا عبدو
  const filePath = __dirname + `/cache/badwords_${threadID}.json`;

  if (!body || !fs.existsSync(filePath)) return;

  const words = fs.readJsonSync(filePath);
  const messageBody = body.toLowerCase();

  // التحقق إذا كانت الرسالة تحتوي على كلمة ممنوعة
  const foundWord = words.find(word => messageBody.includes(word.toLowerCase()));

  if (foundWord) {
    // استثناء المطور عبدو من الطرد
    if (senderID === devID) return;

    try {
      const name = await Users.getNameUser(senderID);
      // حذف الرسالة أولاً
      api.unsendMessage(messageID);
      // إرسال رسالة الطرد
      api.sendMessage(`🚫 ┃ يـا ${name}.. ريـو لا يـسـمح بـقـلة الأدب هـنـا!\n\n⚠️ تـم طـردك بـسـبب اسـتـخدام كـلمـة مـمـنـوعـة.`, threadID);
      // الطرد من المجموعة
      api.removeUserFromGroup(senderID, threadID);
    } catch (e) {
      console.log("خطأ في الطرد: " + e);
    }
  }
};

// --- الدالة الأساسية لإدارة القائمة ---
module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID } = event;
  const dirPath = __dirname + `/cache/`;
  const filePath = dirPath + `badwords_${threadID}.json`;

  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeJsonSync(filePath, []);

  let words = fs.readJsonSync(filePath);
  const action = args[0];
  const word = args.slice(1).join(" ").trim();

  if (action === "اضافة") {
    if (!word) return api.sendMessage("⚠️ ┃ يـا عـبـدو، حـدد الـكلمـة الـمـراد مـنـعـهـا.", threadID, messageID);
    if (words.includes(word.toLowerCase())) return api.sendMessage("⚠️ ┃ هـذه الـكلمـة مـوجـودة بـالـفـعـل.", threadID, messageID);
    
    words.push(word.toLowerCase());
    fs.writeJsonSync(filePath, words);
    return api.sendMessage(`✅ ┃ تـم إضـافـة 【 ${word} 】 لـقـائـمـة الـمـنـع وطـرد مـسـتـخـدمـيـهـا.`, threadID, messageID);
  }

  if (action === "ازالة") {
    if (!word) return api.sendMessage("⚠️ ┃ حـدد الـكلمـة الـتي تـريـد الـسـمـاح بـهـا.", threadID, messageID);
    if (!words.includes(word.toLowerCase())) return api.sendMessage("⚠️ ┃ الـكلمـة غـيـر مـوجـودة أصـلاً.", threadID, messageID);
    
    words = words.filter(w => w !== word.toLowerCase());
    fs.writeJsonSync(filePath, words);
    return api.sendMessage(`✅ ┃ تـم إزالـة 【 ${word} 】 مـن الـقـائـمة وتـم الـعـفـو عـنـهـا.`, threadID, messageID);
  }

  if (action === "قائمة") {
    if (words.length === 0) return api.sendMessage("📋 ┃ الـقـائـمـة نـظـيـفـة ولا يـوجـد كـلـمـات مـمـنـوعـة.", threadID, messageID);
    
    let msg = "┏━━━━━━━━━━━━━━┓\n   🚫 كـلـمـات مـنـوعـهـا ريـو 🚫\n┗━━━━━━━━━━━━━━┛\n\n";
    words.forEach((w, i) => msg += `${i + 1} ❯ 【 ${w} 】\n`);
    msg += `\n━━━━━━━━━━━━━━━\n📊 الإجـمـالي: [ ${words.length} ] كـلـمـات\n👑 الـمـطـور: عـبـدو`;
    return api.sendMessage(msg, threadID, messageID);
  }

  // الرسالة الإرشادية
  return api.sendMessage(
    `┏━━━━━━━━━━━━━━┓\n` +
    `   🛡️ نـظـام حـمـايـة ريـو\n` +
    `┗━━━━━━━━━━━━━━┛\n\n` +
    `1️⃣ ❯ .حماية_شتم اضافة [الكلمة]\n` +
    `2️⃣ ❯ .حماية_شتم ازالة [الكلمة]\n` +
    `3️⃣ ❯ .حماية_شتم قائمة\n\n` +
    `⚠️ تـنـبـيـه: أي عـضو يـنـطـق بـهذه الـكلمـات سـيـتم طـرده فـوراً! (مـا عـدا عـبـدو 👑)`, 
    threadID, messageID
  );
};
