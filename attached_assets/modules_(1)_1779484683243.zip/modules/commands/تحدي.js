const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "تحدي",
  version: "3.1.2",
  hasPermssion: 0,
  credits: "عبدو",
  description: "تحدي بين شخصين بمنشن",
  commandCategory: "العاب",
  usages: "[@منشن]",
  cooldowns: 5
};

module.exports.run = async function ({ event, api }) {    
  const { threadID, messageID, senderID, mentions } = event;
  const mention = Object.keys(mentions);
  if (mention.length === 0) return api.sendMessage("⚠️ | يـرجى عـمل تـاغ لـلشخص الـذي تـريد تـحديـه!", threadID, messageID);
  
  const one = senderID, two = mention[0];
  const cacheDir = path.join(__dirname, "cache", "canvas");
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
  
  const pathImg = path.join(cacheDir, `challenge_${one}_${two}.png`);
  
  api.sendMessage("⏳ | جـاري تـجـهيز الـتحدي...", threadID, messageID);

  try {
    const jimp = require("jimp");
    const [bg, avt1, avt2] = await Promise.all([
      jimp.read("https://i.imgur.com/bAsnmmD.jpg"),
      jimp.read(`https://graph.facebook.com/${one}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`),
      jimp.read(`https://graph.facebook.com/${two}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`)
    ]);

    avt1.circle().resize(200, 200);
    avt2.circle().resize(200, 200);
    
    bg.composite(avt1, 30, 20).composite(avt2, 255, 255);
    
    const buffer = await bg.getBufferAsync(jimp.MIME_PNG);
    fs.writeFileSync(pathImg, buffer);

    return api.sendMessage({ body: "🥊 | تـم تـجهيـز الـتحدي!", attachment: fs.createReadStream(pathImg) }, threadID, () => {
      if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
    }, messageID);
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ حدث خطأ أثناء معالجة الصور.", threadID, messageID);
  }
};