module.exports.config = {
  name: "هدية",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "عبدو & Gemini",
  description: "الحصول على هدية مالية عشوائية بين 100 و 1500 كل 24 ساعة",
  commandCategory: "الاقتصاد",
  usages: "",
  cooldowns: 5
};

if (!global.rio_gift) global.rio_gift = new Map();

module.exports.run = async function ({ api, event, Currencies, Users }) {
  const { threadID, messageID, senderID } = event;
  const cooldownTime = 24 * 60 * 60 * 1000; 
  const userLastGift = global.rio_gift.get(senderID);

  if (userLastGift && (Date.now() - userLastGift < cooldownTime)) {
    const remaining = cooldownTime - (Date.now() - userLastGift);
    const hours = Math.floor(remaining / (60 * 60 * 1000));
    const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
    
    return api.sendMessage(`⏳ ┃ تَمَهَّلْ قَلِيلاً:\n━━━━━━━━━━━━━━━\nلَقَدْ حَصَلْتَ عَلَى هَدِيَّتِكَ بِالْفِعْلِ.\nعُدْ بَعْدَ: [ ${hours} سَاعَة و ${minutes} دَقِيقَة ] لِتَجْرِبَةِ حَظِّكَ مُجَدَّداً.`, threadID, messageID);
  }

  // --- توليد مبلغ عشوائي بين 100 و 1500 ---
  const min = 100;
  const max = 1500;
  const randomAmount = Math.floor(Math.random() * (max - min + 1)) + min;

  try {
    const userData = await Users.getData(senderID);
    const userName = userData ? userData.name : "المستخدم";

    // تحديث الرصيد
    await Currencies.increaseMoney(senderID, randomAmount);
    
    // حفظ وقت الاستخدام الحالي
    global.rio_gift.set(senderID, Date.now());

    const msg = `🎁 ┃ هَدِيَّـةُ رِيـو الْمَلَكِيَّـة\n━━━━━━━━━━━━━━━\nمُبَارَكٌ لَكَ يَا [ ${userName} ]\nلَقَدْ حَالَفَكَ الْحَظُّ الْيَوْمَ.\n\n💸 ┃ الْمَبْلَغُ: [ ${randomAmount} $ ]\n💰 ┃ تَمَّتْ إِضَافَتُهَا لِحِسَابِكَ.\n━━━━━━━━━━━━━━━\n🦾 ┃ سـيـدك: عـبـدو`;

    return api.sendMessage(msg, threadID, messageID);

  } catch (error) {
    console.error(error);
    return api.sendMessage("⚠️ ┃ حَدَثَ خَلَلٌ فِي بْرُوتُوكُولِ الْهَدَايَا، حَاوِلْ لاَحِقاً.", threadID, messageID);
  }
};