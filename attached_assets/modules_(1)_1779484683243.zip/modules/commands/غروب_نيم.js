module.exports.config = {
  name: "غروب_نيم",
  version: "1.0.0",
  hasPermssion: 1, // 1 تعني أدمن المجموعة + مطور البوت
  credits: "RIO BOOT",
  description: "تغيير اسم المجموعة للأدمن والمطور فقط",
  commandCategory: "إدارة المجموعات",
  usages: "[الاسم الجديد]",
  cooldowns: 3
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const newName = args.join(" ");

  // التأكد من أن المستخدم كتب اسماً جديداً
  if (!newName) {
    return api.sendMessage("خطأ: يرجى كتابة الاسم الجديد بعد الأمر\nمثال: .غروب_نيم اسم المجموعة الجديد", threadID, messageID);
  }

  // تنفيذ عملية تغيير الاسم
  return api.setTitle(newName, threadID, (err) => {
    if (err) {
      return api.sendMessage("حدث خطأ: تأكد من أن البوت لديه صلاحية أدمن في المجموعة", threadID, messageID);
    } else {
      return api.sendMessage(`تم تغيير اسم المجموعة بنجاح إلى: ${newName}`, threadID, messageID);
    }
  });
};
