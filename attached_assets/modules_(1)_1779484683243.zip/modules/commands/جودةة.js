const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "جودةة",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "ريو بوت",
  description: "رفع جودة الصور إلى 4K باستخدام الذكاء الاصطناعي ✨",
  commandCategory: "أدوات الصور",
  usages: "[رد على صورة]",
  cooldowns: 10
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, type, messageReply } = event;

  // التحقق من وجود صورة (سواء بالرد أو في الرسالة نفسها)
  let imageUrl;
  if (type === "message_reply" && messageReply.attachments[0]?.type === "photo") {
    imageUrl = messageReply.attachments[0].url;
  } else if (event.attachments[0]?.type === "photo") {
    imageUrl = event.attachments[0].url;
  } else {
    return api.sendMessage("📸 | يـرجى الـرد عـلى الـصورة الـتي تـريد رفـع جـودتها!", threadID, messageID);
  }

  try {
    api.sendMessage("⏳ | جـارٍ مـعالجة الـصورة وتـحويلها إلـى 4K.. انـتظر لـحظة", threadID, messageID);

    // استخدام واجهة برمجة تطبيقات لمعالجة الصور بالذكاء الاصطناعي
    // ملاحظة: هذا الرابط يستخدم سيرفر معالجة خارجي قوي
    const res = await axios.get(`https://smike-01.up.railway.app/remini?url=${encodeURIComponent(imageUrl)}`, {
      responseType: "arraybuffer"
    });

    const cachePath = path.join(__dirname, "cache", `upscale_${Date.now()}.png`);
    if (!fs.existsSync(path.join(__dirname, "cache"))) fs.mkdirSync(path.join(__dirname, "cache"));

    fs.writeFileSync(cachePath, Buffer.from(res.data, "utf-8"));

    return api.sendMessage({
      body: "✨ | تـم رفـع الـجودة إلـى 4K بـنجاح!",
      attachment: fs.createReadStream(cachePath)
    }, threadID, () => {
      if (fs.existsSync(cachePath)) fs.unlinkSync(cachePath);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ | نـعتذر، الـسيرفر مـزدحم الآن أو الـصورة حـجمها كـبير جـداً.", threadID, messageID);
  }
};