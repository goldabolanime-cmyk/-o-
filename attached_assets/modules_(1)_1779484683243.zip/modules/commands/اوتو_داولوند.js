const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "اوتو",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "تحميل فيديوهات فيسبوك تلقائياً فور إرسال الرابط",
  commandCategory: "التحميل",
  usages: "[رابط فيسبوك]",
  cooldowns: 5
};

module.exports.handleEvent = async function ({ api, event }) {
  const { threadID, messageID, body } = event;

  if (!body) return;

  // فحص روابط فيسبوك بجميع صيغها
  const fbRegex = /(https?:\/\/(www\.)?(facebook\.com|fb\.watch|web\.facebook\.com)\/.+)/g;
  if (fbRegex.test(body)) {
    const link = body.match(fbRegex)[0];
    
    // التفاعل بالساعة الرملية
    api.setMessageReaction("⏳", messageID, () => {}, true);

    try {
      // استخدام API بديل وأكثر استقراراً
      const res = await axios.get(`https://api.samirxpikachu.run/api/fbdl?url=${encodeURIComponent(link)}`);
      
      // جلب أعلى جودة متاحة
      const videoUrl = res.data.data.high || res.data.data.low;
      
      if (!videoUrl) {
         return api.setMessageReaction("❌", messageID, () => {}, true);
      }

      // جلب الفيديو وتحليل الحجم
      const videoResponse = await axios.get(videoUrl, { responseType: "arraybuffer" });
      const buffer = Buffer.from(videoResponse.data, "binary");
      
      // حساب الحجم بالميجابايت
      const sizeInMB = (buffer.length / (1024 * 1024)).toFixed(2);

      // التأكد من أن الحجم لا يتخطى حدود فيسبوك (عادة 25MB للبوتات العادية)
      if (sizeInMB > 50) {
        return api.sendMessage(`⚠️ ┃ الْـفِـيدْيُـو كَـبِـيرٌ جِـدّاً (${sizeInMB}MB)، لَا يُمْـكِنُ إِرْسَـالُـهُ عَـبْرَ مَـاسِـنْـجَـر.`, threadID, messageID);
      }

      const path = __dirname + `/cache/fb_auto_${Date.now()}.mp4`;
      fs.writeFileSync(path, buffer);

      api.sendMessage({
        body: `✅ ┃ تَمَّ الـتَّـحْـمِـيلُ بِنَـجَاح\n━━━━━━━━━━━━━━━\n📦 ┃ الـحَـجْـم: ${sizeInMB} MB\n👑 ┃ رِيُـو بُـوت - الـتَّـحْـمِـيلُ الـآلِي`,
        attachment: fs.createReadStream(path)
      }, threadID, () => {
        fs.unlinkSync(path);
        api.setMessageReaction("✅", messageID, () => {}, true);
      }, messageID);

    } catch (err) {
      console.error(err);
      api.setMessageReaction("❌", messageID, () => {}, true);
    }
  }
};

module.exports.run = async function ({ api, event }) {
  return api.sendMessage("💡 ┃ أَرْسِـل رَابِـطَ فِـيـسْـبُـوك فَقَط وَسَـأَتَـوَلَّى الْـبَـاقِي.", event.threadID, event.messageID);
};