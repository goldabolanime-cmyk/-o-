const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "قائمة",
  version: "1.1.0",
  hasPermssion: 2, // للمطور فقط
  credits: "RIO BOT",
  description: "عرض قائمة المتفاعلين ومنحهم مكافآت عشوائية",
  commandCategory: "النظام",
  usages: "رد بكلمة (مكافئة + الرقم)",
  cooldowns: 5
};

const cooldownFile = path.join(__dirname, "cache", "reward_cooldown.json");

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { threadID, messageID, body, senderID } = event;
  
  // التحقق من أن المردود عليه هو المطور نفسه
  if (senderID != handleReply.author) return;

  const input = body.trim().split(/\s+/);
  if (input[0] !== "مكافئة") return;

  const index = parseInt(input[1]) - 1;
  const targetUser = handleReply.topUsers[index];

  if (!targetUser) {
    return api.sendMessage("⚠️ ┃ الرقم غير موجود في القائمة، اختر رقماً صحيحاً.", threadID, messageID);
  }

  // نظام الـ 24 ساعة
  if (!fs.existsSync(path.join(__dirname, "cache"))) fs.mkdirSync(path.join(__dirname, "cache"), { recursive: true });
  if (!fs.existsSync(cooldownFile)) fs.writeJsonSync(cooldownFile, {});
  
  const cooldowns = fs.readJsonSync(cooldownFile);
  const lastTime = cooldowns[senderID] || 0;
  const now = Date.now();

  if (now - lastTime < 24 * 60 * 60 * 1000) {
    const remaining = 24 * 60 * 60 * 1000 - (now - lastTime);
    const hours = Math.floor(remaining / (60 * 60 * 1000));
    const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
    return api.sendMessage(`🚫 ┃ عذراً سيدي المطور، يمكنك المكافأة مرة كل 24 ساعة.\n⏳ ┃ متبقي: ${hours} ساعة و ${minutes} دقيقة.`, threadID, messageID);
  }

  // مبلغ عشوائي بين 200 و 1900
  const reward = Math.floor(Math.random() * (1900 - 200 + 1)) + 200;

  try {
    await Currencies.increaseMoney(targetUser.userID, reward);
    
    cooldowns[senderID] = now;
    fs.writeJsonSync(cooldownFile, cooldowns);

    return api.sendMessage(
      `🎁 ┃ تـم الإهداء بنجاح!\n━━━━━━━━━━━━━━━\n👤 ┃ المستلم: ${targetUser.name}\n💰 ┃ المبلغ: ${reward} $\n✅ ┃ تمت العملية بنجاح.`,
      threadID, messageID
    );
  } catch (e) {
    return api.sendMessage("❌ ┃ فشل إضافة المبلغ، تأكد من نظام العملات لديك.", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, Users, senderID }) {
  const { threadID, messageID } = event;

  try {
    // جلب جميع المستخدمين المسجلين في قاعدة البيانات
    const allUsersData = await Users.getAll(['userID', 'name', 'exp']);
    
    // تصفية البيانات وترتيبها
    let topUsers = allUsersData
      .filter(u => u.name && u.exp > 0) // استبعاد الحسابات الوهمية أو الصفرية
      .sort((a, b) => b.exp - a.exp)
      .slice(0, 15);

    // إذا لم يوجد مستخدمين بتفاعل، اجلب أي مستخدم مسجل
    if (topUsers.length === 0) {
        topUsers = allUsersData.slice(0, 15);
    }

    if (topUsers.length === 0) {
      return api.sendMessage("⚠️ ┃ لم يتم العثور على أي مستخدمين في قاعدة البيانات حتى الآن.", threadID, messageID);
    }

    let msg = `🏆 ━━━【 قائمة المتفاعلين 】━━━ 🏆\n📊 ┃ العدد المتوفر: ${topUsers.length}\n━━━━━━━━━━━━━━━\n\n`;
    
    topUsers.forEach((user, i) => {
      msg += `【 ${i + 1} 】 👤 ${user.name}\n✨ ┃ النقاط: ${user.exp || 0}\n━━━━━━━━━━━━━━━\n`;
    });

    msg += "\n📥 ┃ كـمطور، يمكنك الرد على هذه القائمة بـ:\n👈 (مكافئة + رقم الشخص)\nمثال: مكافئة 1";

    return api.sendMessage(msg, threadID, (err, info) => {
      if (err) return console.error(err);
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        topUsers: topUsers
      });
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حدث خطأ تقني أثناء جلب القائمة.", threadID, messageID);
  }
};