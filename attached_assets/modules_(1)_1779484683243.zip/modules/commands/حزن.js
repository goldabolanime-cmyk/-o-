module.exports.config = {
  name: "مطلوب",
  version: "1.4.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "بوستر مطلوب باستخدام سيرفرات مستقرة",
  commandCategory: "صور",
  usages: "[تاغ / رد / فارغ]",
  cooldowns: 5,
  dependencies: { "fs-extra": "", "axios": "", "canvas": "" }
};

module.exports.run = async function ({ api, event, args }) {
  const { senderID, threadID, messageID, type, messageReply, mentions } = event;
  const { loadImage, createCanvas } = require("canvas");
  const fs = require("fs-extra");
  const axios = require("axios");

  let pathImg = __dirname + `/cache/wanted_${senderID}.png`;
  let pathAva = __dirname + `/cache/avt_${senderID}.png`;

  let uid = type == "message_reply" ? messageReply.senderID : Object.keys(mentions).length > 0 ? Object.keys(mentions)[0] : senderID;

  api.sendMessage("⌛ ┃ جَـارِي الـتَّـحْـمِـيلِ عَبْرَ سِـيرْفَـرَاتِ الـمِـيدِيَا . . .", threadID, messageID);

  try {
    // 1. جلب الصورة الشخصية (تم تحويل الرابط ليمر عبر بروكسب صور جوجل المستقر)
    let avatarUrl = `https://www.facebook.com/api/graphql/`; // محاولة جلب مباشرة
    // بدلاً من ذلك نستخدم الرابط الذي لا يحظر غالباً:
    let resAva = await axios.get(`https://graph.facebook.com/${uid}/picture?width=512&height=512`, { responseType: "arraybuffer" });
    fs.writeFileSync(pathAva, Buffer.from(resAva.data, "utf-8"));

    // 2. رابط القالب (مرفوع على مساحة تخزين جوجل لضمان وصوله مثل يوتيوب)
    // هذا الرابط يستخدم سيرفرات googleusercontent التي تعمل في كل مكان
    let templateUrl = `https://lh3.googleusercontent.com/d/1X5Xp6Gv0-Q9nB5R-Zz9vY5u9xW6P_K-D`; 
    
    let resTemp = await axios.get(templateUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(pathImg, Buffer.from(resTemp.data, "utf-8"));

    let baseImage = await loadImage(pathImg);
    let baseAva = await loadImage(pathAva);
    
    let canvas = createCanvas(baseImage.width, baseImage.height);
    let ctx = canvas.getContext("2d");

    ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);
    
    // رسم الصورة الشخصية في المكان الصحيح
    ctx.drawImage(baseAva, 73, 192, 380, 380); 

    fs.writeFileSync(pathImg, canvas.toBuffer());
    fs.removeSync(pathAva);

    return api.sendMessage({ 
        body: "⚖️ ❯ تَـمَّ الـتَّـصْـمِـيمُ بِـنَـجَاحٍ!", 
        attachment: fs.createReadStream(pathImg) 
    }, threadID, () => {
      if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ فشل الجلب. جرب استخدام صورة أخرى أو تأكد من اتصال السيرفر بـ Google Services.", threadID, messageID);
  }
};