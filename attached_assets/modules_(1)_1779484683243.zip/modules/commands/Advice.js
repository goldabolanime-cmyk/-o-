module.exports.config = {
  name: "نصيحة",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عمر / ريو بوت",
  description: "أعطيك نصيحة ملكية بـزخرفة فخمة ولغات متعددة",
  commandCategory: "ترفيه",
  usages: " ",
  cooldowns: 5,
  dependencies: { "srod-v2": "", "request": "" }
};

module.exports.run = async ({ event, api }) => {
  const request = global.nodemodule["request"];
  const srod = global.nodemodule["srod-v2"];
  const { threadID, messageID } = event;

  // قائمة نصائح رِيُو الملكية الخاصة (عشوائية)
  const rioAdvices = [
    { en: "Be a voice, not an echo.", ar: "كن صوتاً، لا صدى." },
    { en: "Silence is the ultimate weapon of power.", ar: "الصمت هو السلاح الأسمى للقوة." },
    { en: "Kings do not complain, they conquer.", ar: "الملوك لا يشتكون، بل يغزون." },
    { en: "Success is the best revenge.", ar: "النجاح هو أفضل انتقام." },
    { en: "Knowledge is the real crown.", ar: "المعرفة هي التاج الحقيقي." }
  ];

  // دالة زخرفة الخط الإنجليزي (المائل الفخم)
  function italicStyle(text) {
    const fonts = {
      'a': '𝖺', 'b': '𝖻', 'c': '𝖼', 'd': '𝖽', 'e': '𝖾', 'f': '𝖿', 'g': '𝗀', 'h': '𝗁', 'i': '𝗂', 'j': '𝗃', 'k': '𝗄', 'l': '𝗅', 'm': '𝗆', 'n': '𝗇', 'o': '𝗈', 'p': '𝗉', 'q': '𝗊', 'r': '𝗋', 's': '𝗌', 't': '𝗍', 'u': '𝗎', 'v': '𝗏', 'w': '𝗐', 'x': '𝗑', 'y': '𝗒', 'z': '𝗓',
      'A': '𝖠', 'B': '𝖡', 'C': '𝖢', 'D': '𝖣', 'E': '𝖤', 'F': '𝖥', 'G': '𝖦', 'H': '𝖧', 'I': '𝖨', 'J': '𝖩', 'K': '𝖪', 'L': '𝖫', 'M': '𝖬', 'N': '𝖭', 'O': '𝖮', 'P': '𝖯', 'Q': '𝖰', 'R': '𝖱', 'S': '𝖲', 'T': '𝖳', 'U': '𝖴', 'V': '𝖵', 'W': '𝖶', 'X': '𝖷', 'Y': '𝖸', 'Z': '𝖹'
    };
    return text.split('').map(char => fonts[char] || char).join('');
  }

  try {
    // اختيار مصدر النصيحة (خارجي أو من القائمة الخاصة)
    let rawAdvice, translatedText;
    const useRio = Math.random() > 0.5;

    if (useRio) {
      const choice = rioAdvices[Math.floor(Math.random() * rioAdvices.length)];
      rawAdvice = choice.en;
      translatedText = choice.ar;
      sendFinal(rawAdvice, translatedText);
    } else {
      const data = (await srod.GetAdvice()).embed.description;
      request(encodeURI(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=${data}`), (err, res, body) => {
        if (err) return sendFinal(data, "تـعـذر الـتـرجمـة حـالـيـاً.");
        const retrieve = JSON.parse(body);
        let textAr = '';
        retrieve[0].forEach(item => (item[0]) ? textAr += item[0] : '');
        sendFinal(data, textAr);
      });
    }

    function sendFinal(enText, arText) {
      const styledEn = italicStyle(enText);
      let msg = `✨ ══━━━✥ ﴿ نَصِيحَةُ المُلُوك ﴾ ✥━━━══ ✨\n\n`;
      msg += `📜 ┇ 𝓔𝓷𝓰𝓵𝓲𝓼𝓱 𝓐𝓭𝓿𝓲𝓬𝓮:\n`;
      msg += `『 ${styledEn} 』\n\n`;
      msg += `🌟 ┇ الـحِـكْـمَـةُ الـعَـرَبِـيَّـةُ:\n`;
      msg += `« ${arText} »\n\n`;
      msg += `✨ ══━━━━━━━✥━━━━━━━══ ✨\n`;
      msg += `👑 ┇ رِيُـو بُـوتْ لِـخِـدْمَتِكَ ┇ 👑`;
      api.sendMessage(msg, threadID, messageID);
    }

  } catch (e) {
    api.sendMessage("❌ ┇ حـدث خـطـأ فـي الـديوان الـملكي.", threadID, messageID);
  }
};