module.exports.config = {
  name: "منشور",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "إِنْـشَـاءُ مَنْـشُـورٍ مُـزَيَّـفٍ لِـ (أنا / ميسي / ترامب)",
  commandCategory: "صور",
  usages: "[أنا / ميسي / ترامب] [النص]",
  cooldowns: 10,
  dependencies: {
    "canvas": "",
    "axios": "",
    "fs-extra": ""
  }
};

// دالة تنسيق النصوص لضمان ملاءمتها للقوالب
module.exports.wrapText = (ctx, text, maxWidth) => {
  return new Promise(resolve => {
    const words = text.split(' ');
    const lines = [];
    let line = '';
    for (let n = 0; n < words.length; n++) {
      let testLine = line + words[n] + ' ';
      let testWidth = ctx.measureText(testLine).width;
      if (testWidth > maxWidth && n > 0) {
        lines.push(line.trim());
        line = words[n] + ' ';
      } else {
        line = testLine;
      }
    }
    lines.push(line.trim());
    resolve(lines);
  });
};

module.exports.run = async function({ api, event, args, Users }) {
  const { senderID, threadID, messageID } = event;
  const { loadImage, createCanvas } = require("canvas");
  const fs = require("fs-extra");
  const axios = require("axios");

  const type = args[0] ? args[0].toLowerCase() : "";
  const text = args.slice(1).join(" ");

  if (!type || !["أنا", "ميسي", "ترامب", "انا"].includes(type)) {
    return api.sendMessage("⚠️ ┃ سَـيِّـدِي ، يَـجِبُ تَـحْدِيـدُ اَلـنَّـوعِ:\n💡 مِـثَـال: .منشور ميسي [النص]", threadID, messageID);
  }

  if (!text) return api.sendMessage("⚠️ ┃ مِـنْ فَـضْـلِـكَ أَدْخِـلِ اَلـنَّـصَّ اَلَّـذِي تَـرْغَبُ فِـي نَـشْـرِهِ.", threadID, messageID);

  let pathImg = __dirname + `/cache/post_${senderID}.png`;
  let pathAva = __dirname + `/cache/avt_${senderID}.png`;

  try {
    api.sendMessage("⏳ ┃ جَـارِي تَـصْـمِيـمُ اَلْـمَنْـشُـورِ اَلْـمَـلَـكِيِّ . . .", threadID, messageID);

    let imgUrl, fontSize, textColor, x, y, maxWidth;
    
    // إعدادات القوالب
    if (type === "ترامب") {
      imgUrl = "https://i.postimg.cc/W4J1z3dv/1pvsy8.jpg";
      fontSize = 48; textColor = "#000000"; x = 50; y = 200; maxWidth = 1100;
    } else if (type === "ميسي") {
      imgUrl = "https://i.postimg.cc/SNz6vxYx/Picsart-22-10-16-21-04-30-217.jpg";
      fontSize = 45; textColor = "#ffffff"; x = 60; y = 170; maxWidth = 1160;
    } else { // قالب "أنا" (بصورتك الشخصية)
      imgUrl = "https://i.postimg.cc/9FX3QVXf/Picsart-22-07-31-17-43-49-198.jpg";
      fontSize = 40; textColor = "#ffffff"; x = 1250; y = 263; maxWidth = 1160;
      
      // جلب صورة البروفايل للمستخدم
      let avatar = (await axios.get(`https://graph.facebook.com/${senderID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`, { responseType: "arraybuffer" })).data;
      fs.writeFileSync(pathAva, Buffer.from(avatar, "utf-8"));
    }

    const imageBuffer = (await axios.get(imgUrl, { responseType: 'arraybuffer' })).data;
    fs.writeFileSync(pathImg, Buffer.from(imageBuffer, 'utf-8'));

    const baseImage = await loadImage(pathImg);
    const canvas = createCanvas(baseImage.width, baseImage.height);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);

    // إذا كان القالب "أنا"، نرسم الاسم والصورة الشخصية
    if (type === "أنا" || type === "انا") {
      const baseAva = await loadImage(pathAva);
      const namee = (await Users.getData(senderID)).name;
      ctx.drawImage(baseAva, 40, 50, 122, 122);
      ctx.font = "1000 40px Arial";
      ctx.fillStyle = "#FF9900";
      ctx.fillText(namee, 170, 97);
      ctx.textAlign = "right"; // النص في هذا القالب يبدأ من اليمين
    } else {
      ctx.textAlign = "start";
    }

    ctx.font = `500 ${fontSize}px Arial`;
    ctx.fillStyle = textColor;

    const lines = await this.wrapText(ctx, text, maxWidth);
    ctx.fillText(lines.join('\n'), x, y);

    fs.writeFileSync(pathImg, canvas.toBuffer());

    return api.sendMessage({
      body: `✅ ┃ تَـفَـضَّـلْ يَـا سَـيِّـدِي ، مَنْـشُـورُ [ ${type} ] جَـاهِـزٌ:`,
      attachment: fs.createReadStream(pathImg)
    }, threadID, () => {
      if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
      if (fs.existsSync(pathAva)) fs.unlinkSync(pathAva);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي مُـعَالَـجَـةِ اَلـصُّـورَةِ، تَـأَكَّـدْ مِـنَ اَلـسِّـيـرْفَرِ.", threadID, messageID);
  }
};