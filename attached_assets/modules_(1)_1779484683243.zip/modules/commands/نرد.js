module.exports.config = {
  name: "نرد",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "لعبة مراهنة النرد - اختر رقماً وراهن بمبلغ",
  commandCategory: "ألعاب",
  usages: "[الرقم من 1-6] [المبلغ]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args, Currencies }) {
  const { threadID, messageID, senderID } = event;
  
  // 1. التحقق من المدخلات
  const betNumber = parseInt(args[0]);
  const betMoney = parseInt(args[1]);

  if (isNaN(betNumber) || betNumber < 1 || betNumber > 6) {
    return api.sendMessage("⚠️ | يـرجـى اخـتـيار رقـم مـن 1 إلـى 6 فـقـط.\nمـثال: [نرد 5 100]", threadID, messageID);
  }

  if (isNaN(betMoney) || betMoney < 20) {
    return api.sendMessage("⚠️ | أقـل مـبـلغ لـلـمـراهـنة هـو 20$.", threadID, messageID);
  }

  // 2. التحقق من رصيد المستخدم
  let userMoney = (await Currencies.getData(senderID)).money;
  if (userMoney < betMoney) {
    return api.sendMessage(`⚠️ | رصـيـدك لا يـكـفـي! مـعـك حـالـيـاً ${userMoney}$.`, threadID, messageID);
  }

  // 3. رمي النرد (رقم عشوائي من 1 لـ 6)
  const diceResult = Math.floor(Math.random() * 6) + 1;
  const diceEmojis = ["", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];

  // 4. معالجة الفوز أو الخسارة
  if (betNumber === diceResult) {
    const winAmount = betMoney * 2; // يربح الضعف
    await Currencies.increaseMoney(senderID, betMoney); // إضافة الربح الصافي
    
    return api.sendMessage(`
┏━━━━━━━━━━━━┓
   🎲 نـتـيـجـة الـنـرد 🎲
┗━━━━━━━━━━━━┛
🎰 | اخـتـيـارك: ${betNumber}
🎲 | الـنـرد ظـهـر: ${diceResult} ${diceEmojis[diceResult]}

✅ | مـبـروك! لـقـد فـزت بـمـبـلغ ${winAmount}$
💰 | تـم إضـافـتها لـحـسابـك.
━━━━━━━━━━━━━━━`, threadID, messageID);

  } else {
    await Currencies.decreaseMoney(senderID, betMoney); // خصم مبلغ الرهان
    
    return api.sendMessage(`
┏━━━━━━━━━━━━┓
   🎲 نـتـيـجـة الـنـرد 🎲
┗━━━━━━━━━━━━┛
🎰 | اخـتـيـارك: ${betNumber}
🎲 | الـنـرد ظـهـر: ${diceResult} ${diceEmojis[diceResult]}

❌ | لـلأسـف خـسـرت ${betMoney}$
🐦‍⬛ | حـاول مـرة أخـرى، الـحـظ سـيـحـالفـك!
━━━━━━━━━━━━━━━`, threadID, messageID);
  }
};
