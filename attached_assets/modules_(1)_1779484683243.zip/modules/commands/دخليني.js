module.exports.config = {
  name: "اضفني",
  version: "1.2.0",
  hasPermssion: 2, 
  credits: "RIO BOOT",
  description: "عرض مجموعات البوت والانضمام إليها (خاص بالمطور)",
  commandCategory: "نظام",
  usages: "قم بالرد بالأرقام (مثال: 1 أو 1 2 3)",
  cooldowns: 5
};

// ضع هنا الأيدي الخاص بك (ID حسابك على فيسبوك)
const DEVELOPER_ID = "100090081489341"; 

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, senderID, body } = event;
  
  // التأكد أن الذي يرد هو المطور فقط
  if (senderID != DEVELOPER_ID) return;

  const choices = body.split(/\s+/).map(n => parseInt(n) - 1);
  let successGroups = [];
  let failGroups = [];

  api.unsendMessage(handleReply.messageID); 

  for (const index of choices) {
    const group = handleReply.groups[index];
    if (group) {
      try {
        await api.addUserToGroup(senderID, group.threadID);
        successGroups.push(group.threadName);
      } catch (e) {
        failGroups.push(group.threadName);
      }
    }
  }

  let finalMsg = "━━━『 نـتـيـجـة الإضـافـة 』━━━\n";

  if (successGroups.length > 0) {
    finalMsg += `\n✅ | تـمـت إضـافـتـك لـلـمـجـمـوعات:\n${successGroups.map(n => `🔹 ${n}`).join("\n")}\n`;
  }

  if (failGroups.length > 0) {
    finalMsg += `\n❌ | تـعـذر إضـافـتـك لـ:\n${failGroups.map(n => `🔸 ${n}`).join("\n")}\n`;
    finalMsg += `\n💡 | الـسبب: قـد تـكون خـصـوصـيتك مـغـلـقة أو لـست صـديـقاً لـلـبوت.`;
  }

  finalMsg += "\n━━━━━━━━━━━━━━━\nتـفـقـد طـلـبـات الـمراسـلـة ✨";

  return api.sendMessage(finalMsg, threadID, messageID);
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;

  // التحقق من هوية المطور عند كتابة الأمر لأول مرة
  if (senderID != DEVELOPER_ID) {
      return api.sendMessage("━━━『 تـنـبـيـه 』━━━\n\n🚫 | عذراً، هذا الأمر مخصص فقط لمطور البوت الرئيسي!\n\n━━━━━━━━━━━━━━━", threadID, messageID);
  }

  try {
    const list = await api.getThreadList(50, null, ["INBOX"]);
    const groups = list.filter(g => g.isGroup && g.threadID != threadID && g.name);

    if (groups.length == 0) return api.sendMessage("⚠️ | لا يـوجـد مـجـموعات أخـرى مـتـاحـة حالـياً.", threadID, messageID);

    let msg = "━━━『 مـجـمـوعـات ريـو بـوت 』━━━\n\n";
    groups.forEach((g, i) => {
      msg += `${i + 1} ❯ 【 ${g.name} 】\n`;
    });

    msg += `\n━━━━━━━━━━━━━━━\n👑 خـاص بـالـمـطـور (عبدو)\n💡 رد بـرقـم الـمـجـمـوعـة لـلـانـضـمـام\n━━━━━━━━━━━━━━━`;

    return api.sendMessage(msg, threadID, (err, info) => {
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        groups: groups.map(g => ({ threadID: g.threadID, threadName: g.name }))
      });
    }, messageID);
  } catch (err) {
    return api.sendMessage("❌ | حـدث خـطأ أثـناء جـلـب الـقائمة.", threadID, messageID);
  }
};