module.exports.config = {
  name: 'جافا',
  version: '1.0.0',
  hasPermssion: 2,
  credits: 'عمر',
  description: 'سحب ملفات الأوامر من البوت',
  commandCategory: 'المطور',
  usages: '[اسم_الملف.js]',
  cooldowns: 0
};

module.exports.run = async ({ args, api, event, Users }) => {
  const fs = require("fs-extra");
  const stringSimilarity = require('string-similarity'); // اسم المكتبة الصحيح
  
  const permission = ["100090081489341"];
  if (!permission.includes(event.senderID)) return api.sendMessage("ليس لديك صلاحية لاستخدام هذا الأمر :>", event.threadID, event.messageID);

  const file = args[0]; // نأخذ الكلمة الأولى كاسم للملف
  if(!file) return api.sendMessage('لا يمكن ترك اسم الملف فارغًا', event.threadID, event.messageID);
  if (!file.endsWith('.js')) return api.sendMessage('يجب أن ينتهي الملف بـ .js', event.threadID, event.messageID);

  const pathFile = __dirname + "/" + file;

  // دالة البحث عن ملف مشابه في حال عدم وجود الملف المطلوب
  const handleFileNotFound = async (targetFile) => {
    const allFiles = fs.readdirSync(__dirname).filter((f) => f.endsWith(".js")).map(f => f.replace(/\.js/g, ""));
    const checker = stringSimilarity.findBestMatch(targetFile.replace(/\.js/g, ""), allFiles);
    const search = checker.bestMatch.rating >= 0.5 ? checker.bestMatch.target : undefined;
    return search;
  };

  if(event.type == "message_reply") {
    var uid = event.messageReply.senderID;
    var name = (await Users.getData(uid)).name;

    if(!fs.existsSync(pathFile)) { 
      const search = await handleFileNotFound(file);
      if(search == undefined) return api.sendMessage('🔎 لم يتم العثور على الملف: ' + file, event.threadID, event.messageID); 
      
      return api.sendMessage(`🔎 لم يتم العثور على الملف المطلوب.\n💡 هل تقصد الملف: ${search}.js؟\nقم بالتفاعل (Reaction) على هذه الرسالة لإرساله.`, event.threadID, (error, info) => {
          global.client.handleReaction.push({
              name: this.config.name,
              type: 'user',
              author: event.senderID,
              messageID: info.messageID,
              file: search,
              uid: uid,
              namee: name
          });
      }, event.messageID);
    }

    // إذا الملف موجود
    const tempFile = pathFile.replace(".js", ".txt");
    fs.copySync(pathFile, tempFile);
    return api.sendMessage({
      body: `» تفضل ملف الـ جافا: ${file}`, 
      attachment: fs.createReadStream(tempFile)
    }, uid, () => {
        fs.unlinkSync(tempFile);
        api.sendMessage(`» تم إرسال الملف إلى ${name} بنجاح ✅`, event.threadID);
    });
  } 
  else {
    if(!fs.existsSync(pathFile)) { 
      const search = await handleFileNotFound(file);
      if(search == undefined) return api.sendMessage('🔎 لم يتم العثور على الملف: ' + file, event.threadID, event.messageID); 

      return api.sendMessage(`🔎 الملف غير موجود. هل تقصد: ${search}.js؟\nتفاعل مع الرسالة للإرسال.`, event.threadID, (error, info) => {
          global.client.handleReaction.push({
              name: this.config.name,
              type: 'thread',
              author: event.senderID,
              messageID: info.messageID,
              file: search
          });
      }, event.messageID);
    }

    const tempFile = pathFile.replace(".js", ".txt");
    fs.copySync(pathFile, tempFile);
    return api.sendMessage({
      body: `» تفضل ملف الـ جافا: ${file}`, 
      attachment: fs.createReadStream(tempFile)
    }, event.threadID, () => fs.unlinkSync(tempFile), event.messageID);
  }
};

module.exports.handleReaction = async ({ Users, api, event, handleReaction }) => {
    const fs = require("fs-extra");
    const { file, author, type, uid, namee } = handleReaction;
    if (event.userID != author) return;

    const fileSend = file + '.js';
    const pathFile = __dirname + '/' + fileSend;
    const tempFile = __dirname + '/' + file + '.txt';

    if (!fs.existsSync(pathFile)) return api.sendMessage("حدث خطأ، الملف لم يعد موجوداً.", event.threadID);

    api.unsendMessage(handleReaction.messageID);
    fs.copySync(pathFile, tempFile);

    if (type === "user") {
        return api.sendMessage({
            body: `» الملف المطلوب: ${fileSend}`, 
            attachment: fs.createReadStream(tempFile)
        }, uid, () => {
            fs.unlinkSync(tempFile);
            api.sendMessage(`» تفقد خاصك يا ${namee}، تم الإرسال 📁`, event.threadID);
        });
    } else {
        return api.sendMessage({
            body: `» الملف المطلوب: ${fileSend}`, 
            attachment: fs.createReadStream(tempFile)
        }, event.threadID, () => fs.unlinkSync(tempFile), event.messageID);
    }
};
