const fs = require("fs-extra");

module.exports.config = {
  name: "مستذئب",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "عمر / تعديل RIO BOT",
  description: "لعبة المستذئبين مع نظام إشعارات المطورين الملكي",
  commandCategory: "العاب",
  usages: "[انشاء/انضمام/ابدأ/مساعدة/خروج]",
  cooldowns: 1
};

// آيـدي جـروب الـمـطوريـن الـمـعـتـمـد
const devGroupID = "1345646303986676"; 

if (!global.moduleData) global.moduleData = new Object();
if (!global.moduleData.masoi) global.moduleData.masoi = new Map();

module.exports.handleReply = async ({ api, event, handleReply }) => {
    const { body, threadID, senderID, messageID } = event;
    if (handleReply.author != senderID) return;

    if (handleReply.type === "choose_wolves") {
        const count = parseInt(body);
        if (isNaN(count) || count < 1 || count > 5) return api.sendMessage("⚠️ ┃ مـلكي، اختر رقماً بين 1 و 5 فقط.", threadID, messageID);
        
        const values = global.moduleData.masoi.get(threadID);
        values.sosoi = count;
        api.unsendMessage(handleReply.messageID);
        return api.sendMessage(`🐺 ┃ تـمَّ إعداد الـمجزرة بـعدد [ ${count} ] ذئـاب!`, threadID);
    }
};

module.exports.run = async function({ api, event, args, Users }) {
  const { threadID, messageID, senderID } = event;
  const action = args[0];

  if (!global.moduleData.masoi.has(threadID)) {
    global.moduleData.masoi.set(threadID, { start: 0, player: [], sosoi: 0, author: senderID, timer: null });
  }
  const values = global.moduleData.masoi.get(threadID);

  // --- [ مساعدة ] ---
  if (action === "مساعدة") {
    const helpMsg = `🏰 ━━━━【 دَلـيـلُ الـمُـستَـذئـبِ 】━━━━ 🏰\n\n📜 ┃ صراع البقاء بين القرويين والمستذئبين.\n⏱️ ┃ تنطلق اللعبة تلقائياً بعد 70 ثانية من انضمام الثاني.`;
    return api.sendMessage(helpMsg, threadID, messageID);
  }

  // --- [ إنشاء ] ---
  if (action === "انشاء" || action === "إنشاء") {
    if (values.start === 1) return api.sendMessage("⚠️ ┃ الغرفة مفتوحة بالفعل.", threadID, messageID);
    values.start = 1;
    values.author = senderID;
    values.player = [{ id: senderID, name: await Users.getNameUser(senderID) }];
    
    return api.sendMessage("🐺 ┃ تـمَّ فـتـحُ غُـرفَـةِ الـمُـسـتَـذئـبِـيـن الـمـلكيـة!\n━━━━━━━━━━━━━━━\n⚙️ ┃ رُد بـعدد الـذئاب (1-5) لـتجهيز الـكمين.", threadID, (err, info) => {
        global.client.handleReply.push({ name: this.config.name, messageID: info.messageID, author: senderID, type: "choose_wolves" });
    }, messageID);
  }

  // --- [ انضمام ] ---
  if (action === "انضمام") {
    if (values.start !== 1) return api.sendMessage("⚠️ ┃ لا توجد غرفة مفتوحة حالياً.", threadID, messageID);
    if (values.player.find(p => p.id === senderID)) return api.sendMessage("📢 ┃ أنت في القرية بالفعل!", threadID, messageID);
    
    values.player.push({ id: senderID, name: await Users.getNameUser(senderID) });
    api.sendMessage(`✅ ┃ انـضم مـحارب جـديد! الـعدد: ${values.player.length}`, threadID);

    if (values.player.length >= 2 && !values.timer) {
        values.timer = setTimeout(() => {
            this.run({ api, event: { threadID, senderID: values.author }, args: ["ابدأ"], Users });
        }, 70000);
    }
    return;
  }

  // --- [ ابدأ ] ---
  if (action === "ابدأ" || action === "ابدا") {
    if (values.author !== senderID) return api.sendMessage("👑 ┃ المضيف فقط يملك حق إعلان الحرب.", threadID, messageID);
    if (values.player.length < 2) return api.sendMessage("⚠️ ┃ نحتاج لمزيد من الضحايا (2 على الأقل).", threadID, messageID);
    if (values.sosoi === 0) values.sosoi = 1;

    clearTimeout(values.timer);

    // --- [ إرسال الإشعار للمطورين ] ---
    try {
        const threadInfo = await api.getThreadInfo(threadID);
        const hostName = await Users.getNameUser(values.author);
        const devMsg = `🚀 ┃ 【 إشـعـار تـشـغـيـل الـمـستـذئب 】\n━━━━━━━━━━━━━━━\n🏰 ┃ الـمـجـموعة: ${threadInfo.threadName || "غير معرفة"}\n👤 ┃ الـمـضيف: ${hostName}\n👥 ┃ الـلاعبين: ${values.player.length}\n🐺 ┃ الـذئاب: ${values.sosoi}`;
        api.sendMessage(devMsg, devGroupID);
    } catch (e) { console.log("خطأ في إرسال إشعار المطور"); }

    const roles = ["طبيب", "رامي سهام", "متنبئ", "عراف", "مستحضر", "قاتل"];
    let playersShuffle = [...values.player].sort(() => Math.random() - 0.5);
    let gameLog = "🌕 ┃ سـكن الـليل.. وبـدأ الـعواء!\n━━━━━━━━━━━━━━━\n";

    for (let i = 0; i < playersShuffle.length; i++) {
        let role = (i < values.sosoi) ? "مستذئب" : roles[Math.floor(Math.random() * roles.length)];
        api.sendMessage(`🎭 ┃ دورُك الـسـري الـمـلكي: 【 ${role} 】`, playersShuffle[i].id);
        gameLog += `👤 ┃ أرسـلنا الـقدر لـلـلاعب: ${playersShuffle[i].name}\n`;
    }

    gameLog += "━━━━━━━━━━━━━━━\n🔥 ┃ تـفـقـد الـخـاص.. لا تـثـق بـأحد!";
    global.moduleData.masoi.delete(threadID);
    return api.sendMessage(gameLog, threadID);
  }

  // --- [ خروج ] ---
  if (action === "خروج" || action === "حذف") {
    clearTimeout(values.timer);
    global.moduleData.masoi.delete(threadID);
    return api.sendMessage("🗑️ ┃ تـمَّ حـرق الـغُـرفَـة وتَـفـريـغ الـسـجلـات.", threadID);
  }
};