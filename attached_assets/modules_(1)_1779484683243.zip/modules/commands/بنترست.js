const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "بنت",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "Abdou / RIO BOT",
  description: "بحث بنترست (نصي + رد على صورة) بالروابط الأصلية",
  commandCategory: "الصور",
  usages: "[اسم البحث] أو [رد على صورة]",
  cooldowns: 5
};

// --- الروابط والبيانات الأصلية الخاصة بك لضمان الاستقرار ---
const pinterestHeaders = {
    'authority': 'www.pinterest.com',
    'cache-control': 'max-age=0',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'accept-language': 'en-US,en;q=0.9',
    'cookie': 'csrftoken=92c7c57416496066c4cd5a47a2448e28; g_state={"i_l":0}; _auth=1; _pinterest_sess=TWc9PSZBMEhrWHJZbHhCVW1OSzE1MW0zSkVid1o4Uk1laXRzdmNwYll3eEFQV0lDSGNRaDBPTGNNUk5JQTBhczFOM0ZJZ1ZJbEpQYlIyUmFkNzlBV2kyaDRiWTI4THFVUWhpNUpRYjR4M2dxblJCRFhESlBIaGMwbjFQWFc2NHRtL3RUcTZna1c3K0VjVTgyejFDa1VqdXQ2ZEQ3NG91L1JTRHZwZHNIcDZraEp1L0lCbkJWUytvRis2ckdrVlNTVytzOFp3ZlpTdWtCOURnbGc3SHhQOWJPTzArY3BhMVEwOTZDVzg5VDQ3S1NxYXZGUEEwOTZBR21LNC9VZXRFTkErYmtIOW9OOEU3ektvY3ZhU0hZWVcxS0VXT3dTaFpVWXNuOHhiQWdZdS9vY24wMnRvdjBGYWo4SDY3MEYwSEtBV2JxYisxMVVsV01McmpKY0VOQ3NYSUt2ZDJaWld6T0RacUd6WktITkRpZzRCaWlCTjRtVXNMcGZaNG9QcC80Ty9ZZWFjZkVGNURNZWVoNTY4elMyd2wySWhtdWFvS2dQcktqMmVUYmlNODBxT29XRWx5dWZSc1FDY0ZONlZJdE9yUGY5L0p3M1JXYkRTUDAralduQ2xxR3VTZzBveUc2Ykx3VW5CQ0FQeVo5VE8wTEVmamhwWkxwMy9SaTNlRUpoQmNQaHREbjMxRlRrOWtwTVI5MXl6cmN1K2NOTFNyU1cyMjREN1ZFSHpHY0ZCR1RocWRjVFZVWG9VcVpwbXNGdlptVzRUSkNadVc1TnlBTVNGQmFmUmtrNHNkVEhXZytLQjNUTURlZXBUMG9GZ3YwQnVNcERDak16Nlp0Tk13dmNsWG82U2xIKyt5WFhSMm1QUktYYmhYSDNhWnB3RWxTUUttQklEeGpCdE4wQlNNOVRzRXE2NkVjUDFKcndvUzNMM2pMT2dGM05WalV2Q+m8fBfbO79;'
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, type, messageReply } = event;

  // التحقق إذا كان المستخدم رد على صورة
  if (type === "message_reply" && messageReply.attachments && messageReply.attachments[0]?.type === "photo") {
    const imageUrl = messageReply.attachments[0].url;
    api.sendMessage("🔍 | جـاري تـحـلـيـل الـصـورة والـبـحـث عـن مـشـابـه لـهـا بنفس الرابط...", threadID, messageID);
    return sendPinterestImages(api, event, imageUrl, 15, 0, true);
  }

  const keySearch = args.join(" ").split("-")[0].trim();
  const number = parseInt(args.join(" ").split("-")[1]) || 15;

  if (!keySearch) return api.sendMessage("⚠️ | اكتب اسم الصورة أو رد على صورة لجلب مشابه لها.", threadID, messageID);

  return sendPinterestImages(api, event, keySearch, number, 0, false);
};

async function sendPinterestImages(api, event, query, number, startIndex, isVisual) {
  const { threadID, messageID, senderID } = event;

  try {
    // توحيد الرابط: بنترست يقبل الروابط المباشرة في كويري البحث أحياناً
    const url = `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(query)}&rs=typed`;

    const res = await axios.get(url, { headers: pinterestHeaders });
    const body = res.data;
    
    // استخدام نفس تقنية البحث (Regex) التي نجحت في البحث النصي
    const arrMatch = body.match(/https:\/\/i\.pinimg\.com\/originals\/[^.]+\.jpg/g);

    if (!arrMatch || arrMatch.length === 0) {
      return api.sendMessage("❌ | لـم يـتـم الـعـثـور عـلى نـتـائـج مـشـابـهة، حـاول مـع صـورة أخـرى.", threadID, messageID);
    }

    const currentBatch = arrMatch.slice(startIndex, startIndex + Math.min(number, 15));
    if (currentBatch.length === 0) return api.sendMessage("🏁 | انـتهت الـصـور.", threadID, messageID);

    const attachments = [];
    const cacheDir = __dirname + "/cache";
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir);

    for (let i = 0; i < currentBatch.length; i++) {
      const path = `${cacheDir}/pin_${senderID}_${Date.now()}_${i}.jpg`;
      const imageRes = await axios.get(currentBatch[i], { responseType: "arraybuffer" });
      fs.writeFileSync(path, Buffer.from(imageRes.data, "utf-8"));
      attachments.push(fs.createReadStream(path));
    }

    const msg = `🖼️ ┃ تـم جـلـب الـصور بـنـجـاح\n━━━━━━━━━━━━━━━\n💡 ┃ رد بـ [ التالي ] لـعـرض المزيد من النتائج.`;

    return api.sendMessage({ body: msg, attachment: attachments }, threadID, (err, info) => {
      attachments.forEach(file => {
        if (fs.existsSync(file.path)) fs.unlinkSync(file.path);
      });

      if (!global.client.handleReply) global.client.handleReply = [];
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        query: query,
        isVisual: isVisual,
        number: number,
        nextIndex: startIndex + currentBatch.length
      });
    }, messageID);

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ | حـدث خـطأ فـي الاتـصال.. تـأكـد من الـروابط.", threadID, messageID);
  }
}

module.exports.handleReply = async function({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  if (body === "التالي" || body === "المزيد") {
    api.unsendMessage(handleReply.messageID);
    return sendPinterestImages(api, event, handleReply.query, handleReply.number, handleReply.nextIndex, handleReply.isVisual);
  }
};