const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const { translate } = require("@vitalets/google-translate-api");

module.exports.config = {
  name: "2رواية",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "البحث عن روايات عالمية واقعية مع ترجمة مستقرة",
  commandCategory: "خدمات",
  usages: "[اسم الرواية]",
  cooldowns: 10
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const searchQuery = args.join(" ");

  if (!searchQuery) return api.sendMessage("⚠️ ┃ مـلكي، يـرجى كـتابة اسـم الـرواية للـبحث عنها!", threadID, messageID);

  api.sendMessage(`🔍 ┃ جـارٍ الـبحث عـن رِوايـة "${searchQuery}" فـي الـمكتبـة الـعالميـة..`, threadID, messageID);

  try {
    const searchApi = `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(searchQuery)}&maxResults=1`;
    const response = await axios.get(searchApi);
    const book = response.data.items && response.data.items[0];

    if (!book) return api.sendMessage("❌ ┃ لـم أجـد أي رِوايـة تـطابـق بـحثـك.", threadID, messageID);

    const info = book.volumeInfo;
    const rawDescription = info.description || "لا يوجد وصف متوفر.";

    // الترجمة باستخدام المكتبة الجديدة والمستقرة
    let translatedDesc = rawDescription;
    try {
      const resTranslation = await translate(rawDescription, { to: 'ar' });
      translatedDesc = resTranslation.text;
    } catch (e) { console.error("خطأ ترجمة:", e); }

    const cachePath = path.join(__dirname, "cache", `novel_${senderID}.jpg`);
    if (!fs.existsSync(path.join(__dirname, "cache"))) fs.mkdirSync(path.join(__dirname, "cache"));

    let attachment = [];
    if (info.imageLinks && info.imageLinks.thumbnail) {
      const imgRes = await axios.get(info.imageLinks.thumbnail, { responseType: "arraybuffer" });
      fs.writeFileSync(cachePath, Buffer.from(imgRes.data));
      attachment.push(fs.createReadStream(cachePath));
    }

    const msg = `👑 ━━━━【 الـمَـكْـتَـبَـةُ الـمَـلَـكِـيَّـةُ 】━━━━ 👑\n\n📖 ┃ الـعـنـوان: ${info.title}\n✍️ ┃ الـمـؤلـف: ${info.authors ? info.authors.join(", ") : "غير معروف"}\n📅 ┃ الـنشر: ${info.publishedDate || "غير معروف"}\n━━━━━━━━━━━━━━━\n📝 ┃ قِـصَّـةُ الـرِّوايَـةِ:\n\n${translatedDesc.slice(0, 800)}...\n━━━━━━━━━━━━━━━\n✨ رِيُـو بُـوت - نِـظـامُ الـمَـلِـك`;

    return api.sendMessage({ body: msg, attachment }, threadID, () => {
      if (fs.existsSync(cachePath)) fs.unlinkSync(cachePath);
    }, messageID);

  } catch (error) {
    return api.sendMessage("❌ ┃ حـدث خـطأ، تـأكد مـن تـثبيت الـمكتبات بشكل صـحيح.", threadID, messageID);
  }
};