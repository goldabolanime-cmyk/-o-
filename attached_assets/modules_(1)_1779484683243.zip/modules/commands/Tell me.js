module.exports.config = {
  name: "قول",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عمر / ريو بوت",
  description: "يحول النص إلى صوت (محدد بـ 5 مرات كل 3 ساعات)",
  commandCategory: "خدمات",
  usages: "[نص]",
  cooldowns: 5,
  dependencies: {
    "path": "",
    "fs-extra": ""
  }
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const fs = global.nodemodule["fs-extra"];
  const { resolve } = global.nodemodule["path"];
  const pathLimit = resolve(__dirname, 'cache', 'say_limit.json');

  try {
    // إنشاء ملف البيانات إذا لم يكن موجوداً
    if (!fs.existsSync(pathLimit)) fs.writeJsonSync(pathLimit, {});
    let data = fs.readJsonSync(pathLimit);

    // إعدادات النظام
    const LIMIT_COUNT = 5;
    const COOLDOWN_TIME = 3 * 60 * 60 * 1000; // 3 ساعات بالميلي ثانية
    const now = Date.now();

    if (!data[senderID]) {
      data[senderID] = { count: 0, lastReset: now };
    }

    // إعادة تعيين العداد إذا مرت 3 ساعات
    if (now - data[senderID].lastReset > COOLDOWN_TIME) {
      data[senderID].count = 0;
      data[senderID].lastReset = now;
    }

    // التحقق من تجاوز الحد
    if (data[senderID].count >= LIMIT_COUNT) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - data[senderID].lastReset)) / (60 * 1000));
      return api.sendMessage(`⚠️ ┇ عذراً يا رفيق، لقد استنفدت حصتك (5 مرات).\n⏳ ┇ انتظر ${remainingTime} دقيقة لتتمكن من القول مجدداً.`, threadID, messageID);
    }

    // منطق جلب الصوت الأساسي
    var content = (event.type == "message_reply") ? event.messageReply.body : args.join(" ");
    if (!content) return api.sendMessage("📝 ┇ من فضلك اكتب النص أو رد على رسالة.", threadID, messageID);

    var msg = content;
    const pathFile = resolve(__dirname, 'cache', `${threadID}_${senderID}.mp3`);
    
    await global.utils.downloadFile(`https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(msg)}&tl=ar&client=tw-ob`, pathFile);

    // تحديث البيانات وحفظها
    data[senderID].count += 1;
    fs.writeJsonSync(pathLimit, data);

    return api.sendMessage({ 
      body: `🗣️ ┇ الـمـحـاولـة [ ${data[senderID].count} / ${LIMIT_COUNT} ]`,
      attachment: fs.createReadStream(pathFile)
    }, threadID, () => fs.unlinkSync(pathFile), messageID);

  } catch (e) { 
    console.log(e);
    return api.sendMessage("❌ ┇ حدث خطأ في النظام الصوتي.", threadID, messageID);
  }
}
