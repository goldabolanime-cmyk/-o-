const axios = require("axios");
const request = require("request");
const fs = require("fs-extra");

module.exports.config = {
  name: "لوكو",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "إِِنْـشَـاءُ شِـعَارَاتٍ إِحْـتِـرَافِـيَّـةٍ",
  commandCategory: "صور",
  usages: "[رقم اللوكو] [الإسم بالإنجليزية]",
  cooldowns: 5,
};

module.exports.run = async function ({ api, event, args }) {
  const { messageID, threadID } = event;
  const pathImg = __dirname + `/cache/rio_logo.png`;

  // 1. إذا كتب المستخدم "لوكو" فقط أو "لوكو الكل" أو نسى الرقم
  if (args.length < 2) {
    const listLogos = 
      `┏━━━━━━━━━━━━━━━━━━━━┓\n` +
      `   ♛ 𝑹𝑰𝑶 𝑳𝑶𝑮𝑶 𝑳𝑰𝑺𝑻 ♛\n` +
      `┗━━━━━━━━━━━━━━━━━━━━┛\n\n` +
      `💡 ┃ يُـرْجَى كِـتَابَةُ اَلْأَمْرِ هَكَـذَا:\n` +
      `👈 [ لوكو + الرقم + الإسم ]\n\n` +
      `🎨 ┃ اَلْـقَـائِـمَـةُ اَلْـمُـتَـوَفِّـرَةُ (30 شـكـل):\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `1. Neon | 2. Thunder | 3. Blackpink\n` +
      `4. Glitch | 5. Marvel | 6. Blood\n` +
      `7. Metal | 8. Fire | 9. Glass\n` +
      `10. Joker | 11. Luxury | 12. Magma\n` +
      `[ اكتب من 1 إلى 30 واكتشف البقية ]\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`;
    return api.sendMessage(listLogos, threadID, messageID);
  }

  let type = args[0];
  let name = args.slice(1).join(" ");
  
  // تنبيه في حالة كان الرقم غير موجود في القائمة
  if (isNaN(type) || type > 30 || type < 1) {
    return api.sendMessage("⚠️ ┃ يَا عـبـدو، الـرقم خـاصو يـكون بـيـن 1 و 30 فـقط!", threadID, messageID);
  }

  api.sendMessage("⏳ ┃ جَـارِي تَـصْـمِيـمِ شِـعَـارِكَ اَلْـمَـلَـكِي، اِنْـتَـظِـرْ...", threadID, messageID);

  try {
    // الرابط المحدث والفعال (استخدمت API بديل في حالة تعطل ريبليت القديم)
    let apiUrl = `https://free-api.ainz-albert08.repl.co/api/textpro?number=${type}&text=${encodeURIComponent(name)}`;

    let callback = function () {
      api.sendMessage({
        body: `┏━━━━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑳𝑶𝑮𝑶 𝑫𝑬𝑺𝑰𝑮𝑵 ♛\n┗━━━━━━━━━━━━━━━━━━━━┛\n\n✨ ┃ اَلـشِّـعَـارُ بَـاتَ جَـاهِـزاً يَا عـبـدو\n🎨 ┃ رَقْـمُ اَلـتَّـصْـمِيـمِ: 『 ${type} 』\n\n🔱 ┃ بِـوَاسِـطَـةِ: عـبـدو`,
        attachment: fs.createReadStream(pathImg)
      }, threadID, () => fs.unlinkSync(pathImg), messageID);
    };

    return request(encodeURI(apiUrl)).pipe(fs.createWriteStream(pathImg)).on("close", callback);
    
  } catch (err) {
    console.error(err);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي اَلْـخَـادِمِ، حَـاوِلْ مَـرَّةً أُخْـرَى.", threadID, messageID);
  }
};