const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const jimp = require("jimp");

module.exports.config = {
  name: "شنق",
  version: "3.3.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "تشنق شخصاً عبر المنشن أو الرد على رسالته 💀",
  commandCategory: "ألعاب",
  usages: "[@منشن / رد على رسالة]",
  cooldowns: 5
};

const cacheDir = path.join(__dirname, "cache");
const developerID = "100090081489341"; // أيدي المطور عبدو

module.exports.onLoad = async () => {
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
};

async function circle(url) {
  const img = await jimp.read(url);
  img.circle();
  return await img.getBufferAsync(jimp.MIME_PNG);
}

module.exports.run = async function ({ event, api, Users }) {    
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  
  let targetID;
  if (type === "message_reply") {
    targetID = messageReply.senderID;
  } else if (Object.keys(mentions).length > 0) {
    targetID = Object.keys(mentions)[0];
  } else {
    return api.sendMessage("⚠️ ┃ مَـنْ تَـرِيدُ أَنْ تَـشْـنُقَ؟ اِعْـمَلْ لَـهُ تَـاغْ أَوْ رُدَّ عَلَى رِسَـالَتِهِ!", threadID, messageID);
  }

  // ميزة حماية المطور عبدو
  if (targetID == developerID) {
    const responses = [
      "⚠️ ┃ هَلْ تُحَاوِلُ شَنْقَ صَانِعِي؟ عُدْ إِلَى حَجْمِكَ الطَّبِيعِي، الـمُطَوِّرُ عَبْدُو تَاجُ رَأْسِكَ! 👑",
      "🚫 ┃ اِلْعَبْ بَعِيداً يَا شَاطِرْ.. الـمُطَوِّرُ خَطٌّ أَحْمَرُ، رُوحْ اِشْنُقْ حَالُكْ أَحْسَن لَكْ! 😂",
      "💀 ┃ حَاوَلْتَ شَنْقَ الـمَلِكِ فَارْتَدَّتِ الـمِشْنَقَةُ عَلَى رَقَبَتِكَ.. اِلْزَمْ حُدُودَكَ مَعَ الـمُطَوِّرِ عَبْدُو!"
    ];
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    return api.sendMessage(randomResponse, threadID, messageID);
  }

  const pathImg = path.join(cacheDir, `hang_${senderID}_${targetID}.png`);
  api.sendMessage("💀 ┃ جَـارِي تَـحْـضِـيرُ الـمِـشْـنَـقَةِ الـمَـلَـكِـيَّـة . . .", threadID, messageID);

  try {
    const token = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662";
    const avtSender = `https://graph.facebook.com/${senderID}/picture?width=512&height=512&access_token=${token}`;
    const avtTarget = `https://graph.facebook.com/${targetID}/picture?width=512&height=512&access_token=${token}`;

    const [bg, imgOneBuf, imgTwoBuf] = await Promise.all([
      jimp.read("https://i.postimg.cc/brq6rDDB/received-1417994055426496.jpg"),
      circle(avtSender),
      circle(avtTarget)
    ]);

    const imgOne = await jimp.read(imgOneBuf);
    const imgTwo = await jimp.read(imgTwoBuf);

    bg.composite(imgOne.resize(150, 150), 100, 50)
      .composite(imgTwo.resize(120, 120), 350, 80);

    const buffer = await bg.getBufferAsync(jimp.MIME_PNG);
    fs.writeFileSync(pathImg, buffer);

    const nameTarget = await Users.getNameUser(targetID);
    
    const msg = {
      body: `━━━━━━━━━━━━━━━\n💀 ┃ وِدَاعًــا يَـا ${nameTarget}!\n━━━━━━━━━━━━━━━\nتَـمَّ تَـنْـفِيـذُ الـحُـكْـمِ بِنَجَاحٍ. ✅`,
      attachment: fs.createReadStream(pathImg)
    };

    return api.sendMessage(msg, threadID, () => {
      if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ لِـلأَسَـفِ تَعَذَّرَ تَجْهِيزُ المِشْنَقَةِ الآن.", threadID, messageID);
  }
};