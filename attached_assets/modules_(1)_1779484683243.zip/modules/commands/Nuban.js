module.exports.config = {
  name: "نوبان",
  version: "2.0.0",
  hasPermssion: 2,
  credits: "RIO BOOT",
  description: "نظام فك الحظر الشامل (مجموعات/مستخدمين/مدراء)",
  commandCategory: "المطور",
  usages: "[المجموعه / السيرفر / @تاغ / المدراء / الخادم]",
  cooldowns: 2
};

module.exports.run = async ({ event, api, Users, Threads, args }) => {
  const { threadID, messageID, senderID, mentions } = event;

  // زخرفة الهيدر
  const header = "🔓 ═══ ﴿ مَـرْكَـز فـكّ الـحَـظْـر ﴾ ═══ 🔓\n\n";

  switch (args[0]) {
    case 'ادمن':
      {
        const listAdmin = global.config.ADMINBOT;
        for (var idad of listAdmin) {
          const data = (await Users.getData(idad)).data || {};
          data.banned = 0;
          data.reason = null;
          await Users.setData(idad, { data });
          global.data.userBanned.delete(idad);
        }
        api.sendMessage(`${header}✅ تم إلغاء الحظر عن جميع مطوري البوت بنجاح.`, threadID, messageID);
        break;
      }

    case 'سيرفر':
    case 'المجموعات':
      {
        const threadBanned = global.data.threadBanned.keys();
        for (const singleThread of threadBanned) {
          const data = (await Threads.getData(singleThread)).data || {};
          data.banned = 0;
          data.reason = null;
          await Threads.setData(singleThread, { data });
          global.data.threadBanned.delete(singleThread);
        }
        api.sendMessage(`${header}✅ تم فك الحظر عن جميع المجموعات المحظورة في السيرفر.`, threadID, messageID);
        break;
      }

    case 'المجموعه':
    case 'المجموعة':
    case 'هنا':
      {
        var idbox = threadID;
        var data = (await Threads.getData(idbox)).data || {};
        data.banned = 0;
        data.reason = null;
        await Threads.setData(idbox, { data });
        global.data.threadBanned.delete(idbox);
        api.sendMessage(`${header}✅ تم فك الحظر عن هذه المجموعة بنجاح.`, threadID, messageID);
        break;
      }

    case 'الخادم':
    case 'المستخدمين':
      {
        const userBanned = global.data.userBanned.keys();
        for (const singleUser of userBanned) {
          const data = (await Users.getData(singleUser)).data || {};
          data.banned = 0;
          data.reason = null;
          await Users.setData(singleUser, { data });
          global.data.userBanned.delete(singleUser);
        }
        api.sendMessage(`${header}✅ تم فك الحظر عن جميع المستخدمين المحظورين في الخادم.`, threadID, messageID);
        break;
      }

    case 'مدراء':
      {
        const threadInfo = (await Threads.getData(threadID)).threadInfo;
        const listQTV = threadInfo.adminIDs;
        for (let i = 0; i < listQTV.length; i++) {
          const idQtv = listQTV[i].id;
          const data = (await Users.getData(idQtv)).data || {};
          data.banned = 0;
          await Users.setData(idQtv, { data });
          global.data.userBanned.delete(idQtv);
        }
        api.sendMessage(`${header}✅ تم فك الحظر عن جميع مسؤولي هذه المجموعة.`, threadID, messageID);
        break;
      }

    default:
      {
        // فك الحظر عن طريق التاغ أو الرد
        if (Object.keys(mentions).length > 0 || event.type == "message_reply") {
          const targetIDs = event.type == "message_reply" ? [event.messageReply.senderID] : Object.keys(mentions);
          
          for (let id of targetIDs) {
            const data = (await Users.getData(id)).data || {};
            data.banned = 0;
            data.reason = null;
            await Users.setData(id, { data });
            global.data.userBanned.delete(id);
          }
          
          return api.sendMessage(`${header}✅ تم فك الحظر عن المستخدم(ين) المحدد بنجاح.`, threadID, messageID);
        }
        
        // رسالة المساعدة في حال لم يتم إدخال وسيط صحيح
        const helpMsg = `${header}📍 يرجى تحديد نوع فك الحظر:\n` +
          `━━━━━━━━━━━━━━━\n` +
          `➊ ┋ [نوبان هنا] : لفك حظر المجموعة الحالية.\n` +
          `➋ ┋ [نوبان سيرفر] : لفك حظر جميع المجموعات.\n` +
          `➌ ┋ [نوبان الخادم] : لفك حظر جميع المستخدمين.\n` +
          `➍ ┋ [نوبان مدراء] : لفك حظر أدمنية المجموعة.\n` +
          `➎ ┋ [نوبان @تاغ] : لفك حظر شخص محدد.`;
        
        api.sendMessage(helpMsg, threadID, messageID);
        break;
      }
  }
};
