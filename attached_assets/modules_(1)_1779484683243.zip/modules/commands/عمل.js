module.exports.config = {
  name: "عمل",
  version: "1.0.1",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "اعمل واكسب المال مع تفاعل الحقيبة على رسالتك",
  commandCategory: "إقتصاد",
  usages: "",
  cooldowns: 0 
};

module.exports.run = async function ({ api, event, Currencies, Users }) {
  const { threadID, messageID, senderID } = event;
  const cooldownTime = 9 * 60 * 60 * 1000; 
  
  const jobs = [
    "مطور بوتات محترف",
    "طيار في الخطوط الجوية الملكية",
    "مهندس برمجيات في جوجل",
    "طبيب جراح",
    "صياد سمك في أعالي البحار",
    "رائد فضاء في ناسا",
    "شيف في مطعم 5 نجوم",
    "مدرس لغة عربية",
    "حارس شخصي لكبار الشخصيات",
    "عامل منجم ذهب",
    "سائق فورمولا 1",
    "مصمم جرافيك فريلانس",
    "مزارع في قرية هادئة",
    "محامي دفاع",
    "عامل بناء ناطحات سحاب",
    "مبرمج بلغة جافا سكريبت",
    "صانع محتوى على يوتيوب",
    "مدرب رياضي",
    "بائع مجوهرات",
    "عالم آثار"
  ];

  let data = (await Currencies.getData(senderID)).data || {};
  
  if (typeof data.workTime !== "undefined" && cooldownTime - (Date.now() - data.workTime) > 0) {
    const time = cooldownTime - (Date.now() - data.workTime);
    const hours = Math.floor(time / (60 * 60 * 1000));
    const minutes = Math.floor((time % (60 * 60 * 1000)) / (60 * 1000));
    return api.sendMessage(`⚠️ ┃ يـا مـكـافـح، أنـت مـتـعب الآن!\n\n👈 ┃ يـمـكنـك الـعـودة لـلـعـمل بـعـد: ${hours} سـاعة و ${minutes} دقـيـقـة.`, threadID, messageID);
  }

  // التفاعل بحقيبة العمل على رسالة المرسل فوراً
  api.setMessageReaction("💼", messageID, (err) => {}, true);

  const job = jobs[Math.floor(Math.random() * jobs.length)];
  const salary = Math.floor(Math.random() * 1900) + 1;
  const name = await Users.getNameUser(senderID);

  await Currencies.increaseMoney(senderID, salary);
  data.workTime = Date.now();
  await Currencies.setData(senderID, { data });

  const msg = 
    `┏━━━━━━━━━━━━━━┓\n` +
    `  💼 ┃ سـجـل الـعـمـل الـيـومـي\n` +
    `┗━━━━━━━━━━━━━━┛\n\n` +
    `👤 ┃ الـعـامـل: ${name}\n` +
    `🛠️ ┃ الـمـهـنـة: ${job}\n` +
    `💰 ┃ الـراتـب: ${salary} دولار\n\n` +
    `✨ ┃ تـم إيـداع الـمبـلـغ فـي مـحـفـظـتـك بـنـجـاح.\n` +
    `━━━━━━━━━━━━━━━\n` +
    `👑 ┃ الـمـطـور: عـبـدو | 🤖 ┃ ريـو`;

  return api.sendMessage(msg, threadID, messageID);
};
