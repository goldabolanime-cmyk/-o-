const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "كوسبلاي",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "جَـلْـبُ صُـورَةِ كُـوسْـبْـلَايِ أَنِـمِي عَـشْـوَائِيَّـةٍ مُـتَـغَـيِّـرَةٍ",
  commandCategory: "الوسائط",
  usages: " ",
  cooldowns: 3, // نقصت الكول داون باش تقدر تجرب بزاف
  aliases: ["ازياء", "cosplay"]
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, senderID } = event;

  // إرسال تفاعل باش يعرف المستخدم أن البوت خدام
  api.setMessageReaction("✨", messageID, () => {}, true);

  try {
    const cachePath = path.join(__dirname, "cache");
    if (!fs.existsSync(cachePath)) fs.mkdirSync(cachePath, { recursive: true });

    // اسم الملف متميز بـ timestamp باش ما يوقعش تداخل
    const imgPath = path.join(cachePath, `cosplay_${senderID}_${Date.now()}.jpg`);

    // المحرك السريع مع كلمة دلالية محددة وقفل عشوائي (lock) لضمان تغير الصورة كل مرة
    const targetUrl = `https://loremflickr.com/800/1200/anime,cosplay,girl/all?lock=${Math.floor(Math.random() * 100000)}`;

    const res = await axios.get(targetUrl, { 
      responseType: "arraybuffer",
      timeout: 15000 
    });

    fs.writeFileSync(imgPath, Buffer.from(res.data));

    const msg = {
      body: `┏━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑪𝑶𝑺𝑷𝑳𝑨𝒀 𝑺𝒀𝑺𝑻𝑬𝑴 ♛\n┗━━━━━━━━━━━━━━━━━┛\n\n✨ ┃ تَـمَّ جَـلْـبُ صُـورَةِ اَلْـكُـوسْـبْـلَايِ بِنَـجَـاحٍ\n━━━━━━━━━━━━━━━\n👑 ┃ اَلْـمُـطَـوِّرُ اَلْـمَـلَـكِي: عـبـدو`,
      attachment: fs.createReadStream(imgPath)
    };

    return api.sendMessage(msg, threadID, () => {
      // حذف الصورة من الكاش مباشرة للحفاظ على المساحة
      if (fs.existsSync(imgPath)) fs.unlinkSync(imgPath);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ عُـذْراً سَـيِّـدِي عـبـدو، فَـشَـلَ اَلِاتِّـصَـالُ بـسِـيرفَـرِ اَلـصُّـوَرِ.", threadID, messageID);
  }
};