module.exports.config = {
  name: "اكس_او",
  version: "3.5.0",
  hasPermssion: 0,
  credits: "عمر & عبدو",
  description: "لعبة إكس أو ملكية مع ذكاء اصطناعي وحذف تلقائي للرسائل",
  commandCategory: "العاب",
  cooldowns: 5,
  usages: "اكس_او [x/o] | بالرد على صديق للتحدي"
};

if (!global.xo) global.xo = new Map();

const numberEmojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"];

function checkWinner(board) {
  const lines = [
    [[0,0],[0,1],[0,2]], [[1,0],[1,1],[1,2]], [[2,0],[2,1],[2,2]], 
    [[0,0],[1,0],[2,0]], [[0,1],[1,1],[2,1]], [[0,2],[1,2],[2,2]], 
    [[0,0],[1,1],[2,2]], [[0,2],[1,1],[2,0]]
  ];
  for (let line of lines) {
    const [a, b, c] = line;
    if (board[a[0]][a[1]] !== 0 && board[a[0]][a[1]] === board[b[0]][b[1]] && board[a[0]][a[1]] === board[c[0]][c[1]]) {
      return board[a[0]][a[1]];
    }
  }
  return board.flat().includes(0) ? null : "tie";
}

function getBestMove(board) {
  let availableMoves = [];
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[i][j] === 0) availableMoves.push({i, j});
    }
  }
  return availableMoves[Math.floor(Math.random() * availableMoves.length)];
}

function renderBoard(board, p1Sym, p2Sym) {
  let text = "┏━━━━━━┓\n";
  for (let i = 0; i < 3; i++) {
    text += "┃ ";
    for (let j = 0; j < 3; j++) {
      let val = board[i][j];
      if (val === 0) text += numberEmojis[i * 3 + j];
      else if (val === 2) text += (p1Sym === "x" ? "❌" : "⭕");
      else text += (p2Sym === "x" ? "❌" : "⭕");
    }
    text += " ┃\n";
  }
  text += "┗━━━━━━┛";
  return text;
}

module.exports.handleReply = async function({ api, event, handleReply, Users, Currencies }) {
  const { threadID, messageID, senderID, body } = event;
  let gameData = global.xo.get(threadID);
  
  if (!gameData || gameData.gameOver || (senderID !== gameData.player1 && senderID !== gameData.player2)) return;
  if (senderID !== gameData.turn) return api.sendMessage("⏳ ┇ انْتَظِرْ دَوْرَكَ يَا مَلِكُ!", threadID, messageID);

  const move = parseInt(body);
  if (isNaN(move) || move < 1 || move > 9) return;

  const row = Math.floor((move - 1) / 3);
  const col = (move - 1) % 3;

  if (gameData.board[row][col] !== 0) return;

  // حذف الرسالة السابقة لتنظيف الدردشة
  if (gameData.lastMsgID) api.unsendMessage(gameData.lastMsgID);

  // حركة اللاعب الحالي
  gameData.board[row][col] = (senderID === gameData.player1) ? 2 : 1;
  let result = checkWinner(gameData.board);

  if (result) return await finishGame(api, threadID, gameData, result, Users, Currencies);

  // تبديل الأدوار أو لعب البوت
  if (gameData.player2 === "BOT") {
    let botMove = getBestMove(gameData.board);
    gameData.board[botMove.i][botMove.j] = 1;
    result = checkWinner(gameData.board);
    if (result) return await finishGame(api, threadID, gameData, result, Users, Currencies);
  } else {
    gameData.turn = (gameData.turn === gameData.player1) ? gameData.player2 : gameData.player1;
  }

  const nameTurn = gameData.turn === "BOT" ? "الْبُوت الذَّكِي" : (await Users.getData(gameData.turn)).name;
  const msg = `🎮 ┇ تَحَدِّي الْمُلُوكِ\n━━━━━━━━━━━━━━━\n${renderBoard(gameData.board, gameData.p1Sym, gameData.p2Sym)}\n━━━━━━━━━━━━━━━\n👤 ┃ دَوْرُ: [ ${nameTurn} ]\n📝 ┃ أَرْسِلْ رَقْمَ الْمُرَبَّعِ لِلتَّحَرُّكِ.`;
  
  api.sendMessage(msg, threadID, (err, info) => {
    gameData.lastMsgID = info.messageID;
    api.setReply({
        name: this.config.name,
        messageID: info.messageID,
        author: gameData.turn
    });
  });
};

async function finishGame(api, threadID, gameData, winner, Users, Currencies) {
  gameData.gameOver = true;
  let name1 = (await Users.getData(gameData.player1)).name;
  let name2 = gameData.player2 === "BOT" ? "الْبُوت الذَّكِي" : (await Users.getData(gameData.player2)).name;
  let msg = "";

  if (winner === "tie") {
    msg = `🤝 ┇ تَعَادُلٌ مَلَكِيّ! لاَ رَابِحَ وَلاَ خَاسِرَ.`;
  } else {
    let winnerID = winner === 2 ? gameData.player1 : gameData.player2;
    let loserID = winner === 2 ? gameData.player2 : gameData.player1;
    let winnerName = winner === 2 ? name1 : name2;
    
    msg = `🎊 ┇ تَهَانِينَا يَا [ ${winnerName} ]!\n💰 ┇ تَمَّتْ تَسْوِيَةُ الرِّهَانِ (200$).`;
    
    if (winnerID !== "BOT") await Currencies.increaseMoney(winnerID, 200);
    if (loserID !== "BOT") await Currencies.increaseMoney(loserID, -200);
  }

  api.sendMessage(`${renderBoard(gameData.board, gameData.p1Sym, gameData.p2Sym)}\n━━━━━━━━━━━━━━━\n${msg}`, threadID);
  global.xo.delete(threadID);
}

module.exports.run = async function ({ api, event, args, Users, Currencies }) {
  const { threadID, messageID, senderID, type, messageReply } = event;

  if (args[0] == "مسح") {
    global.xo.delete(threadID);
    return api.sendMessage("🛑 ┇ تَمَّ إِنْهَاءُ اللَّعِبِ وَتَصْفِيرُ الطَّاوِلَةِ.", threadID, messageID);
  }

  let opponentID = type === "message_reply" ? messageReply.senderID : "BOT";
  if (opponentID == senderID) return api.sendMessage("⚠️ ┇ لاَ يُمْكِنُكَ تَحَدِّي نَفْسِكَ!", threadID, messageID);

  let userData = await Currencies.getData(senderID);
  if (userData.money < 200) return api.sendMessage("💸 ┇ رَصِيدُكَ أَقَلُّ مِنْ 200$!", threadID, messageID);

  let p1Sym = (args[0] || "x").toLowerCase() === "o" ? "o" : "x";
  let p2Sym = p1Sym === "x" ? "o" : "x";

  let gameData = {
    board: [[0, 0, 0], [0, 0, 0], [0, 0, 0]],
    player1: senderID,
    player2: opponentID,
    p1Sym, p2Sym,
    turn: senderID,
    gameOver: false,
    lastMsgID: null
  };

  global.xo.set(threadID, gameData);
  let name1 = (await Users.getData(senderID)).name;
  let name2 = opponentID === "BOT" ? "الْبُوت الذَّكِي" : (await Users.getData(opponentID)).name;

  let msg = `🎮 ┇ تَحَدِّي الْمُلُوكِ (رِهَان 200$)\n━━━━━━━━━━━━━━━\n${renderBoard(gameData.board, p1Sym, p2Sym)}\n━━━━━━━━━━━━━━━\n👤 ┃ [ ${name1} ]: ${p1Sym.toUpperCase()}\n👤 ┃ [ ${name2} ]: ${p2Sym.toUpperCase()}\n━━━━━━━━━━━━━━━\n📝 ┃ قُمْ بِالرَّدِّ عَلَى هَذِهِ الرِّسَالَةِ بِرَقْمِ الْمُرَبَّعِ.`;

  api.sendMessage(msg, threadID, (err, info) => {
    gameData.lastMsgID = info.messageID;
    api.setReply({
      name: this.config.name,
      messageID: info.messageID,
      author: senderID
    });
  }, messageID);
};
