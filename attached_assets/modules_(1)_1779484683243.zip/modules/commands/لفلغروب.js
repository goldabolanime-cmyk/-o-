module.exports.config = {
  name: "لفل_قروب",
  version: "1.5.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "عرض إحصائيات وتفاعل المجموعة بصرياً مع الصورة",
  commandCategory: "إحصائيات",
  usages: "",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, Threads }) {
  const { threadID, messageID } = event;
  const fs = require("fs-extra");
  const axios = require("axios");

  try {
    // 1. جلب بيانات المجموعة
    const threadInfo = await api.getThreadInfo(threadID);
    const { threadName, messageCount, imageSrc } = threadInfo;

    // 2. حساب المستويات (كل لفل 500 رسالة)
    const level = Math.floor(messageCount / 500) + 1;
    const progress = (messageCount % 500) / 500;
    const nextLevelMessages = level * 500;

    // 3. تصميم شريط الطاقة البصري
    const totalBars = 10;
    const filledBars = Math.round(progress * totalBars);
    const emptyBars = totalBars - filledBars;
    const progressBar = "▓".repeat(filledBars) + "░".repeat(emptyBars);

    // 4. تحديد الرتبة
    let rank = "";
    if (level < 5) rank = "🥉 | بـدايـة الـطـريـق";
    else if (level < 15) rank = "🥈 | مـجـمـوعـة نـشـطـة";
    else if (level < 30) rank = "🥇 | قـلـعة الـتـفاعـل";
    else if (level < 50) rank = "💎 | الـنـخـبـة الـملـكـية";
    else rank = "🔥 | أسطـورة ريـو بـوت";

    // 5. تجهيز الرسالة المزخرفة
    const msgBody = 
      `┏━━━━━━━ ● ● ━━━━━━━┓\n` +
      `   📊 ┃ إحـصـائـيـات الـمـجـمـوعـة\n` +
      `┗━━━━━━━ ● ● ━━━━━━━┛\n\n` +
      `📝 ┃ الاسـم: ${threadName || "مجموعة غير مسمى"}\n` +
      `🆔 ┃ الأيـدي: ${threadID}\n` +
      `🏆 ┃ الـرتـبـة: ${rank}\n` +
      `⭐ ┃ الـمـسـتـوى: [ ${level} ]\n` +
      `💬 ┃ الـرسـائل: ${messageCount}\n\n` +
      `🛡️ ┃ شـريـط الـخـبـرة:\n` +
      `[ ${progressBar} ] ${Math.floor(progress * 100)}%\n\n` +
      `✨ ┃ يـتـبـقـى [ ${nextLevelMessages - messageCount} ] رسـالـة لـلـفـل ${level + 1}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `👑 ┃ الـمـطـور: عـبـدو | 🤖 ┃ ريـو`;

    // 6. التعامل مع صورة المجموعة وإرسالها
    if (imageSrc) {
      const pathImg = __dirname + `/cache/${threadID}_group.png`;
      const getImg = (await axios.get(imageSrc, { responseType: "arraybuffer" })).data;
      fs.writeFileSync(pathImg, Buffer.from(getImg, "utf-8"));

      return api.sendMessage({
        body: msgBody,
        attachment: fs.createReadStream(pathImg)
      }, threadID, () => fs.unlinkSync(pathImg), messageID);
    } else {
      // إذا لم يكن هناك صورة للمجموعة يرسل النص فقط
      return api.sendMessage(msgBody, threadID, messageID);
    }

  } catch (e) {
    console.log(e);
    return api.sendMessage("❌ ┃ عـذراً، حدث خطأ أثناء جلب بيانات المجموعة.", threadID, messageID);
  }
};
