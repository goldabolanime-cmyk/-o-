module.exports.config = {
  name: "قتال",
  version: "3.2.0",
  hasPermssion: 0,
  credits: "عبدو & ريو بوت",
  description: "نظام قتال ملحمي مع تحولات وشروط قاسية ونظام خمول",
  commandCategory: "العاب",
  usages: "[الرد على الخصم]",
  cooldowns: 5
};

function createBar(current, max) {
  let percentage = Math.max(0, Math.min(current, max)) / max;
  let progress = Math.round(10 * percentage);
  return "█".repeat(progress) + "░".repeat(10 - progress);
}

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID != handleReply.turn) return;

  // إلغاء مؤقت الخمول السابق بمجرد الرد
  if (handleReply.timeoutID) clearTimeout(handleReply.timeoutID);

  // حذف الرسالة السابقة لتنظيف الدردشة
  api.unsendMessage(handleReply.messageID);

  let { p1, p2, turn } = handleReply;
  let attacker = (turn == p1.id) ? p1 : p2;
  let defender = (turn == p1.id) ? p2 : p1;
  let msg = "";
  let input = body.toLowerCase();
  const forms = ["ملك الظل", "سلطان الزمان", "امبراطور السماء", "الفارس الأسطوري"];

  switch (input) {
    case "هجوم":
      if (attacker.energy < 10) return api.sendMessage("⚠️ طاقة غير كافية للهجوم!", threadID, messageID);
      let dmg = Math.floor(Math.random() * 40) + 10;
      defender.hp = Math.max(0, defender.hp - dmg);
      attacker.energy = Math.min(100, attacker.energy + 15);
      msg = `🗡️ ${attacker.name} وجه ضربة قاضية نحو ${defender.name}!`;
      break;

    case "مهارة":
      if (attacker.energy < 40) return api.sendMessage("⚠️ مهاراتك تحتاج 40 طاقة على الأقل!", threadID, messageID);
      let sDmg = Math.floor(Math.random() * 30) + 30;
      defender.hp = Math.max(0, defender.hp - sDmg);
      attacker.energy -= 40;
      msg = `✨ ${attacker.name} استدعى قوى الطبيعة ودمر دفاعات ${defender.name}!`;
      break;

    case "التميت":
      if (attacker.energy < 100) return api.sendMessage("⚠️ الـULTIMATE يتطلب طاقة كاملة 100%!", threadID, messageID);
      defender.hp = Math.max(0, defender.hp - 70);
      attacker.energy = 0;
      msg = `💥 ${attacker.name} أطلق الانفجار العظيم! هجوم لا يمكن صده!`;
      break;

    case "تحول":
      if (attacker.energy < 100 || attacker.hp > 50) return api.sendMessage("⚠️ شروط التحول العظيم: (100 طاقة) و (دم أقل من 50)!", threadID, messageID);
      attacker.hp = 100;
      attacker.energy = 50;
      attacker.name = forms[Math.floor(Math.random() * forms.length)] + " " + attacker.name;
      msg = `🔥 أساطير الكون تستجيب! تحول ${attacker.name} الآن لشكله المطلق!`;
      break;

    case "شحن":
      attacker.energy = Math.min(attacker.energy + 45, 100);
      msg = `🔋 ${attacker.name} يتنفس بعمق ويستجمع طاقته الداخلية..`;
      break;

    case "استسلام":
      global.xo.delete(threadID); // إنهاء الجلسة
      return api.sendMessage(`🏳️ انسحب ${attacker.name} من الساحة! أعلن فوز ${defender.name} بالهيبة.`, threadID);

    default: 
      return api.sendMessage("❌ أمر مجهول! اختر: (هجوم - مهارة - التميت - تحول - شحن - استسلام)", threadID, messageID);
  }

  if (defender.hp <= 0) {
    await Currencies.increaseMoney(attacker.id, 200);
    return api.sendMessage(`
┏━━━━━━━━━━━━━━━━━━┓
   🛡️ نـهـايـة الـمـلـحـمـة 🛡️
┗━━━━━━━━━━━━━━━━━━┛

🎊 الـمـنـتـصـر: ${attacker.name}
💰 الـجـائـزة: 200 عـمـلـة ذهـبـيـة

لقد أثبت ${attacker.name} أنه الأقوى في الساحة! 👑
`, threadID);
  }

  handleReply.turn = defender.id;
  
  let status = `
┏━━━━━━━━━━━━━━━━━━┓
   ⚔️ سـاحـة الأبـاطـرة ⚔️
┗━━━━━━━━━━━━━━━━━━┛
💬 ${msg}
━━━━━━━━━━━━━━━
👤 ${p1.name}
❤️ [${createBar(p1.hp, 100)}] ${p1.hp}%
⚡ [${createBar(p1.energy, 100)}] ${p1.energy}%
━━━━━━━━━━━━━━━
       ⚔️ V S ⚔️
━━━━━━━━━━━━━━━
👤 ${p2.name}
❤️ [${createBar(p2.hp, 100)}] ${p2.hp}%
⚡ [${createBar(p2.energy, 100)}] ${p2.energy}%
━━━━━━━━━━━━━━━
👑 الاستحواذ حالياً لـ : 【 ${defender.name} 】
⏰ المهلة: 2 دقيقة للرد!
`;

  // إعداد مؤقت الخمول (2 دقيقة)
  const timeoutID = setTimeout(async () => {
    await Currencies.increaseMoney(p1.id, -40);
    await Currencies.increaseMoney(p2.id, -40);
    api.sendMessage(`⏳ انتهت المعركة بسبب قلة النشاط! تم سحب 40$ من كلا اللاعبين كغرامة للملل.`, threadID);
    const index = global.client.handleReply.findIndex(item => item.messageID == handleReply.messageID);
    if (index !== -1) global.client.handleReply.splice(index, 1);
  }, 120000);

  return api.sendMessage(status, threadID, (err, info) => {
    handleReply.messageID = info.messageID;
    handleReply.timeoutID = timeoutID;
    global.client.handleReply.push(handleReply);
  }, messageID);
};

module.exports.run = async function ({ api, event, Users }) {
  const { threadID, messageID, senderID, type, messageReply } = event;
  if (type != "message_reply") return api.sendMessage("⚠️ يجب الرد على الخصم لإعلان التحدي!", threadID, messageID);
  
  const p2_id = messageReply.senderID;
  if (senderID == p2_id) return api.sendMessage("⚠️ هل تحاول قتال ظلك؟ لا يمكنك قتال نفسك يا بطل!", threadID, messageID);

  const p1_name = await Users.getNameUser(senderID);
  const p2_name = await Users.getNameUser(p2_id);

  const data = {
    p1: { id: senderID, name: p1_name, hp: 100, energy: 50 },
    p2: { id: p2_id, name: p2_name, hp: 100, energy: 50 },
    turn: p2_id
  };

  let intro = `
┏━━━━━━━━━━━━━━━━━━┓
   ⚔️ إعـلان الـتـحدي ⚔️
┗━━━━━━━━━━━━━━━━━━┛
🔱 الـمـقـاتل 1: ${p1_name}
🔱 الـمـقـاتل 2: ${p2_name}
━━━━━━━━━━━━━━━
📜 قـوانـيـن الـحـلبـة:
• الـفـائز يـحـصل عـلى 200 عـملة.
• الـتـحول مـتـاح عند (الطاقة 100 & الدم < 50).
• الخمول لأكثر من دقيقتين يكلفك 40$.
━━━━━━━━━━━━━━━
🔥 الاستحواذ حالياً لـ : 【 ${p2_name} 】
رد عـلى هـذه الـرسـالـة بـحـركـتـك..
`;

  const timeoutID = setTimeout(async () => {
    await Currencies.increaseMoney(senderID, -40);
    await Currencies.increaseMoney(p2_id, -40);
    api.sendMessage(`⏳ انتهت المعركة قبل أن تبدأ! تم سحب 40$ من الطرفين بسبب الخمول.`, threadID);
  }, 120000);

  return api.sendMessage(intro, threadID, (err, info) => {
    global.client.handleReply.push({
      name: this.config.name,
      messageID: info.messageID,
      p1: data.p1,
      p2: data.p2,
      turn: data.turn,
      timeoutID: timeoutID
    });
  }, messageID);
};