module.exports.config = {
  name: "تصفية",
  version: "6.0.0",
  hasPermssion: 1, 
  credits: "عبدو / RIO BOT",
  description: "تَصْفِيَةُ اَلْـحِسَـابَاتِ اَلْـمُعَـطَّلَةِ (Facebook User) لِـلْإِصْـدَارَاتِ اَلْـقَدِيـمَةِ",
  commandCategory: "الحماية",
  usages: "تصفية",
  cooldowns: 15
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID } = event;

  try {
    // جلب معلومات المجموعة
    api.getThreadInfo(threadID, (err, threadInfo) => {
      if (err) return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي جَـلْبِ بَيَـانَاتِ اَلْـمَجْـمُوعَـةِ.", threadID, messageID);

      const { participantIDs, adminIDs } = threadInfo;
      const botID = api.getCurrentUserID();
      
      // التأكد من أن البوت مسؤول
      if (!adminIDs.some(e => e.id == botID)) {
        return api.sendMessage("⚠️ ┃ يَـجِبُ أَنْ أَكُـونَ مَـسْـؤُولاً (ADMIN) لِأَتَـمَكَّـنَ مِـنَ اَلـطَّـرْدِ.", threadID, messageID);
      }

      let count = 0;
      let total = participantIDs.length;

      api.sendMessage("⏳ ┃ جَـارِي بَـدْءُ اَلـتَّـصْـفِيَـةِ اَلْـقَـدِيـمَةِ لِـلْـحِسَـابَاتِ اَلْـمُعَـطَّلَةِ . . .", threadID);

      // مصفوفة لحفظ المعطلين الذين سيتم طردهم
      let toKick = [];

      api.getUserInfo(participantIDs, (err, userInfos) => {
        if (err) return api.sendMessage("❌ ┃ فَـشَـلَ اَلـنِّـظَـامُ فِـي رَصْـدِ اَلْـمُسْـتَخْـدِمِيـنَ.", threadID, messageID);

        for (const uid in userInfos) {
          const user = userInfos[uid];
          // الفحص التقليدي للحسابات الطائرة
          if (user.name == "Facebook User" || !user.name || user.name.trim() === "") {
            toKick.push(uid);
          }
        }

        if (toKick.length === 0) {
          return api.sendMessage("✨ ┃ لَا تُـوجَدُ حِـسَـابَاتٌ مُـعَـطَّلَةٌ فِـي اَلْـمَجْـمُوعَـةِ حَـالِيّـاً.", threadID, messageID);
        }

        // تنفيذ الطرد واحد تلو الآخر باستخدام Callback لتجنب الـ Crash
        let i = 0;
        function nextKick() {
          if (i < toKick.length) {
            api.removeUserFromGroup(toKick[i], threadID, (err) => {
              if (!err) count++;
              i++;
              setTimeout(nextKick, 1500); // تأخير 1.5 ثانية للأمان
            });
          } else {
            // الانتهاء وعرض النتائج
            const msg = `
┏━━━━━━━━━━━━━━━━━┓
   ♛ 𝑹𝑰𝑶 𝑳𝑬𝑮𝑨𝑪𝒀 𝑷𝑼𝑹𝑮𝑬 ♛
┗━━━━━━━━━━━━━━━━━┛

✅ ┃ اِنْـتَهَـتِ اَلـتَّصْـفِيَـةُ اَلـرَّسْـمِيَّـةُ.

📊 ┃ اَلـتَّـقْـرِيـرُ:
━━━━━━━━━━━━━━━
👤 ┃ إِجْـمَـالِي اَلْأَعْـضَـاءِ: [ ${total} ]
🚫 ┃ اَلْـمَـطْـرُودُونَ: [ ${count} ]
✨ ┃ اَلْـحَـالَةُ: تَـمَّ طَـهِيـرُ اَلْـمَجْـمُوعَـةِ.

━━━━━━━━━━━━━━━
👑 ┃ اَلْـمُطَـوِّرُ: عـبـدو`.trim();
            api.sendMessage(msg, threadID);
          }
        }

        nextKick();
      });
    });

  } catch (e) {
    return api.sendMessage("❌ ┃ حَـدَثَ عُـطْـلٌ تَـقْـنِيٌّ فِـي اَلـسِّـيـرْفَرِ.", threadID, messageID);
  }
};