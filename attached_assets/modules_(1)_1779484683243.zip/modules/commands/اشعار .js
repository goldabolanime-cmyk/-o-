const fs = require("fs-extra");

module.exports.config = {
  name: "إشعار",
  version: "1.6.0",
  hasPermssion: 2,
  credits: "RIO BOOT",
  description: "نظام إشعارات مطور - الرد محصور للمطور عبدو فقط",
  commandCategory: "نظام المطور",
  usages: "[النص]",
  cooldowns: 5
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  const devThreadID = "1345646303986676"; // آيدي مجموعة المطورين
  const adminID = "100090081489341"; // 👑 الآيدي الجديد الخاص بك (عبدو)

  // [1] استقبال الردود من المستخدمين وإرسالها لمجموعة المطورين
  if (handleReply.type == "sendNotification" || handleReply.type == "replyToUser") {
    if (threadID == devThreadID) return; 

    const name = (await api.getUserInfo(senderID))[senderID].name;
    const threadInfo = await api.getThreadInfo(threadID);
    const threadName = threadInfo.threadName || "مجموعة بدون اسم";
    
    api.sendMessage({
      body: `📩 | وصـلـك رد جـديـد:\n👤 | الإسـم: ${name}\n👥 | الـمـجـمـوعـة: ${threadName}\n🆔 | آيـدي الـمـجـمـوعـة: ${threadID}\n💬 | الـمـحـتـوى: ${body}\n\n━━━━━━━━━━━━━━\n[•] رد عـلى هـذه الـرسـالـة لـلإجـابة عـلـيـه.`,
    }, devThreadID, (err, info) => {
      if (err) return console.error(err);
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID, 
        targetThreadID: threadID,
        targetMessageID: messageID,
        type: "replyFromDev" 
      });
    });
  }

  // [2] توجيه رد المطور (أنت فقط) إلى المستخدم
  if (handleReply.type == "replyFromDev" && threadID == devThreadID) {
    // التحقق الدقيق باستخدام String لضمان الاستجابة
    if (String(senderID) !== String(adminID)) {
      return api.sendMessage("🚫 | عذراً، أنت لست المطور الأساسي (عبدو). لا يمكنك الرد على الإشعارات.", threadID, messageID);
    }

    api.sendMessage({
      body: `👑 ┃ إشـعـار مـن الـمـطـور ┃ 👑\n━━━━━━━━━━━━━━━\n\n💬 | الـرد:\n${body}\n\n━━━━━━━━━━━━━━━\n✨ | ريـو بـوت - RIO BOOT | ✨\n[•] يـمـكـنـك الـرد مـرة أخـرى لـلـتـواصـل.`,
      mentions: [{ tag: "المستخدم", id: handleReply.author }]
    }, handleReply.targetThreadID, (err, info) => {
      if (err) {
        api.sendMessage("❌ | فـشل إرسـال الـرد، قـد يكون البوت طُرد أو الدردشة مغلقة.", threadID, messageID);
      } else {
        api.sendMessage("✅ | تـم تـوصـيـل ردك بـنـجـاح إلـى الـمـسـتـخـدم.", threadID, messageID);
        global.client.handleReply.push({
          name: this.config.name,
          messageID: info.messageID,
          author: senderID,
          type: "replyToUser" 
        });
      }
    }, handleReply.targetMessageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const adminID = "100090081489341"; // الآيدي الجديد الخاص بك

  // التحقق من صلاحية التنفيذ (أنت فقط)
  if (String(senderID) !== String(adminID)) {
    return api.sendMessage("⚠️ | هذا الأمر مخصص فقط للمطور الأساسي (عبدو).", threadID, messageID);
  }

  if (!args[0]) return api.sendMessage("❌ | يا سيدي، اكتب النص الذي تريد نشره بعد الأمر.", threadID, messageID);

  const allThreads = await api.getThreadList(100, null, ["INBOX"]);
  const msg = args.join(" ");
  let count = 0;

  for (const thread of allThreads) {
    if (thread.isGroup && String(thread.threadID) !== String(threadID)) {
      api.sendMessage({
        body: `👑 ┃ إشـعـار مـن الـمـطـور ┃ 👑\n\n📢 | الـرسـالـة:\n━━━━━━━━━━━━━━━\n\n${msg}\n\n━━━━━━━━━━━━━━━\n✨ | ريـو بـوت - RIO BOOT | ✨\n💬 | رد عـلـى هـذه الـرسـالـة لـلـتـواصـل مـع الـمـطـور.`,
      }, thread.threadID, (err, info) => {
        if (info) {
          global.client.handleReply.push({
            name: this.config.name,
            messageID: info.messageID,
            author: senderID,
            type: "sendNotification"
          });
        }
      });
      count++;
    }
  }

  return api.sendMessage(`🚀 | جـاري إرسـال الإشـعـار إلـى ${count} مـجـمـوعـة بـواسطة الـمـطور عبدو..`, threadID, messageID);
};