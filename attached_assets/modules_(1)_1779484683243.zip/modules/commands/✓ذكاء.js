const axios = require('axios');

module.exports.config = {
    name: "ميكو",
    version: "3.0.0",
    hasPermssion: 0,
    credits: "عبدو / RIO BOOT",
    description: "ذكاء Meta AI (Llama 3) - يرد على الأسئلة",
    commandCategory: "ذكاء اصطناعي",
    usages: "[السؤال] أو فقط ميكو [السؤال]",
    cooldowns: 2
};

module.exports.handleEvent = async function ({ api, event }) {
    const { threadID, messageID, body, senderID } = event;
    if (!body || senderID == api.getCurrentUserID()) return;

    // إذا بدأت الرسالة بكلمة "ميكو" أو انتهت بـ "؟"
    if (body.toLowerCase().startsWith("ميكو") || body.trim().endsWith("؟") || body.trim().endsWith("?")) {
        const query = body.replace(/ميكو/g, "").trim();
        if (!query) return;

        return this.askMeta(api, event, query);
    }
};

module.exports.run = async function ({ api, event, args }) {
    const { threadID, messageID } = event;
    if (!args[0]) return api.sendMessage("🤖 | أنـا مـيـكـو (Meta AI).. اسـألـني أي شـيء الآن!", threadID, messageID);
    
    const query = args.join(" ");
    return this.askMeta(api, event, query);
};

module.exports.askMeta = async function (api, event, query) {
    const { threadID, messageID } = event;
    
    try {
        api.sendTypingIndicator(threadID);
        
        // رابط Meta AI (Llama 3) سريع جداً ومستقر
        const res = await axios.get(`https://api.sandipbaruwal.com/llama3-70b?prompt=${encodeURIComponent(query)}`);
        const reply = res.data.answer || res.data.result || res.data.reply;

        if (reply) {
            const decoratedReply = `—͟͟͞͞🍃 🗨️ مـيـكـو (𝐌𝐞𝐭𝐚 𝐀𝐈) يـجـيـب:\n\n${reply}\n\nȻĦȺŦ MƗꝀØᖫ✧🍃`;
            return api.sendMessage(decoratedReply, threadID, messageID);
        }
    } catch (error) {
        console.error("Meta AI Error:", error.message);
    }
};
