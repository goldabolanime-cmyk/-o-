const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
    name: "سيارة",
    version: "2.5.0",
    hasPermssion: 0,
    credits: "عبدو / RIO BOOT",
    description: "🎰 شراء سيارات فاخرة من قائمة عبدو الخاصة",
    commandCategory: "ألعاب",
    usages: ".سيارة / شراء",
    cooldowns: 5
};

// 📂 قاعدة بيانات السيارات الكاملة بروابطك الصحيحة 100%
const carsData = [
    { name: "Chevrolet Camaro Red", price: 6500, image: "https://i.postimg.cc/bvzbRSZP/chevrolet-camaro-coupe-muscle-car-red-car-hd-cars-HD.jpg", info: "وحش العضلات الأمريكي بلونه الأحمر الناري." },
    { name: "McLaren 720S Blue", price: 9200, image: "https://i.postimg.cc/qvGQ0TKD/772ebe0e93b9d934c992f867f998d0c5.jpg", info: "أناقة وسرعة لا تضاهى من مصنع ماكلارين." },
    { name: "Black Sports Car", price: 5800, image: "https://i.postimg.cc/B6RBNQWX/highspeed-black-sports-car-sunset-highway-653623-23707.jpg", info: "سيارة رياضية سوداء غامضة، مثالية للسرعة." },
    { name: "McLaren 765LT", price: 9800, image: "https://i.postimg.cc/mk0C3dHD/2021-Mc-Laren-765LT-4-780x470.jpg", info: "إصدار خاص ومحدود، قمة الأداء الرياضي." },
    { name: "McLaren W1", price: 8900, image: "https://i.postimg.cc/YSpgxLhN/Mclaren-W1-Arabs-Auto-akhbar-alsyarat-2-780x470.webp", info: "الجديد كلياً من ماكلارين، تكنولوجيا المستقبل." },
    { name: "McLaren Senna", price: 10000, image: "https://i.postimg.cc/Y9C6tL79/ef4fd60c-mclaren-senna-scale-model-4-780x405.jpg", info: "الأسطورة سينا، السيارة التي صُممت لتحطيم الأرقام." }
];

if (!global.rioCars) global.rioCars = new Map();

// --- نظام معالجة أحداث الشراء ---
module.exports.handleEvent = async function ({ api, event, Currencies }) {
    const { threadID, messageID, senderID, body } = event;
    if (!body) return;

    const input = body.toLowerCase();
    if (input === "شراء" || input === ".شراء") {
        const session = global.rioCars.get(senderID);
        if (!session) return;

        const userData = await Currencies.getData(senderID);
        const money = userData.money || 0;

        if (money < session.price) {
            return api.sendMessage(`⚠️ | رصـيـدك غـيـر كـافٍ يا بطل!\n💰 | الـثـمـن: ${session.price} 🇲🇦\n💸 | رصـيدك: ${money} 🇲🇦`, threadID, messageID);
        }

        return api.sendMessage(`🛒 | هـل تـريـد شـراء [ ${session.carName} ]؟\n💵 | الـثـمـن: ${session.price} 🇲🇦\n\n👍 | تـفـاعـل بـلايـك (Like) لـتـأكـيـد الـشـراء!`, threadID, (err, info) => {
            global.client.handleReaction.push({
                name: this.config.name,
                messageID: info.messageID,
                author: senderID,
                carName: session.carName,
                price: session.price
            });
        }, messageID);
    }
};

// --- الأمر الأساسي لعرض سيارة عشوائية ---
module.exports.run = async function ({ api, event, Currencies }) {
    const { threadID, messageID, senderID } = event;

    // اختيار عشوائي من المصفوفة لضمان التنوع
    const car = carsData[Math.floor(Math.random() * carsData.length)];
    global.rioCars.set(senderID, { carName: car.name, price: car.price });

    const path = __dirname + `/cache/car_rio_${senderID}.jpg`;

    try {
        const res = await axios.get(car.image, { responseType: "arraybuffer" });
        fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));

        return api.sendMessage({
            body: `✨ ━━━━━━━━━━━━━━━ ✨\n      🏎️ | سـيـارة الـيـوم مـن رِيـو\n✨ ━━━━━━━━━━━━━━━ ✨\n\n❯ الـنـوع: ${car.name}\n❯ الـوصـف: ${car.info}\n❯ الـسـعـر: ${car.price} 🇲🇦\n\n🛒 | لـلـشـراء، اكـتـب: شراء\n\n✨ ━━━━━━━━━━━━━━━ ✨`,
            attachment: fs.createReadStream(path)
        }, threadID, () => {
            if (fs.existsSync(path)) fs.unlinkSync(path);
        }, messageID);
    } catch (e) {
        console.error(e);
        return api.sendMessage("❌ | فشل في تحميل صورة السيارة، حاول مرة أخرى.", threadID, messageID);
    }
};

// --- معالجة التفاعل لإتمام عملية البيع ---
module.exports.handleReaction = async function ({ api, event, handleReaction, Currencies }) {
    const { threadID, userID, reaction, messageID } = event;
    if (reaction !== "👍" || userID !== handleReaction.author) return;

    try {
        const userData = await Currencies.getData(userID);
        const money = userData.money || 0;

        if (money < handleReaction.price) return api.sendMessage("⚠️ | رصيدك نقص فجأة! لم تعد تملك كلفة السيارة.", threadID, messageID);

        await Currencies.decreaseMoney(userID, handleReaction.price);

        let data = userData.data || {};
        if (!data.cars) data.cars = [];
        data.cars.push(handleReaction.carName);
        
        await Currencies.setData(userID, { data });

        api.unsendMessage(handleReaction.messageID);
        global.rioCars.delete(userID);
        
        return api.sendMessage(`🎊 | مـبـروك! لـقـد اشـتـريـت [ ${handleReaction.carName} ] بـنـجـاح ✅\n💰 | تم خصم ${handleReaction.price} 🇲🇦 من حسابك.\n📂 | تجدها الآن في قائمة ممتلكاتك!`, threadID, messageID);
    } catch (e) {
        console.log(e);
    }
};