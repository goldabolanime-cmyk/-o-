module.exports.config = {
    name: "بادئة",
    version: "1.1.0",
    hasPermssion: 0, // العرض للكل، لكن التغيير للمطور فقط داخل الكود
    credits: "عبدو",
    description: "عَـرْضُ أَوْ تَـغْـيِيـرُ بَـادِئَةِ اَلـنِّـظَـامِ",
    commandCategory: "إعدادات",
    usages: "[تغيير + الرمز]",
    cooldowns: 5,
    aliases: ["البريفيكس", "prefix"]
};

module.exports.run = async ({ api, event, args, Threads }) => {
    const { threadID, messageID, senderID } = event;
    const { PREFIX, ADMINBOT } = global.config; // ADMINBOT غالباً يحتوي على آيدي المطور
    
    // جلب بيانات المجموعة
    const threadData = await Threads.getData(threadID);
    const threadSetting = threadData.settings || {};
    const currentPrefix = threadSetting.PREFIX || PREFIX;

    // الحالة 1: عرض البادئة
    if (args.length == 0) {
        return api.sendMessage(
            `┏━━━━━━━━━━━━━━━━━━━━┓\n` +
            `   ♛ 𝑹𝑰𝑶 𝑷𝑹𝑬𝑭𝑰𝑿 𝑰𝑵𝑭𝑶 ♛\n` +
            `┗━━━━━━━━━━━━━━━━━━━━┛\n\n` +
            `🌐 ┃ بَـادِئَـةُ اَلـنِّـظَـامِ: 『 ${PREFIX} 』\n` +
            `🏘️ ┃ بَـادِئَـةُ اَلْـمَـجْـمُـوعَـةِ: 『 ${currentPrefix} 』\n\n` +
            `💡 ┃ لِـتَـغْـيِـيـرِ اَلْـبَـادِئَـةِ اِكْـتُـبْ:\n` +
            `👈 [ ${currentPrefix}بادئة تغيير ] + الرمز\n\n` +
            `🔱 ┃ اَلْـمُـطَـوِّرُ: عـبـدو`, 
            threadID, messageID
        );
    }

    // الحالة 2: تغيير البادئة (للمطور فقط)
    if (args[0] == "تغيير") {
        // التحقق من أن المرسل هو المطور (آيدي الخاص بك)
        // يمكنك استبدال global.config.ADMINBOT[0] بآيديك المباشر إذا لم تكن مضافة في التكوين
        if (!ADMINBOT.includes(senderID)) {
            return api.sendMessage("❌ ┃ عُـذراً، هَـذَا اَلْأَمْـرُ مَـحْـصُورٌ لِـلْـمُـطَـوِّرِ عـبـدو فَـقَـطْ.", threadID, messageID);
        }

        const newPrefix = args[1];
        if (!newPrefix) return api.sendMessage("❌ ┃ يُـرْجَى تَـحْـدِيـدُ اَلـرَّمْـزِ اَلْـجَـدِيـدِ.", threadID, messageID);
        
        // حفظ التغيير في القاعدة
        threadSetting.PREFIX = newPrefix;
        await Threads.setData(threadID, { settings: threadSetting });
        
        // تحديث البادئة في ذاكرة البوت الحالية لكي يعمل فوراً بدون ريستارت
        if (global.data.threadData.has(threadID)) {
            const data = global.data.threadData.get(threadID);
            data.PREFIX = newPrefix;
            global.data.threadData.set(threadID, data);
        }

        return api.sendMessage(
            `┏━━━━━━━━━━━━━━━━━━━━┓\n` +
            `   ♛ 𝑷𝑹𝑬𝑭𝑰𝑿 𝑼𝑷𝑫𝑨𝑻𝑬𝑫 ♛\n` +
            `┗━━━━━━━━━━━━━━━━━━━━┛\n\n` +
            `✅ ┃ تَـمَّ تَـغْـيِـيـرُ بَـادِئَـةِ اَلْـمَـجْـمُـوعَـةِ\n` +
            `🆕 ┃ اَلْـبَـادِئَـةُ اَلْـجَـدِيـدَةُ: 『 ${newPrefix} 』\n\n` +
            `🔱 ┃ بِـوَاسِـطَـةِ: عـبـدو`, 
            threadID, messageID
        );
    }
}