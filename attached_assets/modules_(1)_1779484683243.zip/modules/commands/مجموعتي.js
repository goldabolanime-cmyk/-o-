module.exports.config = {
  name: "مجموعتي",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "عرض معلومات المجموعة ونشاطها",
  commandCategory: "نظام",
  usages: "",
  cooldowns: 5
};

module.exports.run = async function({ api, event, Threads }) {
  const { threadID, messageID } = event;

  try {
    // 1. جلب بيانات المجموعة من قاعدة بيانات البوت
    const threadInfo = await api.getThreadInfo(threadID);
    const threadData = await Threads.getData(threadID);
    
    const threadName = threadInfo.threadName || "مجموعة بدون اسم";
    const totalMsg = threadData.data.totalMsg || threadInfo.messageCount || 0;
    const memberCount = threadInfo.participantIDs.length;
    const adminCount = threadInfo.adminIDs.length;

    // 2. تحديد حالة النشاط بناءً على عدد الرسائل
    let status, level;
    if (totalMsg > 5000) {
      status = "🔥 نـشـطـة جـداً";
      level = "ممـتـاز (🥇)";
    } else if (totalMsg > 1000) {
      status = "✅ نـشـطـة";
      level = "جـيـد (🥈)";
    } else {
      status = "💤 خـامـلـة قـليلاً";
      level = "مـتـوسـط (🥉)";
    }

    // 3. تجهيز صورة المجموعة
    const imgUrl = threadInfo.imageSrc || "https://i.ibb.co/vYSp97f/no-image.png";

    // 4. تنسيق الرسالة
    const msg = `
━━━━━━━━━━━━━
『 ✦ مـعـلـومـات الـمـجـمـوعة ✦ 』
━━━━━━━━━━━━━

📝 ┃ الاسـم: ${threadName}
🆔 ┃ الأيـدي: ${threadID}

👥 ┃ الأعـضـاء: ${memberCount} عـضـو
👮 ┃ الـمـشـرفـون: ${adminCount} أدمن

📊 ┃ إجـمالي الـرسـائل: ${totalMsg}
📈 ┃ مـسـتوى الـنـشـاط: ${level}
🟢 ┃ الـحـالـة: ${status}

━━━━━━━━━━━━━
『 ✦ RIO BOOT SYSTEM ✦ 』
━━━━━━━━━━━━━`.trim();

    // 5. إرسال المعلومات مع الصورة
    const request = require("request");
    const fs = require("fs-extra");
    const pathImg = __dirname + `/cache/${threadID}_group.png`;

    const callback = () => api.sendMessage({
      body: msg,
      attachment: fs.createReadStream(pathImg)
    }, threadID, () => fs.unlinkSync(pathImg), messageID);

    return request(encodeURI(imgUrl)).pipe(fs.createWriteStream(pathImg)).on("close", callback);

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ | حـدث خـطأ أثـناء جـلب بـيانات الـمجموعة.", threadID, messageID);
  }
};
