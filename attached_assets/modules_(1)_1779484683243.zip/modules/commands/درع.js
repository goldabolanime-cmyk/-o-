const fs = require("fs-extra");
const path = __dirname + "/cache/guard.json";

module.exports.config = {
  name: "درع",
  version: "1.0.0",
  hasPermssion: 1, // للمشرفين فقط
  credits: "عبدو / RIO BOOT",
  description: "حماية المسؤولين: يمنع تغيير قائمة الإدارة",
  commandCategory: "حماية",
  usages: "[تشغيل / ايقاف]",
  cooldowns: 5
};

module.exports.onLoad = () => {
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify([]));
};

module.exports.handleEvent = async function ({ api, event, Threads }) {
  const { threadID, logMessageType, logMessageData, author } = event;
  const guardData = JSON.parse(fs.readFileSync(path));

  // إذا كان الدرع مفعلاً في هذه المجموعة
  if (guardData.includes(threadID)) {
    
    // مراقبة تغيير المسؤولين (إضافة أو إزالة)
    if (logMessageType === "log:thread-admins") {
      const { ADMIN_EVENT, TARGET_ID } = logMessageData;
      const botID = api.getCurrentUserID();

      // إذا كان البوت هو من قام بالتغيير، لا تفعل شيئاً
      if (author === botID) return;

      // 1. إزالة الشخص الذي قام بالتغيير من الإدارة
      await api.changeAdminStatus(threadID, author, false);

      // 2. إزالة الشخص المستهدف (الذي أضيف أو أزيل) لضمان الأمان
      await api.changeAdminStatus(threadID, TARGET_ID, false);

      return api.sendMessage(`
🛡️ ┃ نـظـام الـدرع مـفـعـل!
⚠️ ┃ كـشـفـت مـحـاولة تـغـيـير فـي الإدارة.
━━━━━━━━━━━━━━━
👤 ┃ الـمـنـفـذ: @${author}
🎯 ┃ الـمـسـتـهدف: @${TARGET_ID}
🚫 ┃ تـم سـحـب الإدارة مـن كـلاهـمـا لـحـمـايـة الـمـجـمـوعة.
━━━━━━━━━━━━━━━`.trim(), threadID);
    }
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  let guardData = JSON.parse(fs.readFileSync(path));

  if (args[0] === "تشغيل") {
    if (guardData.includes(threadID)) return api.sendMessage("🛡️ | الـدرع مـفـعـل بـالـفعل فـي هـذه الـمـجـموعة.", threadID, messageID);
    guardData.push(threadID);
    fs.writeFileSync(path, JSON.stringify(guardData, null, 2));
    return api.sendMessage("✅ | تـم تـفـعـيـل درع الـمـجـمـوعة بـنـجاح. لا يـمـكن لأحـد تـغـيـير الإدارة الآن.", threadID, messageID);
  }

  if (args[0] === "ايقاف") {
    if (!guardData.includes(threadID)) return api.sendMessage("⚠️ | الـدرع مـعـطـل بـالأسـاس.", threadID, messageID);
    guardData = guardData.filter(id => id !== threadID);
    fs.writeFileSync(path, JSON.stringify(guardData, null, 2));
    return api.sendMessage("📴 | تـم إيـقـاف نـظـام الـدرع.", threadID, messageID);
  }

  return api.sendMessage("❓ | اسـتـخدام خـاطـئ! اكـتـب:\n• درع تشغيل\n• درع ايقاف", threadID, messageID);
};
