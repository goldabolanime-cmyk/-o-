module.exports.config = {
  name: "حساب",
  version: "6.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "مُـحَـرِّكُ اَلـرِّيَـاضِيَّـاتِ اَلْـمَـلَـكِيُّ (نُـسْـخَةٌ سَـرِيـعَةٌ)",
  commandCategory: "أدوات",
  usages: "[عملية حسابية أو معادلة]",
  cooldowns: 2
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const header = "⚖️ ═══ ﴿ مَـحْـرَكُ اَلـرِّيَـاضِيَّـاتِ اَلْـمَـلَـكِيُّ ﴾ ═══ ⚖️\n\n";

  if (!args[0]) return api.sendMessage(`${header}📍 سَـيِّـدِي عـبـدو، يُـرْجَى إِدْخَـالُ اَلْـعَـمَـلِيَّـةِ أَوِ اَلْـمُـعَـادَلَـةِ.`, threadID, messageID);

  let fullInput = args.join(" ");
  let input = fullInput.toLowerCase().replace(/\s+/g, "").replace(/×/g, "*").replace(/÷/g, "/").replace(/:/g, "/");

  // [1] التحقق من نوع الحساب
  let type = (input.includes("=") && (input.includes("x") || input.includes("س"))) ? "مُـعَـادَلَـةٌ جَـبْـرِيَّـةٌ" : "حِـسَـابٌ عَـادِيٌّ";

  // [2] التعامل مع المعادلات (x أو س)
  if (type === "مُـعَـادَلَـةٌ جَـبْـرِيَّـةٌ") {
    try {
      input = input.replace(/س/g, "x");
      const parts = input.split("=");
      if (parts.length !== 2) throw new Error();

      const prepareSide = (side) => side.replace(/([^0-9*])x/g, "$11*x").replace(/^x/g, "1*x").replace(/(\d+)x/g, "$1*x");
      const leftSide = prepareSide(parts[0]);
      const rightSide = prepareSide(parts[1]);

      let solveEquation = (valX) => {
        try {
          const left = new Function('x', `return ${leftSide}`)(valX);
          const right = new Function('x', `return ${rightSide}`)(valX);
          return left - right;
        } catch { return null; }
      };

      let x1 = solveEquation(0);
      let x2 = solveEquation(1);
      if (x1 === null || x2 === null) throw new Error();
      
      let resultX = -x1 / (x2 - x1);
      if (isNaN(resultX) || !isFinite(resultX)) throw new Error();

      let finalX = Number(resultX.toFixed(4));
      let msg = `${header}`;
      msg += `📂 ┃ اَلـنَّـوعُ: 『 ${type} 』\n`;
      msg += `📝 ┃ اَلْـمُـعَـادَلَـةُ: 『 ${fullInput} 』\n`;
      msg += `✨ ┃ قِـيـمَـةُ x: 『 ${finalX} 』\n`;
      msg += `━━━━━━━━━━━━━━━\n👑 ┃ رِيُـو بُـوت - عـبـدو`;

      return api.sendMessage(msg, threadID, messageID);
    } catch (e) {
      return api.sendMessage(`${header}❌ عُـذْراً سَـيِّـدِي، اَلـصِّيـغَـةُ اَلْـجَـبْـرِيَّـةُ غَـيْـرُ مَـدْعُـومَـةٍ أَوْ بِـهَا خَـطَأٌ.`, threadID, messageID);
    }
  }

  // [3] التعامل مع الحساب العادي
  try {
    const cleanInput = input.replace(/\^/g, "**");
    const result = new Function(`return ${cleanInput}`)();
    if (isNaN(result) || !isFinite(result)) throw new Error();

    let msg = `${header}`;
    msg += `📂 ┃ اَلـنَّـوعُ: 『 ${type} 』\n`;
    msg += `🔢 ┃ اَلْـمَـسْـأَلَـةُ: 『 ${fullInput} 』\n`;
    msg += `✅ ┃ اَلـنَّـتِـيـجَـةُ: 『 ${result.toLocaleString()} 』\n`;
    msg += `━━━━━━━━━━━━━━━\n👑 ┃ رِيُـو بُـوت - عـبـدو`;

    return api.sendMessage(msg, threadID, messageID);
  } catch (error) {
    return api.sendMessage(`${header}❌ خَـطَأٌ فِـي اَلـتَّـحْـلِـيلِ، تَـأَكَّـدْ مِـنَ اَلـرُّمُـوزِ.`, threadID, messageID);
  }
};