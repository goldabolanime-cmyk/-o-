module.exports.config = {
  name: "رصيدي",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "الاسْتِعْلَامُ عَنْ الرَّصِيدِ الْحَالِي",
  commandCategory: "الاموال",
  usages: "[تاغ / رد]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args, Currencies, Users }) {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;

  try {
    let targetID, name;

    // تحديد الشخص المستهدف (رد، تاغ، أو صاحب الأمر)
    if (type == "message_reply") {
      targetID = messageReply.senderID;
    } else if (Object.keys(mentions).length > 0) {
      targetID = Object.keys(mentions)[0];
    } else {
      targetID = senderID;
    }

    // جلب البيانات
    const userData = await Users.getData(targetID);
    const userMoney = await Currencies.getData(targetID);
    
    name = userData.name || "عُـضْـوٌ مَـجْـهُـولٌ";
    let money = userMoney.money || 0;

    // تنسيق الرقم (إضافة فواصل للآلاف)
    const formattedMoney = money.toLocaleString();

    // زخرفة ريو المتميزة مع التشكيل
    const msg = `
━━━━━━━━━━━━━━━
  👑 ┃ رِيُـو بُـوتْ - نِـظَـامُ الْـمَـالِ
━━━━━━━━━━━━━━━

👤 ❯ الِاسْـمُ: ${name}
🆔 ❯ الأَيْـدِي: ${targetID}

💰 ❯ رَصِـيـدُكَ الْـحَـالِي:
❪ ${formattedMoney}$ ❫

━━━━━━━━━━━━━━━
💡 ❯ اسْـتَـخْـدِمْ أَمْـرَ [ الْـبَنْـك ] لِإِدَارَةِ أَمْـوَالِـكَ.
    `.trim();

    return api.sendMessage(msg, threadID, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَـأٌ أَثْـنَـاءَ جَـلْـبِ الرَّصِـيدِ.", threadID, messageID);
  }
};