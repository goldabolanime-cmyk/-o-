const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const { loadImage, createCanvas } = require("canvas");

module.exports.config = {
  name: "مي2",
  version: "1.5.0",
  hasPermssion: 0,
  credits: "عبدو / ريو بوت",
  description: "يضع تعليقك الشخصي على قالب المنشور الجديد 📝",
  commandCategory: "صور",
  usages: "[النص]",
  cooldowns: 5,
  dependencies: {
    "canvas": "",
    "axios": "",
    "fs-extra": ""
  }
};

// دالة تنظيم النص داخل المربع
module.exports.wrapText = (ctx, text, maxWidth) => {
  return new Promise((resolve) => {
    const words = text.split(" ");
    const lines = [];
    let line = "";
    for (let n = 0; n < words.length; n++) {
      let testLine = line + words[n] + " ";
      let metrics = ctx.measureText(testLine);
      let testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        lines.push(line.trim());
        line = words[n] + " ";
      } else {
        line = testLine;
      }
    }
    lines.push(line.trim());
    resolve(lines);
  });
};

module.exports.run = async function ({ api, event, args, Users }) {
  let { senderID, threadID, messageID } = event;
  const cacheDir = path.join(__dirname, "cache");
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  const pathImg = path.join(cacheDir, `me2_${senderID}.png`);
  const pathAva = path.join(cacheDir, `avt_${senderID}.png`);
  const text = args.join(" ");

  if (!text) return api.sendMessage("⚠️ ┃ رِيُـو بُـوتْ: اكْتُبْ شَيْئاً لِأَضَعَهُ فِي الـتَّعْلِيقِ!", threadID, messageID);

  api.sendMessage("⏳ ┃ جَـارِي تَـصْمِيمُ مَنْشُورِكَ الـمَلَكِي . . .", threadID, messageID);

  try {
    const nameUser = (await Users.getData(senderID)).name;
    const token = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662";

    // جلب الصورة الشخصية (الافتار)
    const avatarRes = await axios.get(`https://graph.facebook.com/${senderID}/picture?width=512&height=512&access_token=${token}`, { responseType: "arraybuffer" });
    fs.writeFileSync(pathAva, Buffer.from(avatarRes.data, "utf-8"));

    // تحميل القالب (الصورة التي أرفقتها) والافتار
    // ملاحظة: تأكد من رفع الصورة على رابط مباشر أو وضعها في ملفات البوت
    const baseImage = await loadImage("https://i.ibb.co/L9Hqf39/1000040123.png"); 
    const baseAva = await loadImage(pathAva);

    const canvas = createCanvas(baseImage.width, baseImage.height);
    const ctx = canvas.getContext("2d");

    // رسم الخلفية
    ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);

    // رسم الصورة الشخصية (دائرية)
    ctx.save();
    ctx.beginPath();
    ctx.arc(105, 105, 60, 0, Math.PI * 2, true); // إحداثيات الافتار
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(baseAva, 45, 45, 120, 120);
    ctx.restore();

    // كتابة الاسم
    ctx.font = "bold 35px Arial";
    ctx.fillStyle = "#000000";
    ctx.textAlign = "start";
    ctx.fillText(nameUser, 185, 90);

    // كتابة النص (التعليق) داخل المربع
    ctx.font = "30px Arial";
    ctx.fillStyle = "#333333";
    const lines = await this.wrapText(ctx, text, 850); // أقصى عرض للنص 850
    let y = 160; // نقطة البداية الرأسية للنص
    lines.forEach(line => {
      ctx.fillText(line, 185, y);
      y += 45; // المسافة بين السطور
    });

    const buffer = canvas.toBuffer();
    fs.writeFileSync(pathImg, buffer);

    return api.sendMessage({
      body: "✨ ┃ تَـمَّ تَصْمِيمُ الـمَنْشُورِ بِنَجَاحٍ!",
      attachment: fs.createReadStream(pathImg)
    }, threadID, () => {
      if (fs.existsSync(pathImg)) fs.unlinkSync(pathImg);
      if (fs.existsSync(pathAva)) fs.unlinkSync(pathAva);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حَدَثَ خَطَأٌ أَثْنَاءَ تَصْمِيمِ الـصُّورَةِ.", threadID, messageID);
  }
};
