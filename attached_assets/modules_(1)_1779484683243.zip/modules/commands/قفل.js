module.exports.config = {
  name: "قفل",
  version: "2.0.0",
  hasPermssion: 1,
  credits: "RIO BOOT",
  description: "منع الأعضاء من الخروج من المجموعة (سجن ريو الملكي)",
  commandCategory: "الحماية",
  usages: "تشغيل / ايقاف",
  cooldowns: 5
};

// --- الجزء الأول: مراقب الأحداث (إعادة العضو المتمرد) ---
module.exports.handleEvent = async function({ api, event, Threads }) {
  const { threadID, logMessageType, logMessageData } = event;
  const { antiOut } = (await Threads.getData(threadID)).data || {};

  // التحقق إذا كان الحدث هو خروج عضو والسجن مفعل
  if (logMessageType === "log:unsubscribe" && antiOut === true) {
    const leftID = logMessageData.leftParticipantFbId;
    const botID = api.getCurrentUserID();

    // إذا كان الذي خرج هو البوت نفسه، لا يفعل شيئاً
    if (leftID === botID) return;

    return api.addUserToGroup(leftID, threadID, (err) => {
      if (err) {
        api.sendMessage(`⚠️ | لـم أسـتطِع إعـادة الـعضو [${leftID}]، قـد تكون إعـدادات الخصوصية لديه تمنع ذلك.`, threadID);
      } else {
        api.sendMessage(`🔒 ❯ مَـمْـنُـوعُ الـخُـرُوجِ! لَـقَدْ تَـمَّ إِعَـادَةُ الـمُتَمَرِّدِ إِلَى سِـجْـنِ رِيُـو..`, threadID);
      }
    });
  }
};

// --- الجزء الثاني: الأمر (تشغيل وإيقاف السجن) ---
module.exports.run = async function({ api, event, args, Threads }) {
  const { threadID, messageID } = event;
  let data = (await Threads.getData(threadID)).data || {};

  if (args[0] == "تشغيل") {
    data.antiOut = true;
    await Threads.setData(threadID, { data });
    return api.sendMessage("🔒 ❯ تَـمَّ تَـفْـعِـيلُ [ سِـجْـنِ رِيُـو ] بِنَجَاحٍ.\n⚠️ ❯ مَـمْـنُـوعُ الـخُـرُوجِ مِـنَ الآنِ!", threadID, messageID);
  } 
  else if (args[0] == "ايقاف") {
    data.antiOut = false;
    await Threads.setData(threadID, { data });
    return api.sendMessage("🔓 ❯ تَـمَّ إِغْـلَاقُ الـسِّـجْـنِ.. الـخُـرُوجُ مَـسْـمُوحٌ بِـهِ الآنَ.", threadID, messageID);
  } 
  else {
    return api.sendMessage("❓ ❯ الْـمَـرْجُـو كِـتَـابَـةُ: [ قفل تشغيل ] أَوْ [ قفل ايقاف ]", threadID, messageID);
  }
};