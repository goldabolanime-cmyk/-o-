const fs = require("fs-extra");

module.exports.config = {
  name: "قرعة",
  version: "3.5.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "نظام قرعة احترافي (رسالة واحدة + مؤقت 30 ثانية)",
  commandCategory: "ألعاب",
  usages: "[المبلغ / بدء]",
  cooldowns: 5
};

if (!global.rio_jackpot) {
  global.rio_jackpot = new Map();
}

module.exports.run = async function ({ api, event, args, Currencies, Users }) {
  const { threadID, messageID, senderID } = event;

  // أمر البدء اليدوي بالكتابة
  if (args[0] === "بدء") {
    const game = global.rio_jackpot.get(threadID);
    if (!game) return api.sendMessage("⚠️ ┃ لَا تُوجَدُ قُرْعَةٌ مَفْتُوحَةٌ الآنَ!", threadID, messageID);
    if (game.creator !== senderID) return api.sendMessage("🚫 ┃ فَقَطْ مُنْشِئُ الـقُرْعَةِ مَنْ يَمْلِكُ صَلَاحِيَةَ الـبَدْءِ!", threadID, messageID);
    if (game.players.length < 2) return api.sendMessage("👥 ┃ يَجِبُ انْضِمَامُ شَخْصَيْنِ عَلَى الأَقَلِّ!", threadID, messageID);
    return startDraw(api, threadID, Users, Currencies);
  }

  const betAmount = parseInt(args[0]);
  if (isNaN(betAmount) || betAmount <= 0) {
    return api.sendMessage("⚠️ ┃ يـرجى كـتابة مـبلغ صـحيح! مِـثَال: .قرعة 500", threadID, messageID);
  }

  const userMoney = (await Currencies.getData(senderID)).money;
  if (userMoney < betAmount) {
    return api.sendMessage(`❌ ┃ رَصِـيدُكَ غَـيْرُ كَـافٍ! تَـمْلِكُ فَقَطْ ${userMoney}$`, threadID, messageID);
  }

  // إنشاء اللعبة إذا لم تكن موجودة
  if (!global.rio_jackpot.has(threadID)) {
    global.rio_jackpot.set(threadID, {
      creator: senderID,
      players: [],
      totalPool: 0,
      mainMsgID: null,
      timeout: null
    });

    // مؤقت 30 ثانية للإغلاق التلقائي إذا لم تبدأ
    const timeout = setTimeout(() => {
      const game = global.rio_jackpot.get(threadID);
      if (game) {
        api.sendMessage("⌛ ┃ انْتَهَى الْوَقْتُ (30 ثَانِيَة) وَلَمْ تَبْدَأِ الْقُرْعَةُ، تَمَّ الإِلْغَاءُ وَإِعَادَةُ الأَمْوَالِ.", threadID);
        // إعادة الأموال للمشاركين
        game.players.forEach(async p => await Currencies.increaseMoney(p.id, p.bet));
        global.rio_jackpot.delete(threadID);
      }
    }, 30000);
    global.rio_jackpot.get(threadID).timeout = timeout;
  }

  const game = global.rio_jackpot.get(threadID);
  if (game.players.find(p => p.id === senderID)) return api.sendMessage("🚫 ┃ أَنْتَ مُسَجَّلٌ بِالفِعْلِ!", threadID, messageID);

  await Currencies.decreaseMoney(senderID, betAmount);
  game.players.push({ id: senderID, bet: betAmount });
  game.totalPool += betAmount;

  const msg = `🎰 ┃ نِـظَـامُ الـقُـرْعَـةِ الـمَـلَـكِيَّـة\n━━━━━━━━━━━━━━━\n💰 ┃ الـخزنة: ${game.totalPool}$\n👥 ┃ الـمشاركين: ${game.players.length}\n👤 ┃ الـمُنشِئ: ${(await Users.getNameUser(game.creator))}\n━━━━━━━━━━━━━━━\n💡 ┃ لِلْبَدْءِ: يَجِبُ عَلَى الْمُنْشِئِ التَّفَاعُلُ بِـ 👍\n⏳ ┃ سَتُغْلَقُ تِلْقَائِيَّاً بَعْدَ 30 ثَانِيَة.`;

  // حذف الرسالة القديمة لإرسال الجديدة (لتبقى رسالة واحدة فقط)
  if (game.mainMsgID) api.unsendMessage(game.mainMsgID);

  api.sendMessage(msg, threadID, (err, info) => {
    game.mainMsgID = info.messageID;
  });
};

module.exports.handleReaction = async function ({ api, event, Currencies, Users }) {
  const { threadID, userID, messageID, reaction } = event;
  const game = global.rio_jackpot.get(threadID);

  if (!game || game.mainMsgID !== messageID || reaction !== "👍") return;

  // التحقق أن المتفاعل هو منشئ القرعة حصراً
  if (userID === game.creator) {
    if (game.players.length < 2) return api.sendMessage("👥 ┃ نَحْتَاجُ لِمُشَارِكَيْنِ عَلَى الأَقَلِّ لِلْبَدْءِ!", threadID);
    
    clearTimeout(game.timeout); // إيقاف مؤقت الـ 30 ثانية
    startDraw(api, threadID, Users, Currencies);
  }
};

async function startDraw(api, threadID, Users, Currencies) {
  const game = global.rio_jackpot.get(threadID);
  if (!game) return;

  api.sendMessage("🎡 ┃ جَـارِي سَحْبُ الـقُرْعَةِ . . .", threadID, async (err, info) => {
    const winner = game.players[Math.floor(Math.random() * game.players.length)];
    const winnerName = await Users.getNameUser(winner.id);
    const totalPrize = game.totalPool;

    await Currencies.increaseMoney(winner.id, totalPrize);

    setTimeout(() => {
      const resultMsg = `━━━━━━━━━━━━━━━\n👑 ┃ نَتِيجَةُ القُرْعَةِ - رِيُـو بُـوتْ\n━━━━━━━━━━━━━━━\n👤 ❯ الـفَـائِـز: ${winnerName}\n💰 ❯ الـجَـائِـزَةُ: ${totalPrize}$\n👥 ❯ الـمُشَارِكِينَ: ${game.players.length}\n━━━━━━━━━━━━━━━\nمُـبَـارَكٌ لَكَ الـفَوْزُ بِالْـجَـائِـزَةِ! 💸`.trim();
      api.sendMessage(resultMsg, threadID);
      global.rio_jackpot.delete(threadID);
    }, 3000);
  });
}