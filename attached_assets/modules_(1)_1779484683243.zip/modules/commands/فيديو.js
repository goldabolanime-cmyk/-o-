const axios = require("axios");
const ytSearch = require("youtube-search-api");
const fs = require("fs-extra");

module.exports.config = {
  name: "فيديو",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "بَـحْـثُ وَتَـحْـمِيـلُ فِـيدْيُـوهَـاتِ اَلـيُـوتْـيُـوبِ مُـبَـاشَـرَةً",
  commandCategory: "خدمات",
  usages: "[اسم الفيديو]",
  cooldowns: 10
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const choice = parseInt(body);
  if (isNaN(choice) || choice < 1 || choice > handleReply.videos.length) {
    return api.sendMessage("⚠️ ┃ سَـيِّـدِي ، اِخْـتَـرْ رَقْـمـاً صَـحِيـحاً.", threadID, messageID);
  }

  const video = handleReply.videos[choice - 1];
  const videoUrl = `https://www.youtube.com/watch?v=${video.id}`;
  const path = __dirname + `/cache/video_${senderID}.mp4`;

  api.sendMessage(`⏳ ┃ جَـارِي تَـحْـمِيـلُ [ ${video.title} ] . . .\n⚠️ ┃ قَـدْ يَـسْتَـغْرِقُ اَلْأَمْـرُ لَـحَـظَاتٍ حَـسَـبَ حَـجْـمِ اَلْـفِـيدْيُـو.`, threadID, messageID);

  try {
    // استعمال API خارجي للتحميل لضمان الاستقرار على Node 16
    const res = await axios.get(`https://api.vkrdown.com/server/server.php?url=${videoUrl}`);
    const downloadUrl = res.data.data.url;

    if (!downloadUrl) throw new Error("رابط التحميل غير متاح");

    const videoData = (await axios.get(downloadUrl, { responseType: "arraybuffer" })).data;
    fs.writeFileSync(path, Buffer.from(videoData, "utf-8"));

    // التأكد من حجم الملف (فيسبوك يمنع أكثر من 25MB غالباً)
    if (fs.statSync(path).size > 26214400) {
        fs.unlinkSync(path);
        return api.sendMessage("❌ ┃ عُـذْراً سَـيِّـدِي، اَلْـفِـيدْيُـو حَـجْـمُـهُ كَـبِيـرٌ جِـدّاً (أكثر من 25 ميجا).", threadID, messageID);
    }

    return api.sendMessage({
      body: `✅ ┃ تَـمَّ اَلـتَّحْـمِيـلُ بِنَـجَـاحٍ يَـا سَـيِّـدِي.\n🎬 ┃ اَلْـعُـنْـوَانُ: ${video.title}`,
      attachment: fs.createReadStream(path)
    }, threadID, () => fs.unlinkSync(path), messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ فَـشَـلَ نِـظَـامُ اَلـتَّحْـمِيـلِ، جَـرِّبْ رَابِـطَ اَلْـمُـشَـاهَـدَةِ بَـدَلَ اَلـتَّحْـمِيـلِ.", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const searchQuery = args.join(" ");

  if (!searchQuery) return api.sendMessage("⚠️ ┃ سَـيِّـدِي ، أَدْخِـلْ اِسْمَ اَلْـفِـيدْيُـو!", threadID, messageID);

  api.sendMessage("🔍 ┃ جَـارِي اَلـتَّـبْـحِيـرُ فِـي اَلـيُـوتْـيُـوبِ . . .", threadID, messageID);

  try {
    const data = await ytSearch.GetListByKeyword(searchQuery, false, 6);
    const results = data.items;

    if (!results || results.length === 0) return api.sendMessage("❌ ┃ لَا تُـوجَدُ نَـتَـائِـجُ.", threadID, messageID);

    let msg = `┏━━━━━━━━━━━━━━━━━┓\n   ♛ 𝑹𝑰𝑶 𝑽𝑰𝑫𝑬𝑶 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫 ♛\n┗━━━━━━━━━━━━━━━━━┛\n\n🔍 ┃ بَـحْـثٌ عَـنْ: [ ${searchQuery} ]\n━━━━━━━━━━━━━━━\n\n`;
    const videos = [];

    results.forEach((v, i) => {
      const duration = v.length?.simpleText || v.duration || "غير محدد";
      videos.push({ id: v.id, title: v.title, duration });
      msg += `【 ${i + 1} 】 🎬 ${v.title.slice(0, 45)}...\n⏱️ ┃ اَلـمُـدَّةُ: ${duration}\n━━━━━━━━━━━━━━━\n`;
    });

    msg += "📥 ┃ رُدَّ بِـرَقْـمِ اَلْـفِـيدْيُـو لِـتَحْـمِيـلِـهِ مُـبَـاشَـرَةً.";

    return api.sendMessage(msg, threadID, (err, info) => {
      if (!global.client.handleReply) global.client.handleReply = [];
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        videos
      });
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ فِـي مَـحَـرِّكَ اَلـبَـحْـثِ.", threadID, messageID);
  }
};