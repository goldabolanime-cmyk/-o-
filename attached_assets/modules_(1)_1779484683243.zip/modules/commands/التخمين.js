module.exports.config = {
  name: "تخمين",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "لعبة تخمين شخصيات الأنمي من خلال الوصف",
  commandCategory: "ألعاب",
  usages: "اكتب .تخمين لبدء اللعبة",
  cooldowns: 5
};

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { threadID, messageID, senderID, body } = event;
  
  // التأكد من أن الإجابة صحيحة (تجاهل حالة الأحرف والمسافات)
  if (body.toLowerCase() === handleReply.answer.toLowerCase()) {
    await Currencies.increaseMoney(senderID, 200);
    api.unsendMessage(handleReply.messageID); // حذف رسالة السؤال عند الفوز
    
    const msg = `
┏━━━━━━━━━━━━━━━━━━┓
   --- إجـابـة صـحـيـحـة ---
┗━━━━━━━━━━━━━━━━━━┛

الـبـطـل: 【 ${senderID} 】
الـشـخـصـيـة: 【 ${handleReply.answer} 】
الـجـائـزة: 200 عـمـلـة ذهـبـيـة

━━━━━━━━━━━━━━━
تـهـانـيـنـا.. لـقـد حـصـلـت عـلـى الـمـكـافـأة
━━━━━━━━━━━━━━━
`;
    return api.sendMessage(msg, threadID, messageID);
  } else {
    return api.sendMessage("--- الإجـابـة خـاطـئـة.. حـاول مـجـدداً ---", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;

  const characters = [
    {
      description: "شاب ذو شعر شائك يحلم بأن يصبح ملك القراصنة\nيرتدي قبعة قش مميزة دائماً\nاكتسب قوة مطاطية بعد أكل فاكهة الشيطان",
      answer: "لوفي"
    },
    {
      description: "نينجا منبوذ في صغره يحمل بداخله ثعلباً ذو تسعة ذيول\nحلمه الأكبر هو أن يصبح الهوكاجي ليحمي قريته\nيتميز بشعره الأشقر وعصابة الرأس",
      answer: "ناروتو"
    },
    {
      description: "طالب ذكي جداً يعثر على مفكرة غامضة تقتل من يكتب اسمه فيها\nيسعى لتطهير العالم من المجرمين تحت لقب كيرا\nيواجهه المحقق الغامض ال",
      answer: "لايت"
    },
    {
      description: "سياف يستخدم أسلوب الثلاثة سيوف في القتال\nيعاني من مشكلة كبيرة في الاتجاهات ويضيع دائماً\nنائب قائد طاقم قبعة القش",
      answer: "زورو"
    },
    {
      description: "صياد صغير يبحث عن والده المختفي\nسلاحه الأساسي هو صنارة صيد ويستخدم طاقة النين\nأعز أصدقائه هو كيلوا",
      answer: "غون"
    }
  ];

  const character = characters[Math.floor(Math.random() * characters.length)];

  const msg = `
┏━━━━━━━━━━━━━━━━━━┓
   --- لـعـبـة الـتـخـمـيـن ---
┗━━━━━━━━━━━━━━━━━━┛

الـوصـف:
${character.description}

━━━━━━━━━━━━━━━
الـجـائـزة: 200 عـمـلـة
قـم بـالـرد عـلى هـذه الـرسـالـة بـاسـم الـشـخـصـيـة
━━━━━━━━━━━━━━━
`;

  return api.sendMessage(msg, threadID, (err, info) => {
    global.client.handleReply.push({
      name: this.config.name,
      messageID: info.messageID,
      answer: character.answer
    });
  }, messageID);
};
