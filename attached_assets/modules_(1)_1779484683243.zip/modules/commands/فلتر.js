module.exports.config = {
  name: "فلتر",
  version: "1.4.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "تطبيق فلاتر مع نظام ألوان متطور للفلتر الملكي رقم 8",
  commandCategory: "تسلية",
  usages: "[رقم الفلتر] [اسم اللون]",
  cooldowns: 5
};

const filters = [
  { name: "🎬 سينـمائي (Cinematic)", type: "sepia" },
  { name: "🎥 أفـلام قـديـمة (Vintage)", type: "grayscale" },
  { name: "🧟 رُعــب (Horror)", type: "color", params: { r: 60, g: -60, b: -60 } },
  { name: "🎭 درامــا (Cold)", type: "color", params: { r: -30, g: -10, b: 50 } },
  { name: "🌟 نـضـارة (Bright)", type: "brightness", params: 0.3 },
  { name: "🌑 غـموض (Dark)", type: "brightness", params: -0.4 },
  { name: "🌀 تـشـويـش (Pixel)", type: "pixelate", params: 8 },
  { name: "🎨 تـلويـن مـلكي (Royal Colors)", type: "royal_color" },
  { name: "🌆 غـروب (Sunset)", type: "color", params: { r: 40, g: -10, b: -20 } },
  { name: "🍃 طـبيعة (Nature)", type: "color", params: { r: -10, g: 30, b: -10 } },
  { name: "👻 شـبحي (Ghost)", type: "opacity", params: 0.6 },
  { name: "💎 كـريستال (Posterize)", type: "posterize", params: 5 },
  { name: "🕯️ كـلاسـيك (Classic)", type: "color", params: { r: 10, g: 10, b: -30 } },
  { name: "👾 سـايـبر (Cyberpunk)", type: "color", params: { r: 50, g: -30, b: 50 } },
  { name: "🖤 أبـيض وأسـود (Noir)", type: "low_contrast_gray" }
];

// مـصـفـوفة الألـوان الـمدعومة وإعـداداتـها
const royalColors = {
  "أصفر": { r: 40, g: 40, b: -30 },
  "أخضر": { r: -30, g: 50, b: -30 },
  "بني": { r: 30, g: 10, b: -30 },
  "رمادي": { r: 0, g: 0, b: 0, desaturate: true },
  "أرجواني": { r: 30, g: -30, b: 40 },
  "أزرق": { r: -20, g: -20, b: 50 },
  "أزرق فاتح": { r: -10, g: 20, b: 50 },
  "ذهبي": { r: 45, g: 35, b: -40 },
  "أحمر": { r: 60, g: -20, b: -20 },
  "وردي": { r: 50, g: -10, b: 30 }
};

module.exports.handleReply = async ({ api, event, handleReply, Users }) => {
  const { threadID, messageID, senderID, body } = event;
  if (handleReply.author != senderID) return;

  const args = body.split(" ");
  const index = parseInt(args[0]) - 1;
  const colorName = args.slice(1).join(" "); // دعم الأسماء المركبة مثل "أزرق فاتح"

  if (isNaN(index) || !filters[index]) {
    return api.sendMessage("❌ عـذراً، يـرجى اخـتيار رقم صـحيح من الـقائمة!", threadID, messageID);
  }

  // تـحقق خـاص لـلفلتر رقـم 8
  if (index === 7 && (!colorName || !royalColors[colorName])) {
    let msg = "🎨 ━━━━【 ألـوان مـلكيـة 】━━━━ 🎨\n\n";
    msg += "📍 يـرجى اخـتيار أحـد الألـوان الـتالية:\n";
    Object.keys(royalColors).forEach(c => msg += `✨ ${c}\n`);
    msg += "\n📝 مـثال: 8 أزرق فاتح";
    return api.sendMessage(msg, threadID, messageID);
  }

  api.unsendMessage(handleReply.messageID);
  return applyFilter(api, event, index, Users, colorName);
};

module.exports.run = async ({ api, event, args, Users }) => {
  const { threadID, messageID, senderID } = event;

  if (!args[0]) {
    let list = "🎭 ━━━━【 فـلاتـر ريـو الـمـطورة 】━━━━ 🎭\n\n";
    filters.forEach((f, i) => {
      list += `【 ${i + 1} 】- ${f.name}\n`;
    });
    list += "\n📍 رُد بـالـرقم (مـثال: 8 ذهبي)";
    
    return api.sendMessage(list, threadID, (err, info) => {
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID
      });
    }, messageID);
  }

  const index = parseInt(args[0]) - 1;
  const colorName = args.slice(1).join(" ");
  
  if (index === 7 && (!colorName || !royalColors[colorName])) {
     let msg = "🎨 ━━━━【 ألـوان مـلكيـة 】━━━━ 🎨\n\n";
     Object.keys(royalColors).forEach(c => msg += `✨ ${c}\n`);
     return api.sendMessage(msg, threadID, messageID);
  }

  if (isNaN(index) || !filters[index]) return api.sendMessage("❌ الرقم غير صحيح!", threadID, messageID);
  return applyFilter(api, event, index, Users, colorName);
};

async function applyFilter(api, event, index, Users, colorName) {
  const jimp = require("jimp");
  const fs = require("fs-extra");
  const path = require("path");
  const { threadID, messageID, senderID } = event;

  try {
    api.sendMessage("⏳ جـارٍ تـطبيق الـلمسة الـمـلكيـة...", threadID, messageID);

    const avatarUrl = `https://graph.facebook.com/${senderID}/picture?width=1024&height=1024&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
    const image = await jimp.read(avatarUrl);
    const selected = filters[index];

    switch (selected.type) {
      case "sepia": image.sepia(); break;
      case "grayscale": image.grayscale(); break;
      case "pixelate": image.pixelate(selected.params); break;
      case "brightness": image.brightness(selected.params); break;
      case "posterize": image.posterize(selected.params); break;
      case "opacity": image.opacity(selected.params); break;
      case "low_contrast_gray": image.grayscale().contrast(0.2); break;
      case "color": 
        image.color([
          { apply: "red", params: [selected.params.r] },
          { apply: "green", params: [selected.params.g] },
          { apply: "blue", params: [selected.params.b] }
        ]); 
        break;
      case "royal_color": 
        const c = royalColors[colorName];
        let colorOps = [
          { apply: "red", params: [c.r] },
          { apply: "green", params: [c.g] },
          { apply: "blue", params: [c.b] }
        ];
        if (c.desaturate) colorOps.push({ apply: "desaturate", params: [100] });
        else colorOps.push({ apply: "saturate", params: [25] });

        image.color(colorOps).brightness(-0.1); 
        break;
    }

    const cachePath = path.join(__dirname, "cache", `filter_v5_${senderID}.png`);
    if (!fs.existsSync(path.join(__dirname, "cache"))) fs.mkdirSync(path.join(__dirname, "cache"));
    
    await image.writeAsync(cachePath);
    const name = await Users.getNameUser(senderID);

    return api.sendMessage({
      body: `✨ تـم تـطبيق فـلتر: 【 ${selected.name} 】\n🎨 الـلون: ${colorName || "إفـتراضي"}\n👑 لـلـمبدع: ${name}`,
      attachment: fs.createReadStream(cachePath)
    }, threadID, () => { if (fs.existsSync(cachePath)) fs.unlinkSync(cachePath); }, messageID);

  } catch (e) {
    return api.sendMessage("❌ حـدث خـطأ أثـناء الـتطبيق!", threadID, messageID);
  }
}