const fs = require("fs-extra");
const axios = require("axios");
const path = __dirname + "/cache/rio_guard.json";

module.exports.config = {
  name: "الحماية",
  version: "10.5.0",
  hasPermssion: 1, // الأدمن يشغلها لكن المطور فقط يتحكم بالكل
  credits: "عبدو / RIO BOOT",
  description: "بروتوكول صارم لطرد أي شخص يلمس إعدادات المجموعة",
  commandCategory: "نظام الحماية",
  usages: "[الكل/الاسم/الصورة/الأدمن/الكنية] [تشغيل/ايقاف]",
  cooldowns: 0
};

if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));

module.exports.handleEvent = async function({ api, event, Users }) {
  const { threadID, logMessageType, logMessageData, author, senderID } = event;
  const myID = api.getCurrentUserID();
  const devID = "100090081489341"; // أيدي المطور عبدو

  // استثناء المطور والبوت من العقوبة
  const actorID = author || senderID;
  if (!actorID || actorID == devID || actorID == myID) return;

  let data = JSON.parse(fs.readFileSync(path));
  if (!data[threadID]) return;
  const config = data[threadID];

  // دالة الإعدام (الطرد الفوري)
  const executeNow = async (id, action) => {
    try {
      const info = await Users.getData(id);
      const name = info.name || "مخرب";
      
      // تنفيذ الطرد
      api.removeUserFromGroup(id, threadID, (err) => {
          if(err) return api.sendMessage("⚠️ | لم أستطع طرد المخرب، تأكد من رفعي رتبة مسؤول!", threadID);
          
          api.sendMessage({
            body: `🚨 ┃ [ بـروتـوكـول الإعـدام الـفـوري ]\n━━━━━━━━━━━━━━━\n👤 ┃ الـمـخـرب: ${name}\n🆔 ┃ الأيـدي: ${id}\n🚫 ┃ الـفـعـل: مـحـاولـة الـتـلاعـب بـ [ ${action} ]\n\n🛡️ ┃ تـم طـرده واسـتـعـادة الـنـظـام بـأمـر مـن الـمـطـور عـبـدو!`,
            mentions: [{ tag: name, id: id }]
          }, threadID);
      });
    } catch (e) { console.log(e); }
  };

  // 1. حماية الاسم
  if (logMessageType === "log:thread-name" && config.name) {
    api.setTitle(config.oldName, threadID);
    return await executeNow(actorID, "اسـم الـمـجـمـوعـة");
  }

  // 2. حماية الصورة
  if (logMessageType === "log:thread-image" && config.photo) {
    if (config.oldImage && config.oldImage !== "null") {
      try {
        const res = await axios.get(config.oldImage, { responseType: "stream" });
        api.changeGroupImage(res.data, threadID);
      } catch (e) { console.log("خطأ في استعادة الصورة"); }
    }
    return await executeNow(actorID, "صـورة الـمـجـمـوعـة");
  }

  // 3. حماية الأدمن (إضافة أو إزالة)
  if (logMessageType === "log:thread-admins" && config.admin) {
    if (logMessageData.ADMIN_EVENT === "remove_admin") {
      // إذا حاول إزالة أدمن، البوت يعيد الرتبة
      api.changeAdminStatus(threadID, logMessageData.TARGET_ID, true);
    } else if (logMessageData.ADMIN_EVENT === "add_admin") {
      // إذا حاول إضافة أدمن، البوت يزيل الرتبة
      api.changeAdminStatus(threadID, logMessageData.TARGET_ID, false);
    }
    return await executeNow(actorID, "صـلاحـيـات الإدارة");
  }

  // 4. حماية الكنية (الألقاب)
  if (logMessageType === "log:user-nickname" && config.nickname) {
    api.changeNickname(logMessageData.oldNickname || "", threadID, logMessageData.participant_id);
    return await executeNow(actorID, "الألـقـاب");
  }
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const devID = "100090081489341";

  if (senderID !== devID) return api.sendMessage("👑 ┃ هـذا الأمـر لـلـسـيـد عـبـدو فـقـط!", threadID, messageID);

  const threadInfo = await api.getThreadInfo(threadID);
  let data = JSON.parse(fs.readFileSync(path));

  const action = args[0];
  const status = args[1] === "تشغيل" ? true : args[1] === "ايقاف" ? false : null;

  if (!action || status === null) {
    const s = data[threadID] || { name: false, photo: false, admin: false, nickname: false };
    const stat = (v) => v ? "✅ مـفـعـل" : "❌ مـعـطـل";
    return api.sendMessage(`🛡️ ┃ نـظـام حـمـايـة ريـو الـصـارم\n━━━━━━━━━━━━━━━\n📝 ┃ حـمـايـة الإسـم: ${stat(s.name)}\n🖼️ ┃ حـمـايـة الـصـورة: ${stat(s.photo)}\n👮 ┃ حـمـايـة الإدارة: ${stat(s.admin)}\n👤 ┃ حـمـايـة الـكـنـيـة: ${stat(s.nickname)}\n━━━━━━━━━━━━━━━\n💡 ┃ مـثـال: .الحماية الكل تشغيل\n👑 ┃ الـمـطـور: عـبـدو`, threadID, messageID);
  }

  if (!data[threadID]) data[threadID] = {};

  if (action === "الكل") {
    data[threadID] = { 
      name: status, photo: status, admin: status, nickname: status,
      oldName: threadInfo.threadName, 
      oldImage: threadInfo.imageSrc 
    };
  } else {
    const map = { "الاسم": "name", "الصورة": "photo", "الأدمن": "admin", "الكنية": "nickname" };
    if (!map[action]) return api.sendMessage("❌ ┃ نـوع حـمـايـة غـيـر صـحـيـح!", threadID, messageID);
    
    data[threadID][map[action]] = status;
    data[threadID].oldName = threadInfo.threadName;
    data[threadID].oldImage = threadInfo.imageSrc;
  }

  fs.writeFileSync(path, JSON.stringify(data, null, 2));
  return api.sendMessage(`🛡️ ┃ تـم [ ${status ? "تـفـعـيـل" : "إيـقـاف" } ] الـحـمـايـة لـ [ ${action} ].\n⚠️ ┃ أي تـلاعب سـيـؤدي لـلـطـرد الـفـوري!`, threadID, messageID);
};