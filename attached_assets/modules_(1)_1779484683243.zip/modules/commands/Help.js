module.exports.config = {
  name: "هلب",
  version: "1.0.2",
  hasPermssion: 0,
  credits: "عمر",
  description: "عَـرْضُ قَـائِمَةِ اَلْأَوَامِـرِ اَلْـمُتَـاحَةِ لِـلْـمُسْـتَخْـدِمِ",
  commandCategory: "خدمات",
  usages: "[دليل المستخدم]",
  cooldowns: 1,
  envConfig: {
    autoUnsend: true,
    delayUnsend: 300
  }
};

module.exports.languages = {
  "en": {
    "moduleInfo": "『 %1 』\n\n📝 اَلـوَصْـفُ: %2\n\n← كَـيْـفِيَّـةُ اَلِاسْـتِـخْـدَامِ: %3\n← اَلْـفِـئَـةُ: %4\n← وَقْـتُ اَلِانْـتِـظَـارِ: %5 ثَـوَانِي\n← اَلـصَّـلَاحِيَّـةُ: %6\n\n← طُـوِّرَ بِـوَاسِـطَةِ: %7",
    "helpList": '[ هُـنَاكَ %1 أَمْـرًا فِـي هَـذَا اَلـبُـوتِ، اِسْـتَخْـدِمْ: "%2help اسم_الأمر" لِـتَعْـرِفَ كَـيْـفِيَّـةَ اَلِاسْـتِـخْـدَامِ! ]',
    "user": "『 اَلْـكَـلُّ 』",
    "adminGroup": "『 مَـسْـؤُولُ اَلْـقُـرُوبِ 』",
    "adminBot": "『 اَلْـمُـطَـوِّرُ 』"
  }
};

module.exports.handleEvent = function ({ api, event, getText }) {
  const { commands } = global.client;
  const { threadID, messageID, body } = event;

  if (!body || typeof body == "undefined" || body.indexOf("اوامر") != 0) return;
  const splitBody = body.slice(body.indexOf("اوامر")).trim().split(/\s+/);
  if (splitBody.length == 1 || !commands.has(splitBody[1].toLowerCase())) return;
  const threadSetting = global.data.threadData.get(parseInt(threadID)) || {};
  const command = commands.get(splitBody[1].toLowerCase());
  const prefix = (threadSetting.hasOwnProperty("PREFIX")) ? threadSetting.PREFIX : global.config.PREFIX;
  
  // تطبيق التشكيل على الوصف عند العرض
  const formationDesc = command.config.description || "لَا يُـوجَدُ وَصْـفٌ لِـهَذَا اَلْأَمْـرِ بَـعْدُ.";
  
  return api.sendMessage(getText("moduleInfo", command.config.name, formationDesc, `${prefix}${command.config.name} ${(command.config.usages) ? command.config.usages : ""}`, command.config.commandCategory, command.config.cooldowns, ((command.config.hasPermssion == 0) ? getText("user") : (command.config.hasPermssion == 1) ? getText("adminGroup") : getText("adminBot")), command.config.credits), threadID, messageID);
}

module.exports.run = function({ api, event, args, getText }) {
  const { commands } = global.client;
  const { threadID, messageID } = event;
  const command = commands.get((args[0] || "").toLowerCase());
  const threadSetting = global.data.threadData.get(parseInt(threadID)) || {};
  const { autoUnsend, delayUnsend } = global.configModule[this.config.name];
  const prefix = (threadSetting.hasOwnProperty("PREFIX")) ? threadSetting.PREFIX : global.config.PREFIX;

  if (!command) {
    const arrayInfo = [];
    const page = parseInt(args[0]) || 1;
    const numberOfOnePage = 15;
    
    let i = 0;
    let msg = "";

    for (var [name, value] of (commands)) {
      arrayInfo.push({
        name: name,
        desc: value.config.description
      });
    }

    arrayInfo.sort((a, b) => a.name.localeCompare(b.name));

    const startSlice = numberOfOnePage * page - numberOfOnePage;
    i = startSlice;
    const returnArray = arrayInfo.slice(startSlice, startSlice + numberOfOnePage);

    for (let item of returnArray) {
      msg += ` 〖💀🍃〗  ${++i} . 『 ${item.name} 』\n${item.desc || "لَا يُـوجَدُ وَصْـفٌ لِـهَذَا اَلْأَمْـرِ"}\n—͟͟͞͞\n`;
    }

    const header = `-·=»〖〗«=·-\n🍃 اَلأَمْـرُ اَلْـمُتَـاحُ لِـرِيُـو ᏴϴᏆ. ぐ愛 🍃\n-·=»〖〗«=·-\n✨🍃\n`;
    
    const footer = `\n-·=»〖〗«=·-\n🍃   اَلـصَّـفْـحَـةُ (${page}/${Math.ceil(arrayInfo.length / numberOfOnePage)}) 🍃\n-·=»〖〗«=·-\nBOT: ° ᏴϴᏆ. ぐ愛°\nقائمة📜 الاوامر: ${arrayInfo.length}`;

    return api.sendMessage(header + msg + footer, threadID, async (error, info) => {
      if (autoUnsend) {
        await new Promise(resolve => setTimeout(resolve, delayUnsend * 1000));
        return api.unsendMessage(info.messageID);
      }
    }, event.messageID);
  }

  const formationDesc = command.config.description || "لَا يُـوجَدُ وَصْـفٌ لِـهَذَا اَلْأَمْـرِ بَـعْدُ.";

  return api.sendMessage(getText("moduleInfo", command.config.name, formationDesc, `${prefix}${command.config.name} ${(command.config.usages) ? command.config.usages : ""}`, command.config.commandCategory, command.config.cooldowns, ((command.config.hasPermssion == 0) ? getText("user") : (command.config.hasPermssion == 1) ? getText("adminGroup") : getText("adminBot")), command.config.credits), threadID, messageID);
};