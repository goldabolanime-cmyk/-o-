const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const ytSearch = require("yt-search"); // تأكد من تثبيتها عبر npm install yt-search

module.exports.config = {
  name: "نغمة",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "تشغيل الأغاني كاملة من يوتيوب بجودة عالية",
  commandCategory: "ترفيه",
  usages: "[اسم الأغنية]",
  cooldowns: 10
};

const cacheDir = path.join(__dirname, "cache");

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const choice = parseInt(body);
  if (isNaN(choice) || choice < 1 || choice > handleReply.results.length) {
    return api.sendMessage("⚠️ ┃ مـلكي، اخـتر رقـماً مـن الـقائمة فـقط.", threadID, messageID);
  }

  const video = handleReply.results[choice - 1];
  api.unsendMessage(handleReply.messageID); // حذف قائمة البحث بعد الاختيار
  return downloadAndSend(api, event, video.url, video.title, video.timestamp, video.author.name);
};

async function downloadAndSend(api, event, videoUrl, title, duration, artist) {
  const { threadID, messageID } = event;

  api.sendMessage(`📥 ┃ جـارٍ تـحميل "${title}" كـامـلة.. انـتظر قـليلاً.`, threadID, messageID);

  try {
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
    const filePath = path.join(cacheDir, `music_${Date.now()}.mp3`);

    // استـخدام API وسـيط لـتحويل رابط يوتيوب إلى ملف MP3 مـباشر
    const res = await axios.get(`https://api.vreden.my.id/api/ytmp3?url=${encodeURIComponent(videoUrl)}`);
    const downloadLink = res.data.result.download;

    const audioRes = await axios.get(downloadLink, { responseType: "arraybuffer", timeout: 60000 });
    fs.writeFileSync(filePath, Buffer.from(audioRes.data));

    return api.sendMessage({
      body: 
        `🎼 ┃ تـمَّ الـعزف الـمـلكي بـنجاح\n` +
        `━━━━━━━━━━━━━━━\n` +
        `🎵 ┃ ${title}\n` +
        `🎤 ┃ الـفنان: ${artist}\n` +
        `⏱️ ┃ الـمدة: ${duration}\n` +
        `━━━━━━━━━━━━━━━\n` +
        `👑 ┃ رِيُـو بُـوت - نِـظـامُ الـمَـلِـك`,
      attachment: fs.createReadStream(filePath)
    }, threadID, () => {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ عـذراً مـلكي، تـعذر تـحميل الأغـنية حـالياً.", threadID, messageID);
  }
}

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const songName = args.join(" ");

  if (!songName) return api.sendMessage("🎵 ┃ يـرجى كـتابة اسـم الأغـنية يـا مـلك!", threadID, messageID);

  api.sendMessage("🔍 ┃ جـارٍ الـبحث فـي مـكتبة الـموسـيقى الـعالمية..", threadID, messageID);

  try {
    const searchResults = await ytSearch(songName);
    const videos = searchResults.videos.slice(0, 6); // جلب أول 6 نتائج

    if (videos.length === 0) {
      return api.sendMessage("❌ ┃ لـم أجـد أي أغـنية تـطابق بـحثك.", threadID, messageID);
    }

    let msg = `🏰 ━━━━【 نـتـائـج الـبـحث الـمـلكـي 】━━━━ 🏰\n🔍 ┃ الـبحث: ${songName}\n━━━━━━━━━━━━━━━\n\n`;

    videos.forEach((v, i) => {
      msg += `【 ${i + 1} 】 🎵 ${v.title.slice(0, 50)}\n`;
      msg += `🎤 ${v.author.name} ┃ ⏱️ ${v.timestamp}\n`;
      msg += `━━━━━━━━━━━━━━━\n`;
    });

    msg += "📥 ┃ رد بـرقم الأغـنية لـتـشغـيلهـا كـامـلة.";

    return api.sendMessage(msg, threadID, (err, info) => {
      if (!global.client.handleReply) global.client.handleReply = [];
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        results: videos
      });
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حـدث خـطأ فـي نـظام الـبحث.", threadID, messageID);
  }
};
