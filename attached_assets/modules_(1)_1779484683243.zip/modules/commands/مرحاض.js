const axios = require("axios");
const { createCanvas, loadImage } = require("canvas");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "مرحاض",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "وضع الشخص داخل المرحاض (في الماء)",
  commandCategory: "ترفيه",
  usages: "رد على الشخص واكتب .مرحاض",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID, messageReply, type } = event;
  const developerID = "100090081489341"; // أيدي المطور عبدو
  const toiletImage = "https://i.postimg.cc/nhRcsRDm/received-4192419714309146.jpg";

  let targetID;
  if (type === "message_reply") {
    targetID = messageReply.senderID;
  } else {
    return api.sendMessage("⚠️ ┃ رد على الشخص الذي تريد وضعه في المرحاض!", threadID, messageID);
  }

  // نظام حماية المطور عبدو
  if (targetID === developerID) {
    api.sendMessage("👑 ┃ محاولة فاشلة! لا يمكنك وضع المطور عبدو في المرحاض.\n⚠️ ┃ سأضعك أنت بدلاً منه لتتعلم الأدب!", threadID);
    targetID = senderID; 
  }

  api.sendMessage("🚽 ┃ جـارٍ تجهيز المرحاض وإلقاء الهدف...", threadID, messageID);

  try {
    const avatarURL = `https://graph.facebook.com/${targetID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
    
    const [baseImage, avatarImage] = await Promise.all([
      loadImage(toiletImage),
      loadImage(avatarURL)
    ]);

    const canvas = createCanvas(baseImage.width, baseImage.height);
    const ctx = canvas.getContext("2d");

    // رسم الخلفية (المرحاض)
    ctx.drawImage(baseImage, 0, 0, canvas.width, canvas.height);

    // --- الإحداثيات الجديدة والمصححة لوضع الصورة داخل فتحة المرحاض ---
    const size = 190; // حجم الوجه
    const x = 330;    // الموقع الأفقي (تم تحريكه لليسار قليلاً)
    const y = 570;    // الموقع الرأسي (تم رفعه للأعلى قليلاً ليصبح داخل الفتحة)
    
    ctx.save();
    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.clip();
    
    // رسم الصورة
    ctx.drawImage(avatarImage, x, y, size, size);
    
    // إضافة تأثير "تحت الماء" خفيف (شفافية زرقاء)
    ctx.fillStyle = "rgba(0, 100, 255, 0.15)";
    ctx.fill();
    
    ctx.restore();

    const savePath = path.join(__dirname, "cache", `toilet_${targetID}.png`);
    fs.writeFileSync(savePath, canvas.toBuffer());

    return api.sendMessage({
      body: "🚽 ┃ تـمَّت الإزاحة بنجاح! وداعاً.",
      attachment: fs.createReadStream(savePath)
    }, threadID, () => fs.unlinkSync(savePath), messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حدث خطأ أثناء معالجة الصورة.", threadID, messageID);
  }
};
