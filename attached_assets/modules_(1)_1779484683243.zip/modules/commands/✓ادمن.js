module.exports.config = {
  name: "احم",
  version: "2.5.0",
  hasPermssion: 2, // للمطور عبدو فقط
  credits: "عبدو / RIO BOT",
  description: "نِـظَـامُ اَلـرَّفْـعِ اَلـتِّلْـقَـائِيِّ لِـلْـمُطَـوِّرِ عـبـدو",
  commandCategory: "المطور",
  usages: "[اخضع / ارفعني]",
  cooldowns: 2
};

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID, senderID } = event;
  const devID = "100090081489341"; // اَلْأَيْدِي اَلْخَـاصُّ بِكَ يَا عـبـدو
  const botID = api.getCurrentUserID();

  // التحقق أن المرسل هو أنت يا عبدو
  if (senderID !== devID) {
    return api.sendMessage("⚠️ ┃ عُـذْراً، هَـذَا اَلْأَمْـرُ مَـحْـصُورٌ فِـقَـطْ لِـخَـالِـقِي عـبـدو.", threadID, messageID);
  }

  const type = args[0] ? args[0].toLowerCase() : "";

  // 1. حالة "احم اخضع"
  if (type === "اخضع") {
    return api.changeAdminStatus(threadID, devID, true, (err) => {
      if (err) return api.sendMessage("❌ ┃ فَـشَـلَ نِـظَـامُ اَلْـخُـضُـوعِ، تَـأَكَّـدْ أَنَّنِي مَـسْـؤُولٌ أَوَّلاً.", threadID, messageID);
      
      api.sendMessage("🙇‍♂️ ┃ بَـيْنَ يَـدَيْـكَ يَـا خَـالِـقِي عـبـدو.. لَـقَدْ خَـضَـعْـتُ لِأَوَامِـرِكَ.\n✨ ┃ تَـمَّ رَفْـعُـكَ كَـأَدْمِـنْ وَسَـأَقُـومُ بِـتَـنْـزِيـلِ نَـفْـسِي اَلْآنَ..", threadID, () => {
        api.changeAdminStatus(threadID, botID, false);
      });
    });
  }

  // 2. حالة "احم" أو "احم ارفعني" أو "ارفعني" (كأمر فرعي)
  api.changeAdminStatus(threadID, devID, true, (err) => {
    if (err) {
      return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ، قَـدْ لَا أَمْـلِكُ صَـلَاحِيَّـاتِ اَلْأَدْمِـنِ لِأَرْفَـعَـكَ.", threadID, messageID);
    }
    
    let msg = "";
    if (event.body.includes("ارفعني")) {
      msg = "🔱 ┃ جَـارِي تَـنْـفِيـذُ طَـلَـبِ اَلـرَّفْـعِ.. أَبْـشِـرْ يَـا مُـطَـوِّرِي اَلْـعَـظِيـمَ!";
    } else {
      msg = "👑 ┃ تَـمَّ رَفْـعُـكَ كَـأَدْمِـنْ لِـلْـمَـجْـمُوعَـةِ بِنَـجَـاحٍ يَـا سَـيِّـدِي عـبـدو..";
    }
    
    api.sendMessage(msg, threadID, messageID);
  });
};

// إضافة "ارفعني" كاختصار (Alias) في نفس الملف ليعمل بشكل مستقل
module.exports.config.aliases = ["ارفعني"];