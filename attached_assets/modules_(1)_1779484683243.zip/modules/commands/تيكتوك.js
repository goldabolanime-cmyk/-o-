const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "تيكتوك",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "بحث وتحميل فيديوهات تيك توك بنظام ملكي",
  commandCategory: "الوسائط",
  usages: "[كلمة بحث] أو [رابط تيك توك]",
  cooldowns: 10
};

const TIKWM_BASE = "https://www.tikwm.com";
const cacheDir = path.join(__dirname, "cache");

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const choice = parseInt(body);
  if (isNaN(choice) || choice < 1 || choice > handleReply.videos.length) {
    return api.sendMessage("⚠️ ┃ اختر رقماً من القائمة فقط.", threadID, messageID);
  }

  const video = handleReply.videos[choice - 1];
  api.sendMessage("⏳ ┃ جـارٍ تحميل المقطع من سيرفرات تيك توك..", threadID, messageID);

  try {
    const videoUrl = TIKWM_BASE + video.play;
    const filePath = path.join(cacheDir, `tiktok_${senderID}_${Date.now()}.mp4`);
    
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

    const res = await axios.get(videoUrl, { responseType: "arraybuffer", timeout: 30000 });
    fs.writeFileSync(filePath, Buffer.from(res.data));

    if (fs.statSync(filePath).size > 26214400) {
      fs.unlinkSync(filePath);
      return api.sendMessage("⚠️ ┃ المقطع حجمه أكبر من 25 ميجابايت.", threadID, messageID);
    }

    return api.sendMessage({
      body: `✅ ┃ تـمَّ التجهيز بنجاح\n━━━━━━━━━━━━━━━\n📝 ┃ ${video.title?.slice(0, 80) || "مقطع تيك توك"}\n👤 ┃ الناشر: ${video.author?.nickname || "غير معروف"}\n⏱️ ┃ المدة: ${video.duration} ثانية\n━━━━━━━━━━━━━━━\n👑 ┃ رِيُـو بُـوت`,
      attachment: fs.createReadStream(filePath)
    }, threadID, () => {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ فشل تحميل المقطع، حاول مرة أخرى.", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const input = args.join(" ");

  if (!input) return api.sendMessage(
    "⚠️ ┃ يرجى كتابة كلمة بحث أو رابط تيك توك.\n" +
    "━━━━━━━━━━━━━━━\n" +
    "📌 ┃ مثال بحث: .تيكتوك قطط مضحكة\n" +
    "📌 ┃ مثال رابط: .تيكتوك https://tiktok.com/...",
    threadID, messageID
  );

  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  // تحميل مباشر عبر الرابط
  if (input.includes("tiktok.com")) {
    api.sendMessage("⏳ ┃ جـارٍ تحميل المقطع مباشرة..", threadID, messageID);
    try {
      const res = await axios.post(TIKWM_BASE + "/api/",
        new URLSearchParams({ url: input, hd: 1 }),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" }, timeout: 15000 }
      );

      const data = res.data?.data;
      if (!data || !data.play) throw new Error("لم يتم جلب رابط التحميل");

      const videoUrl = data.hdplay || data.play;
      const filePath = path.join(cacheDir, `tiktok_${senderID}_${Date.now()}.mp4`);

      const videoRes = await axios.get(videoUrl, { responseType: "arraybuffer", timeout: 30000 });
      fs.writeFileSync(filePath, Buffer.from(videoRes.data));

      if (fs.statSync(filePath).size > 26214400) {
        fs.unlinkSync(filePath);
        return api.sendMessage("⚠️ ┃ المقطع حجمه أكبر من 25 ميجابايت.", threadID, messageID);
      }

      return api.sendMessage({
        body: `✅ ┃ تـمَّ التحميل بنجاح\n━━━━━━━━━━━━━━━\n📝 ┃ ${data.title?.slice(0, 80) || "مقطع تيك توك"}\n👤 ┃ الناشر: ${data.author?.nickname || "غير معروف"}\n⏱️ ┃ المدة: ${data.duration} ثانية\n━━━━━━━━━━━━━━━\n👑 ┃ رِيُـو بُـوت - بدون علامة مائية`,
        attachment: fs.createReadStream(filePath)
      }, threadID, () => {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      }, messageID);

    } catch (e) {
      console.error(e);
      return api.sendMessage("❌ ┃ فشل تحميل الرابط، تأكد من صحة الرابط وحاول مجدداً.", threadID, messageID);
    }
  }

  // البحث بالكلمات
  api.sendMessage("🔍 ┃ جـارٍ البحث في تيك توك..", threadID, messageID);
  try {
    const searchRes = await axios.get(
      `${TIKWM_BASE}/api/feed/search?keywords=${encodeURIComponent(input)}&count=5&cursor=0&web=1&hd=1`,
      { timeout: 15000 }
    );

    const videos = searchRes.data?.data?.videos || [];
    if (videos.length === 0) return api.sendMessage("❌ ┃ لم أجد نتائج لهذا البحث.", threadID, messageID);

    let msg = `🏰 ━━━━【 نتائج تيك توك 】━━━━ 🏰\n🔍 ┃ البحث عن: ${input}\n━━━━━━━━━━━━━━━\n\n`;

    videos.forEach((v, i) => {
      msg += `【 ${i + 1} 】 📝 ${v.title?.slice(0, 60) || "بدون عنوان"}\n`;
      msg += `👤 ${v.author?.nickname || "غير معروف"} ┃ ⏱️ ${v.duration}ث ┃ ❤️ ${formatNum(v.digg_count)}\n`;
      msg += `━━━━━━━━━━━━━━━\n`;
    });

    msg += "📥 ┃ رد برقم المقطع لتحميله فوراً.";

    return api.sendMessage(msg, threadID, (err, info) => {
      if (!global.client.handleReply) global.client.handleReply = [];
      global.client.handleReply.push({
        name: module.exports.config.name,
        messageID: info.messageID,
        author: senderID,
        videos: videos
      });
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ خطأ في نظام البحث، حاول مرة أخرى.", threadID, messageID);
  }
};

function formatNum(num) {
  if (!num) return "0";
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return num.toString();
}