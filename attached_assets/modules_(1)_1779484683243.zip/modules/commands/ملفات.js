const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "ملفات",
  version: "4.0.0",
  hasPermssion: 2,
  credits: "عبدو / RIO BOOT",
  description: "إدارة شاملة للملفات عبر اسم الأمر مع تأكيد الحذف بالتفاعل",
  commandCategory: "نظام المطور",
  usages: "[لود/تصنيف/اضافة/حذف/عرض]",
  cooldowns: 2
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const devID = "100090081489341"; // أيدي المطور عبدو
  
  // حماية المطور (صلاحية الحبس والتحكم)
  if (senderID != devID && args[0] !== "عرض") {
    return api.sendMessage("⛔ | عـذراً يـا سـيـدي، هـذه الـصلاحـيات مـحـصورة لـلـمـطور عـبـدو فـقط.", threadID, messageID);
  }

  const commandsPath = __dirname;
  const action = args[0]?.toLowerCase();
  const targetCommand = args[1];

  // وظيفة البحث عن مسار الملف من خلال اسم الأمر (وليس اسم الملف)
  function getFilePathByCommandName(name) {
    const files = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"));
    for (const file of files) {
      const content = fs.readFileSync(path.join(commandsPath, file), "utf-8");
      if (content.includes(`name: "${name}"`) || content.includes(`name: '${name}'`)) {
        return path.join(commandsPath, file);
      }
    }
    return null;
  }

  // 1. ميزة العرض (عرض كل الملفات)
  if (action === "عرض") {
    try {
      const files = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"));
      let msg = `📂 ┃ قـائـمـة مـلـفـات ريـو بـوت ┃ 📂\n━━━━━━━━━━━━━━━\n`;
      files.forEach((file, index) => {
        msg += `【 ${index + 1} 】- ${file}\n`;
      });
      msg += `━━━━━━━━━━━━━━━\n📊 إجـمـالـي الأوامـر: ${files.length}\n👑 مـطـور الـنـظـام: عـبـدو`;
      return api.sendMessage(msg, threadID, messageID);
    } catch (e) {
      return api.sendMessage("❌ | فـشل فـي جـلـب قـائـمـة الـمـلـفـات.", threadID, messageID);
    }
  }

  // 2. ميزة الإضافة
  if (action === "اضافة" || action === "إضافة") {
    if (!targetCommand) return api.sendMessage("⚠️ | حـدد اسـم الأمـر الـجـديـد.", threadID, messageID);
    const filePath = path.join(commandsPath, `${targetCommand}.js`);
    if (fs.existsSync(filePath)) return api.sendMessage("⚠️ | هـذا الـمـلـف مـوجـود بـالـفـعـل!", threadID, messageID);
    
    const template = `module.exports.config = {
  name: "${targetCommand}",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "وصف الأمر هنا",
  commandCategory: "عام",
  usages: "",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args }) => {
  api.sendMessage("تـم تـشـغـيـل الأمـر بـنـجـاح ✅", event.threadID);
};`;
    fs.writeFileSync(filePath, template);
    return api.sendMessage(`✅ | تـم إنـشـاء الأمـر [ ${targetCommand} ] بـمـلف جـديـد بـنـجاح!`, threadID, messageID);
  }

  // 3. ميزة الحذف الذكي (بالتفاعل)
  if (action === "حذف") {
    if (!targetCommand) return api.sendMessage("⚠️ | حـدد اسـم الأمـر الـمـطلوب حـذفـه.", threadID, messageID);
    const filePath = getFilePathByCommandName(targetCommand);
    
    if (!filePath) return api.sendMessage(`❌ | لـم يـتـم الـعـثـور عـلى أمـر بـاسـم [ ${targetCommand} ].`, threadID, messageID);

    return api.sendMessage(`⚠️ ┇ تـأكـيـد الـحـذف الـمـلـكـي:\n━━━━━━━━━━━━━━━\nهـل أنـت مـتـأكـد مـن حـذف أمـر [ ${targetCommand} ]؟\n\nتـفـاعـل بـ (👍) عـلى هـذه الـرسـالـة لـلـتـأكـيـد.`, threadID, (err, info) => {
      global.client.handleReaction.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        filePath: filePath,
        cmdName: targetCommand,
        type: "confirm_delete"
      });
    }, messageID);
  }

  // 4. ميزة اللود (LOAD)
  if (action === "لود") {
    if (!targetCommand) return api.sendMessage("⚠️ | حـدد اسـم الأمـر لـتـحـديـثـه.", threadID, messageID);
    const filePath = getFilePathByCommandName(targetCommand);
    if (!filePath) return api.sendMessage("❌ | هـذا الأمـر غـيـر مـوجـود فـي الـسـيـستـم.", threadID, messageID);

    try {
      delete require.cache[require.resolve(filePath)];
      const command = require(filePath);
      global.client.commands.set(command.config.name, command);
      return api.sendMessage(`✅ | تـم تـحـديـث الأمـر [ ${targetCommand} ] بـنـجاح!`, threadID, messageID);
    } catch (e) {
      return api.sendMessage(`❌ | فـشل الـتـحـديـث: ${e.message}`, threadID, messageID);
    }
  }

  // القائمة الرئيسية في حال عدم وجود args
  let helpMsg = `📂 ┃ مـديـر مـلـفـات ريـو الـمـطـور ┃ 📂\n━━━━━━━━━━━━━━━\n`;
  helpMsg += `🚀 | .ملفات لود [اسم الأمر]\n`;
  helpMsg += `📝 | .ملفات اضافة [اسم الأمر]\n`;
  helpMsg += `🗑️ | .ملفات حذف [اسم الأمر]\n`;
  helpMsg += `🛡️ | .ملفات تصنيف [اسم الأمر] [0/1/2]\n`;
  helpMsg += `👁️ | .ملفات عرض (للملفات الـموجـودة)\n━━━━━━━━━━━━━━━\n👑 بـواسطـة الـمـطـور عـبـدو`;
  return api.sendMessage(helpMsg, threadID, messageID);
};

// معالج التفاعل (Reaction Handler) للحذف
module.exports.handleReaction = async function ({ api, event, handleReaction }) {
  const { threadID, messageID, userID, reaction } = event;
  if (reaction !== "👍" || userID !== handleReaction.author) return;

  if (handleReaction.type === "confirm_delete") {
    try {
      if (fs.existsSync(handleReaction.filePath)) {
        fs.unlinkSync(handleReaction.filePath);
        api.unsendMessage(handleReaction.messageID); // حذف رسالة التأكيد
        return api.sendMessage(`🗑️ | تـم حـذف مـلـف الأمـر [ ${handleReaction.cmdName} ] نـهـائـيـاً بـأمـر مـن الـمـطـور.`, threadID);
      }
    } catch (e) {
      return api.sendMessage(`❌ | فـشل الـحـذف: ${e.message}`, threadID);
    }
  }
};