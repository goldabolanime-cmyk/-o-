const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "تغيير",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "التحكم الكامل في بروفايل البوت (صورة، غلاف، بايو، حماية)",
  commandCategory: "نظام المطور",
  usages: "[صورة / غلاف / بايو / حماية]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, type, messageReply, senderID } = event;
  const adminID = "100090081489341"; // الأيدي الخاص بك
  const assistantsPath = __dirname + "/cache/assistants.json";

  // --- 1. التحقق من الصلاحية ---
  let assistants = fs.existsSync(assistantsPath) ? fs.readJsonSync(assistantsPath) : [];
  if (senderID !== adminID && !assistants.includes(senderID)) {
      return api.sendMessage("❌ | عـذراً، هـذا اَلْـأَمْرُ لِـلْـمُطَوِّرِ عَـبْدُو وَمُـسَاعِدِيهِ فَـقَطْ!", threadID, messageID);
  }

  const action = args[0];

  // --- 2. تغيير البايو (الوصف) ---
  if (action === "بايو") {
    const newBio = args.slice(1).join(" ");
    if (!newBio) return api.sendMessage("📝 | يُـرجى كـتـابـة اَلـنَّـصِّ اَلْـجَدِيدِ بَـعْدَ كَـلِمَةِ بَـايُو.", threadID, messageID);
    return api.changeBio(newBio, (err) => {
      if (err) return api.sendMessage("⚠️ | فَـشَلَ تَـحْدِيثُ اَلـبَايُو.", threadID, messageID);
      return api.sendMessage(`✅ | تَـمَّ تَـحْدِيثُ وَصْـفِ اَلْـمَكْتَبِ (اَلـبَايُو) بِنَـجَاحٍ:\n『 ${newBio} 』`, threadID, messageID);
    });
  }

  // --- 3. تغيير صورة البروفايل ---
  if (action === "صورة") {
    if (type !== "message_reply" || !messageReply.attachments[0] || messageReply.attachments[0].type !== "photo") {
      return api.sendMessage("🖼️ | يَـجِبُ اَلـرَّدُّ عَـلَى صُـورَةٍ لِـتَغْيِيرِ اَلـبْرُوفَـايلِ.", threadID, messageID);
    }
    const pathImg = __dirname + `/cache/avt_${senderID}.png`;
    const imgUrl = messageReply.attachments[0].url;
    const response = await axios.get(imgUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(pathImg, Buffer.from(response.data, "binary"));

    return api.changeAvatar(fs.createReadStream(pathImg), "RIO BOT SYSTEM", (err) => {
      fs.unlinkSync(pathImg);
      if (err) return api.sendMessage("⚠️ | فَـشَلَ تَـغْيِيرُ اَلـصُّورَةِ.", threadID, messageID);
      return api.sendMessage("✅ | تَـمَّ تَـحْدِيثُ صُـورَةِ اَلـبْرُوفَـايلِ بِنَـجَاحٍ!", threadID, messageID);
    });
  }

  // --- 4. تغيير صورة الغلاف ---
  if (action === "غلاف") {
    if (type !== "message_reply" || !messageReply.attachments[0] || messageReply.attachments[0].type !== "photo") {
      return api.sendMessage("🎨 | يَـجِبُ اَلـرَّدُّ عَـلَى صُـورَةٍ لِـتَغْيِيرِ اَلْـغِلَافِ.", threadID, messageID);
    }
    const pathCover = __dirname + `/cache/cover_${senderID}.png`;
    const imgUrl = messageReply.attachments[0].url;
    const response = await axios.get(imgUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(pathCover, Buffer.from(response.data, "binary"));

    return api.changeCover(fs.createReadStream(pathCover), (err) => {
      fs.unlinkSync(pathCover);
      if (err) return api.sendMessage("⚠️ | فَـشَلَ تَـغْيِيرُ اَلْـغِلَافِ.", threadID, messageID);
      return api.sendMessage("✅ | تَـمَّ تَـحْدِيثُ صُـورَةِ اَلْـغِلَافِ بِنَـجَاحٍ!", threadID, messageID);
    });
  }

  // --- 5. نظام حماية الصورة (Guard) ---
  if (action === "حماية") {
    const status = args[1];
    if (status === "تفعيل") {
      return api.changeGuard(true, (err) => {
        if (err) return api.sendMessage("⚠️ | فَـشَلَ تَـفْعِيلُ اَلْـحِمَايَةِ.", threadID, messageID);
        return api.sendMessage("🛡️ | تَـمَّ تَـفْعِيلُ دِرْعِ حِـمَايَةِ صُـورَةِ اَلـبْرُوفَـايلِ بِنَـجَاحٍ.", threadID, messageID);
      });
    } else if (status === "ايقاف" || status === "إيقاف") {
      return api.changeGuard(false, (err) => {
        if (err) return api.sendMessage("⚠️ | فَـشَلَ إِيـقَافُ اَلْـحِمَايَةِ.", threadID, messageID);
        return api.sendMessage("🛡️ | تَـمَّ إِيـقَافُ دِرْعِ حِـمَايَةِ صُـورَةِ اَلـبْرُوفَـايلِ.", threadID, messageID);
      });
    } else {
      return api.sendMessage("🛡️ | اَلْاسْتِخْدَامُ: [ تغيير حماية تفعيل / ايقاف ]", threadID, messageID);
    }
  }

  // --- القائمة الافتراضية في حال عدم تحديد أمر ---
  return api.sendMessage(
    "⚙️ ═══ ﴿ نِـظَـامُ اَلـتَّـحَـكُّـمِ ﴾ ═══ ⚙️\n\n" +
    "📝 『 تغيير بايو [النص] 』\n" +
    "🖼️ 『 تغيير صورة 』 ← (رد على صورة)\n" +
    "🎨 『 تغيير غلاف 』 ← (رد على صورة)\n" +
    "🛡️ 『 تغيير حماية تفعيل / ايقاف 』\n\n" +
    "🔱 ┃ اَلْـمُطَوِّرُ: عَـبْدُو", 
    threadID, messageID
  );
};
