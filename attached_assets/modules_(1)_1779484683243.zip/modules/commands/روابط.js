module.exports.config = {
  name: "رابط",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "تحويل صور فيسبوك المؤقتة إلى روابط ثابتة للمبرمجين",
  commandCategory: "خدمات",
  usages: "[رد على صورة]",
  cooldowns: 5,
  dependencies: {
    "axios": ""
  }
};

module.exports.run = async ({ api, event }) => {
  const axios = require("axios");
  const { threadID, messageID, messageReply, attachments } = event;
  
  let links = [];

  // 1. التحقق من الرد على رسالة بها صور أو إرسال صور مع الأمر
  if (event.type === "message_reply" && messageReply.attachments.length > 0) {
    for (const attachment of messageReply.attachments) {
      if (attachment.type === "photo") links.push(attachment.url);
    }
  } else if (attachments && attachments.length > 0) {
    for (const attachment of attachments) {
      if (attachment.type === "photo") links.push(attachment.url);
    }
  }

  if (links.length === 0) {
    return api.sendMessage('⚠️ ┃ يـا عـبـدو، قـم بـالـرد عـلى صـورة لـتحـويلـها لـرابـط ثـابـت.', threadID, messageID);
  }

  api.sendMessage(`⏳ ┃ جـاري رفـع [ ${links.length} ] صـورة إلـى سـيـرفـر الإسـتـضـافـة...`, threadID, messageID);

  try {
    const shortenedLinks = [];
    
    for (const link of links) {
      // الرفع عبر API ImgBB (مفتاحك الشخصي مفعل)
      const res = await axios.get(`https://api.imgbb.com/1/upload?key=6be0e378c8a149c4f14120f2694b83b3&image=${encodeURIComponent(link)}`);
      shortenedLinks.push(res.data.data.url);
    }

    let msg = `✅ ┃ تـم اسـتـخـراج الـروابـط بـنـجـاح:\n\n`;
    shortenedLinks.forEach((url, i) => {
      msg += `🖼️ ┃ الـرابـط [${i + 1}]:\n${url}\n\n`;
    });
    
    msg += `💡 ┃ هـذه الـروابـط دائـمـة ولا تـنـتـهـي صـلاحـيـتـهـا.`;
    
    return api.sendMessage(msg, threadID, messageID);
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ عـذراً، فـشل رفـع الـصورة. قـد يـكون الـسـيرفـر مـضغـوطاً.", threadID, messageID);
  }
};
