const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
    name: "نجوم",
    version: "2.0.0",
    hasPermssion: 0,
    credits: "RIO BOOT",
    description: "عرض معلومات نجم رياضي عشوائي (قدم، سلة، يد) مع خصم 80 دولار",
    commandCategory: "الترفيه الملكي",
    usages: "",
    cooldowns: 10
};

module.exports.run = async ({ api, event, Currencies }) => {
    const { threadID, messageID, senderID } = event;
    const cacheDir = path.join(__dirname, "cache");
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

    try {
        // 1. التحقق من الرصيد
        const userData = await Currencies.getData(senderID);
        const money = userData.money;

        if (money < 80) {
            return api.sendMessage("⚠️ ┇ عذراً مولي، يجب أن تمتلك 80 دولاراً على الأقل لدخول قاعة النجوم!", threadID, messageID);
        }

        // 2. رسالة انتظار فخمة
        api.sendMessage("⏳ ┇ جـاري اقـتـحـام أرشـيـف الـنـجـوم الـعـالـمـي...", threadID, messageID);

        // 3. قائمة بحث عشوائية لتنويع النجوم (كرة قدم، سلة، يد)
        const categories = ["Messi", "Cristiano Ronaldo", "LeBron James", "Stephen Curry", "Mikkel Hansen", "Nikola Karabatic", "Earvin Ngapeth"];
        const randomSearch = categories[Math.floor(Math.random() * categories.length)];

        // جلب البيانات من API الرياضة العالمي
        const response = await axios.get(`https://www.thesportsdb.com/api/v1/json/3/searchplayers.php?p=${encodeURIComponent(randomSearch)}`);
        const players = response.data.player;
        const star = players[0]; // اختيار النجم الأبرز من النتيجة

        if (!star) return api.sendMessage("❌ ┇ تعذر العثور على النجم في الوقت الحالي.", threadID, messageID);

        // 4. معالجة الصورة
        const imagePath = path.join(cacheDir, `star_${Date.now()}.jpg`);
        const imageURL = star.strThumb || "https://via.placeholder.com/500";
        const imgRes = await axios.get(imageURL, { responseType: "arraybuffer" });
        fs.writeFileSync(imagePath, Buffer.from(imgRes.data, "utf-8"));

        // 5. خصم المبلغ
        await Currencies.decreaseMoney(senderID, 80);

        // 6. حساب العمر تقريبياً
        const birthYear = star.dateBorn ? star.dateBorn.split("-")[0] : "غير محدد";
        const currentYear = new Date().getFullYear();
        const age = birthYear !== "غير محدد" ? currentYear - parseInt(birthYear) : "غير محدد";

        // 7. تنسيق الرسالة بالزخرفة الملكية المطلوبة
        const infoMsg = `┏━━━━━━━ 👑 ━━━━━━━┓\n   سِـجِـلُّ الـنُّـجُـومِ الـعَـالـمِـيّ   \n┗━━━━━━━ 👑 ━━━━━━━┛\n\n[👤] الاسـم: ${star.strPlayer}\n[🌍] الـجـنـسـيـة: ${star.strNationality}\n[🏀] الـريـاضـة: ${star.strSport}\n[🏟️] الـنـادي الـحـالـي: ${star.strTeam}\n[🏃] الـمـركـز: ${star.strPosition}\n[🎂] الـعـمـر: ${age} سـنـة\n[🏆] أفضل نادٍ: ${star.strTeam2 || star.strTeam}\n\n━━━━━━━━━━━━━━━━━━━\n[📜] نـبـذة: ${star.strDescriptionEN ? (star.strDescriptionEN.substring(0, 100) + "...") : "نجم غني عن التعريف"}\n━━━━━━━━━━━━━━━━━━━\n[💸] تـم خـصـم 80 دولار مـن رصـيـدك!\n[•] رِيُـو بُـوت - سُـلـطَـةُ الـتَّـقَـدُّم`;

        // 8. إرسال النتيجة مع الصورة
        return api.sendMessage({
            body: infoMsg,
            attachment: fs.createReadStream(imagePath)
        }, threadID, () => {
            if (fs.existsSync(imagePath)) fs.unlinkSync(imagePath);
        }, messageID);

    } catch (e) {
        console.error(e);
        return api.sendMessage("❌ ┇ حـدث خـطأ أثـنـاء اسـتـدعـاء الـنـجـوم.", threadID, messageID);
    }
};