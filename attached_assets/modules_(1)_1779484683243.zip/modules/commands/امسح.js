module.exports.config = {
    name: "مسح",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "RIO BOOT",
    description: "حذف رسالة البوت عن طريق الرد عليها",
    commandCategory: "أدوات",
    usages: "قم بالرد على الرسالة التي تريد حذفها واكتب مسح",
    cooldowns: 0
};

module.exports.run = function({ api, event, getText }) {
    // التحقق مما إذا كان المستخدم قد رد على رسالة أم لا
    if (event.type !== "message_reply") {
        return api.sendMessage("⚠️ | عذراً، يجب عليك الرد على الرسالة التي تريد مني حذفها.", event.threadID, event.messageID);
    }

    // التحقق مما إذا كانت الرسالة المراد حذفها هي رسالة البوت نفسه
    // ملاحظة: البوتات عادة لا تستطيع حذف رسائل المستخدمين الآخرين إلا إذا كانت "مسؤول" (Admin) في المجموعة
    return api.unsendMessage(event.messageReply.messageID, (err) => {
        if (err) {
            return api.sendMessage("❌ | فشل حذف الرسالة. تأكد من أنني أملك الصلاحيات الكافية (مسؤول) إذا كانت الرسالة ليست لي.", event.threadID, event.messageID);
        }
    });
};