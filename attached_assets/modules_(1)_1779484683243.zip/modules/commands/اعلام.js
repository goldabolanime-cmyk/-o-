// مصفوفة الأسئلة المحدثة (أضفها فوق دالة الـ run)
const questions = [
  { question: "علم الجزائر 🇩🇿", answer: "الجزائر", link: "https://i.postimg.cc/mD3fL6rL/dz.png" },
  { question: "علم المغرب 🇲🇦", answer: "المغرب", link: "https://i.postimg.cc/8PzXyX8z/ma.png" },
  { question: "علم تونس 🇹🇳", answer: "تونس", link: "https://i.postimg.cc/0j6W0B5z/tn.png" },
  { question: "علم مصر 🇪🇬", answer: "مصر", link: "https://i.postimg.cc/52P6vK5z/eg.png" },
  { question: "علم السعودية 🇸🇦", answer: "السعودية", link: "https://i.postimg.cc/7Z9vK5z/sa.png" },
  { question: "علم فلسطين 🇵🇸", answer: "فلسطين", link: "https://i.postimg.cc/3R9vK5z/ps.png" },
  { question: "علم العراق 🇮🇶", answer: "العراق", link: "https://i.postimg.cc/4y9vK5z/iq.png" },
  { question: "علم الأردن 🇯🇴", answer: "الأردن", link: "https://i.postimg.cc/1r9vK5z/jo.png" },
  { question: "علم سوريا 🇸🇾", answer: "سوريا", link: "https://i.postimg.cc/2s9vK5z/sy.png" },
  { question: "علم لبنان 🇱🇧", answer: "لبنان", link: "https://i.postimg.cc/6l9vK5z/lb.png" },
  { question: "علم الإمارات 🇦🇪", answer: "الإمارات", link: "https://i.postimg.cc/8u9vK5z/ae.png" },
  { question: "علم قطر 🇶🇦", answer: "قطر", link: "https://i.postimg.cc/9q9vK5z/qa.png" },
  { question: "علم الكويت 🇰🇼", answer: "الكويت", link: "https://i.postimg.cc/0k9vK5z/kw.png" },
  { question: "علم البحرين 🇧🇭", answer: "البحرين", link: "https://i.postimg.cc/1b9vK5z/bh.png" },
  { question: "علم عمان 🇴🇲", answer: "عمان", link: "https://i.postimg.cc/2o9vK5z/om.png" },
  { question: "علم اليمن 🇾🇪", answer: "اليمن", link: "https://i.postimg.cc/3y9vK5z/ye.png" },
  { question: "علم ليبيا 🇱🇾", answer: "ليبيا", link: "https://i.postimg.cc/4l9vK5z/ly.png" },
  { question: "علم السودان 🇸🇩", answer: "السودان", link: "https://i.postimg.cc/5s9vK5z/sd.png" },
  { question: "علم موريتانيا 🇲🇷", answer: "موريتانيا", link: "https://i.postimg.cc/6m9vK5z/mr.png" },
  { question: "علم فرنسا 🇫🇷", answer: "فرنسا", link: "https://i.postimg.cc/7f9vK5z/fr.png" },
  { question: "علم إسبانيا 🇪🇸", answer: "إسبانيا", link: "https://i.postimg.cc/8e9vK5z/es.png" },
  { question: "علم إيطاليا 🇮🇹", answer: "إيطاليا", link: "https://i.postimg.cc/9i9vK5z/it.png" },
  { question: "علم ألمانيا 🇩🇪", answer: "ألمانيا", link: "https://i.postimg.cc/0d9vK5z/de.png" },
  { question: "علم البرازيل 🇧🇷", answer: "البرازيل", link: "https://i.postimg.cc/1b9vB5z/br.png" },
  { question: "علم الأرجنتين 🇦🇷", answer: "الأرجنتين", link: "https://i.postimg.cc/2a9vK5z/ar.png" },
  { question: "علم اليابان 🇯🇵", answer: "اليابان", link: "https://i.postimg.cc/3j9vK5z/jp.png" },
  { question: "علم كوريا الجنوبية 🇰🇷", answer: "كوريا الجنوبية", link: "https://i.postimg.cc/4k9vK5z/kr.png" },
  { question: "علم تركيا 🇹🇷", answer: "تركيا", link: "https://i.postimg.cc/5t9vK5z/tr.png" },
  { question: "علم بريطانيا 🇬🇧", answer: "بريطانيا", link: "https://i.postimg.cc/6b9vK5z/gb.png" },
  { question: "علم أمريكا 🇺🇸", answer: "أمريكا", link: "https://i.postimg.cc/7u9vK5z/us.png" }
];

// الجزء الخاص بدالة الـ run كما هو مع الالتزام بالكود المبعوث
const axios = require("axios");
const fs = require("fs");

module.exports.run = async function ({ api, event }) {
  const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
  const correctAnswer = randomQuestion.answer;
  const question = randomQuestion.question;
  const imageLink = randomQuestion.link;

  const path = __dirname + `/cache/flag_${event.threadID}.png`;
  const getImg = (await axios.get(imageLink, { responseType: "arraybuffer" })).data;
  fs.writeFileSync(path, Buffer.from(getImg, "utf-8"));

  const attachment = fs.createReadStream(path);
  const message = `اسرع شخص يحزر اسم العلم : 【 ${question} 】`;

  api.sendMessage({ body: message, attachment }, event.threadID, (error, info) => {
      if (!error) {
          global.client.handleReply.push({
              name: this.config.name,
              messageID: info.messageID,
              correctAnswer: correctAnswer
          });
      }
  });
};
