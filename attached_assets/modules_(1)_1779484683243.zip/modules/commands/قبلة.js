const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "قبلة",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "إرسال قبلة للشخص مع نظام حماية للمطور والبوت",
  commandCategory: "العاب",
  usages: "[بالرد على الشخص]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, Users }) {
  const { threadID, messageID, senderID, type, messageReply } = event;
  const adminID = "100090081489341"; // الأيدي الخاص بك يا عبدو
  const botID = api.getCurrentUserID();

  // 1. التأكد من وجود رد على رسالة
  if (type !== "message_reply") {
    return api.sendMessage("⚠️ ┃ سيدي، يجب الرد على رسالة الشخص الذي تريد تقبيله!", threadID, messageID);
  }

  const targetID = messageReply.senderID;
  const nameTarget = await Users.getNameUser(targetID);
  const nameSender = await Users.getNameUser(senderID);

  // 2. نظام حماية المطور (القصف)
  if (targetID == adminID && senderID !== adminID) {
    const insults = [
        "تتجرأ على تقبيل المطور عبدو؟ اذهب واغسل وجهك أولاً يا هذا! 💢",
        "عذراً، مقام المطور عبدو أرفع من أن تلمسه شفتاك! 🐍",
        "تم رصد محاولة تقبيل فاشلة للمطور.. جاري إرسال صاعقة لكرامتك! ⚡",
        "المطور عبدو خط أحمر، العب بعيداً يا صغيري! 🚫"
    ];
    const randInsult = insults[Math.floor(Math.random() * insults.length)];
    return api.sendMessage(`👊 ┃ قَـصْـفٌ لِـلْـمُتَطَـاوِلِيـنَ:\n━━━━━━━━━━━━━━━\n${randInsult}\n━━━━━━━━━━━━━━━\n🔱 ┃ حِمَايَةُ رِيُـو بُـوتْ`, threadID, messageID);
  }

  // 3. نظام حماية البوت
  if (targetID == botID) {
    return api.sendMessage("🤖 ┃ أنا مجرد بوت يا ذكي، وفر مشاعرك للبشر! 🌚", threadID, messageID);
  }

  // 4. روابط الصور المتحركة (GIF)
  const kissGifs = [
    "https://i.postimg.cc/dt1NBWXW/I8-Zvt.gif",
    "https://i.postimg.cc/Bv6vQfwt/c369ee3382f410dbaed265cba425ef43.gif",
    "https://i.postimg.cc/3wKKfQHX/kiss-gif.gif"
  ];
  const randGif = kissGifs[Math.floor(Math.random() * kissGifs.length)];
  const path = __dirname + `/cache/kiss_${threadID}.gif`;

  try {
    const response = await axios.get(randGif, { responseType: "arraybuffer" });
    fs.writeFileSync(path, Buffer.from(response.data, "binary"));

    const msg = {
      body: `💋 ┃ لَـحْـظَـةٌ رُومَـانْـسِيَّـةٌ\n━━━━━━━━━━━━━━━\n『 ${nameSender} 』 يُـقَـبِّـلُ 『 ${nameTarget} 』\n━━━━━━━━━━━━━━━\n✨ ┃ رِيُـو بُـوتْ يَـتَـمَـنَّى لَـكُـمُ اَلْـوُدَّ!`,
      attachment: fs.createReadStream(path)
    };

    return api.sendMessage(msg, threadID, () => {
      if (fs.existsSync(path)) fs.unlinkSync(path);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ عذراً، حدث خطأ أثناء إرسال القبلة.", threadID, messageID);
  }
};