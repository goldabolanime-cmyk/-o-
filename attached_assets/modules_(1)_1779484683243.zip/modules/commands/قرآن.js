const axios = require("axios");

module.exports.config = {
  name: "قرآن",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Gemini",
  description: "آية عشوائية مع إمكانية طلب التفسير",
  commandCategory: "الدينية",
  usages: "آية عشوائية",
  cooldowns: 5
};

module.exports.handleReply = async ({ api, event, handleReply }) => {
  const { threadID, messageID, body } = event;
  if (body.toLowerCase() !== "شرح") return;

  try {
    api.sendMessage("⏳ ┇ جـاري جـلـب الـتـفـسـيـر الـمـفـصـل...", threadID, messageID);
    
    // جلب التفسير (الميسر) باستخدام رقم السورة والآية من الـ handleReply
    const response = await axios.get(`https://quranenc.com/api/v1/translation/aya/arabic_moyassar/${handleReply.surah}/${handleReply.aya}`);
    const data = response.data.result;

    const msg = `📖 ┇ تـفـسـيـر الآيـة الـمـبـاركـة:\n──────────────\n${data.translation}\n──────────────\n⚠️ ┇ الـمـصدر: مـجـمـع الـمـلـك فـهـد لـطـبـاعـة الـمـصـحـف الـشـريـف.`;
    
    return api.sendMessage(msg, threadID, messageID);
  } catch (e) {
    return api.sendMessage("❌ ┇ عذراً، تعذر جلب التفسير في الوقت الحالي.", threadID, messageID);
  }
};

module.exports.run = async ({ api, event }) => {
  const { threadID, messageID } = event;

  try {
    // جلب آية عشوائية من API موثوق (نسخة تشكيل كاملة)
    const randomAyaNum = Math.floor(Math.random() * 6236) + 1;
    const response = await axios.get(`https://api.alquran.cloud/v1/ayah/${randomAyaNum}/ar.alafasy`);
    const ayaData = response.data.data;

    const surah = ayaData.surah.name;
    const ayaText = ayaData.text;
    const surahNum = ayaData.surah.number;
    const ayaNumInSurah = ayaData.numberInSurah;

    const msg = `✨ ┇ قـال الله تـعـالـى:\n\n« ${ayaText} »\n\n📖 ┇ سـورة: ${surah}\n📝 ┇ الآيـة: [${ayaNumInSurah}]\n──────────────\n💬 ┇ رد بـ " شرح " لـتـفـسـيـر الآيـة بـشـكـل مـفـصـل.`;

    return api.sendMessage(msg, threadID, (err, info) => {
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        surah: surahNum,
        aya: ayaNumInSurah
      });
    }, messageID);

  } catch (e) {
    console.log(e);
    return api.sendMessage("❌ ┇ حـدث خـطأ أثـنـاء جـلـب الآيـة الـكـريـمـة.", threadID, messageID);
  }
};
