const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const jimp = require("jimp");

module.exports.config = {
  name: "علم",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "نظام الأعلام الملكي المعدل",
  commandCategory: "ترفيه",
  usages: "[قائمة / رقم]",
  cooldowns: 5
};

const flagsList = [
  { name: "المغرب", url: "https://flagcdn.com/w512/ma.png" },
  { name: "فلسطين", url: "https://flagcdn.com/w512/ps.png" },
  { name: "الجزائر", url: "https://flagcdn.com/w512/dz.png" },
  { name: "مصر", url: "https://flagcdn.com/w512/eg.png" },
  { name: "تونس", url: "https://flagcdn.com/w512/tn.png" },
  { name: "السعودية", url: "https://flagcdn.com/w512/sa.png" },
  { name: "العراق", url: "https://flagcdn.com/w512/iq.png" },
  { name: "سوريا", url: "https://flagcdn.com/w512/sy.png" },
  { name: "روسيا", url: "https://flagcdn.com/w512/ru.png" },
  { name: "اليابان", url: "https://flagcdn.com/w512/jp.png" },
  { name: "علم الألوان (تأديب)", url: "https://i.ibb.co/7N86mS6/pride-flag.png" }
];

module.exports.handleReply = async ({ api, event, handleReply, Users }) => {
  const { threadID, messageID, senderID, body } = event;
  if (handleReply.author != senderID) return;
  const index = parseInt(body) - 1;
  if (isNaN(index) || !flagsList[index]) return;
  api.unsendMessage(handleReply.messageID);
  return applyFlag(api, event, index, Users);
};

module.exports.run = async ({ api, event, args, Users }) => {
  const { threadID, messageID, senderID } = event;
  if (!args[0] || args[0] === "قائمة") {
    let list = "┏━━━━━━━ ♛ ━━━━━━━┓\n   🚩 ┃ قَـائِمَةُ اَلْأَعْـلَامِ\n┗━━━━━━━━━━━━━━━━━━┛\n\n";
    flagsList.forEach((f, i) => list += `【 ${i + 1} 】- علم ${f.name}\n`);
    list += "\n📍 رُد بـالـرقم لتطبيق الفلتر";
    return api.sendMessage(list, threadID, (err, info) => {
      global.client.handleReply.push({ name: this.config.name, messageID: info.messageID, author: senderID });
    }, messageID);
  }
  const index = parseInt(args[0]) - 1;
  if (isNaN(index) || !flagsList[index]) return api.sendMessage("❌ رقم غير صحيح!", threadID, messageID);
  return applyFlag(api, event, index, Users);
};

async function applyFlag(api, event, index, Users) {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  const devID = "100090081489341";
  let targetID = (type === "message_reply") ? messageReply.senderID : (Object.keys(mentions).length > 0 ? Object.keys(mentions)[0] : senderID);
  
  if (targetID == devID && flagsList[index].name.includes("الألوان")) {
    return api.sendMessage("❌ ┃ لَا يُمْكِنُ تَطْبِيقُ هَذَا عَلَى سَيِّدِكَ اَلْـمُطَوِّرِ!", threadID, messageID);
  }

  try {
    api.sendMessage("⏳ جـارٍ اَلـتَّصْمِيـمُ...", threadID, messageID);
    const avatarUrl = `https://graph.facebook.com/${targetID}/picture?width=800&height=800&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
    
    // تحميل الصور كـ Buffer لضمان عدم حدوث خطأ في القراءة المباشرة
    const [avatarRes, flagRes] = await Promise.all([
      axios.get(avatarUrl, { responseType: 'arraybuffer' }),
      axios.get(flagsList[index].url, { responseType: 'arraybuffer' })
    ]);

    const image = await jimp.read(avatarRes.data);
    const flag = await jimp.read(flagRes.data);

    flag.resize(image.getWidth(), image.getHeight());
    flag.opacity(0.4);
    image.composite(flag, 0, 0);

    const pathImg = path.join(__dirname, "cache", `flag_${targetID}.png`);
    await image.writeAsync(pathImg);

    const name = await Users.getNameUser(targetID);
    return api.sendMessage({
      body: `┏━━━━━━━ ♛ ━━━━━━━┓\n   🚩 ┃ تَـمَّ اَلـتَّصْمِيـمُ بِنَـجَاحٍ\n┗━━━━━━━━━━━━━━━━━━┛\n👤 ┃ اَلْـمُسْتَهْدَفُ: 『 ${name} 』\n🔱 ┃ اَلْـمُطَـوِّرُ: عـبـدو`,
      attachment: fs.createReadStream(pathImg)
    }, threadID, () => fs.unlinkSync(pathImg), messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ حـدث خـطأ، تأكد من أن حساب الشخص ليس مقيداً.", threadID, messageID);
  }
}