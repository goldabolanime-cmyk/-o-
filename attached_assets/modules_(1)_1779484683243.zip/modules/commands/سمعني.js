const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "سماع",
  version: "9.0.0",
  hasPermssion: 0,
  credits: "عبدو",
  description: "بحث واستماع لأغاني ديزر (30 ثانية) مع 4 صور",
  commandCategory: "الوسائط",
  usages: "[اسم الأغنية]",
  cooldowns: 5
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const choice = parseInt(body);
  if (isNaN(choice) || choice < 1 || choice > handleReply.list.length) {
    return api.sendMessage("⚠️ ┃ اختر رقماً صحيحاً من القائمة.", threadID, messageID);
  }

  api.unsendMessage(handleReply.messageID);
  const selected = handleReply.list[choice - 1];
  
  api.sendMessage(`⏳ ┃ جـاري تجهيز المقطع (30 ثانية) لـ 『 ${selected.title} 』...`, threadID, messageID);

  try {
    const filePath = path.join(__dirname, "cache", `${Date.now()}.mp3`);
    const audioStream = await axios.get(selected.preview, { responseType: "arraybuffer" });
    fs.writeFileSync(filePath, Buffer.from(audioStream.data));

    return api.sendMessage({
      body: `✅ ┃ تـم التحميل بنجاح\n🎵 ┃ العنوان: ${selected.title}\n👤 ┃ الفنان: ${selected.artist}\n\n🔱 ┃ المطور: عبدو`,
      attachment: fs.createReadStream(filePath)
    }, threadID, () => {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ عذراً، تعذر سحب المقطع الصوتي حالياً.", threadID, messageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const query = args.join(" ");

  if (!query) return api.sendMessage("أرسل اسم الأغنية التي تبحث عنها.", threadID, messageID);

  try {
    // البحث في Deezer لجلب الصور والنتائج (أكثر استقراراً)
    const res = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(query)}`);
    const results = res.data.data.slice(0, 4);

    if (results.length === 0) return api.sendMessage("❌ ┃ لم أجد أي نتائج لهذه الأغنية.", threadID, messageID);

    const attachments = [];
    let msg = `✨ ┃ نـتـائـج اَلـبَـحْـثِ: ${query}\n━━━━━━━━━━━━━━━\n\n`;
    const listData = [];

    if (!fs.existsSync(path.join(__dirname, "cache"))) fs.mkdirSync(path.join(__dirname, "cache"));

    for (let i = 0; i < results.length; i++) {
      const track = results[i];
      msg += `【 ${i + 1} 】 ${track.title}\n👤 الفنان: ${track.artist.name}\n━━━━━━━━━━━━━━━\n`;
      
      const imgPath = path.join(__dirname, "cache", `dz_${i}_${Date.now()}.jpg`);
      const imgRes = await axios.get(track.album.cover_medium, { responseType: "arraybuffer" });
      fs.writeFileSync(imgPath, Buffer.from(imgRes.data));
      attachments.push(fs.createReadStream(imgPath));

      listData.push({
        title: track.title,
        artist: track.artist.name,
        preview: track.preview
      });
    }

    msg += "\n📥 ┃ رد برقم المقطع لسماع المعاينة (30 ثانية).";

    return api.sendMessage({ body: msg, attachment: attachments }, threadID, (err, info) => {
      // تنظيف الصور بعد الإرسال بـ 10 ثواني لضمان وصولها
      setTimeout(() => {
        attachments.forEach(s => { if (fs.existsSync(s.path)) fs.unlinkSync(s.path); });
      }, 10000);

      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        list: listData
      });
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ السيرفر مشغول حالياً، حاول مجدداً.", threadID, messageID);
  }
};