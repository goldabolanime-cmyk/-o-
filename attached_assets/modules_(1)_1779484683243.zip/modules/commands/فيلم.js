const axios = require("axios");
const fs = require("fs-extra");

module.exports.config = {
  name: "رواية",
  version: "3.2.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "البحث عن الروايات (مانهوا/مانها) بفلتر آمن ومنع محتوى الأنمي",
  commandCategory: "خدمات",
  usages: "[اسم الرواية بالانجليزية]",
  cooldowns: 5
};

async function translate(text) {
  try {
    const res = await axios.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=${encodeURIComponent(text)}`);
    return res.data[0].map(item => item[0]).join("");
  } catch (e) { return text; }
}

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const novelName = args.join(" ");

  if (!novelName) return api.sendMessage("⚠️ ┃ يـرجـى كـتـابـة اسـم الـروايـة.\nمـثـال: .رواية The Beginning After The End", threadID, messageID);

  try {
    const searchRes = await axios.get(`https://api.mangadex.org/manga`, { 
      params: { 
        title: novelName, 
        limit: 1,
        // استبعاد المحتوى المخل (الإباحي والجنسي)
        "contentRating[]": ["safe", "suggestive"], 
        // استبعاد المانجا اليابانية (الأنمي التقليدي) لضمان أنها روايات/مانهوا
        "excludedTags[]": ["2d1f5d5a-0297-4b0a-ad7c-21958428d57d"], // تاغ Sexual Violence أو محتوى غير مرغوب
        "publicationDemographic[]": ["shounen", "shoujo", "josei", "seinen"],
        // التركيز على المانهوا الكورية والمانها الصينية (أصل الروايات الحديثة)
        "availableTranslatedLanguage[]": ["en"]
      } 
    });

    if (searchRes.data.data.length === 0) return api.sendMessage("❌ ┃ لـم أجـد نـتـائج تـطـابـق فلاتـر الـحماية والـنوع.", threadID, messageID);

    const novel = searchRes.data.data[0];
    const novelID = novel.id;
    const title = novel.attributes.title.en || Object.values(novel.attributes.title)[0];
    const description = await translate((novel.attributes.description.en || "لا يوجد وصف").slice(0, 500));

    // جلب الغلاف
    const coverRel = novel.relationships.find(r => r.type === "cover_art");
    let coverUrl = "";
    if (coverRel) {
      const coverRes = await axios.get(`https://api.mangadex.org/cover/${coverRel.id}`);
      coverUrl = `https://uploads.mangadex.org/covers/${novelID}/${coverRes.data.data.attributes.fileName}`;
    }

    const cachePath = __dirname + `/cache/novel_${senderID}.jpg`;
    if (!fs.existsSync(__dirname + `/cache`)) fs.mkdirSync(__dirname + `/cache`);
    
    const getImg = (await axios.get(coverUrl, { responseType: "arraybuffer" })).data;
    fs.writeFileSync(cachePath, Buffer.from(getImg, "utf-8"));

    const msg = `📖 ┃ الـنـتـيـجـة: ${title}\n━━━━━━━━━━━━━━━\n📝 ┃ الـقـصـة: ${description}\n━━━━━━━━━━━━━━━\n✨ ┃ نـوع الـمحتـوى: آمـن (Safe Content)\n💡 ┃ رُد بـ [ فصل رقم ] لـلـقراءة الـملكيـة.`;

    return api.sendMessage({ body: msg, attachment: fs.createReadStream(cachePath) }, threadID, (err, info) => {
      if (fs.existsSync(cachePath)) fs.unlinkSync(cachePath);
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        novelID: novelID
      });
    }, messageID);

  } catch (e) { return api.sendMessage("❌ ┃ عـذراً، واجـه الـسـيرفر مـشكلة فـي الـتـصـفية.", threadID, messageID); }
};

module.exports.handleReply = async function({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (handleReply.author != senderID) return;

  const input = body.split(" ");
  if (input[0].toLowerCase() != "فصل") return;
  const chapterNum = input[1];

  api.sendMessage(`⏳ ┃ جـاري جـلب صـور الـفـصل ${chapterNum}.. لـحظة مـن فـضلك.`, threadID, messageID);

  try {
    const chapters = await axios.get(`https://api.mangadex.org/manga/${handleReply.novelID}/feed`, {
      params: { limit: 100, "translatedLanguage[]": ["en"], order: { chapter: "asc" } }
    });

    const chapter = chapters.data.data.find(c => c.attributes.chapter == chapterNum);
    if (!chapter) return api.sendMessage(`❌ ┃ الـفصل ${chapterNum} غـير مـتوفـر.`, threadID, messageID);

    const server = await axios.get(`https://api.mangadex.org/at-home/server/${chapter.id}`);
    const hash = server.data.chapter.hash;
    const pages = server.data.chapter.data;

    const attachments = [];
    const tempPaths = [];

    // جلب 8 صفحات لضمان سرعة الإرسال وعدم تعليق البوت
    for (let i = 0; i < Math.min(pages.length, 8); i++) {
      const url = `https://uploads.mangadex.org/data/${hash}/${pages[i]}`;
      const imgData = (await axios.get(url, { responseType: "arraybuffer" })).data;
      const imgPath = __dirname + `/cache/p_${i}_${senderID}.jpg`;
      fs.writeFileSync(imgPath, Buffer.from(imgData));
      tempPaths.push(imgPath);
      attachments.push(fs.createReadStream(imgPath));
    }

    api.sendMessage({
      body: `✅ ┃ الـفـصل ${chapterNum} جـاهـز لـلقـراءة.\n👑 اسـتمـتع بـالـوقت مـع رِيُـو بـوت.`,
      attachment: attachments
    }, threadID, () => {
      tempPaths.forEach(p => { if (fs.existsSync(p)) fs.unlinkSync(p); });
    }, messageID);

  } catch (e) {
    return api.sendMessage("❌ ┃ ضـغط عـلى الـسـيرفر، حـاول لاحقـاً.", threadID, messageID);
  }
};