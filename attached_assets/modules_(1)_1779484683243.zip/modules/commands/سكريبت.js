module.exports.config = {
  name: "شرح",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "عبدو / ريو بوت",
  description: "تحليل وشرح الصور باستخدام ذكاء Gemini الاصطناعي",
  commandCategory: "ذكاء اصطناعي",
  cooldowns: 5,
  dependencies: {
    "@google/generative-ai": "",
    "axios": "",
    "fs-extra": ""
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, type, messageReply } = event;
  const fs = require("fs-extra");
  const axios = require("axios");
  const { GoogleGenerativeAI } = require("@google/generative-ai");

  // دمج مفتاح الـ API الخاص بك
  const genAI = new GoogleGenerativeAI("AIzaSyA4ycxa1fnSJXJa6lUO6YXuf0EyyGL0rFM");

  // التحقق من وجود صورة (سواء في الرسالة أو برد على رسالة)
  let imageURL;
  if (type === "message_reply") {
    if (messageReply.attachments[0]?.type === "photo") {
      imageURL = messageReply.attachments[0].url;
    }
  } else if (event.attachments[0]?.type === "photo") {
    imageURL = event.attachments[0].url;
  }

  if (!imageURL) return api.sendMessage("⚠️ ┃ يرجى إرسال صورة أو الرد على صورة باستخدام أمر [ شرح ]", threadID, messageID);

  api.sendMessage("⏳ ┃ جـاري تـحـلـيـل الـصـورة بـواسطة ذكـاء رِيـو.. انـتـظـر لـحـظـة.", threadID, messageID);

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    // تحميل الصورة وتحويلها لتنسيق يفهمه الذكاء الاصطناعي
    const response = await axios.get(imageURL, { responseType: "arraybuffer" });
    const imgData = Buffer.from(response.data, "binary").toString("base64");

    const prompt = args.join(" ") || "اشرح هذه الصورة بالتفصيل وباللغة العربية، ركز على الألوان والمكونات والأجواء.";

    const result = await model.generateContent([
      prompt,
      { inlineData: { data: imgData, mimeType: "image/jpeg" } }
    ]);

    const description = result.response.text();

    const msg = `✨ ﴿ تَـحْـلِـيـلُ الـصُّـورَةِ ﴾ ✨\n━━━━━━━━━━━━━━━━━━\n📝 الـوَصْـف:\n${description}\n━━━━━━━━━━━━━━━━━━\n👑 رِيـو بُـوت - ذَكَـاءٌ لا مَـحْـدودٌ`;

    return api.sendMessage(msg, threadID, messageID);

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ ┃ عـذراً يا سـيدي، حـدث خـطأ أثـناء الاتـصال بـخوادم جـيـمـيـناي.", threadID, messageID);
  }
};