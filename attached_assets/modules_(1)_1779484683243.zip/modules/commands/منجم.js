module.exports.config = {
  name: "منجم",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOOT",
  description: "اقتحم المناجم الأسطورية واجمع الذهب مع تفاعل على رسالتك",
  commandCategory: "إقتصاد",
  usages: "",
  cooldowns: 0 
};

module.exports.run = async function ({ api, event, Currencies }) {
  const { threadID, messageID, senderID } = event;
  const cooldownTime = 3 * 60 * 60 * 1000; 
  
  const mines = [
    "منجم كاشينوجي (Kaiji)",
    "منجم الماس الأفريقي",
    "منجم ماجيكول (That Time I Got Reincarnated as a Slime)",
    "منجم الذهب في كاليفورنيا",
    "منجم الفضة الملعون (Black Clover)",
    "منجم الأحجار الكريمة (Steven Universe)",
    "منجم اليورانيوم السري",
    "منجم مملكة كوكو (Dr. Stone)",
    "منجم غرييد آيلاند (Hunter x Hunter)",
    "منجم جبل فوجي المستقبلي"
  ];

  let data = (await Currencies.getData(senderID)).data || {};
  if (typeof data.mineTime !== "undefined" && cooldownTime - (Date.now() - data.mineTime) > 0) {
    const time = cooldownTime - (Date.now() - data.mineTime);
    const hours = Math.floor(time / (60 * 60 * 1000));
    const minutes = Math.floor((time % (60 * 60 * 1000)) / (60 * 1000));
    return api.sendMessage(`⏳ ┃ يـا عـبـد الـذهب، عـمالك مـتـعبون الآن!\n\n👈 ┃ ارجـع لـلـمـنجم بـعـد: ${hours} سـاعـة و ${minutes} دقـيـقـة.`, threadID, messageID);
  }

  const selectedMine = mines[Math.floor(Math.random() * mines.length)];
  const reward = Math.floor(Math.random() * (1000 - 100 + 1)) + 100;

  // إرسال رسالة البداية
  api.sendMessage("⛏️ ┃ جـاري إرسـال الـعـمـال واقـتـحـام الـمنـجـم...\n\n⏳ ┃ انـتـظـر 10 ثـوانٍ لـتـرى مـاذا سـتـجـد.", threadID, messageID);

  // التفاعل بالساعة الرملية على رسالة المستخدم (messageID)
  setTimeout(() => { 
    api.setMessageReaction("⏳", messageID, (err) => {}, true); 
  }, 500);

  // الانتظار 10 ثواني قبل النتيجة
  setTimeout(async () => {
    // إضافة المال للبنك
    await Currencies.increaseMoney(senderID, reward);
    
    // حفظ وقت المحاولة
    data.mineTime = Date.now();
    await Currencies.setData(senderID, { data });

    const msg = 
      `┏━━━━━━━━━━━━━━┓\n` +
      `  💰 ┃ عـمـلـيـة تـنـقـيـب نـاجـحـة\n` +
      `┗━━━━━━━━━━━━━━┛\n\n` +
      `🛠️ ┃ لـقـد اقـتـحـمـت: ${selectedMine}\n` +
      `💎 ┃ وجـدت ثـروة قـدرهـا: ${reward} دولار\n` +
      `🏦 ┃ تـم إيـداع الـمـبـلـغ فـي حـسـابـك.\n\n` +
      `━━━━━━━━━━━━━━━\n` +
      `👑 ┃ الـمـطـور: عـبـدو | 🤖 ┃ ريـو`;

    api.sendMessage(msg, threadID, messageID);
    
    // تغيير التفاعل إلى علامة الصح على رسالة المستخدم (messageID)
    api.setMessageReaction("✅", messageID, (err) => {}, true);
  }, 10000);
};
