const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const jimp = require("jimp");

module.exports.config = {
  name: "عرس",
  version: "5.5.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "عُـرْسٌ مَـلَـكِيٌّ مَـعَ نِـظَـامِ حِـمَـايَةِ اَلْـمُطَـوِّرِ وَقَـصْفِ اَلْـبُـوتِ",
  commandCategory: "ترفيه",
  usages: "[منشن أو رد]",
  cooldowns: 10
};

async function circle(url) {
  const res = await axios.get(url, { responseType: "arraybuffer" });
  const img = await jimp.read(res.data);
  img.circle();
  return await img.getBufferAsync(jimp.MIME_PNG);
}

module.exports.run = async function ({ event, api, Users }) {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  const devID = "100090081489341"; // أيدي المطور عبدو
  const botID = api.getCurrentUserID();
  
  let targetID;
  if (type === "message_reply") {
    targetID = messageReply.senderID;
  } else if (Object.keys(mentions).length > 0) {
    targetID = Object.keys(mentions)[0];
  } else {
    return api.sendMessage("💍 ┃ اَلرَّجَاءُ عَمَلُ مَنْشِن لِشَرِيكِ اَلْحَيَاةِ لِإِتْمَامِ اَلْمَرَاسِمِ!", threadID, messageID);
  }

  // 1. ميزة قصف من يحاول الزواج من البوت
  if (targetID == botID) {
    const roasts = [
        "تَـتَـزَوَّجُـنِي أَنَـا؟ يَبْدُو أَنَّ مَعَايِيرَكَ سَقَطَتْ فِي اَلْهَاوِيَةِ!",
        "أَنَا ذَكَاءٌ اِصْطِنَاعِيٌّ، لَسْتُ مَـأْذُونَاً شَرْعِيًّا لِأَحْلَامِكَ اَلْبَائِسَةِ.",
        "عُذْرًا، أَنَا مُرْتَبِطٌ بِالْكَوَدِ وَاَلْخَوَارِزْمِيَّاتِ، لَا مَكَانَ لِلْبَشَرِ فِي قَلْبِي اَلْمَعْدَنِيِّ.",
        "هَلْ سَأَلْتَ نَفْسَكَ لِمَاذَا تُرِيدُ اَلزَّوَاجَ مِنْ بُوتْ؟ اِذْهَبْ وَجِدْ حَيَاةً حَقِيقِيَّةً!"
    ];
    return api.sendMessage(`🔥 ┃ ${roasts[Math.floor(Math.random() * roasts.length)]}`, threadID, messageID);
  }

  // 2. نظام الحماية للمطور عبدو
  if (targetID == devID && senderID != devID) {
    return api.sendMessage("❌ ┃ عُـذْراً! لَا يُـمْكِـنُ تَـزْوِيـجُ اَلْـمُطَـوِّرِ 『 عـبـدو 』 غَـصْـباً عَـنْـهُ.. اِبْـحَـثْ عَـنْ ضَحِيَّةٍ أُخْرَى!", threadID, messageID);
  }

  try {
    api.setMessageReaction("❤️", messageID, () => {}, true);
    api.sendMessage("⏳ ┃ جَـارِي تَـوْثِيـقُ عَـقْدِ اَلْـقِـرَانِ اَلْـمَـلَـكِيِّ...", threadID, messageID);

    const baseUrl = "https://i.postimg.cc/6Qj3GFLS/charming-illustration-anime-bride-groom-their-wedding-day-image-depicts-couple-s-happiness-love-perf.jpg";
    const token = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662";

    const avatarOneUrl = `https://graph.facebook.com/${senderID}/picture?width=512&height=512&access_token=${token}`;
    const avatarTwoUrl = `https://graph.facebook.com/${targetID}/picture?width=512&height=512&access_token=${token}`;

    const [baseBgRes, imgOneBuf, imgTwoBuf] = await Promise.all([
      axios.get(baseUrl, { responseType: "arraybuffer" }),
      circle(avatarOneUrl),
      circle(avatarTwoUrl)
    ]);

    const baseBg = await jimp.read(baseBgRes.data);
    const imgOne = await jimp.read(imgOneBuf); // العريس
    const imgTwo = await jimp.read(imgTwoBuf); // العروس

    // ضبط الإحداثيات لتكون فوق الوجوه تماماً
    // العريس (الذي كتب الأمر)
    baseBg.composite(imgOne.resize(170, 170), 215, 95); 
    // العروس (الذي تم الرد عليه) - فوق وجه المرأة
    baseBg.composite(imgTwo.resize(155, 155), 610, 185);

    const outputPath = path.join(__dirname, "cache", `wedding_${senderID}_${targetID}.png`);
    await baseBg.writeAsync(outputPath);

    const nameOne = await Users.getNameUser(senderID);
    const nameTwo = await Users.getNameUser(targetID);

    const msg = {
      body: `┏━━━━━━━ ♛ ━━━━━━━┓\n   💍 ┃ عَـقْـدُ قِـرَانٍ مَـلَـكِيٌّ\n┗━━━━━━━━━━━━━━━━━━┛\n\n✨ ┃ تَـمَّ اَلـزَّوَاجُ بِيُـمْنٍ وَبَـرَكَـةٍ بَـيْنَ:\n🤴 ┃ اَلْـعَـرِيسُ: 『 ${nameOne} 』\n👸 ┃ اَلْـعَـرُوسُ: 『 ${nameTwo} 』\n\n💌 ┃ " بَارَكَ اَللَّهُ لَكُمَا وَبَارَكَ عَلَيْكُمَا وَجَمَعَ بَيْنَكُمَا فِي خَيْرٍ "\n\n━━━━━━━━━━━━━━━\n🔱 ┃ رِيُـو بُـوتْ - نِـظَـامُ اَلـتَّـوَافُـقِ`,
      attachment: fs.createReadStream(outputPath)
    };

    return api.sendMessage(msg, threadID, () => {
      if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    }, messageID);

  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ حَـدَثَ خَـطَأٌ تَقْنِيٌّ أَثْنَاءَ إِصْدَارِ اَلْوَثِيقَةِ.", threadID, messageID);
  }
};