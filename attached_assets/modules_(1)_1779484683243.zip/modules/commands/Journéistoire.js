const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "تاريخ",
  version: "3.5.0",
  hasPermssion: 0,
  credits: "عبدو / ريو بوت",
  description: "تحدى أساطير التاريخ (3 محاولات كل 4 ساعات) ⚔️",
  commandCategory: "ألعاب",
  cooldowns: 5
};

module.exports.run = async function ({ event, api }) {
  const { threadID, messageID, senderID } = event;
  const pathData = path.join(__dirname, "cache", "history_limit.json");

  // التأكد من وجود المجلد والملف
  if (!fs.existsSync(path.join(__dirname, "cache"))) fs.mkdirSync(path.join(__dirname, "cache"));
  if (!fs.existsSync(pathData)) fs.writeJsonSync(pathData, {});

  let limitData = fs.readJsonSync(pathData);
  let userLimit = limitData[senderID] || { count: 0, time: Date.now() };

  const fourHours = 4 * 60 * 60 * 1000; // 4 ساعات بالملي ثانية

  // فحص الوقت: إذا مر أكثر من 4 ساعات، نصفر المحاولات
  if (Date.now() - userLimit.time >= fourHours) {
    userLimit.count = 0;
    userLimit.time = Date.now();
  }

  // فحص عدد المحاولات
  if (userLimit.count >= 3) {
    const timeLeft = Math.ceil((fourHours - (Date.now() - userLimit.time)) / (60 * 60 * 1000));
    return api.sendMessage(`⚠️ ┃ نَفَدَتْ مَحَاوَلَاتُكَ الـمَلَكِيَّة! اِنْتَظِرْ حَوَالِي ${timeLeft} سَاعَة لِتَجْدِيدِ طَاقَتِكَ.`, threadID, messageID);
  }

  // تحديث البيانات وحفظها قبل البدء
  userLimit.count += 1;
  limitData[senderID] = userLimit;
  fs.writeJsonSync(pathData, limitData);

  api.setMessageReaction("📖", messageID, (err) => {}, true);

  const msg = `━━━━━━━━━━━━━━━\n✨ ┃ سِـجِلُّ الـتَّارِيخِ الـمَلَكِي (رِيـو بُـوت)\n━━━━━━━━━━━━━━━\nاِخْتَرْ مَيْدَانَ الـتَّحَدِّي:\n(مَحَاوَلَةُ رَقْمِ: ${userLimit.count}/3)\n\n[ 1 ] ┃ مَيْدَانُ الْـفَاتِحِينَ ⚔️\n[ 2 ] ┃ مَيْدَانُ الْـمُحَارِبِينَ 🛡️\n\n━━━━━━━━━━━━━━━\n⚠️ ┃ رُدَّ بِرَقْمِ الـمَيْدَانِ لِكَشْفِ الأَسَاطِير!`;

  return api.sendMessage(msg, threadID, (err, info) => {
    global.client.handleReply.push({
      name: this.config.name,
      messageID: info.messageID,
      author: senderID,
      type: "choose_list"
    });
  }, messageID);
};

module.exports.handleReply = async ({ event, api, handleReply, Currencies }) => {
  const { threadID, messageID, senderID, body } = event;
  if (handleReply.author != senderID) return;

  api.unsendMessage(handleReply.messageID);

  const heroes1 = ["خَالِدُ بْنُ الْوَلِيدِ", "صَلَاحُ الدِّينِ الأَيُّوبِيُّ", "طَارِقُ بْنُ زِيَادٍ", "عَمْرُو بْنُ العَاصِ", "مُحَمَّدٌ الفَاتِحُ", "قُتَيْبَةُ بْنُ مُسْلِمٍ"];
  const heroes2 = ["عُمَرُ الـمُخْتَارُ", "يُوسُفُ بْنُ تَاشْفِينَ", "عُقْبَةُ بْنُ نَافِعٍ", "سَيْفُ الدِّينِ قُطُزُ", "الـمَلِكُ فَيْصَلٌ", "الـظَّاهِرُ بَيْبَرْسُ"];

  if (handleReply.type === "choose_list") {
    let listToDisplay = (body == "1") ? heroes1 : (body == "2") ? heroes2 : null;
    if (!listToDisplay) return api.sendMessage("❌ ┃ اِخْتِيَارٌ غَيْرُ صَحِيحٍ!", threadID, messageID);

    let msg = `━━━━━━━━━━━━━━━\n📜 ┃ اِخْتَرْ خَصْمَكَ مِنَ الأَسَاطِيرِ:\n━━━━━━━━━━━━━━━\n`;
    listToDisplay.forEach((name, index) => {
      msg += `[ ${index + 1} ] ┃ ${name}\n`;
    });
    msg += `━━━━━━━━━━━━━━━\n⚠️ ┃ رُدَّ بِرَقْمِ الْبَطَلِ لِبَدْءِ الـمُوَاجَهَةِ!`;

    return api.sendMessage(msg, threadID, (err, info) => {
      global.client.handleReply.push({
        name: "تاريخ",
        messageID: info.messageID,
        author: senderID,
        type: "fight",
        heroes: listToDisplay
      });
    }, messageID);
  }

  if (handleReply.type === "fight") {
    const heroIndex = parseInt(body) - 1;
    if (isNaN(heroIndex) || !handleReply.heroes[heroIndex]) {
      return api.sendMessage("❌ ┃ اِخْتِيَارٌ غَيْرُ صَحِيحٍ لِلْبَطَلِ!", threadID, messageID);
    }

    const chosenHero = handleReply.heroes[heroIndex];
    const isWin = Math.random() > 0.4;
    const amount = Math.floor(Math.random() * 901) + 100;

    if (isWin) {
      await Currencies.increaseMoney(senderID, amount);
      api.setMessageReaction("✅", messageID, () => {}, true);
      const winMsg = `━━━━━━━━━━━━━━━\n⚔️ ┃ تَـحَدِّي الأَسَاطِيرِ\n━━━━━━━━━━━━━━━\n✅ ┃ لَقَدْ انْتَصَرْتَ فِي مَعْرَكَتِكَ ضِدَّ:\n🔥 ┃ 【 ${chosenHero} 】\n\n💰 ┃ الـمُكَافَأَةُ الـمَلَكِيَّة: +${amount} كَاش\n━━━━━━━━━━━━━━━`;
      return api.sendMessage(winMsg, threadID, messageID);
    } else {
      await Currencies.decreaseMoney(senderID, amount);
      api.setMessageReaction("❌", messageID, () => {}, true);
      const loseMsg = `━━━━━━━━━━━━━━━\n⚔️ ┃ تَـحَدِّي الأَسَاطِيرِ\n━━━━━━━━━━━━━━━\n💀 ┃ لَقَدْ هُزِمْتَ شَرَّ هَزِيمَةٍ أَمَامَ:\n🛡️ ┃ 【 ${chosenHero} 】\n\n💸 ┃ غَرَامَةُ الـفَشَلِ: -${amount} كَاش\n━━━━━━━━━━━━━━━`;
      return api.sendMessage(loseMsg, threadID, messageID);
    }
  }
};