module.exports.config = {
    name: "آية",
    version: "1.2.0",
    hasPermssion: 0,
    credits: "عمر & عبدو",
    description: "تحدي معرفة معلومات الآية الكريمة مع مكافآت مالية",
    commandCategory: "إسلاميات",
    usages: "آية",
    cooldowns: 5,
    dependencies: {
        "axios": ""
    }
};

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
    const { body, senderID, threadID, messageID } = event;
    if (senderID !== handleReply.author) return;

    const { sName, sPart, aNum, aOrder } = handleReply;
    const input = body.trim().split(/\s+/); // تقسيم النص بناءً على المساحات مهما كان عددها
    
    const timeTaken = ((Date.now() - handleReply.startTime) / 1000).toFixed(1);
    
    let reward = 0;
    let results = "";

    // مصفوفة للتحقق من الإجابات (بدون زخرفة في النتائج)
    const checkAnswers = [
        { val: input[0], correct: sName, label: "اسم السورة" },
        { val: input[1], correct: sPart, label: "الجزء" },
        { val: input[2], correct: aNum, label: "رقم الآية" },
        { val: input[3], correct: aOrder, label: "الترتيب" }
    ];

    checkAnswers.forEach(item => {
        if (item.val == item.correct) {
            reward += 100;
            results += `[OK] ${item.label}: صحيحة (+100$)\n`;
        } else {
            results += `[X] ${item.label}: خطأ (الإجابة: ${item.correct})\n`;
        }
    });

    await Currencies.increaseMoney(senderID, reward);

    // رسالة النتيجة بسيطة وغير مزخرفة لتسهيل الاستخدام
    const finalMsg = `--- نتيجة التحدي ---
المستخدم: ${senderID}
الوقت المستغرق: ${timeTaken} ثانية
-------------------
${results}
-------------------
المكافأة الكلية: ${reward}$
تم إضافة المبلغ لرصيدك بنجاح.`;

    api.unsendMessage(handleReply.messageID).catch(e => {});
    return api.sendMessage(finalMsg, threadID, messageID);
};

module.exports.run = async function ({ api, event, Currencies }) {
    const axios = require("axios");
    const { threadID, messageID, senderID } = event;

    try {
        const randomAyahNum = Math.floor(Math.random() * 6236) + 1;
        const res = await axios.get(`https://api.alquran.cloud/v1/ayah/${randomAyahNum}/ar.alafasy`);
        const data = res.data.data;

        const ayahText = data.text;
        const sName = data.surah.name;
        const sPart = data.juz;
        const aNum = data.numberInSurah;
        const aOrder = data.number;

        // رسالة العرض مزخرفة لتكون جذابة
        const msg = `━━━━━━━━━━━━━
『 ✦ تـحـدي الآيـة الـكـريـمـة ✦ 』
━━━━━━━━━━━━━
۞ { ${ayahText} } ۞
━━━━━━━━━━━━━
📝 المطلوب الرد على الرسالة بالترتيب:
[اسم السورة] [الجزء] [رقم الآية] [الترتيب]

💡 مثال: البقرة 1 5 5
━━━━━━━━━━━━━
⏳ الوقت: 70 ثانية | 🎁 الجائزة: 400$
━━━━━━━━━━━━━`;

        return api.sendMessage(msg, threadID, (err, info) => {
            if (err) return;
            global.client.handleReply.push({
                name: this.config.name,
                messageID: info.messageID,
                author: senderID,
                sName,
                sPart,
                aNum,
                aOrder,
                startTime: Date.now()
            });

            setTimeout(() => {
                api.unsendMessage(info.messageID).catch(e => {});
            }, 70000);
        }, messageID);

    } catch (e) {
        return api.sendMessage("⚠️ حدث خطأ أثناء جلب البيانات، يرجى المحاولة لاحقاً.", threadID, messageID);
    }
};
