module.exports.config = {
  name: "تجميع",
  version: "2.5.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "لعبة تجميع الكلمات المبعثرة - 60 كلمة ملكية",
  commandCategory: "العاب",
  usages: ["تجميع"],
  cooldowns: 5
};

const questions = [
  { question: "ا ل ظ ل ا م", answer: "الظلام" },
  { question: "ا ل س ع ا د ة", answer: "السعادة" },
  { question: "ا ل ث ر و ة", answer: "الثروة" },
  { question: "ا ل ح ر ا ر ة", answer: "الحرارة" },
  { question: "ا ل ر ط و ب ة", answer: "الرطوبة" },
  { question: "ا ل ض و ض ا ء", answer: "الضوضاء" },
  { question: "ا ل م و ت", answer: "الموت" },
  { question: "ا ل ن ه ا ي ة", answer: "النهاية" },
  { question: "ا ل أ د ن ى", answer: "الأدنى" },
  { question: "ا ل خ ا ر ج", answer: "الخارج" },
  { question: "ا ل خ ل ف", answer: "الخلف" },
  { question: "ا ل ي س ا ر", answer: "اليسار" },
  { question: "ا ل ب ع ي د", answer: "البعيد" },
  { question: "ا ل ص ع ب", answer: "الصعب" },
  { question: "ا ل ق ا س ي", answer: "القاسي" },
  { question: "ا ل ح ز ن", answer: "الحزن" },
  { question: "ا ل ك ر ا ه ي ة", answer: "الكراهية" },
  { question: "ا ل ع ص ب ي ة", answer: "العصبية" },
  { question: "ا ل ح ق ي ق ة", answer: "الحقيقة" },
  { question: "ا ل م ا ض ي", answer: "الماضي" },
  { question: "ا ل ح ا ض ر", answer: "الحاضر" },
  { question: "ا ل م ز ي ف", answer: "المزيف" },
  { question: "ا ل خ ط أ", answer: "الخطأ" },
  { question: "ا ل س ي ئ", answer: "السيئ" },
  { question: "ا ل ق ب ي ح", answer: "القبيح" },
  { question: "ا ل ف ق ي ر", answer: "الفقير" },
  { question: "ا ل ض ع ي ف", answer: "الضعيف" },
  { question: "ا ل خ ا ئ ن", answer: "الخائن" },
  { question: "ا ل أ ن ث ى", answer: "الأنثى" },
  { question: "ا ل م ؤ ن ث", answer: "المؤنث" },
  { question: "ا ل س ل ب ي", answer: "السلبي" },
  { question: "ا ل م ل ل", answer: "الملل" },
  { question: "ا ل ك ب ر ى", answer: "الكبرى" },
  { question: "ا ل ك ث ر ة", answer: "الكثرة" },
  { question: "ا ل ص ع و ب ة", answer: "الصعوبة" },
  { question: "ا ل ق س و ة", answer: "القسوة" },
  { question: "ا ل ا ي م ا ن", answer: "الايمان" },
  { question: "ا ل ي أ س", answer: "اليأس" },
  { question: "ا ل غ ي ب و ب ة", answer: "الغيبوبة" },
  { question: "ا ل ن و م", answer: "النوم" },
  { question: "ا ل ك ذ ب", answer: "الكذب" },
  { question: "ا ل ظ ل م", answer: "الظلم" },
  { question: "ا ل ش ر", answer: "الشر" },
  { question: "ا ل ق ب ح", answer: "القبح" },
  { question: "ا ل ن ق ص", answer: "النقص" },
  { question: "ا ل ق س ط ن ط ي ن ي ة", answer: "القسطنطينية" },
  { question: "ا ل د ي م ق ر ا ط ي ة", answer: "الديمقراطية" },
  { question: "ا ل ج غ ر ا ف ي ا", answer: "الجغرافيا" },
  { question: "ا ل م س ت ق ب ل", answer: "المستقبل" },
  { question: "ا ل ك ي م ي ا ء", answer: "الكيمياء" },
  { question: "ا ل ب ر م ج ة", answer: "البرمجة" },
  { question: "ا ل م خ ا ب ر ا ت", answer: "المخابرات" },
  { question: "ا ل م س ت ش ف ى", answer: "المستشفى" },
  { question: "ا ل م ه ن د س", answer: "المهندس" },
  { question: "ا ل ص ي د ل ي ة", answer: "الصيدلية" },
  { question: "ا ل ت ك ن و ل و ج ي ا", answer: "التكنولوجيا" },
  { question: "ا ل إ م ب ر ا ط و ر ي ة", answer: "الإمبراطورية" },
  { question: "ا ل م س ؤ و ل ي ة", answer: "المسؤولية" },
  { question: "ا ل ا س ت ق ل ا ل", answer: "الاستقلال" },
  { question: "ا ل م و س ي ق ى", answer: "الموسيقى" }
];

module.exports.handleReply = async function ({ api, event, handleReply, Currencies }) {
  const { body, senderID, threadID, messageID } = event;
  const userAnswer = body.trim();
  const correctAnswer = handleReply.correctAnswer;

  if (userAnswer === correctAnswer) {
      await Currencies.increaseMoney(senderID, 50);
      api.unsendMessage(handleReply.messageID);
      return api.sendMessage(`✨ ┃ تـهـانـيـنـا يـا بـطـل!\n━━━━━━━━━━━━━━━\n✅ ┃ إجـابـتـك صـحـيـحـة: [ ${correctAnswer} ]\n💰 ┃ لـقـد حـصـلـت عـلـى: 50$\n🏆 ┃ تـم إضـافـتـهـا لـحـسـابـك الـبـنـكـي.`, threadID, messageID);
  } else {
      return api.sendMessage(`❌ ┃ حـاول مـرة أخرى، اَلـتَّـجْـمِـيعُ غـيـر صـحـيـح.`, threadID, messageID);
  }
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
  const question = randomQuestion.question;
  const correctAnswer = randomQuestion.answer;

  const msg = `🧩 ┃ لُـعْـبَـةُ اَلـتَّـجْـمِـيعِ اَلْـمَـلَـكِيَّـةِ\n━━━━━━━━━━━━━━━\n‹ أَسْـرعُ شَـخْـصٍ يُـجَـمِّـعُ اَلْـكَـلِـمَـةَ ›\n\n『 ${question} 』\n\n━━━━━━━━━━━━━━━\n💰 ┃ اَلْـجَـائِـزَةُ: [ 50$ ]\n📝 ┃ قُـمْ بِـالـرَّدِّ عـلـى اَلـرِّسَـالَـةِ بِـالْـحَلِّ.`;

  return api.sendMessage(msg, threadID, (err, info) => {
    api.setMessageReaction("🧩", info.messageID, () => {}, true);
    
    global.client.handleReply.push({
      name: this.config.name,
      messageID: info.messageID,
      correctAnswer: correctAnswer
    });
  }, messageID);
};