module.exports.config = {
  name: "جوعان",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "يرسل صور مأكولات شهية عشوائية بروابط مباشرة",
  commandCategory: "تسلية",
  usages: "",
  cooldowns: 5,
  dependencies: {
    "axios": "",
    "fs-extra": ""
  }
};

module.exports.run = async function ({ api, event }) {
  const axios = require("axios");
  const fs = require("fs-extra");
  const { threadID, messageID } = event;

  // قائمة مأكولات بروابط مباشرة ومجربة
  const foodList = [
    { name: "شاورما صاج 🌯", url: "https://i.imgur.com/8Nf0q0F.jpg" },
    { name: "برجر بالجبنة 🍔", url: "https://i.imgur.com/66N7L3R.jpg" },
    { name: "بيتزا إيطالية 🍕", url: "https://i.imgur.com/S6L2BwW.jpg" },
    { name: "دجاج مقلي (كنتاكي) 🍗", url: "https://i.imgur.com/A6uU97V.jpg" },
    { name: "صحن مشويات 🍢", url: "https://i.imgur.com/B9Oun9X.jpg" },
    { name: "كنافة بالجبنة 🍮", url: "https://i.imgur.com/Xp7V6rU.jpg" },
    { name: "بطاطس مقلية 🍟", url: "https://i.imgur.com/vHqB3qf.jpg" },
    { name: "سوشي 🍣", url: "https://i.imgur.com/S6M8R2L.jpg" }
  ];

  const food = foodList[Math.floor(Math.random() * foodList.length)];
  const path = __dirname + `/cache/food_${event.senderID}.jpg`;

  try {
    // تحميل الصورة مع وضع headers لتجنب المنع
    const response = await axios.get(food.url, { 
        responseType: "arraybuffer",
        headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    
    fs.writeFileSync(path, Buffer.from(response.data, "utf-8"));

    return api.sendMessage({
      body: `😋 ┃ اِبلع يـا جـوعـان: [ ${food.name} ]`,
      attachment: fs.createReadStream(path)
    }, threadID, () => {
      if (fs.existsSync(path)) fs.unlinkSync(path);
    }, messageID);

  } catch (error) {
    console.error(error);
    return api.sendMessage("❌ | لـلأسـف السيرفر مشغول، حاول مرة أخرى!", threadID, messageID);
  }
};
