module.exports.config = {
  name: "بيانات",
  version: "1.5.0",
  hasPermssion: 0,
  credits: "عمر / تعديل ريو",
  description: "عرض الحالة الملكية وإحصائيات نظام ريو بوت",
  commandCategory: "خدمات",
  cooldowns: 5,
  dependencies: {
    "pidusage": ""
  }
};

function byte2mb(bytes) {
  const units = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  let l = 0, n = parseInt(bytes, 10) || 0;
  while (n >= 1024 && ++l) n = n / 1024;
  return `${n.toFixed(2)} ${units[l]}`;
}

module.exports.run = async ({ api, event }) => {
  const time = process.uptime(),
    days = Math.floor(time / (24 * 60 * 60)),
    hours = Math.floor((time % (24 * 60 * 60)) / (60 * 60)),
    minutes = Math.floor((time % (60 * 60)) / 60),
    seconds = Math.floor(time % 60);

  const pidusage = await global.nodemodule["pidusage"](process.pid);
  const timeStart = Date.now();

  let msg = `🏰 ═══ ﴿ حَالة مَمْلَكة رِيُو ﴾ ═══ 🏰\n\n`;
  msg += `👑 ┇ نـظـام الـتـشـغـيـل: مـسـتـقـر ✅\n`;
  msg += `⏳ ┇ وقـت الـصـمـود: ${days} يوم و ${hours} ساعة و ${minutes} دقيقة.\n`;
  msg += `👥 ┇ عـدد الـرعـايـا: ${global.data.allUserID.length} مـسـتـخـدم\n`;
  msg += `🏯 ┇ عـدد الـمـقاطـعـات: ${global.data.allThreadID.length} مـجـمـوعـة\n`;
  msg += `━━━━━━━━━━━━━━━\n`;
  msg += `⚙️ ┇ اسـتـهـلاك الـقـوة (CPU): ${pidusage.cpu.toFixed(1)}%\n`;
  msg += `🧠 ┇ ذاكـرة الـمـمـلـكـة (RAM): ${byte2mb(pidusage.memory)}\n`;
  msg += `📡 ┇ سـرعـة الاسـتـجـابـة: ${Date.now() - timeStart} مـلي ثـانـيـة\n`;
  msg += `━━━━━━━━━━━━━━━\n`;
  msg += `✨ ┇ رِيُو بُوت فـي خـدمـتـك دائـمـاً ┇ ✨`;

  return api.sendMessage(msg, event.threadID, event.messageID);
}