module.exports.config = {
  name: "تعال",
  version: "1.0.0",
  hasPermssion: 1, // للأدمن والمطور عبدو
  credits: "عبدو / RIO BOOT",
  description: "إعادة الشخص الذي غادر المجموعة فوراً",
  commandCategory: "نظام الحماية",
  usages: "بالرد على إشعار المغادرة أو الشخص واكتب .تعال",
  cooldowns: 5
};

module.exports.handleEvent = async function({ api, event }) {
  const { threadID, logMessageType, logMessageData } = event;
  
  // إذا غادر شخص أو تم طرده، يرسل البوت تنبيهاً مع زر الإعادة
  if (logMessageType === "log:unsubscribe") {
    const leftID = logMessageData.leftParticipantFbId;
    if (leftID == api.getCurrentUserID()) return; // تجاهل خروج البوت نفسه

    return api.sendMessage(`⚠️ ┃ لـقـد حـاول "${leftID}" الـهـروب مـن الـمـمـلـكـة!\n━━━━━━━━━━━━━━━\n💡 ┃ سـيـدي عـبـدو، رد عـلـى هـذا الإشـعـار بـكـلـمـة [.تـعال] لإعـادتـه فوراً.`, threadID);
  }
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, type, messageReply } = event;

  // 1. التأكد من الرد على رسالة
  if (type !== "message_reply") {
    return api.sendMessage("❌ ┃ يـا سـيـدي، يـجـب أن تـرد عـلى إشـعـار مـغـادرة الـشـخـص لأسـحـبـه.", threadID, messageID);
  }

  // 2. استخراج الأيدي من الرسالة التي تم الرد عليها
  let targetID;
  const replyBody = messageReply.body;
  
  // محاولة استخراج الأيدي إذا كان الرد على رسالة البوت التلقائية
  const idRegex = /"(\d+)"/; 
  const match = replyBody.match(idRegex);

  if (match && match[1]) {
    targetID = match[1];
  } else {
    // إذا كان الرد على رسالة عادية للشخص قبل خروجه
    targetID = messageReply.senderID;
  }

  if (!targetID) return api.sendMessage("❌ ┃ لـم أسـتـطـع تـحـديـد هـويـة الـهـارب.", threadID, messageID);

  // 3. تنفيذ عملية الإعادة (السحب)
  return api.addUserToGroup(targetID, threadID, (err) => {
    if (err) {
      return api.sendMessage("⚠️ ┃ فـشـلـت فـي إعـادتـه. قـد يـكـون حـظـر الـبـوت أو أنـنـي لـسـت أدمن.", threadID, messageID);
    } else {
      return api.sendMessage(`⛓️ ┃ تـم سـحـب الـهـارب وإعـادتـه لـلـقـيـد بـنـجـاح!\n👤 ┃ الأيـدي: ${targetID}`, threadID, messageID);
    }
  });
};
