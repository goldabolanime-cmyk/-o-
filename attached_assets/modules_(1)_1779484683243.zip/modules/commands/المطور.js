module.exports.config = {
  name: "المطور",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "عرض معلومات المطور عبدو الرسمية",
  commandCategory: "الخدمات",
  usages: "المطور",
  cooldowns: 5,
  dependencies: {
    "axios": "",
    "fs-extra": ""
  }
};

module.exports.run = async function ({ api, event }) {
  const axios = require("axios");
  const fs = require("fs-extra");
  const { threadID, messageID } = event;

  const devID = "100090081489341";
  const fbLink = `https://www.facebook.com/profile.php?id=${devID}`;
  const igLink = "https://www.instagram.com/bdww1015?igsh=NXI2NG9qZGZjNG11";
  const whatsapp = "+212606167137";
  const avatarUrl = `https://graph.facebook.com/${devID}/picture?width=512&height=512&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
  const path = __dirname + "/cache/dev_avatar.png";

  try {
    const response = await axios.get(avatarUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(path, Buffer.from(response.data, "utf-8"));

    const message = {
      body: `┌──────────────┐\n   بَيَانَاتُ المُطَوِّرِ الرَّسْمِيِّ\n└──────────────┘\n\n« الِاسْمُ »\n【 عـبـدو | 𝗔𝗕𝗗𝗢𝗨 】\n\n« الـأَيْدِي »\n【 ${devID} 】\n\n« الـبَـلَدُ »\n【 الـمَغْرِبُ الأَقْصَى 】\n\n« الـلُّعْبَةُ المُفَضَّلَةُ »\n【 𝗚𝗧𝗔 𝗩 】\n\n« الـهِـوَايَـةُ »\n【 مَـا دَخـلُـكَ 】\n\n« الـأَنْمِيُّ المُفَضَّلُ »\n【 مَـا دَخـلُـكَ بَـرْضُـو 】\n\n« رَابِـطُ الـفِـيـسـبُـوك »\n${fbLink}\n\n« رَابِـطُ إِنـسـتِـغـرَام »\n${igLink}\n\n« رَقـمُ الـوَاتـسَـاب »\n【 ${whatsapp} 】\n\n— — — — — — — — — —\nتَـمَّ الـتَّـطْـوِيـرُ بِـوَاسِـطَـةِ :\n𝗥𝗜𝗢 𝗕𝗢𝗢𝗧 𝗦𝗬𝗦𝗧𝗘𝗠`,
      attachment: fs.createReadStream(path)
    };

    return api.sendMessage(message, threadID, () => {
        if (fs.existsSync(path)) fs.unlinkSync(path);
    }, messageID);

  } catch (e) {
    return api.sendMessage(`بَيَانَاتُ المُطَوِّرِ الرَّسْمِيِّ\n\nالاسم: عبدو\nالايدي: ${devID}\nالرابط: ${fbLink}`, threadID, messageID);
  }
};