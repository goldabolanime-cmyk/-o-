module.exports.config = {
  name: "اوبتايم",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "Mustapha",
  description: "عرض معلومات السيرفر بفخامة",
  commandCategory: "النظام",
  usages: "اوبتايم",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const os = require("os");
  const moment = require("moment-timezone");

  // حساب وقت التشغيل
  const uptime = process.uptime();
  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);

  // حساب الذاكرة
  const totalMem = (os.totalmem() / 1024 / 1024).toFixed(0);
  const freeMem = (os.freemem() / 1024 / 1024).toFixed(0);
  const usedMem = (totalMem - freeMem).toFixed(0);
  const memUsage = ((usedMem / totalMem) * 100).toFixed(1);

  const cpuModel = os.cpus()[0].model;
  const cpuCores = os.cpus().length;
  const currentTime = moment.tz("Africa/Algiers").format("HH:mm:ss | YYYY/MM/DD");

  const message = `
┏━━━━━━━━━━━━━━━━━━━┓
  ✨ 𝗦𝗬𝗦𝗧𝗘𝗠 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ✨
┗━━━━━━━━━━━━━━━━━━━┛

👑 ⟪ حـالـة الـنـظـام ⟫ 👑

⌛ ❪ مـدة الـتـشـغـيـل ❫
» ${hours} سـاعـة | ${minutes} دقـيـقـة | ${seconds} ثـانـيـة

🖥️ ❪ مـعـالـج الـسـيـرفـر ❫
» الـنـوع: ${cpuModel}
» الألـويـة: [ ${cpuCores} ] Cores

💾 ❪ ذاكـرة الـنـظـام (RAM) ❫
» الـكـلـيـة: ${totalMem} MB
» الـمـسـتـهـلـكـة: ${usedMem} MB
» الـنـسـبـة: [ ${memUsage}% ]

🌍 ❪ تـفـاصـيـل الإقـلـيـم ❫
» الـوقـت: ${currentTime}
» الـمـنـطـقـة: Africa / Algiers

┗━━━━━━━━━━━━━━━━━━━┛
      ✅️ تـم الـفـحـص بـنـجـاح ✅️
`;

  api.sendMessage(message, event.threadID, event.messageID);
};
