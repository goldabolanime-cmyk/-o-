module.exports.config = {
  name: "رست",
  version: "3.0.0",
  hasPermssion: 2,
  credits: "RIO BOOT",
  description: "إعادة تشغيل النظام مع رسائل متتالية وتفاعل",
  commandCategory: "المطور",
  cooldowns: 5
};

module.exports.run = async ({ api, event }) => {
  const { threadID, messageID, senderID } = event;
  
  // التحقق من الأيدي الخاص بك يا عبدو
  const devID = "100090081489341";
  if (senderID !== devID) return api.sendMessage("🚫 ┃ عـذراً، هـذا الأمـر مـخصـص لـلـمـطـور عـبـدو فـقـط!", threadID, messageID);

  // 1. التفاعل الأول بالساعة الرملية
  api.setMessageReaction("⏳", messageID, (err) => {}, true);

  // 2. إرسال الرسالة الأولى
  return api.sendMessage("⏳ ┃ جـاري إعـادة تـشـغـيـل الـنـظـام...", threadID, async () => {
    
    // الانتظار 5 ثواني كما طلبت
    await new Promise(resolve => setTimeout(resolve, 5000));

    // 3. إرسال الرسالة الثانية قبل الإغلاق مباشرة
    api.sendMessage("✅ ┃ تـمـت عـمـلـيـة إعـادة الـتـشـغـيـل بـنـجـاح!\n🚀 ┃ جـاري الاتـصـال بـالـخـادم الآن...", threadID, async () => {
      
      // التفاعل بعلامة الصح
      api.setMessageReaction("✅", messageID, (err) => {}, true);
      
      // تأخير بسيط جداً لضمان وصول الرسالة الأخيرة قبل قتل العملية
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // الخروج من النظام (ليقوم الرافع بإعادة التشغيل تلقائياً)
      process.exit(1);
    }, messageID);

  }, messageID);
};
