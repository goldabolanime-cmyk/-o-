module.exports.config = {
  name: "ابلاغ",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "RIO BOOT",
  description: "ابلاغ عن مشكلة وإرسالها لقروب الإدارة",
  commandCategory: "خدمات",
  usages: "[النص]",
  cooldowns: 5,
};

module.exports.handleReply = async function({ api, event, handleReply, Users }) {
  const { threadID, messageID, senderID, body } = event;
  const name = await Users.getNameUser(senderID);
  const adminGroupID = "1345646303986676"; // أيدي قروب الإدارة الخاص بك

  switch (handleReply.type) {
    case "reply": {
      // إرسال رد المستخدم إلى قروب الإدارة
      api.sendMessage({
        body: `✉️ ┃ رد من الـمـسـتـخـدم: ${name}\n━━━━━━━━━━━━━\n${body}`,
        mentions: [{ id: senderID, tag: name }]
      }, adminGroupID, (e, data) => global.client.handleReply.push({
        name: this.config.name,
        messageID: data.messageID,
        messID: messageID,
        author: senderID,
        id: threadID,
        type: "calladmin"
      }));
      break;
    }
    case "calladmin": {
      // إرسال رد الإدارة إلى المستخدم في مجموعته الأصلية
      api.sendMessage({
        body: `👑 ┃ رد مـن الإدارة:\n━━━━━━━━━━━━━\n${body}\n━━━━━━━━━━━━━\n» رد عـلى هـذه الـرسـالة لـلإكـمال.`,
      }, handleReply.id, (e, data) => global.client.handleReply.push({
        name: this.config.name,
        author: senderID,
        messageID: data.messageID,
        type: "reply"
      }), handleReply.messID);
      break;
    }
  }
};

module.exports.run = async function({ api, event, args, Users }) {
  const { threadID, messageID, senderID } = event;
  if (!args[0]) return api.sendMessage("⚠️ ┃ يـرجى كـتابة الـمـشـكـلة لـلإبـلاغ عـنـهـا.", threadID, messageID);

  const adminGroupID = "1345646303986676"; // أيدي قروب الإدارة
  const name = await Users.getNameUser(senderID);
  const threadInfo = await api.getThreadInfo(threadID);
  const threadName = threadInfo.threadName || "مجموعة غير مسمى";

  const moment = require("moment-timezone");
  const time = moment.tz("Africa/Casablanca").format("HH:mm:ss DD/MM/YYYY");

  api.sendMessage("✅ ┃ تـم إرسـال بـلاغـك إلـى إدارة ريـو بـوت، سـيـتـم الـرد عـلـيـك قـريـبـاً.", threadID, () => {
    api.sendMessage({
      body: `🚨 ┃ تـقـريـر بـلاغ جـديـد\n━━━━━━━━━━━━━\n👤 ┃ مـن: ${name}\n🆔 ┃ أيدي الـمـرسـل: ${senderID}\n🏘️ ┃ الـمـجموعـة: ${threadName}\n🔖 ┃ أيدي الـمـجموعـة: ${threadID}\n━━━━━━━━━━━━━\n📝 ┃ الـمـشـكـلـة: ${args.join(" ")}\n━━━━━━━━━━━━━\n⏰ ┃ الـتـوقـيـت: ${time}`,
      mentions: [{ tag: name, id: senderID }]
    }, adminGroupID, (error, info) => {
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        author: senderID,
        messID: messageID,
        id: threadID,
        type: "calladmin"
      });
    });
  }, messageID);
};
