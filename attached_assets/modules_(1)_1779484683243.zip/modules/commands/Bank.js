const path = require("path");
const fs = require("fs-extra");

const pathData = path.join(__dirname, '/banking/banking.json');
const pathCheques = path.join(__dirname, '/banking/cheques.json');

module.exports.config = {
  name: "بنك",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "عبدو / RIO BOT",
  description: "نظام بنك ريو الملكي - إصدار الشيكات المطور",
  commandCategory: "الأموال",
  usages: "[تسجيل/ايداع/سحب/عرض/توب/تحويل/شيك/فحص/عدالة/رست]",
  cooldowns: 5,
  dependencies: { "fs-extra": "", "path": "" }
};

module.exports.onLoad = async () => {
  const dir = path.join(__dirname, '/banking');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(pathData)) fs.writeFileSync(pathData, "[]", "utf-8");
  if (!fs.existsSync(pathCheques)) fs.writeFileSync(pathCheques, "{}", "utf-8");
};

module.exports.run = async function({ api, event, args, Currencies, Users }) {
  const { threadID, messageID, senderID, mentions, type, messageReply } = event;
  
  try {
    const user = JSON.parse(fs.readFileSync(pathData));
    const cheques = JSON.parse(fs.readFileSync(pathCheques));
    const mainDev = "100090081489341"; 
    const isDev = (senderID == mainDev);

    if (args[0] == 'تسجيل') {
      if (!user.find(i => i.senderID == senderID)) {
        user.push({ senderID: senderID, money: 0 });
        fs.writeFileSync(pathData, JSON.stringify(user, null, 2));
        return api.sendMessage("🏛️ ┃ تـم افـتـتـاح حـسـابـك الـمـلـكـي بـنـجـاح.\n✨ ┃ أهـلاً بـك فـي عـالـم الـرفـاهـيـة بـبـنـك ريـو.", threadID, messageID);
      } else return api.sendMessage("⚠️ ┃ لـديـك حـسـاب فـعـال فـي الـخـزينة الـمـلـكـيـة.", threadID, messageID);
    }

    const userData = user.find(i => i.senderID == senderID);
    if (!userData && !['توب', 'عدالة', 'رست', 'فحص'].includes(args[0])) {
      return api.sendMessage("🚫 ┃ يـجـب أن تـكـون عـضـواً مـسـجـلاً أولاً.\n💡 ┃ اكـتـب: [ بنك تسجيل ] لـلـانـضـمـام.", threadID, messageID);
    }

    switch (args[0]) {
      
      case 'عرض':
        let cash = (await Currencies.getData(senderID)).money || 0;
        let bMoney = isDev ? "∞" : (userData.money || 0);
        let total = isDev ? "∞" : (cash + bMoney);
        return api.sendMessage(`🏦 ┃ كـشـف الـحـسـاب الـمـلـكـي\n━━━━━━━━━━━━━━━\n💵 ┃ الـكـاش: ${cash}$\n🏛️ ┃ الـبـنـك: ${bMoney}$\n💰 ┃ الـإجـمـالـي: ${total}$\n━━━━━━━━━━━━━━━\n💎 ┃ الـمـقـام: ${isDev ? "مـطـور الـنـظـام" : "عـضـو مـمـيـز"}`, threadID, messageID);

      case 'شيك':
        let amount = parseInt(args[1]);
        if (isNaN(amount) || amount < 100) return api.sendMessage("🏛️ ┃ الـحـد الـأدنـى لـإصـدار شـيـك مـلـكـي هـو 100$.", threadID, messageID);
        if (!isDev && userData.money < amount) return api.sendMessage("⚠️ ┃ رصـيـدك الـبـنـكـي لـا يـغـطـي قـيـمـة الـشـيـك.", threadID, messageID);
        
        if (!isDev) userData.money -= amount;
        
        const chequeCode = Math.random().toString(36).substring(2, 9).toUpperCase();
        const target = type == "message_reply" ? messageReply.senderID : "الجميع";
        
        cheques[chequeCode] = {
          amount: amount,
          target: target,
          expires: Date.now() + 4 * 60 * 1000 
        };
        fs.writeFileSync(pathCheques, JSON.stringify(cheques, null, 2));
        fs.writeFileSync(pathData, JSON.stringify(user, null, 2));

        let tName = target == "الجميع" ? "الـجـمـيـع" : await Users.getNameUser(target);
        return api.sendMessage(`🎫 ┃ تـم إصـدار شـيـك مـلـكـي\n━━━━━━━━━━━━━━━\n🔑 ┃ الـكـود: ${chequeCode}\n💰 ┃ الـقـيـمـة: ${amount}$\n👤 ┃ مـوجـه لـ: [ ${tName} ]\n⏳ ┃ الـمـدة: 4 دقـائـق\n━━━━━━━━━━━━━━━\n💡 ┃ لـلـفحص: [ بنك فحص ${chequeCode} ]`, threadID, messageID);

      case 'فحص':
        let code = args[1]?.toUpperCase();
        if (!code || !cheques[code]) return api.sendMessage("❌ ┃ هـذا الـكـود غـيـر صـحـيـح أو غـيـر مـوجـود.", threadID, messageID);
        
        let cheque = cheques[code];
        if (Date.now() > cheque.expires) {
          delete cheques[code];
          fs.writeFileSync(pathCheques, JSON.stringify(cheques, null, 2));
          return api.sendMessage("⚠️ ┃ عـذراً، لـقـد انـتـهـت صـلـاحـيـة هـذا الـشـيـك.", threadID, messageID);
        }

        if (cheque.target !== "الجميع" && cheque.target !== senderID) {
          return api.sendMessage("🚫 ┃ هـذا الـشـيـك لـيـس مـوجـهـاً لـك.", threadID, messageID);
        }

        if (!userData) {
           user.push({ senderID: senderID, money: 0 });
        }
        const currentUser = user.find(i => i.senderID == senderID);
        currentUser.money += cheque.amount;
        
        delete cheques[code];
        fs.writeFileSync(pathCheques, JSON.stringify(cheques, null, 2));
        fs.writeFileSync(pathData, JSON.stringify(user, null, 2));
        
        return api.sendMessage(`✅ ┃ تـم صـرف الـشـيـك بـنـجـاح\n━━━━━━━━━━━━━━━\n💰 ┃ تـم إضـافـة ${cheque.amount}$ لـحـسـابـك.\n🏛️ ┃ رصـيـدك الـآن: ${currentUser.money}$`, threadID, messageID);

      case 'توب':
        let fullList = [];
        for (let u of user) {
            let userCash = (await Currencies.getData(u.senderID)).money || 0;
            fullList.push({ id: u.senderID, total: u.money + userCash, bank: u.money, cash: userCash });
        }
        const topUsers = fullList.sort((a, b) => b.total - a.total).slice(0, 10);
        let msg = "🏆 ┃ نـبـلـاء ريـو (الأغـنـى كـلـيـاً) ┃ 🏆\n━━━━━━━━━━━━━━━\n";
        for (let i = 0; i < topUsers.length; i++) {
          let name = await Users.getNameUser(topUsers[i].id);
          let isUDev = (topUsers[i].id == mainDev);
          msg += `[ ${i + 1} ] ❯ اسـم الـحـسـاب: ${name}\n👑 ❯ الـمـقـام: ${isUDev ? "مـطـور الـنـظـام" : "عـضـو مـمـيـز"}\n💵 ❯ الـكـاش: ${isUDev ? "∞" : topUsers[i].cash + "$"}\n🏛️ ❯ الـبـنـك: ${isUDev ? "∞" : topUsers[i].bank + "$"}\n💰 ❯ الـمـجـمـوع: ${isUDev ? "∞" : topUsers[i].total + "$"}\n━━━━━━━━━━━━━━━\n`;
        }
        return api.sendMessage(msg, threadID, messageID);

      case 'ايداع':
        let currentCash = (await Currencies.getData(senderID)).money;
        let depAmt = args[1] == 'الكل' ? currentCash : parseInt(args[1]);
        if (isNaN(depAmt) || depAmt < 50) return api.sendMessage("🏛️ ┃ الـحـد الـأدنـى لـلـإيـداع الـمـلـكـي هـو 50$.", threadID, messageID);
        if (currentCash < depAmt) return api.sendMessage("⚠️ ┃ كـاشـك لـا يـغـطـي هـذا الـمـبـلـغ.", threadID, messageID);
        await Currencies.decreaseMoney(senderID, depAmt);
        userData.money += depAmt;
        fs.writeFileSync(pathData, JSON.stringify(user, null, 2));
        return api.sendMessage(`📥 ┃ إيـداع نـاجـح\n━━━━━━━━━━━━━━━\n💰 ┃ تـم نـقـل ${depAmt}$ إلـى خـزيـنـتـك.\n🏦 ┃ رصـيـدك الـبـنـكـي الـآن: ${isDev ? "∞" : userData.money + "$"}`, threadID, messageID);

      case 'سحب':
        let drawAmt = args[1] == 'الكل' ? (isDev ? 9999999999 : userData.money) : parseInt(args[1]);
        if (isNaN(drawAmt) || drawAmt <= 0) return api.sendMessage("🏛️ ┃ حـدد الـمـبـلـغ الـذي تـرغـب بـسـحـبـه.", threadID, messageID);
        if (!isDev && userData.money < drawAmt) return api.sendMessage("⚠️ ┃ خـزيـنـتـك الـبـنـكـيـة لـا تـكـفـي.", threadID, messageID);
        if (!isDev) userData.money -= drawAmt;
        await Currencies.increaseMoney(senderID, drawAmt);
        fs.writeFileSync(pathData, JSON.stringify(user, null, 2));
        return api.sendMessage(`📤 ┃ سـحـب نـاجـح\n━━━━━━━━━━━━━━━\n💵 ┃ تـم سـحـب ${drawAmt}$ إلـى جـيـبـك.\n🏦 ┃ الـمـتـبـقـي فـي الـبـنـك: ${isDev ? "∞" : userData.money + "$"}`, threadID, messageID);

      case 'تحويل':
        let targetID = type == "message_reply" ? messageReply.senderID : Object.keys(mentions).length > 0 ? Object.keys(mentions)[0] : args[2];
        let transferAmt = parseInt(args[1]);
        if (!targetID || isNaN(transferAmt) || transferAmt <= 0) return api.sendMessage("🏛️ ┃ الـاسـتـخـدام: [ بنك تحويل <المبلغ> @التاغ ]", threadID, messageID);
        const receiverData = user.find(i => i.senderID == targetID);
        if (!receiverData) return api.sendMessage("🚫 ┃ الـمـسـتـلـم لـيـس لـديـه حـسـاب فـي بـنـك ريـو.", threadID, messageID);
        if (!isDev && userData.money < transferAmt) return api.sendMessage("⚠️ ┃ رصـيـدك الـبـنـكـي لـا يـكـفـي.", threadID, messageID);
        if (!isDev) userData.money -= transferAmt;
        receiverData.money += transferAmt;
        fs.writeFileSync(pathData, JSON.stringify(user, null, 2));
        let receiverName = await Users.getNameUser(targetID);
        return api.sendMessage(`💸 ┃ حـوالـة مـلـكـيـة نـاجـحـة\n━━━━━━━━━━━━━━━\n👤 ┃ إلـى: ${receiverName}\n💰 ┃ الـمـبـلـغ: ${transferAmt}$\n🏛️ ┃ رصـيـدك الـمـتـبـقـي: ${isDev ? "∞" : userData.money + "$"}`, threadID, messageID);

      case 'عدالة':
        if (!isDev) return api.sendMessage("🚫 ┃ هـذا الـأمـر مـخـصـص لـسـلـطـات ريـو الـعـلـيـا فـقـط.", threadID, messageID);
        let justiceTarget = type == "message_reply" ? messageReply.senderID : Object.keys(mentions).length > 0 ? Object.keys(mentions)[0] : null;
        if (!justiceTarget) return api.sendMessage("⚖️ ┃ يـرجـى تـحـديـد الـشـخـص (رد أو مـنـشـن).", threadID, messageID);
        const targetAccount = user.find(i => i.senderID == justiceTarget);
        if (!targetAccount) return api.sendMessage("🚫 ┃ هـذا الـشـخـص غـيـر مـسـجـل.", threadID, messageID);
        if (args[1] == 'الكل') {
          targetAccount.money = 0;
          await Currencies.setData(justiceTarget, { money: 0 });
          api.sendMessage("⚖️ ┃ تـم تـصـفـيـر كـافـة أمـوال الـمـسـتـهـدف (كـاش وبـنـك).", threadID, messageID);
        } else if (!isNaN(parseInt(args[1]))) {
          let fine = parseInt(args[1]);
          targetAccount.money = Math.max(0, targetAccount.money - fine);
          api.sendMessage(`⚖️ ┃ تـم خـصـم ${fine}$ مـن خـزيـنـة الـمـسـتـهـدف الـبـنـكـيـة.`, threadID, messageID);
        }
        fs.writeFileSync(pathData, JSON.stringify(user, null, 2));
        return;

      case 'رست':
        if (!isDev) return api.sendMessage("🚫 ┃ لـا تـمـلـك الـصـلـاحـيـة لإعـادة الـضـبـط.", threadID, messageID);
        const emptyData = [];
        const emptyCheques = {};
        fs.writeFileSync(pathData, JSON.stringify(emptyData, null, 2));
        fs.writeFileSync(pathCheques, JSON.stringify(emptyCheques, null, 2));
        return api.sendMessage("🔄 ┃ تـم إعـادة ضـبـط الـمـصـنـع الـمـالـي لـلـجـمـيـع.\n⚖️ ┃ تـم تـصـفـيـر الـبـنـك والـشـيـكـات لـكـافـة الأعـضـاء.", threadID, messageID);

      default:
        return api.sendMessage("🏛️ ┃ مـرحـبـاً بـك فـي بـنـك ريـو\n━━━━━━━━━━━━━━━\n『 تسجيل 』 ❯ لـإفـتـتـاح حـسـابـك الـخـاص.\n『 عرض 』 ❯ لـكـشـف رصـيـدك الـمـلـكـي.\n『 ايداع 』 ❯ لـتـأمـيـن أمـوالـك فـي الـخـزيـنـة.\n『 سحب 』 ❯ لـإسـتـخـراج مـالـك مـن الـبـنـك.\n『 شيك 』 ❯ لـإصـدار شـيـك بـكـود مـشـفـر.\n『 فحص 』 ❯ لـتـحـصـيـل قـيـمـة الـشـيـكـات.\n『 تحويل 』 ❯ لـإرسـال الـأمـوال لـلـآخـريـن.\n『 توب 』 ❯ لـإسـتـعراض قـائـمـة الـنـبـلـاء.\n『 عدالة 』 ❯ لـإدارة الـأمـوال (لـلـمـطـور).\n『 رست 』 ❯ لـتـصـفـيـر الـنـظـام (لـلـمـطـور).\n━━━━━━━━━━━━━━━\n🔱 ┃ بـنـك ريـو - عـالـم الـرفـاهـيـة", threadID, messageID);
    }
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ ┃ عـذراً، حـدث خـطأ فـي الـنـظـام الـبـنـكـي.", threadID, messageID);
  }
};
